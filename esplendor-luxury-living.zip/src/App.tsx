import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PageRoute, LuxuryProject } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { OurStoryPage } from './pages/OurStoryPage';
import { LuxuryHomesPage } from './pages/LuxuryHomesPage';
import { TheLivingDifferencePage } from './pages/TheLivingDifferencePage';
import { ContactPage } from './pages/ContactPage';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { ConsultationModal } from './components/ConsultationModal';
import { GeminiChatDrawer } from './components/GeminiChatDrawer';
import { ClientPortfolioModal } from './components/ClientPortfolioModal';
import { AmbientSoundscapeController } from './components/AmbientSoundscapeController';
import { ScrollProgressBar } from './components/ScrollProgressBar';
import { GoldSparkleCursor } from './components/GoldSparkleCursor';
import { ScrollToTopButton } from './components/ScrollToTopButton';
import { LuxurySkeletonScreen } from './components/LuxurySkeletonScreen';
import { AuthProvider } from './lib/AuthContext';
import { LanguageProvider } from './lib/LanguageContext';
import { Sparkles } from 'lucide-react';

export function AppContent() {
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState<PageRoute>('home');
  const [selectedProject, setSelectedProject] = useState<LuxuryProject | null>(null);
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [consultationSubject, setConsultationSubject] = useState('Private Viewing & Consultation');

  // Initial load simulation to ensure assets and custom typography are ready
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 650);
    return () => clearTimeout(timer);
  }, []);

  // AI & Auth Modals state
  const [isGeminiChatOpen, setIsGeminiChatOpen] = useState(false);
  const [geminiProjectContext, setGeminiProjectContext] = useState<string | undefined>(undefined);
  const [isPortfolioOpen, setIsPortfolioOpen] = useState(false);

  // Handle URL hash changes for direct linking & back/forward support
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#/', '').replace('#', '');
      if (['home', 'our-story', 'luxury-homes', 'the-living-difference', 'contact'].includes(hash)) {
        setCurrentPage(hash as PageRoute);
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigate = (page: PageRoute) => {
    setCurrentPage(page);
    window.location.hash = `#/${page}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenConsultation = (subject?: string) => {
    if (subject) setConsultationSubject(subject);
    else setConsultationSubject('Private Viewing & Consultation');
    setIsConsultationOpen(true);
  };

  const handleProjectSelect = (project: LuxuryProject) => {
    setSelectedProject(project);
  };

  const handleOpenGeminiChat = (projectName?: string) => {
    setGeminiProjectContext(projectName);
    setIsGeminiChatOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#2b2b2b] flex flex-col selection:bg-[#c9974f] selection:text-black">
      {/* Custom Luxury Gold Sparkle Cursor Trail */}
      <GoldSparkleCursor />

      {/* Top Scroll Depth Progress Indicator */}
      <ScrollProgressBar />

      {/* Top Fixed Luxury Navigation Bar */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onOpenConsultation={() => handleOpenConsultation()}
        onOpenGeminiChat={() => handleOpenGeminiChat()}
        onOpenClientPortfolio={() => setIsPortfolioOpen(true)}
      />

      {/* Main Multi-Page Container with Smooth Luxury Page Transitions */}
      <main className="flex-1 w-full overflow-hidden">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <LuxurySkeletonScreen key="luxury-skeleton" pageType={currentPage} />
          ) : (
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{
                duration: 0.4,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="w-full"
            >
              {currentPage === 'home' && (
                <HomePage
                  onNavigate={handleNavigate}
                  onOpenConsultation={() => handleOpenConsultation('General Advisory & Viewing')}
                  onSelectProject={handleProjectSelect}
                />
              )}

              {currentPage === 'our-story' && (
                <OurStoryPage
                  onNavigate={handleNavigate}
                  onOpenConsultation={() => handleOpenConsultation('Founders Advisory Inquiry')}
                />
              )}

              {currentPage === 'luxury-homes' && (
                <LuxuryHomesPage
                  onNavigate={handleNavigate}
                  onOpenConsultation={() => handleOpenConsultation('Luxury Homes Portfolio Inquiry')}
                  onSelectProject={handleProjectSelect}
                />
              )}

              {currentPage === 'the-living-difference' && (
                <TheLivingDifferencePage
                  onNavigate={handleNavigate}
                  onOpenConsultation={() => handleOpenConsultation('The Living Difference Concierge')}
                />
              )}

              {currentPage === 'contact' && (
                <ContactPage onNavigate={handleNavigate} />
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Shared Footer across all pages */}
      <Footer
        onNavigate={handleNavigate}
        onOpenConsultation={() => handleOpenConsultation('Footer Advisory Inquiry')}
      />

      {/* Floating Action Quick Access Badges (Ambient Luxury Audio & Gemini AI Concierge) */}
      <div className="fixed bottom-6 left-6 z-40 flex items-center gap-2.5">
        {/* Subtle Ambient Luxury Soundscape Controller */}
        <AmbientSoundscapeController />

        {/* AI Concierge Trigger */}
        <button
          onClick={() => handleOpenGeminiChat()}
          className="hidden sm:flex px-3.5 py-2 rounded-full bg-gradient-to-r from-[#1a150e]/95 to-[#241c10]/95 hover:from-[#2a2216] hover:to-[#382b18] border border-[#c9974f]/60 text-[#f5d79e] text-xs font-semibold uppercase tracking-wider backdrop-blur-md transition-all shadow-[0_4px_20px_rgba(201,151,79,0.25)] items-center gap-2 cursor-pointer hover:scale-105"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#c9974f] animate-pulse" />
          <span>AI Concierge</span>
        </button>
      </div>

      {/* Floating Luxury Scroll To Top Button with Circular Gold Progress Indicator */}
      <ScrollToTopButton threshold={320} />

      {/* Interactive Project Details Modal */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onInquire={(projectName) => {
          handleOpenConsultation(`Inquiry for ${projectName}`);
        }}
        onOpenGeminiChat={(projectName) => {
          handleOpenGeminiChat(projectName);
        }}
      />

      {/* Interactive Consultation / Contact Booking Modal */}
      <ConsultationModal
        isOpen={isConsultationOpen}
        onClose={() => setIsConsultationOpen(false)}
        initialSubject={consultationSubject}
      />

      {/* Gemini AI Multi-Turn Chatbot Drawer */}
      <GeminiChatDrawer
        isOpen={isGeminiChatOpen}
        onClose={() => setIsGeminiChatOpen(false)}
        onOpenConsultation={(subj) => handleOpenConsultation(subj)}
        selectedProjectName={geminiProjectContext}
      />

      {/* Firebase Client Portfolio & Auth Lounge */}
      <ClientPortfolioModal
        isOpen={isPortfolioOpen}
        onClose={() => setIsPortfolioOpen(false)}
        onSelectProject={(projectId) => {
          // If project exists, find and open modal
        }}
      />
    </div>
  );
}

export function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;

import React, { useState } from 'react';
import { PageRoute, FeatureCardItem } from '../types';
import { SectionEyebrow } from '../components/SectionEyebrow';
import { GoldButton } from '../components/GoldButton';
import { TiltCard } from '../components/TiltCard';
import { ParticleCanvas } from '../components/ParticleCanvas';
import { GoldFlourishDivider } from '../components/GoldFlourishDivider';
import { LuxuryInsights } from '../components/LuxuryInsights';
import { LIVING_DIFFERENCE_CARDS } from '../data/siteData';
import { IconResolver } from '../components/Icons';
import { X, CheckCircle, ArrowUpRight } from 'lucide-react';
import { useLanguage } from '../lib/LanguageContext';

interface TheLivingDifferencePageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenConsultation: () => void;
}

export const TheLivingDifferencePage: React.FC<TheLivingDifferencePageProps> = ({
  onNavigate,
  onOpenConsultation
}) => {
  const { t } = useLanguage();
  const [selectedFeature, setSelectedFeature] = useState<FeatureCardItem | null>(null);

  return (
    <div className="bg-[#0a0a0a] text-white min-h-screen">
      {/* ========================================================
          1. HERO SECTION (Warm Luxury Living Room & Infinity Pool)
      ======================================================== */}
      <section className="relative min-h-[60vh] sm:min-h-[70vh] flex items-center justify-center text-center overflow-hidden pt-20">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1800&q=85"
            alt="Warm Luxury Living Room with Infinity Pool Visible Through Glass"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/75 to-black/60" />
        </div>

        <ParticleCanvas count={30} />

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <SectionEyebrow label={t('difference.eyebrow', 'UNRIVALED STANDARD')} theme="gold" className="justify-center mb-4" />

          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light text-white leading-tight tracking-tight mb-6">
            {t('difference.title1', 'What makes')} <br />
            <span className="italic text-[#c9974f] font-normal">{t('difference.title2', 'ESPLENDOR different?')}</span>
          </h1>

          <p className="text-base sm:text-lg text-[#d5d5d5] font-sans font-light leading-relaxed max-w-2xl mx-auto">
            {t('difference.desc', 'Every detail is designed to give you a life of comfort, convenience and lasting value.')}
          </p>
        </div>
      </section>

      {/* ========================================================
          2. THE 8-CARD GRID (Cream #f5f0e7 Background)
      ======================================================== */}
      <section className="bg-[#f5f0e7] text-[#2b2b2b] py-24 sm:py-32 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <SectionEyebrow label="EIGHT LIVING PILLARS" theme="dark" className="justify-center" />
            <h2 className="font-serif text-3xl sm:text-4xl text-[#1a1a1a] font-normal">
              Curated for <span className="italic text-[#9a6e2e]">Effortless Luxury</span>
            </h2>
            <p className="text-sm text-[#666] font-sans">
              Click any pillar to explore our bespoke services, amenities, and asset management guarantees.
            </p>
          </div>

          {/* 4 cols x 2 rows responsive grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {LIVING_DIFFERENCE_CARDS.map((card) => (
              <TiltCard
                key={card.id}
                onClick={() => setSelectedFeature(card)}
                className="bg-[#efe8db] border border-[#d8cfbe] rounded-sm overflow-hidden flex flex-col group shadow-md hover:shadow-xl transition-all duration-300"
              >
                {/* Image */}
                <div className="relative h-48 w-full overflow-hidden bg-black">
                  <img
                    src={card.image}
                    alt={card.imageAlt}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                  {/* Number Badge */}
                  <div className="absolute top-3 left-3 w-7 h-7 rounded-full bg-[#0a0a0a]/80 border border-[#c9974f] text-[#c9974f] text-[10px] font-bold flex items-center justify-center">
                    0{card.number}
                  </div>

                  {/* Icon on Image */}
                  <div className="absolute bottom-3 right-3 w-9 h-9 rounded-full bg-[#c9974f] text-black flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                    <IconResolver name={card.iconName} className="w-4 h-4" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="font-serif text-xl font-bold text-[#1a1a1a] group-hover:text-[#9a6e2e] transition-colors mb-2">
                      {card.title}
                    </h3>
                    <div className="w-10 h-[1.5px] bg-[#9a6e2e] mb-3 group-hover:w-16 transition-all duration-300" />
                    <p className="text-xs sm:text-sm text-[#555] leading-relaxed font-sans font-light">
                      {card.description}
                    </p>
                  </div>

                  <div className="pt-2 flex items-center justify-between border-t border-[#ded5c4]">
                    <span className="text-[9px] tracking-widest font-semibold uppercase text-[#9a6e2e]">
                      {card.badge}
                    </span>
                    <span className="text-xs font-bold text-[#1a1a1a] group-hover:translate-x-1 transition-transform">
                      →
                    </span>
                  </div>
                </div>
              </TiltCard>
            ))}
          </div>

          {/* Decorative Gold Flourish */}
          <div className="pt-16">
            <GoldFlourishDivider variant="ornate" theme="light" />
          </div>
        </div>
      </section>

      {/* ========================================================
          3. LUXURY INSIGHTS & BESPOKE CLIENT FAQ
      ======================================================== */}
      <LuxuryInsights
        theme="dark"
        onOpenConsultation={onOpenConsultation}
      />

      {/* ========================================================
          4. FEATURE DETAIL MODAL
      ======================================================== */}
      {selectedFeature && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div
            className="relative w-full max-w-2xl bg-[#0e0e0e] border border-[#c9974f]/40 rounded-sm shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedFeature(null)}
              className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-black/60 border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="relative h-60 w-full overflow-hidden">
              <img
                src={selectedFeature.image}
                alt={selectedFeature.imageAlt}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0e0e0e] via-[#0e0e0e]/40 to-transparent" />
              <div className="absolute bottom-4 left-6 right-6">
                <span className="text-[10px] tracking-widest text-[#c9974f] uppercase font-semibold block mb-1">
                  PILLAR 0{selectedFeature.number} · {selectedFeature.badge}
                </span>
                <h3 className="font-serif text-3xl text-white font-bold">
                  {selectedFeature.title}
                </h3>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-4">
              <p className="text-sm sm:text-base text-[#d0d0d0] leading-relaxed font-sans">
                {selectedFeature.longDescription}
              </p>

              <div className="pt-4 flex items-center justify-between border-t border-[#252019]">
                <span className="text-xs text-[#888]">
                  Included in all Esplendor Goa residences.
                </span>
                <GoldButton
                  label="INQUIRE WITH ADVISOR"
                  onClick={() => {
                    setSelectedFeature(null);
                    onOpenConsultation();
                  }}
                  variant="solid-gold"
                  size="sm"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          4. CTA BANNER (Dark #0a0a0a Background)
      ======================================================== */}
      <section className="bg-[#0a0a0a] py-24 border-t border-[#221c15] text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
          <SectionEyebrow label="ELEVATE YOUR STANDARD" theme="gold" className="justify-center" />

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-white font-normal leading-tight">
            Experience a lifestyle <br />
            <span className="italic text-[#c9974f]">that goes beyond the ordinary.</span>
          </h2>

          <p className="text-sm sm:text-base text-[#a0a0a0] max-w-xl mx-auto font-sans leading-relaxed">
            Take the first step toward possessing a home that combines architectural brilliance with world-class hospitality.
          </p>

          <div className="pt-4 flex justify-center gap-4">
            <GoldButton
              label="EXPLORE OUR HOMES"
              onClick={() => onNavigate('luxury-homes')}
              variant="solid-gold"
              size="lg"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { PageRoute, LuxuryProject } from '../types';
import { SectionEyebrow } from '../components/SectionEyebrow';
import { GoldButton } from '../components/GoldButton';
import { TiltCard } from '../components/TiltCard';
import { ParticleCanvas } from '../components/ParticleCanvas';
import { PROJECTS_COLLECTION, LUXURY_HOMES_FEATURES } from '../data/siteData';
import { IconResolver } from '../components/Icons';
import { MapPin, ArrowUpRight, Bed, Bath, Maximize2, Check, Filter } from 'lucide-react';
import { useLanguage } from '../lib/LanguageContext';

interface LuxuryHomesPageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenConsultation: () => void;
  onSelectProject: (project: LuxuryProject) => void;
}

type FilterCategory = 'all' | 'completed' | 'ongoing' | 'upcoming' | 'luxury-apartments' | 'villas';

export const LuxuryHomesPage: React.FC<LuxuryHomesPageProps> = ({
  onNavigate,
  onOpenConsultation,
  onSelectProject
}) => {
  const { t } = useLanguage();
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('all');
  const [projects, setProjects] = useState<LuxuryProject[]>(PROJECTS_COLLECTION);
  const [isLoading, setIsLoading] = useState(false);

  // Filter tabs definition with specific icons
  const filterTabs: { id: FilterCategory; label: string; icon: string }[] = [
    { id: 'all', label: 'All Projects', icon: 'grid-blocks' },
    { id: 'completed', label: 'Completed Projects', icon: 'shield' },
    { id: 'ongoing', label: 'Ongoing Projects', icon: 'crane' },
    { id: 'upcoming', label: 'Upcoming Homes', icon: 'sprout' },
    { id: 'luxury-apartments', label: 'Luxury Apartments', icon: 'pillars' },
    { id: 'villas', label: 'Private Villas', icon: 'house' },
  ];

  useEffect(() => {
    // Optionally fetch dynamic project list from backend /api/projects
    const fetchProjects = async () => {
      try {
        setIsLoading(true);
        const query = activeFilter !== 'all' ? `?status=${activeFilter}` : '';
        const res = await fetch(`/api/projects${query}`);
        if (res.ok) {
          const json = await res.json();
          if (json.data && json.data.length > 0) {
            // Merge with local enriched details
            const matched = json.data.map((item: any) => {
              const local = PROJECTS_COLLECTION.find((p) => p.id === item.id);
              return {
                ...item,
                statusLabel: item.status === 'completed' ? 'Completed Project' : item.status === 'ongoing' ? 'Ongoing Project' : 'Upcoming Home',
                highlights: item.highlights || local?.highlights || [],
              };
            });
            setProjects(matched);
            return;
          }
        }
      } catch (err) {
        console.warn('Backend fetch failed, fallback to local data', err);
      } finally {
        setIsLoading(false);
      }

      // Local fallback filter
      if (activeFilter === 'all') {
        setProjects(PROJECTS_COLLECTION);
      } else if (activeFilter === 'completed' || activeFilter === 'ongoing' || activeFilter === 'upcoming') {
        setProjects(PROJECTS_COLLECTION.filter((p) => p.status === activeFilter));
      } else {
        setProjects(PROJECTS_COLLECTION.filter((p) => p.category === activeFilter));
      }
    };

    fetchProjects();
  }, [activeFilter]);

  return (
    <div className="bg-[#0a0a0a] text-white min-h-screen">
      {/* ========================================================
          1. HERO SECTION (Night Luxury Residence & Palm Trees)
      ======================================================== */}
      <section className="relative min-h-[60vh] sm:min-h-[70vh] flex items-center overflow-hidden pt-20">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1800&q=85"
            alt="Night Exterior of Modern Luxury Residence Framed by Palms"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/80 to-black/60" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />
        </div>

        <ParticleCanvas count={30} />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="max-w-2xl space-y-4">
            <SectionEyebrow label={t('homes.eyebrow', 'LUXURY HOMES')} theme="gold" />

            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light text-white leading-[1.1] tracking-tight">
              {t('homes.title1', 'Crafted for life.')} <br />
              <span className="italic text-[#c9974f] font-normal">
                {t('homes.title2', 'Designed for you.')}
              </span>
            </h1>

            <p className="text-base sm:text-lg text-[#d0d0d0] font-sans font-light leading-relaxed max-w-xl">
              {t('homes.desc', 'At ESPLENDOR, we create residences that blend timeless architecture with the natural beauty of Goa to deliver an unmatched living experience.')}
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================
          2. FILTER TABS (Cream Bar Overlapping Container)
      ======================================================== */}
      <section className="bg-[#f5f0e7] text-[#2b2b2b] py-8 border-b border-[#ded5c4] sticky top-[60px] z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-start sm:justify-center gap-2 sm:gap-4 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
            {filterTabs.map((tab) => {
              const isActive = activeFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`flex flex-col items-center justify-center px-4 sm:px-6 py-2.5 rounded-sm transition-all duration-300 shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-[#0a0a0a] text-white shadow-lg'
                      : 'bg-transparent text-[#444] hover:bg-[#e8dfcf] hover:text-black'
                  }`}
                >
                  <div className={`mb-1 ${isActive ? 'text-[#c9974f]' : 'text-[#888]'}`}>
                    <IconResolver name={tab.icon} className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] sm:text-xs font-semibold tracking-[0.14em] uppercase whitespace-nowrap">
                    {tab.label}
                  </span>
                  {isActive && (
                    <span className="w-6 h-[2px] bg-[#c9974f] mt-1 rounded-full" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ========================================================
          3. SUBHEADING & INTRO SECTION (Cream Background)
      ======================================================== */}
      <section className="bg-[#f5f0e7] text-[#2b2b2b] pt-16 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#dfd5c3] pb-10">
            <div className="max-w-2xl space-y-3">
              <SectionEyebrow label="RESIDENTIAL PORTFOLIO" theme="dark" />
              <h2 className="font-serif text-3xl sm:text-4xl text-[#1a1a1a] font-normal leading-tight">
                Spaces that inspire. <br className="hidden sm:inline" />
                <span className="italic text-[#9a6e2e]">Homes that last.</span>
              </h2>
              <p className="text-sm sm:text-base text-[#555] font-sans font-light leading-relaxed">
                Every residence is a reflection of our promise — superior craftsmanship, thoughtful design and a commitment to creating spaces that stand the test of time.
              </p>
            </div>

            <div className="shrink-0">
              <GoldButton
                label="SCHEDULE A PRIVATE TOUR"
                onClick={onOpenConsultation}
                variant="solid-dark"
                size="md"
              />
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          4. PROJECT GRID SECTION (Cream Background)
      ======================================================== */}
      <section className="bg-[#f5f0e7] text-[#2b2b2b] pb-24 sm:pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <TiltCard
                key={project.id}
                onClick={() => onSelectProject(project)}
                className="bg-[#efe8db] border border-[#d8cfbe] rounded-sm overflow-hidden flex flex-col group shadow-md hover:shadow-2xl"
              >
                {/* Image Container */}
                <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-black">
                  <img
                    src={project.image}
                    alt={project.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                  {/* Status Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-[#0a0a0a]/90 border border-[#c9974f] text-[#c9974f] text-[9px] font-bold tracking-widest uppercase rounded-full">
                      {project.statusLabel}
                    </span>
                  </div>

                  {/* Price Tag */}
                  <div className="absolute top-4 right-4 bg-[#c9974f] text-black px-3 py-1 rounded-full text-[10px] font-bold tracking-wider">
                    {project.price}
                  </div>

                  {/* Bottom Image Info */}
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <div className="flex items-center gap-1.5 text-xs text-[#e0b877] font-sans mb-0.5">
                      <MapPin className="w-3.5 h-3.5 text-[#c9974f]" />
                      <span>{project.location}</span>
                    </div>
                    <h3 className="font-serif text-2xl font-bold tracking-wide">
                      {project.name}
                    </h3>
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <p className="text-xs sm:text-sm text-[#555] leading-relaxed line-clamp-2">
                    {project.description}
                  </p>

                  {/* Specs Pill */}
                  <div className="grid grid-cols-3 gap-2 py-2.5 px-3 bg-[#e5dcce] border border-[#d2c7b5] rounded text-center text-xs">
                    <div className="flex items-center justify-center gap-1 text-[#2b2b2b] font-medium">
                      <Bed className="w-3.5 h-3.5 text-[#9a6e2e]" />
                      <span>{project.bedrooms} Beds</span>
                    </div>
                    <div className="flex items-center justify-center gap-1 text-[#2b2b2b] font-medium border-x border-[#c8bdab]">
                      <Bath className="w-3.5 h-3.5 text-[#9a6e2e]" />
                      <span>{project.bathrooms} Baths</span>
                    </div>
                    <div className="flex items-center justify-center gap-1 text-[#2b2b2b] font-medium">
                      <Maximize2 className="w-3.5 h-3.5 text-[#9a6e2e]" />
                      <span>{project.area}</span>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between border-t border-[#ded5c4]">
                    <span className="text-[10px] tracking-widest text-[#888] uppercase">
                      Private Estate
                    </span>
                    <button
                      type="button"
                      className="inline-flex items-center gap-1 text-xs font-semibold tracking-wider text-[#9a6e2e] group-hover:text-black uppercase transition-colors"
                    >
                      <span>VIEW DETAILS</span>
                      <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </button>
                  </div>
                </div>
              </TiltCard>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================
          5. FEATURE STRIP (Dark #0a0a0a Background, 5 Columns)
      ======================================================== */}
      <section className="bg-[#0a0a0a] py-20 border-y border-[#221c15]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {LUXURY_HOMES_FEATURES.map((feat) => (
              <div
                key={feat.id}
                className="p-6 bg-[#111111] border border-[#221c15] rounded-sm text-center group hover:border-[#c9974f]/50 hover:bg-[#161616] transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-full border border-[#c9974f]/30 flex items-center justify-center text-[#c9974f] mx-auto mb-4 group-hover:border-[#c9974f] group-hover:scale-110 transition-all">
                  <IconResolver name={feat.iconName} className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold tracking-[0.14em] uppercase text-white mb-2 font-sans">
                  {feat.title}
                </h4>
                <p className="text-xs text-[#8e8e8e] leading-relaxed font-sans">
                  {feat.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================
          6. CTA BANNER (Dark Background)
      ======================================================== */}
      <section className="bg-[#111111] py-24 border-b border-[#221c15] text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
          <SectionEyebrow label="BESPOKE RESIDENCES" theme="gold" className="justify-center" />

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-white font-normal leading-tight">
            Let's build a home that becomes <br />
            <span className="italic text-[#c9974f]">your legacy.</span>
          </h2>

          <p className="text-sm sm:text-base text-[#a0a0a0] max-w-xl mx-auto font-sans leading-relaxed">
            Connect with our lead architects to discuss custom layouts, off-market opportunities, or private site visits.
          </p>

          <div className="pt-4 flex justify-center">
            <GoldButton
              label="SCHEDULE A CONSULTATION"
              onClick={onOpenConsultation}
              variant="solid-gold"
              size="lg"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

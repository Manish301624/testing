import React from 'react';
import { PageRoute } from '../types';
import { SectionEyebrow } from '../components/SectionEyebrow';
import { GoldButton } from '../components/GoldButton';
import { StatCounter } from '../components/StatCounter';
import { STATS_DATA, COMMITMENTS_DATA } from '../data/siteData';
import { EsplendorLogoIcon, VisionEyeIcon, MissionTargetIcon, IconResolver } from '../components/Icons';
import { ParticleCanvas } from '../components/ParticleCanvas';
import { GoldFlourishDivider } from '../components/GoldFlourishDivider';
import { useLanguage } from '../lib/LanguageContext';

interface OurStoryPageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenConsultation: () => void;
}

export const OurStoryPage: React.FC<OurStoryPageProps> = ({
  onNavigate,
  onOpenConsultation
}) => {
  const { t } = useLanguage();
  return (
    <div className="bg-[#0a0a0a] text-white min-h-screen">
      {/* ========================================================
          1. HERO SECTION (Goa Sunset Beach)
      ======================================================== */}
      <section className="relative h-[65vh] min-h-[460px] flex items-center overflow-hidden">
        {/* Background Image with Parallax Vibe */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1800&q=85"
            alt="Tranquil Goa Sunset with Silhouette of Palm Trees"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center transform scale-105"
          />
          {/* Deep dark gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/75 to-black/50" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />
        </div>

        <ParticleCanvas count={25} />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="max-w-2xl space-y-4">
            <SectionEyebrow label={t('story.eyebrow', 'HERITAGE & VISION')} theme="gold" />
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-light text-white tracking-tight leading-tight">
              {t('story.title1', 'The Art of')} <span className="italic text-[#c9974f]">{t('story.title2', 'Timeless Habitation')}</span>
            </h1>
            <p className="text-base sm:text-lg text-[#d0d0d0] font-sans font-light leading-relaxed max-w-xl">
              {t('story.desc', 'Rooted in the timeless beauty of Goa. Inspired by a vision to create homes that elevate the way life is lived.')}
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================
          2. ABOUT THE COMPANY (Cream #f5f0e7 2-Column Section)
      ======================================================== */}
      <section className="bg-[#f5f0e7] text-[#2b2b2b] py-24 sm:py-32 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Left Narrative */}
            <div className="lg:col-span-7 space-y-6">
              <SectionEyebrow label="ABOUT THE COMPANY" theme="dark" />

              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#1a1a1a] font-normal leading-tight">
                About <span className="text-[#9a6e2e] font-serif italic">ESPLENDOR</span>
              </h2>

              <div className="space-y-4 text-sm sm:text-base text-[#4a4a4a] leading-relaxed font-sans font-light">
                <p>
                  Founded on a conviction that modern luxury should be deeply connected to its environment, ESPLENDOR represents over a decade of dedication to residential mastery in Goa.
                </p>
                <p>
                  We bring together award-winning architects, landscape artisans, and precision engineers to design homes that honor Goan heritage while incorporating international standards of sustainability and acoustic comfort.
                </p>
                <p>
                  Every residence is a limited edition masterpiece — built with native laterite stone, reclaimed teak, bespoke brass accents, and intuitive smart home automations that make everyday living effortless.
                </p>
              </div>

              <div className="pt-4 flex items-center gap-6">
                <GoldButton
                  label="EXPLORE OUR HOMES"
                  onClick={() => onNavigate('luxury-homes')}
                  variant="solid-dark"
                  size="md"
                />
                <GoldButton
                  label="CONTACT ADVISORY"
                  onClick={onOpenConsultation}
                  variant="text-link"
                  className="text-[#9a6e2e] hover:text-[#2b2b2b]"
                />
              </div>
            </div>

            {/* Right Brand Interior Image */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-sm overflow-hidden border border-[#d8cfbe] shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=900&q=80"
                  alt="Esplendor Architecture Studio & Concierge Lounge"
                  referrerPolicy="no-referrer"
                  className="w-full h-[420px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6 text-white">
                  <div className="flex items-center gap-2 mb-1">
                    <EsplendorLogoIcon className="w-4 h-6 text-[#c9974f]" />
                    <span className="text-[10px] tracking-[0.2em] font-semibold text-[#e0b877] uppercase">
                      STUDIO ESPLENDOR · NORTH GOA
                    </span>
                  </div>
                  <p className="text-xs text-[#e0e0e0] font-sans">
                    Where architectural vision meets artisanal craftsmanship.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Gold Flourish Divider inside Cream Section */}
          <div className="pt-16">
            <GoldFlourishDivider variant="emblem" theme="light" />
          </div>
        </div>
      </section>

      {/* ========================================================
          3. STATS ROW (Dark #0a0a0a Background, 6 Columns)
      ======================================================== */}
      <section className="bg-[#0a0a0a] py-20 border-y border-[#221c15]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
            {STATS_DATA.map((stat, idx) => (
              <StatCounter
                key={idx}
                value={stat.value}
                suffix={stat.suffix}
                prefix={stat.prefix}
                textValue={stat.textValue}
                label={stat.label}
                iconName={stat.iconName}
              />
            ))}
          </div>

          {/* Subtle separator below stats */}
          <div className="pt-12">
            <GoldFlourishDivider variant="crest" theme="gold" />
          </div>
        </div>
      </section>

      {/* ========================================================
          4. VISION & MISSION (Cream Alt #efe8db Background)
      ======================================================== */}
      <section className="bg-[#efe8db] text-[#2b2b2b] py-24 sm:py-32 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <SectionEyebrow label="GUIDING PRINCIPLES" theme="dark" className="justify-center" />
            <h2 className="font-serif text-3xl sm:text-4xl text-[#1a1a1a] font-normal">
              Purpose in <span className="italic text-[#9a6e2e]">Every Foundation</span>
            </h2>
          </div>

          <div className="relative grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-stretch">
            {/* Vision Card */}
            <div className="bg-[#f5f0e7] border border-[#d8cfbe] p-8 sm:p-12 rounded-sm space-y-5 shadow-lg flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-14 h-14 rounded-full bg-[#111] text-[#c9974f] flex items-center justify-center border border-[#c9974f]/40">
                  <VisionEyeIcon className="w-6 h-6" />
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1a1a1a] tracking-wide">
                  OUR VISION
                </h3>

                <p className="text-sm sm:text-base text-[#4a4a4a] leading-relaxed font-sans font-light">
                  To redefine luxury living in India by creating timeless homes where architecture, nature, and thoughtful design come together to enrich everyday life and nurture generations to come.
                </p>
              </div>

              <div className="pt-4 border-t border-[#dfd5c3] text-xs font-semibold tracking-widest text-[#9a6e2e] uppercase">
                01 · THE HORIZON AHEAD
              </div>
            </div>

            {/* Central Brand Badge */}
            <div className="hidden lg:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-[#0a0a0a] border-2 border-[#c9974f] items-center justify-center shadow-2xl z-20">
              <EsplendorLogoIcon className="w-6 h-8 text-[#c9974f]" />
            </div>

            {/* Mission Card */}
            <div className="bg-[#f5f0e7] border border-[#d8cfbe] p-8 sm:p-12 rounded-sm space-y-5 shadow-lg flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-14 h-14 rounded-full bg-[#111] text-[#c9974f] flex items-center justify-center border border-[#c9974f]/40">
                  <MissionTargetIcon className="w-6 h-6" />
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1a1a1a] tracking-wide">
                  OUR MISSION
                </h3>

                <p className="text-sm sm:text-base text-[#4a4a4a] leading-relaxed font-sans font-light">
                  To develop exceptional residences through uncompromising quality, sustainable ecological practices, and meaningful design, creating lasting financial and emotional value for homeowners.
                </p>
              </div>

              <div className="pt-4 border-t border-[#dfd5c3] text-xs font-semibold tracking-widest text-[#9a6e2e] uppercase">
                02 · OUR COMMITMENT
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          5. OUR COMMITMENT (Dark Background, 6 Column Icon Grid)
      ======================================================== */}
      <section className="bg-[#0a0a0a] py-24 sm:py-32 relative border-t border-[#221c15]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <SectionEyebrow label="PILLARS OF TRUST" theme="gold" className="justify-center" />
            <h2 className="font-serif text-3xl sm:text-4xl text-white font-normal">
              OUR COMMITMENT
            </h2>
            <p className="text-sm text-[#999] font-sans">
              Six unyielding standards that govern every blueprint, material selection, and customer relationship.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {COMMITMENTS_DATA.map((item) => (
              <div
                key={item.id}
                className="p-8 bg-[#111111] border border-[#221c15] rounded-sm hover:border-[#c9974f]/50 hover:bg-[#151515] transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-full border border-[#c9974f]/30 flex items-center justify-center text-[#c9974f] mb-6 group-hover:border-[#c9974f] group-hover:scale-110 transition-all">
                  <IconResolver name={item.iconName} className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold tracking-[0.16em] uppercase text-white mb-2 font-sans">
                  {item.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#8e8e8e] leading-relaxed font-sans">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================
          6. BOTTOM CTA (Cinematic Dark Ocean Parallax)
      ======================================================== */}
      <section className="relative py-28 sm:py-36 overflow-hidden flex items-center justify-center text-center">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1800&q=80"
            alt="Esplendor Architecture Twilight"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/80 backdrop-blur-xs" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
          <SectionEyebrow label="YOUR STORY STARTS HERE" theme="gold" className="justify-center" />

          <h2 className="font-serif text-3xl sm:text-5xl md:text-6xl text-white font-normal leading-tight">
            Building Homes. <br />
            <span className="italic text-[#c9974f]">Creating Legacies.</span>
          </h2>

          <p className="text-sm sm:text-base text-[#d0d0d0] max-w-xl mx-auto font-sans leading-relaxed">
            Discover the harmony of Goan living with an architectural standard tailored for you.
          </p>

          <div className="pt-4 flex justify-center">
            <GoldButton
              label="CONNECT WITH OUR CONCIERGE"
              onClick={onOpenConsultation}
              variant="solid-gold"
              size="lg"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

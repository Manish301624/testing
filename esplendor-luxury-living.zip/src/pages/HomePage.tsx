import React, { useState } from 'react';
import { motion } from 'motion/react';
import { PageRoute, LuxuryProject } from '../types';
import { SectionEyebrow } from '../components/SectionEyebrow';
import { GoldButton } from '../components/GoldButton';
import { ParticleCanvas } from '../components/ParticleCanvas';
import { TiltCard } from '../components/TiltCard';
import { IconResolver } from '../components/Icons';
import { GoldFlourishDivider } from '../components/GoldFlourishDivider';
import { TestimonialSlider } from '../components/TestimonialSlider';
import { SIGNATURE_FEATURES, PROJECTS_COLLECTION } from '../data/siteData';
import { 
  ArrowUpRight, 
  Sparkles, 
  MapPin, 
  Bed, 
  Bath, 
  Maximize2, 
  ArrowRight,
  Eye,
  Volume2,
  VolumeX,
  Waves
} from 'lucide-react';
import { useAuth } from '../lib/AuthContext';
import { useLanguage } from '../lib/LanguageContext';
import { ambientAudioEngine } from '../lib/ambientAudioEngine';

interface HomePageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenConsultation: () => void;
  onSelectProject: (project: LuxuryProject) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenConsultation,
  onSelectProject,
}) => {
  const { isPropertySaved } = useAuth();
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'all' | 'completed' | 'ongoing' | 'upcoming'>('all');
  const [isAmbientPlaying, setIsAmbientPlaying] = useState(ambientAudioEngine.getIsPlaying());

  const handleToggleAmbient = async () => {
    if (isAmbientPlaying) {
      ambientAudioEngine.stop();
      setIsAmbientPlaying(false);
    } else {
      await ambientAudioEngine.play('coastal-waves');
      setIsAmbientPlaying(true);
    }
  };

  const featuredProjects = activeTab === 'all'
    ? PROJECTS_COLLECTION.slice(0, 4)
    : PROJECTS_COLLECTION.filter((p) => p.status === activeTab).slice(0, 4);

  const collectionCards = [
    {
      id: 'completed',
      category: '01 / PORTFOLIO',
      title: 'COMPLETED HOMES',
      badge: 'DELIVERED',
      badgeClass: 'bg-[#c9974f] text-black',
      image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=900&q=80',
      description: 'Crafted. Delivered. Cherished. Fully realized residences ready for immediate occupancy.',
      buttonText: 'Explore Completed',
    },
    {
      id: 'ongoing',
      category: '02 / PORTFOLIO',
      title: 'ONGOING HOMES',
      badge: 'IN PROGRESS',
      badgeClass: 'bg-[#1a1a1a] border border-[#c9974f] text-[#c9974f]',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=80',
      description: 'In progress. On its way. Witness modern architectural marvels taking shape across North Goa.',
      buttonText: 'Explore Ongoing',
    },
    {
      id: 'upcoming',
      category: '03 / PORTFOLIO',
      title: 'UPCOMING HOMES',
      badge: 'PRE-LAUNCH',
      badgeClass: 'bg-[#c9974f]/20 text-[#e0b877] border border-[#e0b877]/50 backdrop-blur-sm',
      image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=900&q=80',
      description: 'The future. Coming soon. Private estates and waterfront penthouses now accepting priority reservations.',
      buttonText: 'Explore Upcoming',
    },
  ];

  return (
    <div className="bg-[#0a0a0a] text-white min-h-screen">
      {/* ========================================================
          1. HERO SECTION (Split Diagonal Layout)
      ======================================================== */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-20 lg:pt-0">
        {/* Ambient Gold Particle Dust */}
        <ParticleCanvas count={35} />

        {/* Diagonal split background: Dark on left, Hero villa on right */}
        <div className="absolute inset-0 grid grid-cols-1 lg:grid-cols-12 pointer-events-none">
          <div className="lg:col-span-6 bg-[#0a0a0a] z-10" />
          <div className="lg:col-span-6 relative h-full min-h-[500px]">
            <img
              src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1800&q=85"
              alt="Esplendor Luxury Villa with Infinity Pool at Dusk in Goa"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center transform scale-105 transition-transform duration-1000 will-parallax"
            />
            {/* Smooth gradient blend from dark left panel into image */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/60 to-transparent lg:block hidden" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent lg:hidden block" />
            {/* Top dark gradient overlay for navbar legibility */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/80 via-transparent to-[#0a0a0a]/90" />
          </div>
        </div>

        {/* Rotated vertical scroll indicator on the left border */}
        <div className="hidden xl:flex absolute left-8 bottom-16 z-20 items-center gap-3 rotate-[-90deg] origin-left text-[9px] font-sans tracking-[0.25em] uppercase text-[#c9974f]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#c9974f] animate-ping" />
          <span>SCROLL TO DISCOVER</span>
        </div>

        {/* Content Container */}
        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 w-full">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-2xl lg:max-w-xl"
          >
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#141414]/90 border border-[#c9974f]/30 rounded-full mb-6 text-[#c9974f] text-[10px] tracking-[0.22em] uppercase font-semibold">
              <Sparkles className="w-3 h-3" />
              <span>{t('hero.badge', 'CRAFTING TIMELESS LIVING IN GOA')}</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light text-white leading-[1.08] tracking-tight mb-6">
              {t('hero.title1', 'Not just where you live,')} <br />
              <span className="italic font-normal text-[#c9974f]">
                {t('hero.title2', 'how you live.')}
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-sm sm:text-base md:text-lg text-[#b8b8b8] font-sans font-light leading-relaxed max-w-lg mb-10">
              {t('hero.desc', 'Timeless architecture. Natural beauty. Refined living. Experience bespoke residential sanctuaries crafted for generations.')}
            </p>

            {/* CTA Group & Ambient Soundscape Trigger */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6">
              <GoldButton
                label={t('hero.exploreHomes', 'EXPLORE OUR HOMES')}
                onClick={() => onNavigate('luxury-homes')}
                variant="solid-dark"
                size="lg"
                iconType="arrow-up-right"
              />

              <GoldButton
                label={t('nav.ourStory', 'OUR STORY')}
                onClick={() => onNavigate('our-story')}
                variant="text-link"
              />

              {/* Subtle Hero Ambient Audio Pill */}
              <button
                onClick={handleToggleAmbient}
                className={`px-3.5 py-2 rounded-full border text-xs tracking-wider uppercase transition-all duration-300 flex items-center gap-2 cursor-pointer ${
                  isAmbientPlaying
                    ? 'bg-[#1e170f] border-[#c9974f] text-[#f5d79e] shadow-[0_0_15px_rgba(201,151,79,0.3)]'
                    : 'bg-[#141414]/90 hover:bg-[#1f1912] border-[#382d21] text-[#999] hover:text-[#c9974f]'
                }`}
                title="Toggle Ambient Luxury coastal soundscape"
              >
                {isAmbientPlaying ? (
                  <>
                    <Waves className="w-3.5 h-3.5 text-[#c9974f] animate-pulse" />
                    <span className="font-semibold text-[#c9974f]">Atmosphere: Live</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-[#c9974f] animate-ping" />
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-[#c9974f]" />
                    <span>Soundscape: Muted</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>

        {/* Decorative Gold Flourish Divider */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20">
          <GoldFlourishDivider variant="crest" theme="gold" />
        </div>
      </section>

      {/* ========================================================
          2. MANIFESTO SECTION (Dark #0a0a0a Background)
      ======================================================== */}
      <section className="relative bg-[#0a0a0a] py-24 sm:py-32 border-t border-[#1f1912]/80 overflow-hidden">
        {/* Subtle decorative geometric gold circle arc in background */}
        <div className="absolute right-[-150px] top-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full border border-[#c9974f]/10 pointer-events-none" />
        <div className="absolute right-[-250px] top-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full border border-[#c9974f]/5 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center"
          >
            {/* Left Column */}
            <div className="lg:col-span-7 space-y-6">
              <SectionEyebrow label="OUR MANIFESTO" theme="gold" />

              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-white font-normal leading-[1.2] tracking-tight">
                We believe true luxury is <span className="italic text-[#c9974f]">quiet, intentional</span> and made to last.
              </h2>
            </div>

            {/* Right Column */}
            <div className="lg:col-span-5 space-y-6 border-l-0 lg:border-l lg:border-[#2a241b] lg:pl-10">
              <p className="text-sm sm:text-base text-[#a8a8a8] leading-relaxed font-sans font-light">
                At ESPLENDOR, every home is a reflection of our commitment to design excellence, uncompromising quality craftsmanship and a deeper, more harmonious connection with nature. We shape spaces that elevate everyday existence into a timeless art.
              </p>

              <div className="pt-2">
                <GoldButton
                  label="DISCOVER OUR STORY"
                  onClick={() => onNavigate('our-story')}
                  variant="text-link"
                />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Section Separation Gold Flourish */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 relative z-10">
          <GoldFlourishDivider variant="ornate" theme="gold" />
        </div>
      </section>

      {/* ========================================================
          3. FEATURED SIGNATURE RESIDENCES (Scroll-Triggered Project Cards)
      ======================================================== */}
      <section className="bg-[#0e0e0e] py-24 sm:py-32 border-t border-[#1f1912] relative overflow-hidden">
        {/* Subtle background ambient glows */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#c9974f]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#c9974f]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Section Header */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6"
          >
            <div className="space-y-4">
              <SectionEyebrow label="SIGNATURE MASTERPIECES" theme="gold" />
              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-white font-normal leading-tight">
                Architectural Icons <br className="hidden sm:inline" />
                <span className="italic font-normal text-[#c9974f]">framed in Goa's serenity.</span>
              </h2>
            </div>

            {/* Quick Status Filter Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
              {(['all', 'completed', 'ongoing', 'upcoming'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3.5 py-1.5 rounded-full text-xs uppercase tracking-wider font-medium transition-all duration-300 cursor-pointer whitespace-nowrap ${
                    activeTab === tab
                      ? 'bg-[#c9974f] text-black font-semibold shadow-[0_2px_12px_rgba(201,151,79,0.3)]'
                      : 'bg-[#181818] text-[#888] hover:text-white border border-[#2b251e]'
                  }`}
                >
                  {tab === 'all' ? 'All Estates' : tab}
                </button>
              ))}
            </div>
          </motion.div>

          {/* Project Cards Grid with Scroll-Triggered Fade & Slide-In Animation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
            {featuredProjects.map((project, idx) => {
              const isSaved = isPropertySaved(project.id);
              return (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 45 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{
                    duration: 0.75,
                    delay: (idx % 2) * 0.15,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  whileHover={{ y: -6 }}
                  className="group relative bg-[#141414] border border-[#262017] hover:border-[#c9974f]/60 rounded-xl overflow-hidden shadow-xl transition-all duration-500 flex flex-col justify-between cursor-pointer"
                  onClick={() => onSelectProject(project)}
                >
                  {/* Image & Badges */}
                  <div className="relative h-72 sm:h-80 md:h-84 overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/30 to-transparent" />

                    {/* Top Status & Saved Badges */}
                    <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
                      <span className="px-3 py-1 bg-black/75 backdrop-blur-md border border-[#c9974f]/40 text-[#c9974f] text-[10px] font-bold tracking-widest uppercase rounded-full">
                        {project.statusLabel}
                      </span>

                      {isSaved && (
                        <span className="px-2.5 py-0.5 rounded-full bg-[#c9974f] text-black text-[9.5px] font-semibold uppercase tracking-wider shadow-sm">
                          Saved
                        </span>
                      )}
                    </div>

                    {/* Bottom Title inside Image Banner */}
                    <div className="absolute bottom-4 left-5 right-5 z-10 flex items-end justify-between">
                      <div>
                        <div className="flex items-center gap-1.5 text-xs text-[#e0b877] font-medium mb-1">
                          <MapPin className="w-3.5 h-3.5 text-[#c9974f]" />
                          <span>{project.location}</span>
                        </div>
                        <h3 className="font-serif text-2xl sm:text-3xl text-white font-bold tracking-wide group-hover:text-[#c9974f] transition-colors duration-300">
                          {project.name}
                        </h3>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] uppercase tracking-widest text-[#888] block">Starting at</span>
                        <span className="font-serif text-lg sm:text-xl font-semibold text-[#c9974f]">
                          {project.price}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Body Specs & Action */}
                  <div className="p-5 sm:p-6 space-y-4">
                    <p className="text-xs sm:text-sm text-[#999] leading-relaxed line-clamp-2">
                      {project.description}
                    </p>

                    {/* Specs Grid */}
                    <div className="grid grid-cols-3 gap-2 py-3 px-4 bg-[#1b1712] border border-[#282119] rounded-lg text-center">
                      <div className="flex items-center justify-center gap-1.5 text-white text-xs">
                        <Bed className="w-3.5 h-3.5 text-[#c9974f]" />
                        <span className="font-medium">{project.bedrooms} Beds</span>
                      </div>
                      <div className="flex items-center justify-center gap-1.5 text-white text-xs border-x border-[#282119]">
                        <Bath className="w-3.5 h-3.5 text-[#c9974f]" />
                        <span className="font-medium">{project.bathrooms} Baths</span>
                      </div>
                      <div className="flex items-center justify-center gap-1.5 text-white text-xs">
                        <Maximize2 className="w-3.5 h-3.5 text-[#c9974f]" />
                        <span className="font-medium">{project.area}</span>
                      </div>
                    </div>

                    {/* Bottom CTA Row */}
                    <div className="pt-2 flex items-center justify-between text-xs font-semibold tracking-wider text-[#c9974f] group-hover:text-white uppercase transition-colors">
                      <span className="flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Architectural Details</span>
                      </span>
                      <div className="w-8 h-8 rounded-full bg-[#1e1913] group-hover:bg-[#c9974f] group-hover:text-black flex items-center justify-center transition-all duration-300 text-[#c9974f]">
                        <ArrowUpRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* View All Projects Button Footer */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-12 text-center"
          >
            <button
              onClick={() => onNavigate('luxury-homes')}
              className="inline-flex items-center gap-2.5 px-8 py-3.5 rounded-full bg-[#161616] hover:bg-[#c9974f] text-[#c9974f] hover:text-black border border-[#c9974f]/50 text-xs font-bold uppercase tracking-[0.2em] transition-all duration-300 shadow-lg cursor-pointer group"
            >
              <span>Explore Complete Goan Portfolio</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>
        </div>
      </section>

      {/* ========================================================
          4. OUR COLLECTION SECTION (Warm Cream #f5f0e7 Bg)
      ======================================================== */}
      <section className="bg-[#f5f0e7] text-[#2b2b2b] py-24 sm:py-32 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header Row */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6"
          >
            <div className="space-y-4">
              <SectionEyebrow label="OUR COLLECTION" theme="dark" />
              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#1a1a1a] font-normal leading-tight">
                Homes, crafted to inspire <br className="hidden sm:inline" />
                <span className="italic font-normal text-[#9a6e2e]">every chapter.</span>
              </h2>
            </div>

            <div>
              <GoldButton
                label="VIEW ALL HOMES"
                onClick={() => onNavigate('luxury-homes')}
                variant="text-link"
                className="text-[#9a6e2e] hover:text-[#2b2b2b]"
              />
            </div>
          </motion.div>

          {/* 3 Collection Cards Grid with Scroll-Triggered Entrance */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {collectionCards.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.7,
                  delay: index * 0.15,
                  ease: [0.22, 1, 0.36, 1],
                }}
              >
                <TiltCard
                  onClick={() => onNavigate('luxury-homes')}
                  className="bg-[#efe8db] border border-[#d8cfbe] rounded-sm overflow-hidden group shadow-md hover:shadow-xl h-full flex flex-col justify-between cursor-pointer"
                >
                  <div className="relative h-72 sm:h-80 overflow-hidden">
                    <img
                      src={card.image}
                      alt={card.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className={`px-3 py-1 text-[9px] font-bold tracking-widest uppercase rounded-full ${card.badgeClass}`}>
                        {card.badge}
                      </span>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <span className="text-[10px] tracking-[0.2em] text-[#e0b877] uppercase font-sans">
                        {card.category}
                      </span>
                      <h3 className="font-serif text-2xl font-semibold mt-0.5">
                        {card.title}
                      </h3>
                    </div>
                  </div>
                  <div className="p-6 bg-[#efe8db] flex-1 flex flex-col justify-between">
                    <p className="text-xs sm:text-sm text-[#5a5a5a] mb-4 leading-relaxed">
                      {card.description}
                    </p>
                    <div className="flex items-center text-xs font-semibold tracking-wider text-[#9a6e2e] group-hover:text-black uppercase gap-1.5 transition-colors">
                      <span>{card.buttonText}</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>

          {/* Decorative Divider in Warm Cream Section */}
          <div className="pt-16">
            <GoldFlourishDivider variant="emblem" theme="light" />
          </div>
        </div>
      </section>

      {/* ========================================================
          5. THE ESPLENDOR SIGNATURE (Dark Background Split)
      ======================================================== */}
      <section className="bg-[#0a0a0a] py-24 sm:py-32 border-t border-[#1f1912] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Top 5-Column Feature Strip */}
          <div className="mb-14">
            <SectionEyebrow label="THE ESPLENDOR SIGNATURE" theme="gold" className="mb-10" />

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-4">
              {SIGNATURE_FEATURES.map((feat, index) => (
                <motion.div
                  key={feat.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{
                    duration: 0.6,
                    delay: index * 0.1,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="p-6 bg-[#111111] border border-[#221c15] rounded-sm hover:border-[#c9974f]/50 hover:bg-[#161616] transition-all duration-300 group"
                >
                  <div className="w-12 h-12 rounded-full border border-[#c9974f]/30 flex items-center justify-center text-[#c9974f] mb-5 group-hover:border-[#c9974f] group-hover:scale-105 transition-all">
                    <IconResolver name={feat.iconName} className="w-5 h-5" />
                  </div>
                  <h4 className="text-xs font-bold tracking-[0.14em] uppercase text-white mb-2 font-sans">
                    {feat.title}
                  </h4>
                  <p className="text-xs text-[#8e8e8e] leading-relaxed font-sans">
                    {feat.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Luxurious Client Testimonials Slider */}
          <div className="mb-20">
            <TestimonialSlider />
          </div>

          {/* Decorative Divider before Final Retreat Invitation */}
          <div className="mb-14">
            <GoldFlourishDivider variant="ornate" theme="gold" />
          </div>

          {/* Bottom Split: Moody photo on left + Call to action on right */}
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center bg-[#111111] border border-[#241e17] rounded-sm p-6 sm:p-10 lg:p-12"
          >
            <div className="lg:col-span-5 relative h-64 sm:h-80 rounded overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=900&q=80"
                alt="Refined Architectural Interior Detail"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 text-xs font-serif italic text-[#e0b877]">
                "Quiet luxury, meticulously articulated."
              </div>
            </div>

            <div className="lg:col-span-7 space-y-6 lg:pl-6">
              <span className="text-[10px] tracking-[0.25em] text-[#c9974f] uppercase font-semibold">
                YOUR PRIVATE RETREAT AWAITS
              </span>

              <h3 className="font-serif text-3xl sm:text-4xl text-white font-normal leading-tight">
                Begin your journey to <br />
                <span className="italic text-[#c9974f]">timeless living.</span>
              </h3>

              <p className="text-sm text-[#a0a0a0] leading-relaxed max-w-xl font-sans">
                Schedule a confidential consultation with our private client team or visit our experiential studio in North Goa to review upcoming masterplans.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-4">
                <GoldButton
                  label={t('nav.connect', "LET'S CONNECT")}
                  onClick={onOpenConsultation}
                  variant="solid-gold"
                  size="md"
                />
                <GoldButton
                  label={t('nav.livingDifference', "THE LIVING DIFFERENCE")}
                  onClick={() => onNavigate('the-living-difference')}
                  variant="text-link"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};


import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PageRoute } from '../types';
import { SectionEyebrow } from '../components/SectionEyebrow';
import { GoldButton } from '../components/GoldButton';
import { ParticleCanvas } from '../components/ParticleCanvas';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Linkedin, Youtube, Check, Loader2, Navigation, Send, ArrowRight, ShieldCheck, Sparkles, RefreshCw } from 'lucide-react';
import { useLanguage } from '../lib/LanguageContext';

interface ContactPageProps {
  onNavigate: (page: PageRoute) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate }) => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    consent: true,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [submittedData, setSubmittedData] = useState<typeof formData | null>(null);
  const [referenceId, setReferenceId] = useState<string>('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage(null);

    // Generate reference code for premium feel
    const ref = `ESP-${Math.floor(100000 + Math.random() * 900000)}`;

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit message');
      }

      setSubmittedData({ ...formData });
      setReferenceId(ref);
      setSubmitted(true);
    } catch (err: any) {
      setErrorMessage(err.message || 'Unable to submit your message. Please contact us directly at +91 77770 00000.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setSubmittedData(null);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      subject: '',
      message: '',
      consent: true,
    });
  };

  const firstName = submittedData?.fullName.split(' ')[0] || formData.fullName.split(' ')[0] || 'Client';

  return (
    <div className="bg-[#0a0a0a] text-white min-h-screen">
      {/* ========================================================
          1. HERO SECTION (Ocean-View Twilight Living Room)
      ======================================================== */}
      <section className="relative min-h-[55vh] flex items-center overflow-hidden pt-20">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1800&q=85"
            alt="Ocean View Luxury Residence at Dusk with Glass Panoramic Doors"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/80 to-black/60" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />
        </div>

        <ParticleCanvas count={25} />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="max-w-2xl space-y-4">
            <SectionEyebrow label={t('contact.eyebrow', 'GET IN TOUCH')} theme="gold" />
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-light text-white leading-tight">
              {t('contact.title', 'Contact Us')}
            </h1>
            <p className="text-base sm:text-lg text-[#d0d0d0] font-sans font-light leading-relaxed max-w-xl">
              {t('contact.desc', "We're here to help you find your perfect home in Goa. Reach out to our team for any enquiries, site visits or collaborations.")}
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================
          2. TWO-COLUMN CONTACT SECTION (Cream #f5f0e7 Background)
      ======================================================== */}
      <section className="bg-[#f5f0e7] text-[#2b2b2b] py-24 sm:py-32 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            {/* Left Column: Let's Connect Details */}
            <div className="lg:col-span-5 space-y-8">
              <div>
                <SectionEyebrow label="DIRECT REACH" theme="dark" className="mb-3" />
                <h2 className="font-serif text-3xl sm:text-4xl text-[#1a1a1a] font-normal leading-tight mb-3">
                  Let's Connect
                </h2>
                <p className="text-sm text-[#666] font-sans">
                  Our private client team will get back to you at the earliest.
                </p>
              </div>

              <div className="space-y-6 text-sm text-[#444] font-sans">
                {/* Visit Us */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#111] text-[#c9974f] flex items-center justify-center shrink-0 mt-1">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold tracking-[0.16em] uppercase text-[#1a1a1a] mb-1">
                      VISIT US
                    </h4>
                    <p className="text-[#555] leading-relaxed">
                      Esplendor Homes Pvt. Ltd.<br />
                      Baga & Assagao, North Goa, Goa – 403516, India
                    </p>
                  </div>
                </div>

                {/* Call Us */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#111] text-[#c9974f] flex items-center justify-center shrink-0 mt-1">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold tracking-[0.16em] uppercase text-[#1a1a1a] mb-1">
                      CALL US
                    </h4>
                    <p className="text-[#555] leading-relaxed">
                      <a href="tel:+917777000000" className="hover:text-[#9a6e2e] transition-colors block">
                        +91 77770 00000
                      </a>
                      <a href="tel:+917777000001" className="hover:text-[#9a6e2e] transition-colors block">
                        +91 77770 00001
                      </a>
                    </p>
                  </div>
                </div>

                {/* Email Us */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#111] text-[#c9974f] flex items-center justify-center shrink-0 mt-1">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold tracking-[0.16em] uppercase text-[#1a1a1a] mb-1">
                      EMAIL US
                    </h4>
                    <p className="text-[#555] leading-relaxed">
                      <a href="mailto:info@esplendorhomes.com" className="hover:text-[#9a6e2e] transition-colors block">
                        info@esplendorhomes.com
                      </a>
                      <a href="mailto:sales@esplendorhomes.com" className="hover:text-[#9a6e2e] transition-colors block">
                        sales@esplendorhomes.com
                      </a>
                    </p>
                  </div>
                </div>

                {/* Business Hours */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#111] text-[#c9974f] flex items-center justify-center shrink-0 mt-1">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold tracking-[0.16em] uppercase text-[#1a1a1a] mb-1">
                      BUSINESS HOURS
                    </h4>
                    <p className="text-[#555] leading-relaxed">
                      Monday – Saturday: 10:00 AM – 7:00 PM<br />
                      <span className="text-xs text-[#888] italic">Sunday: By prior private appointment</span>
                    </p>
                  </div>
                </div>

                {/* Follow Us */}
                <div className="pt-4 border-t border-[#dfd5c3]">
                  <h4 className="text-xs font-bold tracking-[0.16em] uppercase text-[#1a1a1a] mb-3">
                    FOLLOW US
                  </h4>
                  <div className="flex items-center gap-3">
                    <a
                      href="https://instagram.com"
                      target="_blank"
                      rel="noreferrer"
                      className="w-10 h-10 rounded-full border border-[#c9974f] bg-[#0a0a0a] flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all"
                      aria-label="Instagram"
                    >
                      <Instagram className="w-4 h-4" />
                    </a>
                    <a
                      href="https://facebook.com"
                      target="_blank"
                      rel="noreferrer"
                      className="w-10 h-10 rounded-full border border-[#c9974f] bg-[#0a0a0a] flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all"
                      aria-label="Facebook"
                    >
                      <Facebook className="w-4 h-4" />
                    </a>
                    <a
                      href="https://linkedin.com"
                      target="_blank"
                      rel="noreferrer"
                      className="w-10 h-10 rounded-full border border-[#c9974f] bg-[#0a0a0a] flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all"
                      aria-label="LinkedIn"
                    >
                      <Linkedin className="w-4 h-4" />
                    </a>
                    <a
                      href="https://youtube.com"
                      target="_blank"
                      rel="noreferrer"
                      className="w-10 h-10 rounded-full border border-[#c9974f] bg-[#0a0a0a] flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all"
                      aria-label="YouTube"
                    >
                      <Youtube className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Send Us a Message Form with Framer Motion Success Animation */}
            <div className="lg:col-span-7 bg-[#efe8db] border border-[#d8cfbe] p-8 sm:p-12 rounded-sm shadow-xl relative overflow-hidden">
              <AnimatePresence mode="wait">
                {submitted ? (
                  <motion.div
                    key="success-message"
                    initial={{ opacity: 0, scale: 0.94, y: 25 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.96, y: -20 }}
                    transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                    className="text-center py-6 sm:py-8 space-y-6"
                  >
                    {/* Animated Gold Checkmark with Concentric Glowing Rings */}
                    <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                      {/* Ambient Gold Glow */}
                      <motion.div
                        initial={{ scale: 0.6, opacity: 0 }}
                        animate={{ scale: [1, 1.25, 1], opacity: [0.4, 0.7, 0.4] }}
                        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                        className="absolute inset-0 rounded-full bg-[#c9974f]/25 blur-xl pointer-events-none"
                      />

                      {/* Rotating subtle gold ring */}
                      <motion.div
                        initial={{ rotate: 0 }}
                        animate={{ rotate: 360 }}
                        transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                        className="absolute inset-0 rounded-full border border-dashed border-[#c9974f]/40"
                      />

                      {/* Inner gold circular badge */}
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring', stiffness: 300, damping: 20, delay: 0.1 }}
                        className="relative z-10 w-20 h-20 rounded-full bg-[#0a0a0a] border-2 border-[#c9974f] flex items-center justify-center shadow-[0_8px_25px_rgba(201,151,79,0.35)]"
                      >
                        {/* Animated SVG Path Checkmark */}
                        <svg className="w-10 h-10 text-[#c9974f]" viewBox="0 0 52 52">
                          <motion.circle
                            cx="26"
                            cy="26"
                            r="22"
                            fill="none"
                            stroke="#c9974f"
                            strokeWidth="2"
                            strokeOpacity="0.3"
                            initial={{ pathLength: 0 }}
                            animate={{ pathLength: 1 }}
                            transition={{ duration: 0.5, ease: 'easeOut' }}
                          />
                          <motion.path
                            fill="none"
                            stroke="#c9974f"
                            strokeWidth="3.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M15 27l8 8 16-16"
                            initial={{ pathLength: 0, opacity: 0 }}
                            animate={{ pathLength: 1, opacity: 1 }}
                            transition={{ duration: 0.5, delay: 0.35, ease: 'easeOut' }}
                          />
                        </svg>

                        {/* Floating mini sparkles */}
                        <motion.div
                          initial={{ scale: 0, opacity: 0 }}
                          animate={{ scale: [0, 1, 0], opacity: [0, 1, 0] }}
                          transition={{ duration: 2, repeat: Infinity, delay: 0.8 }}
                          className="absolute -top-1 -right-1 text-[#c9974f]"
                        >
                          <Sparkles className="w-4 h-4" />
                        </motion.div>
                      </motion.div>
                    </div>

                    {/* Headline and Narrative */}
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.45, delay: 0.25 }}
                      className="space-y-2"
                    >
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#c9974f]/15 border border-[#c9974f]/40 text-[#845b1d] text-[10px] font-bold tracking-widest uppercase">
                        <ShieldCheck className="w-3.5 h-3.5 text-[#9a6e2e]" />
                        <span>DISPATCHED TO SENIOR CONCIERGE</span>
                      </div>

                      <h3 className="font-serif text-2xl sm:text-3xl text-[#1a1a1a] font-bold tracking-tight">
                        Thank you, {firstName}
                      </h3>

                      <p className="text-xs sm:text-sm text-[#555] max-w-md mx-auto leading-relaxed font-sans">
                        Your inquiry has been successfully transmitted to our Private Client Advisory in North Goa. We have reserved your reference record below.
                      </p>
                    </motion.div>

                    {/* Luxury Receipt / Transmission Record Card */}
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.45, delay: 0.35 }}
                      className="bg-[#fcfaf6] border border-[#d8cfbe] rounded p-5 text-left text-xs font-sans space-y-3 shadow-sm"
                    >
                      <div className="flex items-center justify-between border-b border-[#e8dfcf] pb-2">
                        <span className="text-[10px] uppercase tracking-widest font-semibold text-[#888]">
                          REFERENCE ID
                        </span>
                        <span className="font-mono font-bold text-[#9a6e2e] bg-[#efe8db] px-2 py-0.5 rounded text-[11px]">
                          {referenceId || 'ESP-892104'}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[#444]">
                        <div>
                          <span className="text-[10px] uppercase tracking-wider text-[#888] block">
                            CLIENT
                          </span>
                          <span className="font-semibold text-[#1a1a1a]">
                            {submittedData?.fullName}
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] uppercase tracking-wider text-[#888] block">
                            SUBJECT
                          </span>
                          <span className="font-semibold text-[#1a1a1a] truncate block">
                            {submittedData?.subject}
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] uppercase tracking-wider text-[#888] block">
                            CONTACT CHANNEL
                          </span>
                          <span className="text-[#333]">
                            {submittedData?.email}
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] uppercase tracking-wider text-[#888] block">
                            ADVISORY SLA
                          </span>
                          <span className="text-[#057a55] font-semibold flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#057a55] animate-pulse" />
                            Guaranteed reply within 4 hrs
                          </span>
                        </div>
                      </div>
                    </motion.div>

                    {/* Actions */}
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.45, delay: 0.45 }}
                      className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3"
                    >
                      <button
                        onClick={handleReset}
                        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-[#0a0a0a] text-white hover:bg-[#c9974f] hover:text-black font-semibold text-xs tracking-widest uppercase transition-all duration-300 shadow-md cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>SEND ANOTHER INQUIRY</span>
                      </button>

                      <button
                        onClick={() => onNavigate('luxury-homes')}
                        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-transparent border border-[#9a6e2e] text-[#9a6e2e] hover:bg-[#9a6e2e] hover:text-white font-semibold text-xs tracking-widest uppercase transition-all duration-300 cursor-pointer"
                      >
                        <span>EXPLORE RESIDENCES</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </motion.div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="contact-form"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.96, y: -20 }}
                    transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <div className="mb-8">
                      <h3 className="font-serif text-2xl sm:text-3xl text-[#1a1a1a] font-bold mb-2">
                        Send Us a Message
                      </h3>
                      <p className="text-xs sm:text-sm text-[#666] font-sans">
                        Fill in your details and our team will get in touch with you.
                      </p>
                    </div>

                    {errorMessage && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mb-6 p-4 bg-red-100 border border-red-300 text-red-800 text-xs rounded"
                      >
                        {errorMessage}
                      </motion.div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-5 font-sans text-xs">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div>
                          <label className="block text-[#444] uppercase tracking-wider mb-2 font-semibold">
                            Full Name *
                          </label>
                          <input
                            type="text"
                            required
                            value={formData.fullName}
                            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                            placeholder="e.g. Ananya Roy"
                            className="w-full bg-[#fdfbf7] border border-[#d2c7b5] focus:border-[#9a6e2e] focus:outline-none px-4 py-3.5 rounded text-[#2b2b2b] placeholder-[#999] transition-colors"
                          />
                        </div>

                        <div>
                          <label className="block text-[#444] uppercase tracking-wider mb-2 font-semibold">
                            Email Address *
                          </label>
                          <input
                            type="email"
                            required
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            placeholder="ananya@example.com"
                            className="w-full bg-[#fdfbf7] border border-[#d2c7b5] focus:border-[#9a6e2e] focus:outline-none px-4 py-3.5 rounded text-[#2b2b2b] placeholder-[#999] transition-colors"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div>
                          <label className="block text-[#444] uppercase tracking-wider mb-2 font-semibold">
                            Phone Number *
                          </label>
                          <input
                            type="tel"
                            required
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            placeholder="+91 98000 00000"
                            className="w-full bg-[#fdfbf7] border border-[#d2c7b5] focus:border-[#9a6e2e] focus:outline-none px-4 py-3.5 rounded text-[#2b2b2b] placeholder-[#999] transition-colors"
                          />
                        </div>

                        <div>
                          <label className="block text-[#444] uppercase tracking-wider mb-2 font-semibold">
                            Subject *
                          </label>
                          <input
                            type="text"
                            required
                            value={formData.subject}
                            onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                            placeholder="e.g. Schedule Assagao Villa Site Visit"
                            className="w-full bg-[#fdfbf7] border border-[#d2c7b5] focus:border-[#9a6e2e] focus:outline-none px-4 py-3.5 rounded text-[#2b2b2b] placeholder-[#999] transition-colors"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[#444] uppercase tracking-wider mb-2 font-semibold">
                          Your Message *
                        </label>
                        <textarea
                          rows={4}
                          required
                          value={formData.message}
                          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                          placeholder="Tell us what you are looking for in terms of location, handover dates, or investment objectives..."
                          className="w-full bg-[#fdfbf7] border border-[#d2c7b5] focus:border-[#9a6e2e] focus:outline-none px-4 py-3.5 rounded text-[#2b2b2b] placeholder-[#999] transition-colors resize-none"
                        />
                      </div>

                      <div className="flex items-start gap-3 pt-2">
                        <input
                          type="checkbox"
                          id="contact-consent"
                          checked={formData.consent}
                          onChange={(e) => setFormData({ ...formData, consent: e.target.checked })}
                          className="mt-0.5 accent-[#9a6e2e]"
                        />
                        <label htmlFor="contact-consent" className="text-xs text-[#666] cursor-pointer">
                          I agree to receive updates, confidential pricing, and architectural communications from Esplendor Homes.
                        </label>
                      </div>

                      <div className="pt-4">
                        <motion.button
                          type="submit"
                          disabled={isSubmitting}
                          whileHover={{ scale: isSubmitting ? 1 : 1.01 }}
                          whileTap={{ scale: isSubmitting ? 1 : 0.99 }}
                          className="w-full py-4 px-8 rounded-full bg-[#0a0a0a] hover:bg-[#c9974f] hover:text-black text-[#c9974f] font-semibold text-xs tracking-[0.2em] uppercase transition-all duration-300 flex items-center justify-center gap-2 shadow-lg disabled:opacity-60 cursor-pointer group"
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin" />
                              <span>Transmitting Message...</span>
                            </>
                          ) : (
                            <>
                              <span>SEND MESSAGE</span>
                              <span className="group-hover:translate-x-1 transition-transform">→</span>
                            </>
                          )}
                        </motion.button>
                      </div>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          3. MAP & EXPERIENCE CENTRE SECTION (2 Columns)
      ======================================================== */}
      <section className="bg-[#0a0a0a] py-20 border-t border-[#221c15]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#111111] border border-[#252019] rounded-sm overflow-hidden">
            {/* Stylized North Goa Visual Map */}
            <div className="lg:col-span-7 relative h-80 sm:h-96 w-full bg-[#161616] p-6 flex flex-col justify-between">
              {/* Map Canvas styling with locations */}
              <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#c9974f_1px,transparent_1px)] [background-size:16px_16px]" />

              <div className="relative z-10 flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-widest text-[#c9974f] uppercase">
                  NORTH GOA RESIDENTIAL CORRIDOR
                </span>
                <span className="px-2.5 py-0.5 bg-[#c9974f]/10 border border-[#c9974f]/40 text-[#c9974f] text-[9px] font-semibold uppercase rounded">
                  GPS: 15.5527° N, 73.7517° E
                </span>
              </div>

              {/* Graphical Location Pins in North Goa */}
              <div className="relative z-10 py-6 grid grid-cols-3 gap-4 text-center">
                <div className="p-3 bg-[#1e1e1e] border border-[#333] rounded hover:border-[#c9974f] transition-colors">
                  <span className="text-[#c9974f] text-xs font-bold block">ASSAGAO</span>
                  <span className="text-[10px] text-[#888]">Casa Bella</span>
                </div>
                <div className="p-3 bg-[#1e1e1e] border border-[#333] rounded hover:border-[#c9974f] transition-colors">
                  <span className="text-[#c9974f] text-xs font-bold block">SIOLIM</span>
                  <span className="text-[10px] text-[#888]">Vista Verde</span>
                </div>
                <div className="p-3 bg-[#1e1e1e] border border-[#333] rounded hover:border-[#c9974f] transition-colors">
                  <span className="text-[#c9974f] text-xs font-bold block">CANDOLIM</span>
                  <span className="text-[10px] text-[#888]">The Palms</span>
                </div>
                <div className="p-3 bg-[#1e1e1e] border border-[#333] rounded hover:border-[#c9974f] transition-colors">
                  <span className="text-[#c9974f] text-xs font-bold block">MOIRA</span>
                  <span className="text-[10px] text-[#888]">Solace Villa</span>
                </div>
                <div className="p-3 bg-[#0a0a0a] border-2 border-[#c9974f] rounded shadow-[0_0_15px_rgba(201,151,79,0.3)]">
                  <span className="text-[#e0b877] text-xs font-bold block flex items-center justify-center gap-1">
                    <MapPin className="w-3.5 h-3.5" /> BAGA STUDIO
                  </span>
                  <span className="text-[9px] text-[#c9974f]">Experience Centre</span>
                </div>
                <div className="p-3 bg-[#1e1e1e] border border-[#333] rounded hover:border-[#c9974f] transition-colors">
                  <span className="text-[#c9974f] text-xs font-bold block">VAGATOR</span>
                  <span className="text-[10px] text-[#888]">Ocean Crest</span>
                </div>
              </div>

              <div className="relative z-10 text-[11px] text-[#777]">
                * Private chauffeured airport transfers arranged for verified property viewings.
              </div>
            </div>

            {/* Visit Us Dark Panel */}
            <div className="lg:col-span-5 p-8 sm:p-10 space-y-5">
              <SectionEyebrow label="EXPERIENCE CENTRE" theme="gold" />
              <h3 className="font-serif text-2xl sm:text-3xl text-white font-bold">
                Visit Us in Goa
              </h3>
              <p className="text-xs sm:text-sm text-[#9e9e9e] font-sans leading-relaxed">
                Explore material mockups, scale architectural models, and discuss turnkey interior options in our private VIP lounge.
              </p>
              <div className="pt-2">
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#1c1c1c] border border-[#c9974f] text-[#c9974f] hover:bg-[#c9974f] hover:text-black font-semibold text-xs tracking-widest uppercase transition-all duration-300"
                >
                  <Navigation className="w-4 h-4" />
                  <span>GET DIRECTIONS</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

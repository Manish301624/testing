export type PageRoute = 'home' | 'our-story' | 'luxury-homes' | 'the-living-difference' | 'contact';

export interface FeatureCardItem {
  id: string;
  number: number;
  title: string;
  description: string;
  image: string;
  imageAlt: string;
  iconName: 'sofa' | 'amenities' | 'handshake' | 'bell' | 'shield-house' | 'key' | 'camera' | 'cocktail';
  badge?: string;
  longDescription?: string;
  highlights?: string[];
}

export interface LuxuryProject {
  id: string;
  name: string;
  location: string;
  category: 'all' | 'completed' | 'ongoing' | 'upcoming' | 'luxury-apartments' | 'villas';
  status: 'completed' | 'ongoing' | 'upcoming';
  statusLabel: string;
  description: string;
  image: string;
  bedrooms: number;
  bathrooms: number;
  area: string;
  price: string;
  highlights?: string[];
}

export interface StatItem {
  value: number;
  suffix?: string;
  prefix?: string;
  textValue?: string;
  label: string;
  iconName: 'calendar' | 'user' | 'house' | 'crane' | 'family' | 'pin';
}

export interface ContactFormData {
  fullName: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  consent: boolean;
}

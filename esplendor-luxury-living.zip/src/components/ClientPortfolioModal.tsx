import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  LogOut, 
  Bookmark, 
  Film, 
  Sparkles, 
  Trash2, 
  ExternalLink, 
  Calendar,
  X,
  Plus,
  Play
} from 'lucide-react';
import { useAuth } from '../lib/AuthContext';
import { GoldButton } from './GoldButton';

interface ClientPortfolioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProject?: (projectId: string) => void;
  onOpenVeoStudio?: (imageUrl?: string, title?: string) => void;
}

export const ClientPortfolioModal: React.FC<ClientPortfolioModalProps> = ({
  isOpen,
  onClose,
  onSelectProject,
  onOpenVeoStudio,
}) => {
  const { user, savedProperties, userVideos, unsaveProperty, signOut, signInWithGoogle } = useAuth();
  const [activeTab, setActiveTab] = useState<'saved' | 'videos'>('saved');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-3xl bg-[#0e0e0e] border border-[#c9974f]/40 rounded-xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 bg-[#141414] border-b border-[#252019] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'Client'}
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full border-2 border-[#c9974f] object-cover shrink-0"
              />
            ) : (
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#1b1712] border border-[#c9974f] flex items-center justify-center text-[#c9974f] shrink-0">
                <User className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
            )}
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <h3 className="font-serif text-base sm:text-lg font-bold text-white tracking-wide truncate">
                  {user ? user.displayName || 'VIP Client' : 'Private Client Lounge'}
                </h3>
                <span className="px-2 py-0.5 rounded text-[8.5px] sm:text-[9px] bg-[#c9974f]/15 border border-[#c9974f]/30 text-[#c9974f] font-mono uppercase font-bold shrink-0">
                  {user ? 'Firebase Synced' : 'Guest'}
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-[#8a8a8a] mt-0.5 truncate sm:whitespace-normal">
                {user ? user.email : 'Sign in to sync your saved luxury estates & Veo AI videos'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {user && (
              <button
                onClick={signOut}
                title="Sign Out"
                className="p-1.5 sm:p-2 text-[#888] hover:text-red-400 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/60 border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Auth prompt if not signed in */}
        {!user ? (
          <div className="p-6 sm:p-8 text-center space-y-4 sm:space-y-5 my-auto overflow-y-auto">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#1b1712] border border-[#c9974f] flex items-center justify-center text-[#c9974f] mx-auto shadow-[0_0_20px_rgba(201,151,79,0.25)]">
              <User className="w-7 h-7 sm:w-8 sm:h-8" />
            </div>
            <div className="space-y-2">
              <h4 className="font-serif text-xl sm:text-2xl text-white font-bold">
                Access Your Private Client Portfolio
              </h4>
              <p className="text-xs text-[#a0a0a0] max-w-md mx-auto leading-relaxed">
                Authenticate securely with Google Sign-In to bookmark Goan villas, review private advisory inquiries, and manage your AI-generated Veo 4K cinematic animations.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={signInWithGoogle}
                className="py-3 px-6 sm:px-8 rounded-full bg-[#c9974f] hover:bg-[#e0b877] text-black font-semibold text-xs tracking-widest uppercase transition-all duration-300 inline-flex items-center gap-2 shadow-[0_4px_20px_rgba(201,151,79,0.35)] cursor-pointer"
              >
                <img
                  src="https://www.gstatic.com/mobilesdk/250721_mobilesdk/mono_firebase_dark.svg"
                  alt="Firebase Google"
                  className="w-4 h-4 invert brightness-0"
                />
                <span>Sign In with Google</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Tabs */}
            <div className="px-4 sm:px-6 bg-[#0a0a0a] border-b border-[#201c17] flex items-center gap-4 sm:gap-6 text-xs font-medium overflow-x-auto scrollbar-none shrink-0">
              <button
                onClick={() => setActiveTab('saved')}
                className={`py-3 sm:py-3.5 border-b-2 tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap text-[11px] sm:text-xs ${
                  activeTab === 'saved'
                    ? 'border-[#c9974f] text-[#c9974f] font-semibold'
                    : 'border-transparent text-[#888] hover:text-white'
                }`}
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>Saved Estates ({savedProperties.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('videos')}
                className={`py-3 sm:py-3.5 border-b-2 tracking-wider uppercase transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap text-[11px] sm:text-xs ${
                  activeTab === 'videos'
                    ? 'border-[#c9974f] text-[#c9974f] font-semibold'
                    : 'border-transparent text-[#888] hover:text-white'
                }`}
              >
                <Film className="w-3.5 h-3.5" />
                <span>Veo Animations ({userVideos.length})</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              {activeTab === 'saved' && (
                <div>
                  {savedProperties.length === 0 ? (
                    <div className="text-center py-12 space-y-3">
                      <Bookmark className="w-10 h-10 text-[#44382c] mx-auto" />
                      <p className="text-sm text-white font-serif">No bookmarked properties yet</p>
                      <p className="text-xs text-[#777] max-w-sm mx-auto">
                        Explore our luxury villas in Assagao, Siolim, or Candolim and click the bookmark button to save them to your portfolio.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {savedProperties.map((prop) => (
                        <div
                          key={prop.id}
                          className="bg-[#141414] border border-[#2c261e] hover:border-[#c9974f]/60 rounded-lg overflow-hidden transition-all group flex flex-col justify-between"
                        >
                          <div className="relative aspect-video">
                            <img
                              src={prop.image}
                              alt={prop.projectName}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute top-2 right-2">
                              <button
                                onClick={() => unsaveProperty(prop.projectId)}
                                title="Remove from saved"
                                className="w-7 h-7 rounded-full bg-black/70 hover:bg-red-900/80 text-white/80 hover:text-red-200 flex items-center justify-center transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/80 text-[10px] text-[#c9974f] font-mono">
                              {prop.price}
                            </div>
                          </div>

                          <div className="p-4 space-y-2">
                            <div className="flex items-start justify-between">
                              <h4 className="font-serif text-sm font-bold text-white group-hover:text-[#c9974f] transition-colors">
                                {prop.projectName}
                              </h4>
                              <span className="text-[10px] text-[#888]">{prop.area}</span>
                            </div>
                            <p className="text-[11px] text-[#888]">{prop.location}</p>

                            <div className="pt-2 flex items-center gap-2">
                              {onOpenVeoStudio && (
                                <button
                                  onClick={() => {
                                    onClose();
                                    onOpenVeoStudio(prop.image, prop.projectName);
                                  }}
                                  className="flex-1 py-1.5 px-2.5 rounded bg-[#1f1b15] hover:bg-[#c9974f] hover:text-black text-[#c9974f] text-[10.5px] font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                                >
                                  <Sparkles className="w-3 h-3" />
                                  <span>Animate with Veo</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'videos' && (
                <div>
                  {userVideos.length === 0 ? (
                    <div className="text-center py-12 space-y-3">
                      <Film className="w-10 h-10 text-[#44382c] mx-auto" />
                      <p className="text-sm text-white font-serif">No AI video animations generated yet</p>
                      <p className="text-xs text-[#777] max-w-sm mx-auto">
                        Turn architectural estate renders into cinematic 4K videos using the Veo 3.1 generator.
                      </p>
                      <div className="pt-2">
                        {onOpenVeoStudio && (
                          <button
                            onClick={() => {
                              onClose();
                              onOpenVeoStudio();
                            }}
                            className="px-4 py-2 rounded-full bg-[#c9974f] text-black font-semibold text-xs tracking-wider uppercase inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Launch Veo Video Studio</span>
                          </button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {userVideos.map((vid) => (
                        <div
                          key={vid.id}
                          className="bg-[#141414] border border-[#2c261e] rounded-lg overflow-hidden flex flex-col justify-between"
                        >
                          <div className="relative aspect-video bg-black">
                            {vid.videoUrl ? (
                              <video
                                src={vid.videoUrl}
                                controls
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <img
                                src={vid.sourceImageUrl}
                                alt="Video preview"
                                className="w-full h-full object-cover opacity-60"
                              />
                            )}
                            <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/80 text-[10px] text-[#c9974f] font-mono">
                              Veo {vid.aspectRatio}
                            </div>
                          </div>

                          <div className="p-4 space-y-2">
                            <h4 className="font-serif text-sm font-bold text-white truncate">
                              {vid.title}
                            </h4>
                            <p className="text-[11px] text-[#888] line-clamp-2 italic">
                              "{vid.prompt}"
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </motion.div>
    </div>
  );
};

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Loader2, Calendar, Phone, Mail, User, MessageSquare, ShieldCheck, Sparkles } from 'lucide-react';
import { GoldButton } from './GoldButton';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSubject?: string;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  initialSubject = 'Private Viewing & Consultation'
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    subject: initialSubject,
    message: '',
    consent: true,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit inquiry');
      }

      setSubmitSuccess(true);
    } catch (err: any) {
      setErrorMessage(err.message || 'Something went wrong. Please call us directly at +91 77770 00000.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetAndClose = () => {
    setSubmitSuccess(false);
    setErrorMessage(null);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      subject: initialSubject,
      message: '',
      consent: true,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-2xl bg-[#0e0e0e] border border-[#c9974f]/40 rounded-sm shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={handleResetAndClose}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/60 border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-colors cursor-pointer"
          aria-label="Close Consultation Modal"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="p-4 sm:p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            {submitSuccess ? (
              <motion.div
                key="modal-success"
                initial={{ opacity: 0, scale: 0.93, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -15 }}
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                className="text-center py-8 space-y-5"
              >
                {/* Animated Gold Checkmark */}
                <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
                  <motion.div
                    initial={{ scale: 0.6, opacity: 0 }}
                    animate={{ scale: [1, 1.25, 1], opacity: [0.3, 0.6, 0.3] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
                    className="absolute inset-0 rounded-full bg-[#c9974f]/25 blur-lg pointer-events-none"
                  />

                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                    className="relative z-10 w-16 h-16 rounded-full bg-[#141414] border border-[#c9974f] flex items-center justify-center shadow-[0_0_20px_rgba(201,151,79,0.3)]"
                  >
                    <svg className="w-9 h-9 text-[#c9974f]" viewBox="0 0 52 52">
                      <motion.circle
                        cx="26"
                        cy="26"
                        r="22"
                        fill="none"
                        stroke="#c9974f"
                        strokeWidth="2"
                        strokeOpacity="0.3"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 0.5, ease: 'easeOut' }}
                      />
                      <motion.path
                        fill="none"
                        stroke="#c9974f"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M15 27l8 8 16-16"
                        initial={{ pathLength: 0, opacity: 0 }}
                        animate={{ pathLength: 1, opacity: 1 }}
                        transition={{ duration: 0.45, delay: 0.3, ease: 'easeOut' }}
                      />
                    </svg>

                    <motion.div
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: [0, 1, 0], opacity: [0, 1, 0] }}
                      transition={{ duration: 2, repeat: Infinity, delay: 0.6 }}
                      className="absolute -top-1 -right-1 text-[#c9974f]"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                    </motion.div>
                  </motion.div>
                </div>

                <div className="space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#c9974f]/10 border border-[#c9974f]/30 text-[#c9974f] text-[10px] font-bold tracking-widest uppercase">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>PRIVATE ADVISORY APPOINTED</span>
                  </div>
                  <h3 className="font-serif text-2xl sm:text-3xl text-white font-bold">
                    Inquiry Confirmed
                  </h3>
                  <p className="text-xs sm:text-sm text-[#c0c0c0] max-w-md mx-auto leading-relaxed font-sans font-light">
                    Thank you for your interest in ESPLENDOR. Our private client director has received your request and will connect with you within 4 business hours to arrange your bespoke consultation.
                  </p>
                </div>

                <div className="pt-4">
                  <GoldButton
                    label="CLOSE WINDOW"
                    onClick={handleResetAndClose}
                    variant="solid-gold"
                    size="md"
                  />
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="modal-form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 0.95, y: -15 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              >
                <div className="mb-6">
                  <div className="flex items-center gap-2.5 text-xs text-[#c9974f] tracking-[0.2em] uppercase font-semibold mb-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Private Advisory</span>
                  </div>
                  <h3 className="font-serif text-2xl sm:text-3xl text-white font-bold tracking-tight">
                    Schedule a Consultation
                  </h3>
                  <p className="text-xs sm:text-sm text-[#8a8a8a] mt-1">
                    Connect with our senior architects and property concierges in Goa.
                  </p>
                </div>

                {errorMessage && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-4 p-3 bg-red-950/60 border border-red-800/60 text-red-200 text-xs rounded"
                  >
                    {errorMessage}
                  </motion.div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4 font-sans text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Full Name */}
                    <div>
                      <label className="block text-[#a0a0a0] uppercase tracking-wider mb-1.5 font-medium">
                        Full Name *
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          required
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          placeholder="e.g. Vikramaditya Sharma"
                          className="w-full bg-[#161616] border border-[#2c261e] focus:border-[#c9974f] focus:outline-none px-3.5 py-3 rounded text-white placeholder-[#555] text-xs transition-colors"
                        />
                        <User className="w-3.5 h-3.5 text-[#666] absolute right-3 top-3.5 pointer-events-none" />
                      </div>
                    </div>

                    {/* Phone Number */}
                    <div>
                      <label className="block text-[#a0a0a0] uppercase tracking-wider mb-1.5 font-medium">
                        Phone Number *
                      </label>
                      <div className="relative">
                        <input
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+91 98200 00000"
                          className="w-full bg-[#161616] border border-[#2c261e] focus:border-[#c9974f] focus:outline-none px-3.5 py-3 rounded text-white placeholder-[#555] text-xs transition-colors"
                        />
                        <Phone className="w-3.5 h-3.5 text-[#666] absolute right-3 top-3.5 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Email */}
                    <div>
                      <label className="block text-[#a0a0a0] uppercase tracking-wider mb-1.5 font-medium">
                        Email Address *
                      </label>
                      <div className="relative">
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="vikram@luxuryestates.com"
                          className="w-full bg-[#161616] border border-[#2c261e] focus:border-[#c9974f] focus:outline-none px-3.5 py-3 rounded text-white placeholder-[#555] text-xs transition-colors"
                        />
                        <Mail className="w-3.5 h-3.5 text-[#666] absolute right-3 top-3.5 pointer-events-none" />
                      </div>
                    </div>

                    {/* Subject */}
                    <div>
                      <label className="block text-[#a0a0a0] uppercase tracking-wider mb-1.5 font-medium">
                        Inquiry Type *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        placeholder="e.g. Casa Bella Villa Viewing"
                        className="w-full bg-[#161616] border border-[#2c261e] focus:border-[#c9974f] focus:outline-none px-3.5 py-3 rounded text-white placeholder-[#555] text-xs transition-colors"
                      />
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-[#a0a0a0] uppercase tracking-wider mb-1.5 font-medium">
                      Your Requirements / Message
                    </label>
                    <div className="relative">
                      <textarea
                        rows={3}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="Tell us about your preferred timeline, bedroom requirements, or specific location interests in Goa..."
                        className="w-full bg-[#161616] border border-[#2c261e] focus:border-[#c9974f] focus:outline-none px-3.5 py-3 rounded text-white placeholder-[#555] text-xs transition-colors resize-none"
                      />
                      <MessageSquare className="w-3.5 h-3.5 text-[#666] absolute right-3 top-3 pointer-events-none" />
                    </div>
                  </div>

                  {/* Consent */}
                  <div className="flex items-start gap-2.5 pt-1">
                    <input
                      type="checkbox"
                      id="consent-check"
                      checked={formData.consent}
                      onChange={(e) => setFormData({ ...formData, consent: e.target.checked })}
                      className="mt-0.5 accent-[#c9974f]"
                    />
                    <label htmlFor="consent-check" className="text-[11px] text-[#888] cursor-pointer">
                      I agree to receive communications, brochures, and confidential updates from Esplendor Homes.
                    </label>
                  </div>

                  {/* Submit button */}
                  <div className="pt-3">
                    <motion.button
                      type="submit"
                      disabled={isSubmitting}
                      whileHover={{ scale: isSubmitting ? 1 : 1.01 }}
                      whileTap={{ scale: isSubmitting ? 1 : 0.99 }}
                      className="w-full py-3.5 px-6 rounded-full bg-[#c9974f] hover:bg-[#e0b877] text-black font-semibold text-xs tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(201,151,79,0.3)] disabled:opacity-60 cursor-pointer"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Submitting Request...</span>
                        </>
                      ) : (
                        <span>SEND INQUIRY →</span>
                      )}
                    </motion.button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

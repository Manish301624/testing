import React from 'react';

// Esplendor Brand Tower Logo (5 staggered golden vertical pillars + chevron top + base bar)
export const EsplendorLogoIcon: React.FC<{ className?: string }> = ({ className = "w-7 h-9" }) => (
  <svg viewBox="0 0 40 50" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="ESPLENDOR Logo">
    <defs>
      <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#e0b877" />
        <stop offset="50%" stopColor="#c9974f" />
        <stop offset="100%" stopColor="#9a6e2e" />
      </linearGradient>
    </defs>
    <rect x="4" y="22" width="3.5" height="26" rx="1" fill="url(#goldGrad)" />
    <rect x="11.5" y="14" width="3.5" height="34" rx="1" fill="url(#goldGrad)" />
    <rect x="19" y="8" width="3.5" height="40" rx="1" fill="url(#goldGrad)" />
    <path d="M20.75 1.5L25 7H16.5L20.75 1.5Z" fill="url(#goldGrad)" />
    <rect x="26.5" y="14" width="3.5" height="34" rx="1" fill="url(#goldGrad)" />
    <rect x="34" y="22" width="3.5" height="26" rx="1" fill="url(#goldGrad)" />
    <rect x="2" y="47" width="37.5" height="1.5" rx="0.75" fill="url(#goldGrad)" />
  </svg>
);

// Architectural Pillars with arches
export const PillarsIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M3 21h18M4 21V7M8 21V7M12 21V7M16 21V7M20 21V7" />
    <path d="M4 7c0-2.2 1.8-4 4-4s4 1.8 4 4" />
    <path d="M12 7c0-2.2 1.8-4 4-4s4 1.8 4 4" />
    <path d="M2 3h20" />
  </svg>
);

// Nature / Sprout Icon
export const SproutIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M7 20h10" />
    <path d="M12 20v-8" />
    <path d="M12 12c-3.5 0-6-2.5-6-6 4 0 6 2 6 6z" />
    <path d="M12 9c3 0 5-2 5-5-3.5 0-5 2-5 5z" />
  </svg>
);

// Finer Materials (Grid Blocks) Icon
export const GridBlocksIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="7" height="7" rx="1.5" />
    <rect x="14" y="3" width="7" height="7" rx="1.5" />
    <rect x="3" y="14" width="7" height="7" rx="1.5" />
    <rect x="14" y="14" width="7" height="7" rx="1.5" />
  </svg>
);

// Everyday Comfort (Armchair/Sofa)
export const ArmchairIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3" />
    <path d="M3 11a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5z" />
    <path d="M6 18v3" />
    <path d="M18 18v3" />
    <path d="M8 10v2" />
    <path d="M16 10v2" />
  </svg>
);

// Diamond / Legacy of Value
export const DiamondIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M6 3h12l4 6-10 12L2 9l4-6z" />
    <path d="M2 9h20" />
    <path d="M10 3l-4 6 6 12 6-12-4-6" />
  </svg>
);

// Compass & Ruler (Exceptional Design)
export const CompassRulerIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="5" r="2" />
    <path d="M12 7v3" />
    <path d="M4 21l7-11 7 11" />
    <path d="M7 16h10" />
    <path d="M3 3l18 18" strokeDasharray="2 2" strokeOpacity="0.5" />
  </svg>
);

// Handshake
export const HandshakeIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M11 15h2l4-4-2-2-4 4-2-2-4 4 3 3" />
    <path d="M18 11l3-3a2 2 0 0 0-3-3l-3 3" />
    <path d="M2 13l4-4 2 2" />
    <path d="M16 7l1.5-1.5" />
    <circle cx="7" cy="17" r="1.5" />
    <path d="M8.5 17H13" />
  </svg>
);

// Leaf / Eco
export const LeafIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M11 20A7 7 0 0 1 4 13C4 7 11 3 20 3c0 9-4 16-9 17z" />
    <path d="M4 13c7 0 12-4 16-10" />
  </svg>
);

// Shield / Quality
export const ShieldIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    <path d="M12 8v8" />
    <path d="M8 12h8" />
  </svg>
);

// Calendar
export const CalendarIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="4" width="18" height="18" rx="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
    <circle cx="8" cy="14" r="1" fill="#c9974f" />
    <circle cx="12" cy="14" r="1" fill="#c9974f" />
    <circle cx="16" cy="14" r="1" fill="#c9974f" />
    <circle cx="8" cy="18" r="1" fill="#c9974f" />
    <circle cx="12" cy="18" r="1" fill="#c9974f" />
  </svg>
);

// User / Leader
export const UserIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);

// House
export const HouseIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    <path d="M9 22V12h6v10" />
  </svg>
);

// Construction Crane / Tower
export const CraneIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 22V4l16-2v3L8 7" />
    <path d="M8 7v15" />
    <path d="M4 14h4" />
    <path d="M20 5v6" />
    <circle cx="20" cy="13" r="2" />
  </svg>
);

// Family / People Community
export const FamilyIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
  </svg>
);

// Pin Location
export const PinLocationIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
    <circle cx="12" cy="10" r="3" />
  </svg>
);

// Vision Eye
export const VisionEyeIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
    <circle cx="12" cy="12" r="3" />
    <path d="M12 9v1" />
  </svg>
);

// Mission Target
export const MissionTargetIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="12" r="6" />
    <circle cx="12" cy="12" r="2" fill="#c9974f" />
  </svg>
);

// Living Difference Icons
export const SofaIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 11V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3" />
    <path d="M3 11a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4z" />
    <path d="M4 17v2" />
    <path d="M20 17v2" />
    <path d="M8 11v-2" />
    <path d="M16 11v-2" />
  </svg>
);

export const AmenitiesIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M18 10V4" />
    <path d="M14 6l4-2 4 2" />
    <path d="M3 18l5-3 5 3 8-5" />
    <path d="M3 21h18" />
    <circle cx="7" cy="7" r="2.5" />
  </svg>
);

export const ConciergeBellIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 4v2" />
    <path d="M10 4h4" />
    <path d="M4 17a8 8 0 0 1 16 0H4z" />
    <path d="M2 19h20" />
    <path d="M12 10v3" />
  </svg>
);

export const HouseShieldIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M3 10.5L12 3l9 7.5v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-9z" />
    <path d="M9 21v-7a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v7" />
    <circle cx="12" cy="7.5" r="0.75" fill="#c9974f" />
  </svg>
);

export const KeyIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="7.5" cy="15.5" r="4.5" />
    <path d="M10.8 12.2L20.5 2.5" />
    <path d="M17.5 5.5L20 8" />
    <path d="M15 8l2 2" />
  </svg>
);

export const ShieldEyeIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    <circle cx="12" cy="11" r="2.5" />
  </svg>
);

export const CocktailIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="#c9974f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M8 22h8" />
    <path d="M12 15v7" />
    <path d="M6 3l6 9 6-9H6z" />
    <path d="M7.5 6h9" />
  </svg>
);

// Dynamic icon resolver helper
export const IconResolver: React.FC<{ name: string; className?: string }> = ({ name, className = "w-6 h-6" }) => {
  switch (name) {
    case 'pillars':
      return <PillarsIcon className={className} />;
    case 'sprout':
    case 'leaf':
      return <SproutIcon className={className} />;
    case 'grid-blocks':
      return <GridBlocksIcon className={className} />;
    case 'armchair':
    case 'sofa-relax':
      return <ArmchairIcon className={className} />;
    case 'diamond':
    case 'diamond-sparkle':
      return <DiamondIcon className={className} />;
    case 'compass-ruler':
      return <CompassRulerIcon className={className} />;
    case 'handshake':
      return <HandshakeIcon className={className} />;
    case 'shield':
      return <ShieldIcon className={className} />;
    case 'calendar':
      return <CalendarIcon className={className} />;
    case 'user':
      return <UserIcon className={className} />;
    case 'house':
      return <HouseIcon className={className} />;
    case 'crane':
      return <CraneIcon className={className} />;
    case 'family':
      return <FamilyIcon className={className} />;
    case 'pin':
      return <PinLocationIcon className={className} />;
    case 'vision':
      return <VisionEyeIcon className={className} />;
    case 'mission':
      return <MissionTargetIcon className={className} />;
    case 'sofa':
      return <SofaIcon className={className} />;
    case 'amenities':
      return <AmenitiesIcon className={className} />;
    case 'bell':
      return <ConciergeBellIcon className={className} />;
    case 'shield-house':
      return <HouseShieldIcon className={className} />;
    case 'key':
      return <KeyIcon className={className} />;
    case 'camera':
      return <ShieldEyeIcon className={className} />;
    case 'cocktail':
      return <CocktailIcon className={className} />;
    default:
      return <PillarsIcon className={className} />;
  }
};

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  Waves, 
  Sun, 
  Wind, 
  Sparkles, 
  ChevronUp, 
  ChevronDown,
  Music
} from 'lucide-react';
import { 
  ambientAudioEngine, 
  SOUNDSCAPES, 
  SoundscapeType, 
  SoundscapeInfo 
} from '../lib/ambientAudioEngine';

interface AmbientSoundscapeControllerProps {
  className?: string;
}

export const AmbientSoundscapeController: React.FC<AmbientSoundscapeControllerProps> = ({
  className = '',
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSoundscape, setCurrentSoundscape] = useState<SoundscapeType>('coastal-waves');
  const [volume, setVolume] = useState(35);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    // Sync initial state
    setIsPlaying(ambientAudioEngine.getIsPlaying());
    setCurrentSoundscape(ambientAudioEngine.getCurrentSoundscape());
    setVolume(Math.round(ambientAudioEngine.getVolume() * 100));

    return () => {
      // Audio engine continues or cleanly manages itself
    };
  }, []);

  const handleTogglePlay = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (isPlaying) {
      ambientAudioEngine.stop();
      setIsPlaying(false);
    } else {
      await ambientAudioEngine.play(currentSoundscape);
      setIsPlaying(true);
    }
  };

  const handleSelectSoundscape = async (id: SoundscapeType) => {
    setCurrentSoundscape(id);
    if (isPlaying) {
      await ambientAudioEngine.play(id);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    ambientAudioEngine.setVolume(newVol / 100);
    if (newVol > 0 && !isPlaying) {
      // Optional
    }
  };

  const getIcon = (type: SoundscapeType) => {
    switch (type) {
      case 'coastal-waves':
        return <Waves className="w-4 h-4 text-[#c9974f]" />;
      case 'villa-sunset':
        return <Sun className="w-4 h-4 text-[#c9974f]" />;
      case 'tropical-breeze':
        return <Wind className="w-4 h-4 text-[#c9974f]" />;
      default:
        return <Music className="w-4 h-4 text-[#c9974f]" />;
    }
  };

  const activeInfo = SOUNDSCAPES.find((s) => s.id === currentSoundscape) || SOUNDSCAPES[0];

  return (
    <div className={`relative z-40 ${className}`}>
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.95 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="absolute bottom-14 left-0 w-72 sm:w-80 bg-[#121212]/95 border border-[#c9974f]/50 rounded-xl p-4 shadow-[0_12px_40px_rgba(0,0,0,0.8)] backdrop-blur-xl mb-2 text-white"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#252019]">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-[#1b1712] border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f]">
                  <Sparkles className="w-3 h-3 text-[#c9974f]" />
                </div>
                <div>
                  <h4 className="font-serif text-xs font-bold tracking-wider text-white uppercase">
                    Ambient Luxury
                  </h4>
                  <p className="text-[9.5px] text-[#8e8e8e] font-sans">
                    Organic Goan Coastal Soundscapes
                  </p>
                </div>
              </div>

              {/* Master Play/Pause in Header */}
              <button
                onClick={handleTogglePlay}
                className={`w-7 h-7 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  isPlaying
                    ? 'bg-[#c9974f] text-black shadow-[0_0_12px_rgba(201,151,79,0.5)]'
                    : 'bg-[#201c17] text-[#c9974f] hover:bg-[#c9974f] hover:text-black border border-[#c9974f]/40'
                }`}
                title={isPlaying ? 'Pause Soundscape' : 'Play Soundscape'}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
              </button>
            </div>

            {/* Soundscape Options */}
            <div className="space-y-1.5 py-3">
              <span className="text-[9.5px] uppercase tracking-widest text-[#888] font-mono block">
                Select Atmosphere
              </span>
              {SOUNDSCAPES.map((item) => {
                const isSelected = currentSoundscape === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectSoundscape(item.id)}
                    className={`w-full text-left p-2 rounded-lg transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-[#221b14] border border-[#c9974f]/60'
                        : 'bg-[#181818]/60 hover:bg-[#1f1a14] border border-transparent hover:border-[#382c20]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-7 h-7 rounded-full bg-[#121212] border border-[#332c22] flex items-center justify-center shrink-0">
                        {getIcon(item.id)}
                      </div>
                      <div className="min-w-0">
                        <p className={`text-[11px] font-serif font-bold truncate ${isSelected ? 'text-[#e0b877]' : 'text-white'}`}>
                          {item.name}
                        </p>
                        <p className="text-[9px] text-[#777] truncate">
                          {item.subtitle}
                        </p>
                      </div>
                    </div>

                    {isSelected && isPlaying && (
                      <div className="flex items-center gap-0.5 px-1.5 py-1">
                        <span className="w-0.5 h-2.5 bg-[#c9974f] animate-pulse rounded-full" />
                        <span className="w-0.5 h-4 bg-[#c9974f] animate-pulse delay-75 rounded-full" />
                        <span className="w-0.5 h-2 bg-[#c9974f] animate-pulse delay-150 rounded-full" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Volume Slider & Controls */}
            <div className="pt-2 border-t border-[#252019] space-y-1.5">
              <div className="flex items-center justify-between text-[10px] text-[#8e8e8e]">
                <div className="flex items-center gap-1.5">
                  {volume === 0 ? <VolumeX className="w-3.5 h-3.5 text-[#666]" /> : <Volume2 className="w-3.5 h-3.5 text-[#c9974f]" />}
                  <span>Volume</span>
                </div>
                <span className="font-mono text-[#c9974f] font-semibold">{volume}%</span>
              </div>

              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => handleVolumeChange(Number(e.target.value))}
                className="w-full h-1.5 bg-[#252019] rounded-lg appearance-none cursor-pointer accent-[#c9974f]"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Pill Toggle Button */}
      <div className="flex items-center">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`px-3 py-2 rounded-full border transition-all duration-300 backdrop-blur-md flex items-center gap-2 cursor-pointer shadow-[0_4px_20px_rgba(0,0,0,0.6)] ${
            isPlaying
              ? 'bg-[#18130d]/95 border-[#c9974f] text-[#f5d79e]'
              : 'bg-[#121212]/90 hover:bg-[#1c1712] border-[#332c22] hover:border-[#c9974f]/70 text-[#a0a0a0] hover:text-white'
          }`}
          title="Toggle Ambient Luxury Soundscape"
        >
          {/* Wave/Music Icon */}
          <div className="relative flex items-center justify-center">
            {isPlaying ? (
              <div className="flex items-center gap-0.5 h-3.5">
                <span className="w-0.5 h-2 bg-[#c9974f] animate-pulse rounded-full" />
                <span className="w-0.5 h-3.5 bg-[#c9974f] animate-pulse delay-100 rounded-full" />
                <span className="w-0.5 h-1.5 bg-[#c9974f] animate-pulse delay-200 rounded-full" />
                <span className="w-0.5 h-3 bg-[#c9974f] animate-pulse delay-300 rounded-full" />
              </div>
            ) : (
              <Volume2 className="w-3.5 h-3.5 text-[#c9974f]" />
            )}
          </div>

          {/* Label */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold tracking-wider uppercase font-sans">
              {isPlaying ? activeInfo.name : 'Ambient Soundscape'}
            </span>
          </div>

          {/* Quick Play/Pause Icon Button on pill */}
          <span
            onClick={handleTogglePlay}
            className="w-5 h-5 rounded-full bg-black/40 hover:bg-[#c9974f] hover:text-black flex items-center justify-center text-[#c9974f] transition-colors ml-0.5"
          >
            {isPlaying ? <Pause className="w-2.5 h-2.5" /> : <Play className="w-2.5 h-2.5 ml-0.5" />}
          </span>

          {/* Expansion Chevron */}
          {isExpanded ? (
            <ChevronDown className="w-3.5 h-3.5 text-[#888]" />
          ) : (
            <ChevronUp className="w-3.5 h-3.5 text-[#888]" />
          )}
        </button>
      </div>
    </div>
  );
};

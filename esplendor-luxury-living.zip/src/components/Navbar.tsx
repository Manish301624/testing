import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Mail, MapPin, Sparkles, User, Bookmark } from 'lucide-react';
import { PageRoute } from '../types';
import { EsplendorLogoIcon } from './Icons';
import { GoldButton } from './GoldButton';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useAuth } from '../lib/AuthContext';
import { useLanguage } from '../lib/LanguageContext';

interface NavbarProps {
  currentPage: PageRoute;
  onNavigate: (page: PageRoute) => void;
  onOpenConsultation: () => void;
  onOpenGeminiChat: () => void;
  onOpenClientPortfolio: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  onOpenConsultation,
  onOpenGeminiChat,
  onOpenClientPortfolio,
}) => {
  const { user, savedProperties } = useAuth();
  const { t } = useLanguage();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { label: string; route: PageRoute }[] = [
    { label: t('nav.home', 'HOME'), route: 'home' },
    { label: t('nav.ourStory', 'OUR STORY'), route: 'our-story' },
    { label: t('nav.luxuryHomes', 'LUXURY HOMES'), route: 'luxury-homes' },
    { label: t('nav.livingDifference', 'THE LIVING DIFFERENCE'), route: 'the-living-difference' },
    { label: t('nav.contact', 'CONTACT'), route: 'contact' },
  ];

  const handleNavClick = (route: PageRoute) => {
    onNavigate(route);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#0a0a0a]/95 backdrop-blur-md py-3 border-b border-[#252019] shadow-2xl'
            : 'bg-gradient-to-b from-[#0a0a0a]/95 via-[#0a0a0a]/60 to-transparent py-4 sm:py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Logo */}
          <button
            id="nav-logo-btn"
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3.5 group text-left cursor-pointer"
          >
            <EsplendorLogoIcon className="w-6 h-8 text-[#c9974f] transition-transform duration-300 group-hover:scale-105" />
            <div className="flex flex-col">
              <span className="font-serif tracking-[0.25em] text-lg font-bold text-white group-hover:text-[#c9974f] transition-colors duration-300">
                ESPLENDOR
              </span>
              <span className="text-[7.5px] tracking-[0.28em] text-[#c9974f] font-sans font-medium uppercase -mt-0.5">
                {t('nav.brandTagline', 'CRAFTING TIMELESS LIVING')}
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-8">
            {navItems.map((item) => {
              const isActive = currentPage === item.route;
              return (
                <button
                  key={item.route}
                  id={`nav-link-${item.route}`}
                  onClick={() => handleNavClick(item.route)}
                  className="relative py-2 text-[11px] font-medium tracking-[0.16em] uppercase transition-colors duration-200 cursor-pointer"
                >
                  <span
                    className={`${
                      isActive ? 'text-[#c9974f] font-semibold' : 'text-[#d0d0d0] hover:text-white'
                    }`}
                  >
                    {item.label}
                  </span>
                  {/* Golden active indicator dot */}
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#c9974f] shadow-[0_0_8px_#c9974f]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* AI Tools & User Actions */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Multi-Language Switcher */}
            <LanguageSwitcher dropdownAlign="right" />

            {/* Gemini AI Concierge Trigger */}
            <button
              onClick={onOpenGeminiChat}
              className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#1c1813] to-[#2b2214] hover:from-[#2a2218] hover:to-[#3d301c] border border-[#c9974f]/50 text-[11px] text-[#f5d79e] font-semibold tracking-wider uppercase transition-all duration-300 flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(201,151,79,0.2)]"
              title="Chat with Gemini AI Concierge"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#c9974f] animate-pulse" />
              <span>{t('nav.aiConcierge', 'AI Concierge')}</span>
            </button>

            {/* Auth / Client Portfolio */}
            <button
              onClick={onOpenClientPortfolio}
              className="relative p-2 rounded-full bg-[#161616] hover:bg-[#201d18] border border-[#332c22] hover:border-[#c9974f] text-[#c9974f] transition-colors cursor-pointer"
              title={user ? `Signed in as ${user.displayName || user.email}` : `${t('nav.portfolio', 'Client Portfolio')} & Sign In`}
            >
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || "User"}
                  className="w-5 h-5 rounded-full object-cover ring-1 ring-[#c9974f]"
                />
              ) : (
                <User className="w-4 h-4" />
              )}
              {savedProperties.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#c9974f] text-black text-[9px] font-bold flex items-center justify-center">
                  {savedProperties.length}
                </span>
              )}
            </button>

            {/* Primary CTA */}
            <GoldButton
              id="nav-consultation-btn"
              label={t('nav.connect', "LET'S CONNECT")}
              onClick={onOpenConsultation}
              size="sm"
              variant="solid-dark"
            />
          </div>

          {/* Mobile Right Bar */}
          <div className="lg:hidden flex items-center gap-1.5 sm:gap-2">
            {/* Mobile Compact Language Switcher */}
            <LanguageSwitcher dropdownAlign="right" />

            <button
              onClick={onOpenGeminiChat}
              className="p-2 rounded-full bg-[#1b1712] border border-[#c9974f]/60 text-[#c9974f] cursor-pointer"
              aria-label="Open AI Concierge"
            >
              <Sparkles className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenClientPortfolio}
              className="relative p-2 rounded-full bg-[#161616] border border-[#332c22] text-[#c9974f] cursor-pointer"
              aria-label="Open Portfolio"
            >
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt="User"
                  className="w-4 h-4 rounded-full object-cover"
                />
              ) : (
                <User className="w-4 h-4" />
              )}
            </button>

            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#c9974f] hover:text-white transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-[#0a0a0a]/98 backdrop-blur-xl lg:hidden flex flex-col pt-16 px-6 pb-8 animate-fadeIn overflow-y-auto">
          {/* Top close bar in mobile drawer */}
          <div className="flex items-center justify-between pb-4 border-b border-[#252019]">
            <div className="flex items-center gap-2.5">
              <EsplendorLogoIcon className="w-5 h-6 text-[#c9974f]" />
              <span className="font-serif tracking-[0.2em] text-sm font-bold text-white">
                ESPLENDOR
              </span>
            </div>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="w-9 h-9 rounded-full bg-[#161616] border border-[#332c22] flex items-center justify-center text-[#c9974f] hover:text-white"
              aria-label="Close menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-col gap-4 my-auto py-4">
            {navItems.map((item) => {
              const isActive = currentPage === item.route;
              return (
                <button
                  key={item.route}
                  onClick={() => handleNavClick(item.route)}
                  className="flex items-center justify-between text-left py-2.5 border-b border-[#252019] text-sm sm:text-base tracking-[0.18em] uppercase transition-colors"
                >
                  <span className={isActive ? 'text-[#c9974f] font-semibold' : 'text-white'}>
                    {item.label}
                  </span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-[#c9974f]" />}
                </button>
              );
            })}

            {/* Language Switcher in Drawer */}
            <div className="pt-2">
              <LanguageSwitcher variant="expanded" />
            </div>

            {/* AI Tools inside mobile drawer */}
            <div className="grid grid-cols-1 gap-3 pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenGeminiChat();
                }}
                className="p-3 rounded-lg bg-[#1b1712] border border-[#c9974f]/40 text-left space-y-1 hover:border-[#c9974f] transition-colors"
              >
                <Sparkles className="w-4 h-4 text-[#c9974f]" />
                <p className="text-xs text-white font-serif font-bold">{t('nav.aiConcierge', 'AI Concierge')}</p>
                <p className="text-[10px] text-[#888]">{t('nav.aiConciergeSub', 'Gemini Multi-Turn Advisory')}</p>
              </button>
            </div>

            <div className="pt-2">
              <GoldButton
                label={t('nav.scheduleConsultation', 'SCHEDULE A CONSULTATION')}
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenConsultation();
                }}
                variant="solid-gold"
                size="md"
                className="w-full justify-center"
              />
            </div>
          </div>

          {/* Drawer footer details */}
          <div className="pt-4 border-t border-[#252019] text-xs text-[#8a8a8a] space-y-1.5">
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-[#c9974f] shrink-0" />
              <span className="truncate">Assagao & Baga, North Goa, India</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-[#c9974f] shrink-0" />
              <span>+91 77770 00000</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-[#c9974f] shrink-0" />
              <span>info@esplendorhomes.com</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};


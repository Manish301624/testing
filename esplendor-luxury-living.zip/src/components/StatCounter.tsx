import React, { useEffect, useRef, useState } from 'react';
import { IconResolver } from './Icons';

interface StatCounterProps {
  value: number;
  suffix?: string;
  prefix?: string;
  textValue?: string;
  label: string;
  iconName: string;
  duration?: number;
}

export const StatCounter: React.FC<StatCounterProps> = ({
  value,
  suffix = '',
  prefix = '',
  textValue,
  label,
  iconName,
  duration = 1800
}) => {
  const [displayCount, setDisplayCount] = useState<number>(textValue ? 0 : 0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (textValue) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          let startTime: number | null = null;

          const animate = (currentTime: number) => {
            if (!startTime) startTime = currentTime;
            const progress = Math.min((currentTime - startTime) / duration, 1);
            // Ease out cubic
            const easeProgress = 1 - Math.pow(1 - progress, 3);
            setDisplayCount(Math.floor(easeProgress * value));

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setDisplayCount(value);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.2 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, [value, duration, hasAnimated, textValue]);

  return (
    <div
      ref={containerRef}
      className="flex flex-col items-center text-center p-6 bg-[#0e0e0e] border border-[#252019] rounded-sm hover:border-[#c9974f]/50 hover:bg-[#141414] transition-all duration-300 group"
    >
      <div className="w-12 h-12 rounded-full border border-[#c9974f]/30 flex items-center justify-center mb-4 text-[#c9974f] group-hover:border-[#c9974f] group-hover:scale-110 transition-all duration-300">
        <IconResolver name={iconName} className="w-5 h-5" />
      </div>

      <div className="font-serif text-3xl md:text-4xl text-[#c9974f] font-semibold mb-1 tracking-tight">
        {textValue ? (
          <span>{textValue}</span>
        ) : (
          <span>
            {prefix}
            {displayCount}
            {suffix}
          </span>
        )}
      </div>

      <span className="text-[10px] md:text-[11px] font-sans font-medium tracking-[0.16em] uppercase text-[#a0a0a0] group-hover:text-[#e0e0e0] transition-colors duration-200">
        {label}
      </span>
    </div>
  );
};

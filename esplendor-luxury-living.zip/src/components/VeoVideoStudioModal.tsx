import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Film, 
  Upload, 
  Sparkles, 
  Loader2, 
  Play, 
  Pause, 
  Download, 
  RefreshCw, 
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Ratio,
  Sliders,
  Bookmark,
  Share2,
  Lock
} from 'lucide-react';
import { GoldButton } from './GoldButton';
import { useAuth } from '../lib/AuthContext';

interface VeoVideoStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialImageUrl?: string;
  initialTitle?: string;
}

const sampleArchitecturalScenes = [
  {
    title: 'Sunset over Casa Bella Infinity Pool',
    prompt: 'Cinematic slow-motion drone flyover above a luxury Portuguese modern villa in Goa at golden hour sunset, water surface glowing and coconut palms swaying gently in the sea breeze, 4K architectural cinematography',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
  },
  {
    title: 'Vista Verde Riverfront Salon',
    prompt: 'Smooth cinematic push-in through double-height floor-to-ceiling glass sliding doors into a designer living room overlooking a serene Goan river, warm atmospheric ambient lighting',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
  },
  {
    title: 'Ocean Crest Cliffside Horizon',
    prompt: 'Breathtaking orbital pan around a cliffside luxury penthouse terrace with Arabian Sea waves crashing softly in the background, warm sunset tones, hyperrealistic architectural render',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
  }
];

export const VeoVideoStudioModal: React.FC<VeoVideoStudioModalProps> = ({
  isOpen,
  onClose,
  initialImageUrl,
  initialTitle,
}) => {
  const { user, signInWithGoogle, saveVideoRecord } = useAuth();
  const [selectedImage, setSelectedImage] = useState<string | null>(initialImageUrl || null);
  const [customImageFile, setCustomImageFile] = useState<File | null>(null);
  const [prompt, setPrompt] = useState(
    'Cinematic slow camera pan showcasing contemporary architectural facade with lush tropical landscaping and golden hour ambient light reflections, 4k resolution.'
  );
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressStatus, setProgressStatus] = useState<string>('');
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Sync initial image if passed
  React.useEffect(() => {
    if (initialImageUrl) {
      setSelectedImage(initialImageUrl);
      if (initialTitle) {
        setPrompt(`Cinematic luxury architectural tour of ${initialTitle} in Goa with sun rays filtering through tropical palm trees and ambient water ripples, 4k ultra-realistic`);
      }
    }
  }, [initialImageUrl, initialTitle]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please upload a valid image file (JPG, PNG, WebP).');
      return;
    }

    setErrorMessage(null);
    setCustomImageFile(file);

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSample = (sample: typeof sampleArchitecturalScenes[0]) => {
    setSelectedImage(sample.image);
    setPrompt(sample.prompt);
    setCustomImageFile(null);
    setErrorMessage(null);
  };

  const handleGenerateVideo = async () => {
    if (!prompt.trim()) {
      setErrorMessage('Please provide a cinematic animation prompt.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);
    setGeneratedVideoUrl(null);
    setSavedSuccess(false);
    setProgressStatus('Initializing Veo 3.1 video generation model...');

    try {
      let imageBase64: string | undefined = undefined;
      let mimeType = 'image/jpeg';

      if (selectedImage) {
        if (selectedImage.startsWith('data:image')) {
          imageBase64 = selectedImage;
          const match = selectedImage.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,/);
          if (match) mimeType = match[1];
        } else {
          // Fetch remote image and convert to base64
          setProgressStatus('Optimizing architectural rendering frame...');
          const imgFetch = await fetch(selectedImage);
          const blob = await imgFetch.blob();
          mimeType = blob.type || 'image/jpeg';
          const buffer = await blob.arrayBuffer();
          const bytes = new Uint8Array(buffer);
          let binary = '';
          for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
          }
          imageBase64 = `data:${mimeType};base64,${btoa(binary)}`;
        }
      }

      setProgressStatus('Veo AI rendering photorealistic frames & motion vectors (~20-40s)...');

      const response = await fetch('/api/ai/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          aspectRatio,
          imageBase64,
          mimeType,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to render video with Veo.');
      }

      setGeneratedVideoUrl(data.videoUrl);
      setProgressStatus('Video synthesis complete!');

      // Save to user's Firestore portfolio if logged in
      if (user) {
        try {
          await saveVideoRecord({
            title: initialTitle || 'Esplendor Architectural Animation',
            prompt,
            sourceImageUrl: selectedImage || undefined,
            videoUrl: data.videoUrl,
            aspectRatio,
            status: 'completed',
          });
          setSavedSuccess(true);
        } catch (saveErr) {
          console.warn('Firestore video auto-save notice:', saveErr);
        }
      }
    } catch (err: any) {
      console.error('Video generation error:', err);
      setErrorMessage(err.message || 'An error occurred generating the video. Please check prompt and try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadVideo = () => {
    if (!generatedVideoUrl) return;
    const a = document.createElement('a');
    a.href = generatedVideoUrl;
    a.download = `esplendor-cinematic-veo-${Date.now()}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-4xl bg-[#0e0e0e] border border-[#c9974f]/40 rounded-xl shadow-2xl overflow-hidden max-h-[94vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 bg-[#141414] border-b border-[#252019] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#1b1712] border border-[#c9974f] flex items-center justify-center text-[#c9974f] shadow-[0_0_15px_rgba(201,151,79,0.3)] shrink-0">
              <Film className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-serif text-base sm:text-xl font-bold text-white tracking-wide truncate">
                  Veo Cinematic Video Animator
                </h3>
                <span className="px-2 py-0.5 rounded text-[8.5px] sm:text-[9.5px] bg-[#c9974f]/15 border border-[#c9974f]/40 text-[#c9974f] font-mono uppercase font-semibold shrink-0">
                  veo-3.1-fast-generate-preview
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-[#8a8a8a] mt-0.5 truncate sm:whitespace-normal">
                Transform any luxury residence photo into cinematic 4K motion videos.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/60 border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-colors cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5 sm:space-y-6">
          {errorMessage && (
            <div className="p-3.5 bg-red-950/60 border border-red-800/60 text-red-200 text-xs rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6">
            {/* Left Column: Image Source & Config */}
            <div className="lg:col-span-6 space-y-4 sm:space-y-5">
              {/* Photo Selector */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-[#a0a0a0] font-semibold mb-2 flex items-center justify-between">
                  <span>1. Select or Upload Residence Photo</span>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="text-[#c9974f] hover:underline normal-case font-normal text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Upload className="w-3 h-3" />
                    <span>Upload Custom Photo</span>
                  </button>
                </label>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                {selectedImage ? (
                  <div className="relative rounded-lg overflow-hidden border border-[#332c22] aspect-video bg-black group">
                    <img
                      src={selectedImage}
                      alt="Source for Veo"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3 justify-between">
                      <span className="text-[11px] text-white/90 bg-black/60 px-2 py-1 rounded backdrop-blur-sm">
                        Source Frame
                      </span>
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="text-xs bg-[#c9974f] text-black font-semibold px-2.5 py-1 rounded hover:bg-[#e0b877] transition-colors cursor-pointer"
                      >
                        Change Photo
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-[#332c22] hover:border-[#c9974f] rounded-lg p-6 text-center cursor-pointer transition-colors bg-[#141414]"
                  >
                    <ImageIcon className="w-8 h-8 text-[#c9974f] mx-auto mb-2 opacity-80" />
                    <p className="text-xs text-white font-medium">Click to upload residence picture</p>
                    <p className="text-[11px] text-[#777] mt-1">Supports JPG, PNG, WebP up to 10MB</p>
                  </div>
                )}
              </div>

              {/* Sample Estates */}
              <div>
                <span className="block text-[11px] uppercase tracking-wider text-[#888] font-medium mb-2">
                  Or pick from curated Esplendor estates:
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {sampleArchitecturalScenes.map((sample, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSelectSample(sample)}
                      className={`relative rounded-md overflow-hidden border text-left aspect-video transition-all cursor-pointer ${
                        selectedImage === sample.image
                          ? 'border-[#c9974f] ring-2 ring-[#c9974f]/40'
                          : 'border-[#26211a] hover:border-[#554737]'
                      }`}
                    >
                      <img src={sample.image} alt={sample.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 hover:bg-transparent transition-colors" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Aspect Ratio Selector */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-[#a0a0a0] font-semibold mb-2">
                  2. Video Aspect Ratio
                </label>
                <div className="grid grid-cols-1 xs:grid-cols-2 gap-2 sm:gap-3">
                  <button
                    onClick={() => setAspectRatio('16:9')}
                    className={`p-2.5 sm:p-3 rounded-lg border flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                      aspectRatio === '16:9'
                        ? 'bg-[#c9974f]/15 border-[#c9974f] text-[#c9974f] shadow-[0_0_10px_rgba(201,151,79,0.2)]'
                        : 'bg-[#141414] border-[#26211a] text-[#888] hover:text-white'
                    }`}
                  >
                    <Ratio className="w-4 h-4 shrink-0" />
                    <span>16:9 Landscape</span>
                  </button>

                  <button
                    onClick={() => setAspectRatio('9:16')}
                    className={`p-2.5 sm:p-3 rounded-lg border flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                      aspectRatio === '9:16'
                        ? 'bg-[#c9974f]/15 border-[#c9974f] text-[#c9974f] shadow-[0_0_10px_rgba(201,151,79,0.2)]'
                        : 'bg-[#141414] border-[#26211a] text-[#888] hover:text-white'
                    }`}
                  >
                    <Ratio className="w-4 h-4 rotate-90 shrink-0" />
                    <span>9:16 Portrait Reel</span>
                  </button>
                </div>
              </div>

              {/* Prompt Input */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-[#a0a0a0] font-semibold mb-2">
                  3. Cinematic Motion Description
                </label>
                <textarea
                  rows={3}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe camera movement, lighting changes, weather or water dynamics..."
                  className="w-full bg-[#161616] border border-[#2c261e] focus:border-[#c9974f] focus:outline-none p-3 rounded-lg text-white placeholder-[#555] text-xs transition-colors resize-none"
                />
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerateVideo}
                disabled={isGenerating || !selectedImage}
                className="w-full py-3 sm:py-3.5 px-4 sm:px-6 rounded-lg bg-[#c9974f] hover:bg-[#e0b877] text-black font-semibold text-xs tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(201,151,79,0.35)] disabled:opacity-50 cursor-pointer"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Generating with Veo 3.1...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Animate Residence into Video</span>
                  </>
                )}
              </button>
            </div>

            {/* Right Column: Output & Video Player */}
            <div className="lg:col-span-6 flex flex-col justify-between bg-[#121212] border border-[#262018] rounded-xl p-5">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-serif text-sm font-bold text-white tracking-wide flex items-center gap-2">
                    <Film className="w-4 h-4 text-[#c9974f]" />
                    <span>Veo Video Output</span>
                  </h4>
                  {generatedVideoUrl && (
                    <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded font-mono">
                      RENDER COMPLETE
                    </span>
                  )}
                </div>

                {isGenerating ? (
                  <div className="aspect-video bg-black/60 rounded-lg border border-[#332c22] flex flex-col items-center justify-center p-6 text-center space-y-4">
                    <div className="relative">
                      <Loader2 className="w-12 h-12 text-[#c9974f] animate-spin opacity-80" />
                      <Sparkles className="w-5 h-5 text-[#c9974f] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                    </div>
                    <div>
                      <p className="text-sm text-white font-medium">{progressStatus}</p>
                      <p className="text-xs text-[#888] mt-1">Veo synthesizes lighting physics & temporal coherence</p>
                    </div>
                  </div>
                ) : generatedVideoUrl ? (
                  <div className="space-y-4">
                    <div className={`relative bg-black rounded-lg overflow-hidden border border-[#c9974f]/50 shadow-2xl mx-auto ${
                      aspectRatio === '9:16' ? 'max-w-[240px] aspect-[9/16]' : 'aspect-video w-full'
                    }`}>
                      <video
                        ref={videoRef}
                        src={generatedVideoUrl}
                        autoPlay
                        loop
                        playsInline
                        controls
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-2">
                      <GoldButton
                        label="DOWNLOAD MP4"
                        onClick={handleDownloadVideo}
                        variant="solid-gold"
                        size="sm"
                        className="flex-1 justify-center"
                      />

                      <button
                        onClick={handleGenerateVideo}
                        className="px-4 py-2.5 rounded-lg bg-[#1a1a1a] hover:bg-[#252525] border border-[#332c22] text-[#c9974f] text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Re-generate</span>
                      </button>
                    </div>

                    {user && savedSuccess && (
                      <div className="p-2.5 bg-[#171c14] border border-emerald-800/40 rounded text-emerald-300 text-[11px] flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Saved to your private client Firebase portfolio.</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="aspect-video bg-black/40 rounded-lg border border-dashed border-[#2b251e] flex flex-col items-center justify-center p-6 text-center text-[#777]">
                    <Film className="w-10 h-10 text-[#554737] mb-2" />
                    <p className="text-xs font-medium text-[#aaa]">No animation generated yet</p>
                    <p className="text-[11px] max-w-xs mt-1">
                      Choose an architectural image, write or customize your prompt, and click animate to generate with Veo 3.1.
                    </p>
                  </div>
                )}
              </div>

              {/* Authentication Status Badge */}
              <div className="pt-3.5 border-t border-[#201c16] mt-4 flex flex-col xs:flex-row items-start xs:items-center justify-between text-[11px] text-[#888] gap-2">
                {user ? (
                  <div className="flex items-center gap-2 min-w-0">
                    <img
                      src={user.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                      alt={user.displayName || 'Client'}
                      className="w-5 h-5 rounded-full border border-[#c9974f] shrink-0"
                    />
                    <span className="truncate">Signed in as <strong className="text-white">{user.displayName || user.email}</strong></span>
                  </div>
                ) : (
                  <div className="flex flex-col xs:flex-row items-start xs:items-center justify-between w-full gap-2">
                    <span className="flex items-center gap-1 text-[#aaa] text-[10.5px]">
                      <Lock className="w-3.5 h-3.5 text-[#c9974f] shrink-0" />
                      <span>Sign in with Google to persist your generated videos</span>
                    </span>
                    <button
                      onClick={signInWithGoogle}
                      className="text-[#c9974f] hover:underline font-semibold cursor-pointer text-xs whitespace-nowrap"
                    >
                      Sign In →
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

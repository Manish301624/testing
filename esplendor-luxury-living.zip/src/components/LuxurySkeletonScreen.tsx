import React from 'react';
import { motion } from 'motion/react';

interface LuxurySkeletonScreenProps {
  pageType?: 'home' | 'our-story' | 'luxury-homes' | 'the-living-difference' | 'contact';
}

export const LuxurySkeletonScreen: React.FC<LuxurySkeletonScreenProps> = ({
  pageType = 'home',
}) => {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } }}
      className="w-full min-h-screen bg-[#0a0a0a] text-white pt-24 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden relative select-none"
      aria-hidden="true"
    >
      {/* Background ambient glow effect */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-[#c9974f]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto space-y-16 relative z-10">
        
        {/* ========================================================
            1. HERO BANNER SKELETON
        ======================================================== */}
        <div className="relative rounded-2xl border border-[#241c14] bg-[#110e0b]/80 p-8 sm:p-14 overflow-hidden">
          {/* Shimmer overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/10 to-transparent -translate-x-full animate-gold-shimmer pointer-events-none" />

          <div className="max-w-3xl space-y-6">
            {/* Eyebrow badge placeholder */}
            <div className="flex items-center gap-3">
              <div className="w-6 h-[1px] bg-[#c9974f]/40" />
              <div className="h-4 w-40 bg-[#1e1711] rounded-full relative overflow-hidden border border-[#33281c]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/20 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
            </div>

            {/* Headline Title Lines */}
            <div className="space-y-3 pt-2">
              <div className="h-10 sm:h-12 w-3/4 bg-[#1e1711] rounded-lg relative overflow-hidden border border-[#2d2217]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/20 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
              <div className="h-10 sm:h-12 w-1/2 bg-[#1e1711] rounded-lg relative overflow-hidden border border-[#2d2217]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/20 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
            </div>

            {/* Subtext Paragraph Lines */}
            <div className="space-y-2 pt-2 max-w-xl">
              <div className="h-3.5 w-full bg-[#18120d] rounded relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/15 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
              <div className="h-3.5 w-5/6 bg-[#18120d] rounded relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/15 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
              <div className="h-3.5 w-2/3 bg-[#18120d] rounded relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/15 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
            </div>

            {/* Action Buttons Placeholders */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <div className="h-11 w-44 rounded-full bg-[#2a1e12] border border-[#c9974f]/40 relative overflow-hidden shadow-[0_0_15px_rgba(201,151,79,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/30 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
              <div className="h-11 w-36 rounded-full bg-[#16110c] border border-[#2d2217] relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/15 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
            </div>
          </div>

          {/* Floating Subtle Watermark Brand Crest */}
          <div className="absolute right-8 bottom-8 hidden md:flex flex-col items-center opacity-30">
            <div className="w-16 h-16 rounded-full border border-[#c9974f]/40 flex items-center justify-center">
              <div className="w-10 h-10 border border-[#c9974f]/30 rotate-45" />
            </div>
            <span className="text-[9px] uppercase tracking-[0.3em] text-[#c9974f] mt-2 font-mono">
              ESPLENDOR
            </span>
          </div>
        </div>

        {/* ========================================================
            2. STATS & ARCHITECTURAL METRICS ROW SKELETON
        ======================================================== */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {[1, 2, 3, 4].map((idx) => (
            <div
              key={idx}
              className="p-6 rounded-xl border border-[#221a13] bg-[#100d0a]/70 relative overflow-hidden space-y-3"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/10 to-transparent -translate-x-full animate-gold-shimmer" />
              <div className="h-8 w-20 bg-[#1c150e] rounded border border-[#2f2216] relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/25 to-transparent -translate-x-full animate-gold-shimmer" />
              </div>
              <div className="h-3 w-28 bg-[#16100b] rounded" />
            </div>
          ))}
        </div>

        {/* ========================================================
            3. LUXURY ESTATES CARDS GRID SKELETON
        ======================================================== */}
        <div className="space-y-6">
          {/* Section Header skeleton */}
          <div className="flex items-end justify-between border-b border-[#1f1812] pb-5">
            <div className="space-y-2">
              <div className="h-3 w-32 bg-[#1b140d] rounded-full border border-[#302316]" />
              <div className="h-8 w-64 bg-[#1f160e] rounded-lg border border-[#332417]" />
            </div>
            <div className="h-9 w-32 bg-[#16100b] rounded-full border border-[#261c13] hidden sm:block" />
          </div>

          {/* Cards Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {[1, 2, 3].map((card) => (
              <div
                key={card}
                className="rounded-xl border border-[#241c14] bg-[#110e0a] overflow-hidden relative space-y-4 pb-6"
              >
                {/* Gold Shimmer Effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#c9974f]/12 to-transparent -translate-x-full animate-gold-shimmer pointer-events-none z-10" />

                {/* Image Placeholder Aspect Box */}
                <div className="aspect-[16/10] w-full bg-[#18120c] relative overflow-hidden border-b border-[#221810]">
                  <div className="absolute top-3 right-3 h-6 w-20 bg-[#24190e]/90 border border-[#c9974f]/30 rounded-full" />
                </div>

                {/* Card Content Lines */}
                <div className="px-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="h-3 w-24 bg-[#1d150e] rounded" />
                    <div className="h-4 w-16 bg-[#261a0f] rounded border border-[#3d2b1a]" />
                  </div>

                  <div className="h-6 w-4/5 bg-[#20160d] rounded-md border border-[#2d1f13]" />

                  <div className="space-y-1.5 pt-1">
                    <div className="h-3 w-full bg-[#16100a] rounded" />
                    <div className="h-3 w-4/5 bg-[#16100a] rounded" />
                  </div>

                  <div className="pt-3 border-t border-[#1a130c] flex items-center justify-between">
                    <div className="h-3 w-28 bg-[#18110a] rounded" />
                    <div className="h-8 w-8 rounded-full bg-[#1e150d] border border-[#332415]" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ========================================================
            4. SUBTLE BOTTOM BRANDING FOOTER SKELETON
        ======================================================== */}
        <div className="pt-8 text-center flex flex-col items-center justify-center gap-3">
          <div className="w-8 h-8 rounded-full border border-[#c9974f]/30 animate-pulse flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-[#c9974f]" />
          </div>
          <p className="text-[11px] uppercase tracking-[0.25em] text-[#8c7355] font-mono">
            Loading Bespoke Sanctuary Assets...
          </p>
        </div>
      </div>
    </motion.div>
  );
};

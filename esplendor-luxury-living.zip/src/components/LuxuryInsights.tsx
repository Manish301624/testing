import React, { useState, useId } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Plus, Minus, Search, Sparkles, HelpCircle, ShieldCheck, ArrowRight } from 'lucide-react';
import { SectionEyebrow } from './SectionEyebrow';
import { GoldButton } from './GoldButton';

export interface InsightFAQItem {
  id: string;
  category: 'architecture' | 'concierge' | 'legal' | 'climate';
  categoryLabel: string;
  question: string;
  answer: string;
  highlight?: string;
}

export const LUXURY_INSIGHTS_DATA: InsightFAQItem[] = [
  {
    id: 'faq-1',
    category: 'architecture',
    categoryLabel: 'Bespoke Architecture',
    question: 'How extensive is the bespoke customization for estate buyers before construction completion?',
    answer:
      'Every Esplendor residence offers an individualized architectural tailoring phase. In collaboration with our lead Portuguese and Goan restoration architects, buyers can customize layout configurations, specify imported natural stone (such as Italian Carrara or honed Portuguese limestone), integrate bespoke walnut cabinetry, and adjust private pool dimensions and courtyard water features prior to handover.',
    highlight: 'Tailored floor plans & imported stone selections with our master architects.',
  },
  {
    id: 'faq-2',
    category: 'concierge',
    categoryLabel: 'Asset & Concierge',
    question: 'What ongoing property management and hospitality services are included for absentee owners?',
    answer:
      'Our dedicated Esplendor Living Concierge provides seamless turnkey asset care. This includes 24/7 biometric site security, daily pool and botanical garden maintenance, HVAC climate cycling during monsoon months, preventive structural audits, and complete pre-arrival provisioning (private chefs, chilled wine cellars, luxury transport, and housekeeping).',
    highlight: 'Complete keyholding, monsoon climate protection, and pre-arrival luxury staging.',
  },
  {
    id: 'faq-3',
    category: 'legal',
    categoryLabel: 'Conveyancing & NRI Advisory',
    question: 'How does Esplendor manage confidential conveyancing, clear titles, and NRI investment compliance?',
    answer:
      'Every parcel of land in the Esplendor portfolio undergoes rigorous 30-year forensic title due diligence conducted by tier-one Goan legal counsels. We facilitate seamless RBI, FEMA, and RERA compliance for Non-Resident Indians (NRIs) and international buyers, offering private institutional escrow structures and non-disclosure agreements.',
    highlight: '100% marketable 30-year vetted freehold titles with dedicated NRI concierge support.',
  },
  {
    id: 'faq-4',
    category: 'climate',
    categoryLabel: 'Climate & Sustainability',
    question: 'How are the estates engineered to withstand the tropical coastal monsoon climate?',
    answer:
      'Our residences fuse indigenous Goan laterite masonry with German high-grade waterproofing membranes, double-glazed UV thermal acoustic fenestration, and subterranean gravity drainage networks. We integrate concealed micro-solar arrays, rainwater harvesting reservoirs, and energy-efficient VRV air filtration to ensure permanent thermal comfort.',
    highlight: 'German waterproofing, laterite thermal massing, and solar micro-grids.',
  },
  {
    id: 'faq-5',
    category: 'concierge',
    categoryLabel: 'Asset & Concierge',
    question: 'Can owners enroll their residence in a curated private rental portfolio for capital yields?',
    answer:
      'Yes. Owners may elect to place their villa in the exclusive Esplendor Private Collection. Our team handles high-net-worth guest vetting, bespoke hospitality services, premium insurance escrows, and financial auditing, delivering attractive net rental yields while protecting your estate’s pristine condition.',
    highlight: 'Selective high-net-worth rental management with complete asset preservation.',
  },
  {
    id: 'faq-6',
    category: 'architecture',
    categoryLabel: 'Bespoke Architecture',
    question: 'How do you balance modern luxury amenities with authentic Goan-Portuguese heritage?',
    answer:
      'We practice restorative luxury. We preserve historic roof timber structures, handcrafted azulejo ceramic tile motifs, and expansive veranda colonnades, while invisibly integrating centralized smart-home automation (Lutron lighting, multi-room acoustic zones, concealed sub-zero refrigeration, and keyless biometric access).',
    highlight: 'Historic vaulted aesthetics paired with discrete smart-home automation.',
  },
];

interface LuxuryInsightsProps {
  theme?: 'dark' | 'light';
  className?: string;
  onOpenConsultation?: () => void;
}

export const LuxuryInsights: React.FC<LuxuryInsightsProps> = ({
  theme = 'dark',
  className = '',
  onOpenConsultation,
}) => {
  const [openId, setOpenId] = useState<string | null>('faq-1');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const isDark = theme === 'dark';

  const categories = [
    { id: 'all', label: 'All Inquiries' },
    { id: 'architecture', label: 'Bespoke Architecture' },
    { id: 'concierge', label: 'Asset & Concierge' },
    { id: 'legal', label: 'Conveyancing & NRI' },
    { id: 'climate', label: 'Climate & Tech' },
  ];

  const filteredItems = LUXURY_INSIGHTS_DATA.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch =
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleAccordion = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section
      id="luxury-insights-section"
      className={`relative py-20 sm:py-28 overflow-hidden ${
        isDark ? 'bg-[#0a0a0a] text-white' : 'bg-[#f5f0e7] text-[#1c1c1c]'
      } ${className}`}
    >
      {/* Background ambient lighting effects */}
      {isDark && (
        <>
          <div className="absolute top-1/3 left-10 w-96 h-96 bg-[#c9974f]/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-10 right-10 w-80 h-80 bg-[#c9974f]/5 rounded-full blur-3xl pointer-events-none" />
        </>
      )}

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <SectionEyebrow
            label="CLIENT ADVISORY & BESPOKE PROTOCOLS"
            theme={isDark ? 'gold' : 'dark'}
            className="justify-center mb-4"
          />
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal tracking-tight">
            Luxury <span className="italic text-[#c9974f]">Insights & FAQ</span>
          </h2>
          <p
            className={`mt-4 text-sm sm:text-base font-sans leading-relaxed max-w-xl mx-auto ${
              isDark ? 'text-[#a39f99]' : 'text-[#615a50]'
            }`}
          >
            Transparent answers on bespoke architectural commissions, private NRI conveyancing, and turnkey estate governance.
          </p>

          {/* Quick Search & Category Tabs */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <Search
                className={`absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 ${
                  isDark ? 'text-[#8b7355]' : 'text-[#9c8466]'
                }`}
              />
              <input
                id="faq-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search bespoke topics..."
                className={`w-full pl-10 pr-4 py-2 text-xs rounded-full border transition-all focus:outline-none ${
                  isDark
                    ? 'bg-[#14100c] border-[#2e261d] text-white focus:border-[#c9974f] placeholder-[#665a4c]'
                    : 'bg-[#ece4d6] border-[#d4c6b2] text-[#1c1c1c] focus:border-[#8c6123] placeholder-[#8c8070]'
                }`}
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-[#999] hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category Pills */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 w-full sm:w-auto">
              {categories.map((cat) => {
                const isActive = activeCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`px-3.5 py-1.5 text-[11px] font-mono tracking-wider uppercase rounded-full transition-all cursor-pointer ${
                      isActive
                        ? isDark
                          ? 'bg-[#c9974f] text-[#0a0a0a] font-semibold shadow-[0_0_12px_rgba(201,151,79,0.3)]'
                          : 'bg-[#8c6123] text-white font-semibold'
                        : isDark
                        ? 'bg-[#14100c] border border-[#282017] text-[#998b7a] hover:border-[#c9974f]/50 hover:text-white'
                        : 'bg-[#ebe3d4] border border-[#d8ccb8] text-[#6d6252] hover:border-[#8c6123] hover:text-black'
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Minimalist Accordion Container with Elegant Gold Borders */}
        <div className="space-y-4">
          {filteredItems.length === 0 ? (
            <div
              className={`text-center py-12 rounded-lg border ${
                isDark ? 'border-[#241c14] bg-[#100d0a]' : 'border-[#d8ccb8] bg-[#ebe3d4]'
              }`}
            >
              <HelpCircle className="w-8 h-8 mx-auto text-[#c9974f] mb-3 opacity-60" />
              <p className="text-sm text-[#888]">No matching luxury insights found for "{searchQuery}".</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('all');
                }}
                className="mt-3 text-xs text-[#c9974f] underline underline-offset-4 hover:text-[#f5d79e] cursor-pointer"
              >
                Reset filters
              </button>
            </div>
          ) : (
            filteredItems.map((item, index) => {
              const isOpen = openId === item.id;
              const itemId = `insight-accordion-${item.id}`;

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04, duration: 0.3 }}
                  className={`rounded-lg border transition-all duration-300 overflow-hidden ${
                    isOpen
                      ? isDark
                        ? 'bg-[#120e0b] border-[#c9974f]/70 shadow-[0_4px_25px_rgba(201,151,79,0.12)]'
                        : 'bg-[#fffdf9] border-[#8c6123] shadow-md'
                      : isDark
                      ? 'bg-[#0f0b08]/80 border-[#241d15] hover:border-[#c9974f]/40 hover:bg-[#140f0c]'
                      : 'bg-[#efe7d8] border-[#ded3be] hover:border-[#8c6123]/50'
                  }`}
                >
                  {/* Accordion Trigger Header */}
                  <button
                    id={itemId}
                    onClick={() => toggleAccordion(item.id)}
                    aria-expanded={isOpen}
                    className="w-full text-left p-5 sm:p-6 flex items-start justify-between gap-4 cursor-pointer select-none group"
                  >
                    <div className="space-y-1.5 flex-1 pr-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] uppercase font-mono tracking-widest font-semibold px-2 py-0.5 rounded ${
                            isOpen
                              ? 'bg-[#c9974f]/20 text-[#c9974f]'
                              : isDark
                              ? 'bg-[#1a140f] text-[#8c7860]'
                              : 'bg-[#ded3be] text-[#6d6252]'
                          }`}
                        >
                          {item.categoryLabel}
                        </span>
                      </div>
                      <h3
                        className={`font-serif text-base sm:text-lg font-medium transition-colors ${
                          isOpen
                            ? isDark
                              ? 'text-[#f5d79e]'
                              : 'text-[#8c6123]'
                            : isDark
                            ? 'text-[#e8e4dc] group-hover:text-white'
                            : 'text-[#202020] group-hover:text-black'
                        }`}
                      >
                        {item.question}
                      </h3>
                    </div>

                    {/* Gold Accordion Indicator Toggle */}
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 flex-shrink-0 ${
                        isOpen
                          ? 'bg-[#c9974f] text-[#0a0a0a] rotate-180 shadow-[0_0_10px_rgba(201,151,79,0.4)]'
                          : isDark
                          ? 'bg-[#1b150f] border border-[#33281c] text-[#c9974f] group-hover:border-[#c9974f]'
                          : 'bg-[#ded3be] border border-[#c4b69f] text-[#8c6123] group-hover:border-[#8c6123]'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  {/* Expandable Content Area */}
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        key="content"
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                        className="overflow-hidden"
                      >
                        <div
                          className={`px-5 pb-6 sm:px-6 sm:pb-7 pt-2 border-t font-sans text-xs sm:text-sm leading-relaxed ${
                            isDark
                              ? 'border-[#261e15] text-[#cac5bd]'
                              : 'border-[#ebdcc5] text-[#4d4841]'
                          }`}
                        >
                          <p>{item.answer}</p>

                          {item.highlight && (
                            <div
                              className={`mt-4 p-3 rounded flex items-start gap-2.5 ${
                                isDark
                                  ? 'bg-[#19130c] border border-[#382b1c] text-[#dfcfb8]'
                                  : 'bg-[#f7f1e4] border border-[#d6c4a8] text-[#554a3a]'
                              }`}
                            >
                              <Sparkles className="w-4 h-4 text-[#c9974f] flex-shrink-0 mt-0.5" />
                              <span className="text-xs font-medium tracking-wide">
                                <strong className="text-[#c9974f] font-semibold">Key Guarantee:</strong>{' '}
                                {item.highlight}
                              </span>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })
          )}
        </div>

        {/* Bottom Direct Advisory Prompt */}
        {onOpenConsultation && (
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className={`mt-14 p-6 sm:p-8 rounded-xl border text-center flex flex-col sm:flex-row items-center justify-between gap-6 ${
              isDark
                ? 'bg-gradient-to-r from-[#14100c] via-[#1a140f] to-[#14100c] border-[#382a1b]'
                : 'bg-gradient-to-r from-[#ebe2d1] via-[#f3ebe0] to-[#ebe2d1] border-[#cfbea6]'
            }`}
          >
            <div className="text-left space-y-1">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#c9974f]" />
                <span className="text-xs uppercase font-mono tracking-widest text-[#c9974f] font-semibold">
                  Confidential Advisory
                </span>
              </div>
              <h4 className="font-serif text-lg sm:text-xl font-medium text-white">
                Have a bespoke architectural inquiry or private viewing request?
              </h4>
              <p className={`text-xs ${isDark ? 'text-[#9e968b]' : 'text-[#635a4d]'}`}>
                Our founding directors and master architects are available for private consultations under strict NDA.
              </p>
            </div>

            <GoldButton
              label="CONNECT WITH DIRECTORS"
              onClick={onOpenConsultation}
              variant="solid-gold"
              size="md"
              className="flex-shrink-0"
            />
          </motion.div>
        )}
      </div>
    </section>
  );
};

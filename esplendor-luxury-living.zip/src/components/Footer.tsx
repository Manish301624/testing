import React from 'react';
import { PageRoute } from '../types';
import { EsplendorLogoIcon } from './Icons';
import { MapPin, Phone, Mail, Instagram, Facebook, Linkedin, Youtube, ArrowUpRight } from 'lucide-react';
import { useLanguage } from '../lib/LanguageContext';

interface FooterProps {
  onNavigate: (page: PageRoute) => void;
  onOpenConsultation: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenConsultation }) => {
  const { t } = useLanguage();

  return (
    <footer className="bg-[#0a0a0a] text-[#8e8e8e] border-t border-[#221c15] pt-16 pb-12 font-sans relative overflow-hidden">
      {/* Subtle background ambient light */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-[#c9974f]/5 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-12 pb-14 border-b border-[#221c15]">
          {/* Brand Info Column */}
          <div className="lg:col-span-2 space-y-4">
            <div
              onClick={() => onNavigate('home')}
              className="inline-flex items-center gap-3 cursor-pointer group"
            >
              <EsplendorLogoIcon className="w-7 h-9 text-[#c9974f] transition-transform duration-300 group-hover:scale-105" />
              <div className="flex flex-col">
                <span className="font-serif tracking-[0.25em] text-xl font-bold text-white group-hover:text-[#c9974f] transition-colors">
                  ESPLENDOR
                </span>
                <span className="text-[8px] tracking-[0.28em] text-[#c9974f] font-sans uppercase">
                  {t('nav.brandTagline', 'CRAFTING TIMELESS LIVING')}
                </span>
              </div>
            </div>

            <p className="text-sm leading-relaxed text-[#9a9a9a] max-w-sm">
              {t('footer.desc', 'Crafting bespoke luxury residences in Goa where timeless architecture, natural tranquility, and refined hospitality unite.')}
            </p>

            <div className="pt-2 flex items-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:border-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all duration-300"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:border-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all duration-300"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:border-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all duration-300"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:border-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all duration-300"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation Column */}
          <div>
            <h4 className="text-xs font-semibold tracking-[0.2em] uppercase text-white mb-5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c9974f]" />
              {t('footer.navigation', 'Navigation')}
            </h4>
            <ul className="space-y-3 text-xs tracking-wider uppercase">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  {t('nav.home', 'Home')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('our-story')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  {t('nav.ourStory', 'Our Story')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('luxury-homes')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  {t('nav.luxuryHomes', 'Luxury Homes')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('the-living-difference')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  {t('nav.livingDifference', 'The Living Difference')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  {t('nav.contact', 'Contact Us')}
                </button>
              </li>
            </ul>
          </div>

          {/* Luxury Homes Column */}
          <div>
            <h4 className="text-xs font-semibold tracking-[0.2em] uppercase text-white mb-5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c9974f]" />
              {t('footer.estates', 'Portfolio')}
            </h4>
            <ul className="space-y-3 text-xs tracking-wider uppercase">
              <li>
                <button
                  onClick={() => onNavigate('luxury-homes')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  Completed Homes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('luxury-homes')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  Ongoing Projects
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('luxury-homes')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  Upcoming Estates
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('luxury-homes')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  Private Villas
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('luxury-homes')}
                  className="hover:text-[#c9974f] transition-colors cursor-pointer"
                >
                  Sea-Facing Penthouses
                </button>
              </li>
            </ul>
          </div>

          {/* Connect / Office Column */}
          <div>
            <h4 className="text-xs font-semibold tracking-[0.2em] uppercase text-white mb-5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c9974f]" />
              {t('footer.advisory', 'Connect')}
            </h4>
            <div className="space-y-3.5 text-xs text-[#a0a0a0]">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#c9974f] shrink-0 mt-0.5" />
                <span>Baga & Assagao, North Goa, 403516, India</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#c9974f] shrink-0" />
                <a href="tel:+917777000000" className="hover:text-[#c9974f] transition-colors">
                  +91 77770 00000
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#c9974f] shrink-0" />
                <a href="mailto:info@esplendorhomes.com" className="hover:text-[#c9974f] transition-colors">
                  info@esplendorhomes.com
                </a>
              </div>
              <div className="pt-2">
                <button
                  onClick={onOpenConsultation}
                  className="inline-flex items-center gap-1.5 text-[11px] font-semibold tracking-widest text-[#c9974f] hover:text-[#e0b877] uppercase cursor-pointer"
                >
                  <span>{t('insights.confidentialAdvisory', 'Private Advisory')}</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#6b6b6b] gap-4">
          <div>
            © {new Date().getFullYear()} ESPLENDOR HOMES PVT. LTD. {t('footer.rights', 'ALL RIGHTS RESERVED.')}
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-[#a0a0a0] transition-colors cursor-pointer">{t('footer.privacy', 'PRIVACY POLICY')}</span>
            <span>•</span>
            <span className="hover:text-[#a0a0a0] transition-colors cursor-pointer">{t('footer.terms', 'TERMS OF SERVICE')}</span>
            <span>•</span>
            <span className="hover:text-[#a0a0a0] transition-colors cursor-pointer">{t('footer.rera', 'RERA REGISTERED')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};


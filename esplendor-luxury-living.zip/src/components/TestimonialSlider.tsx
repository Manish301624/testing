import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, Variants } from 'motion/react';
import { ChevronLeft, ChevronRight, Quote, Sparkles } from 'lucide-react';
import { SectionEyebrow } from './SectionEyebrow';
import { useLanguage } from '../lib/LanguageContext';

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  title: string;
  residence: string;
  location: string;
  acquisitionYear: string;
  rating: number;
}

export const CLIENT_TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't-1',
    quote:
      'Acquiring our estate in Assagao through Esplendor was an absolute masterclass in discretion and architectural artistry. The Portuguese vaulted ceilings and serene courtyard pool have become our family’s sanctuary.',
    author: 'Vikramaditya & Meera Singhania',
    title: 'Managing Director & Venture Partner',
    residence: 'The Assagao Grand Haven',
    location: 'Assagao, North Goa',
    acquisitionYear: '2024',
    rating: 5,
  },
  {
    id: 't-2',
    quote:
      'The concierge and asset management team handle every single detail while we are overseas. Walking through the bronze-lined doors of Candolim Palms feels like stepping into a private six-star retreat every single time.',
    author: 'Sir Julian & Lady Eleanor Vance',
    title: 'Private Wealth & Art Collectors',
    residence: 'Candolim Palms Sanctuary',
    location: 'Candolim Coast, Goa',
    acquisitionYear: '2023',
    rating: 5,
  },
  {
    id: 't-3',
    quote:
      'Esplendor does not simply build residences; they curate a lifestyle. The integration of sustainable Goan laterite stone with cutting-edge smart home automation represents the pinnacle of quiet luxury.',
    author: 'Dr. Aarav & Natasha Mehta',
    title: 'Chief of Neurosurgery & Landscape Architect',
    residence: 'Villa do Sol',
    location: 'Anjuna Heights, Goa',
    acquisitionYear: '2025',
    rating: 5,
  },
  {
    id: 't-4',
    quote:
      'From the confidential title conveyancing to the bespoke Italian walnut millwork, every commitment made by the founders was exceeded. Our villa is truly an heirloom asset for generations.',
    author: 'Rohit K. Merchant',
    title: 'Global Tech Founder & Angel Investor',
    residence: 'Casa Esplendor Estate',
    location: 'Siolim Riverfront, Goa',
    acquisitionYear: '2024',
    rating: 5,
  },
];

interface TestimonialSliderProps {
  className?: string;
}

export const TestimonialSlider: React.FC<TestimonialSliderProps> = ({ className = '' }) => {
  const { t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState<number>(0);
  const [isAutoPlay, setIsAutoPlay] = useState(true);

  // Auto slide every 7 seconds if user isn't actively interacting
  useEffect(() => {
    if (!isAutoPlay) return;
    const timer = setInterval(() => {
      handleNext();
    }, 7000);
    return () => clearInterval(timer);
  }, [currentIndex, isAutoPlay]);

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % CLIENT_TESTIMONIALS.length);
  };

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + CLIENT_TESTIMONIALS.length) % CLIENT_TESTIMONIALS.length);
  };

  const handleSelect = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  const current = CLIENT_TESTIMONIALS[currentIndex];

  const variants: Variants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 50 : -50,
      opacity: 0,
      scale: 0.98,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
      transition: {
        x: { type: 'spring' as const, stiffness: 300, damping: 30 },
        opacity: { duration: 0.45 },
        scale: { duration: 0.45 },
      },
    },
    exit: (dir: number) => ({
      x: dir > 0 ? -50 : 50,
      opacity: 0,
      scale: 0.98,
      transition: {
        x: { type: 'spring' as const, stiffness: 300, damping: 30 },
        opacity: { duration: 0.35 },
      },
    }),
  };

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      onMouseEnter={() => setIsAutoPlay(false)}
      onMouseLeave={() => setIsAutoPlay(true)}
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <SectionEyebrow label={t('testimonials.eyebrow', 'DISTINGUISHED PATRONS')} theme="gold" className="justify-center mb-4" />
          <h2 className="font-serif text-3xl sm:text-4xl text-white font-normal">
            {t('testimonials.title1', 'Voices of')} <span className="italic text-[#c9974f]">{t('testimonials.title2', 'Refined Living')}</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#8e8e8e] max-w-lg mx-auto mt-3 font-sans">
            {t('testimonials.desc', 'Reflections from connoisseurs, collectors, and visionary families who have made Esplendor their sanctuary.')}
          </p>
        </div>

        {/* Testimonial Card Frame */}
        <div className="relative bg-[#111111]/90 border border-[#262018] rounded-xl p-8 sm:p-12 lg:p-14 backdrop-blur-sm shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 right-1/4 w-72 h-72 bg-[#c9974f]/5 rounded-full blur-3xl pointer-events-none" />

          {/* Top Decorative Elements */}
          <div className="flex items-center justify-between mb-8 pb-6 border-b border-[#221c15]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#1b150f] border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f]">
                <Quote className="w-4 h-4 text-[#c9974f]" />
              </div>
              <div>
                <span className="text-[10px] tracking-[0.2em] uppercase font-mono text-[#c9974f] block">
                  {t('testimonials.badge', 'Private Client Endorsement')}
                </span>
                <span className="text-[11px] text-[#777] font-sans">
                  Acquired {current.acquisitionYear} • {current.location}
                </span>
              </div>
            </div>

            {/* 5-Star Micro Badge */}
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Sparkles key={i} className="w-3 h-3 text-[#c9974f]" />
              ))}
            </div>
          </div>

          {/* Animated Quote Slider */}
          <div className="min-h-[190px] sm:min-h-[160px] flex items-center">
            <AnimatePresence custom={direction} mode="wait">
              <motion.div
                key={current.id}
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                className="w-full"
              >
                <blockquote className="font-serif text-lg sm:text-2xl text-[#f3ede2] leading-relaxed font-light italic mb-8">
                  "{current.quote}"
                </blockquote>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-[#1d1812]">
                  <div>
                    <h4 className="font-serif text-base font-semibold text-white tracking-wide">
                      {current.author}
                    </h4>
                    <p className="text-xs text-[#c9974f] font-sans">
                      {current.title}
                    </p>
                  </div>

                  <div className="sm:text-right">
                    <span className="text-[10px] uppercase tracking-wider text-[#777] font-mono block">
                      {t('testimonials.residence', 'Residence')}
                    </span>
                    <span className="text-xs text-[#dfd7ca] font-sans font-medium">
                      {current.residence}
                    </span>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation Controls & Pagination */}
          <div className="flex items-center justify-between mt-10 pt-6 border-t border-[#221c15]">
            {/* Dots */}
            <div className="flex items-center gap-2">
              {CLIENT_TESTIMONIALS.map((item, idx) => (
                <button
                  key={item.id}
                  onClick={() => handleSelect(idx)}
                  className={`h-1.5 transition-all rounded-full cursor-pointer ${
                    idx === currentIndex
                      ? 'w-8 bg-[#c9974f]'
                      : 'w-2 bg-[#332a1f] hover:bg-[#5a4833]'
                  }`}
                  aria-label={`Go to testimonial ${idx + 1}`}
                />
              ))}
            </div>

            {/* Slider Buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={handlePrev}
                className="w-10 h-10 rounded-full bg-[#16120d] border border-[#33271b] hover:border-[#c9974f] hover:bg-[#201810] text-[#c9974f] flex items-center justify-center transition-all cursor-pointer"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                className="w-10 h-10 rounded-full bg-[#16120d] border border-[#33271b] hover:border-[#c9974f] hover:bg-[#201810] text-[#c9974f] flex items-center justify-center transition-all cursor-pointer"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

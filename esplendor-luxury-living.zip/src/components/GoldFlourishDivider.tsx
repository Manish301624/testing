import React from 'react';
import { motion } from 'motion/react';

export type FlourishVariant = 'emblem' | 'ornate' | 'minimal' | 'crest';
export type FlourishTheme = 'dark' | 'light' | 'gold';

interface GoldFlourishDividerProps {
  variant?: FlourishVariant;
  theme?: FlourishTheme;
  className?: string;
  animate?: boolean;
}

export const GoldFlourishDivider: React.FC<GoldFlourishDividerProps> = ({
  variant = 'emblem',
  theme = 'dark',
  className = '',
  animate = true,
}) => {
  // Gradients and colors based on theme
  const isLight = theme === 'light';
  const gradId = React.useId().replace(/:/g, '');
  const gradStart = isLight ? '#b8893d' : '#f5d79e';
  const gradMid = isLight ? '#8c6123' : '#c9974f';
  const gradEnd = isLight ? '#593e14' : '#7d5c2a';

  const renderContent = () => {
    switch (variant) {
      case 'ornate':
        return (
          <svg
            viewBox="0 0 800 40"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full max-w-4xl h-8 sm:h-10 mx-auto overflow-visible"
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`grad-${gradId}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={gradStart} stopOpacity="0" />
                <stop offset="15%" stopColor={gradMid} stopOpacity="0.4" />
                <stop offset="45%" stopColor={gradStart} stopOpacity="0.9" />
                <stop offset="50%" stopColor={gradStart} stopOpacity="1" />
                <stop offset="55%" stopColor={gradStart} stopOpacity="0.9" />
                <stop offset="85%" stopColor={gradMid} stopOpacity="0.4" />
                <stop offset="100%" stopColor={gradEnd} stopOpacity="0" />
              </linearGradient>
              <filter id={`glow-${gradId}`} x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="2" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* Left tapered hairline */}
            <path
              d="M 50 20 L 330 20"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1"
              strokeLinecap="round"
            />
            {/* Right tapered hairline */}
            <path
              d="M 470 20 L 750 20"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1"
              strokeLinecap="round"
            />

            {/* Left flourish curls */}
            <path
              d="M 330 20 C 350 20, 360 10, 375 14 C 385 17, 388 23, 393 20"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1.25"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M 345 20 C 360 20, 368 28, 380 25 C 388 23, 391 18, 395 20"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1"
              fill="none"
              strokeLinecap="round"
              opacity="0.8"
            />

            {/* Right flourish curls (mirrored) */}
            <path
              d="M 470 20 C 450 20, 440 10, 425 14 C 415 17, 412 23, 407 20"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1.25"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M 455 20 C 440 20, 432 28, 420 25 C 412 23, 409 18, 405 20"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1"
              fill="none"
              strokeLinecap="round"
              opacity="0.8"
            />

            {/* Center Royal Medallion & 4-Point Diamond Star */}
            <g filter={!isLight ? `url(#glow-${gradId})` : undefined}>
              {/* Outer Diamond */}
              <polygon
                points="400,6 408,20 400,34 392,20"
                stroke={`url(#grad-${gradId})`}
                strokeWidth="1"
                fill={isLight ? '#f5f0e7' : '#0a0a0a'}
              />
              {/* Inner Solid Diamond */}
              <polygon
                points="400,11 405,20 400,29 395,20"
                fill={`url(#grad-${gradId})`}
              />
              {/* Flanking Micro Diamond Beads */}
              <polygon points="360,20 363,17 366,20 363,23" fill={`url(#grad-${gradId})`} />
              <polygon points="440,20 437,17 434,20 437,23" fill={`url(#grad-${gradId})`} />
              <circle cx="340" cy="20" r="1.5" fill={`url(#grad-${gradId})`} />
              <circle cx="460" cy="20" r="1.5" fill={`url(#grad-${gradId})`} />
            </g>
          </svg>
        );

      case 'crest':
        return (
          <svg
            viewBox="0 0 600 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full max-w-3xl h-6 sm:h-8 mx-auto overflow-visible"
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`grad-${gradId}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={gradStart} stopOpacity="0" />
                <stop offset="20%" stopColor={gradMid} stopOpacity="0.5" />
                <stop offset="50%" stopColor={gradStart} stopOpacity="1" />
                <stop offset="80%" stopColor={gradMid} stopOpacity="0.5" />
                <stop offset="100%" stopColor={gradEnd} stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Left Rule */}
            <line x1="30" y1="16" x2="260" y2="16" stroke={`url(#grad-${gradId})`} strokeWidth="1" strokeLinecap="round" />
            {/* Right Rule */}
            <line x1="340" y1="16" x2="570" y2="16" stroke={`url(#grad-${gradId})`} strokeWidth="1" strokeLinecap="round" />

            {/* Center Esplendor Crest Chevron & Pillars */}
            <g transform="translate(285, 4)">
              <rect x="2" y="10" width="2" height="12" rx="0.5" fill={`url(#grad-${gradId})`} />
              <rect x="7" y="6" width="2" height="16" rx="0.5" fill={`url(#grad-${gradId})`} />
              <rect x="14" y="3" width="2" height="19" rx="0.5" fill={`url(#grad-${gradId})`} />
              <rect x="21" y="6" width="2" height="16" rx="0.5" fill={`url(#grad-${gradId})`} />
              <rect x="26" y="10" width="2" height="12" rx="0.5" fill={`url(#grad-${gradId})`} />
              {/* Crown Chevron point */}
              <polygon points="15,0 18,3 12,3" fill={`url(#grad-${gradId})`} />
            </g>
          </svg>
        );

      case 'minimal':
        return (
          <svg
            viewBox="0 0 500 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full max-w-xl h-4 mx-auto overflow-visible"
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`grad-${gradId}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={gradStart} stopOpacity="0" />
                <stop offset="50%" stopColor={gradStart} stopOpacity="1" />
                <stop offset="100%" stopColor={gradEnd} stopOpacity="0" />
              </linearGradient>
            </defs>
            <line x1="20" y1="8" x2="230" y2="8" stroke={`url(#grad-${gradId})`} strokeWidth="1" strokeLinecap="round" />
            <polygon points="250,2 256,8 250,14 244,8" fill={`url(#grad-${gradId})`} />
            <line x1="270" y1="8" x2="480" y2="8" stroke={`url(#grad-${gradId})`} strokeWidth="1" strokeLinecap="round" />
          </svg>
        );

      case 'emblem':
      default:
        return (
          <svg
            viewBox="0 0 700 28"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full max-w-2xl sm:max-w-3xl h-6 sm:h-7 mx-auto overflow-visible"
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`grad-${gradId}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={gradStart} stopOpacity="0" />
                <stop offset="25%" stopColor={gradMid} stopOpacity="0.5" />
                <stop offset="50%" stopColor={gradStart} stopOpacity="1" />
                <stop offset="75%" stopColor={gradMid} stopOpacity="0.5" />
                <stop offset="100%" stopColor={gradEnd} stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Left Line */}
            <path
              d="M 30 14 L 305 14"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1"
              strokeLinecap="round"
            />
            {/* Right Line */}
            <path
              d="M 395 14 L 670 14"
              stroke={`url(#grad-${gradId})`}
              strokeWidth="1"
              strokeLinecap="round"
            />

            {/* Center Sweeping Filigree & Diamond */}
            <g>
              {/* Left wing curve */}
              <path
                d="M 305 14 C 322 14, 332 8, 342 14"
                stroke={`url(#grad-${gradId})`}
                strokeWidth="1.2"
                fill="none"
                strokeLinecap="round"
              />
              {/* Right wing curve */}
              <path
                d="M 395 14 C 378 14, 368 8, 358 14"
                stroke={`url(#grad-${gradId})`}
                strokeWidth="1.2"
                fill="none"
                strokeLinecap="round"
              />

              {/* Central Diamond Star */}
              <polygon
                points="350,5 356,14 350,23 344,14"
                fill={`url(#grad-${gradId})`}
              />
              <polygon
                points="350,8 353,14 350,20 347,14"
                fill={isLight ? '#f5f0e7' : '#0e0e0e'}
              />
              <circle cx="350" cy="14" r="1.25" fill={`url(#grad-${gradId})`} />

              {/* Side Accent Beads */}
              <circle cx="330" cy="14" r="1.5" fill={`url(#grad-${gradId})`} />
              <circle cx="370" cy="14" r="1.5" fill={`url(#grad-${gradId})`} />
            </g>
          </svg>
        );
    }
  };

  if (!animate) {
    return (
      <div className={`py-6 sm:py-8 flex items-center justify-center pointer-events-none select-none ${className}`}>
        {renderContent()}
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scaleX: 0.85 }}
      whileInView={{ opacity: 1, scaleX: 1 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={`py-6 sm:py-8 flex items-center justify-center pointer-events-none select-none ${className}`}
    >
      {renderContent()}
    </motion.div>
  );
};

import React from 'react';
import { 
  X, 
  MapPin, 
  Bed, 
  Bath, 
  Maximize2, 
  ShieldCheck, 
  CheckCircle2, 
  Phone, 
  Sparkles, 
  Film, 
  Bookmark, 
  BookmarkCheck,
  Bot
} from 'lucide-react';
import { LuxuryProject } from '../types';
import { GoldButton } from './GoldButton';
import { useAuth } from '../lib/AuthContext';

interface ProjectDetailModalProps {
  project: LuxuryProject | null;
  onClose: () => void;
  onInquire: (projectName: string) => void;
  onOpenVeoStudio?: (imageUrl: string, projectName: string) => void;
  onOpenGeminiChat?: (projectName: string) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onInquire,
  onOpenVeoStudio,
  onOpenGeminiChat,
}) => {
  const { isPropertySaved, saveProperty, unsaveProperty } = useAuth();

  if (!project) return null;

  const isSaved = isPropertySaved(project.id);

  const handleToggleSave = async () => {
    if (isSaved) {
      await unsaveProperty(project.id);
    } else {
      await saveProperty({
        projectId: project.id,
        projectName: project.name,
        location: project.location,
        price: project.price,
        image: project.image,
        bedrooms: project.bedrooms,
        area: project.area,
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 md:p-8 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div
        className="relative w-full max-w-4xl bg-[#0e0e0e] border border-[#c9974f]/40 rounded-xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-black/70 border border-[#c9974f]/40 flex items-center justify-center text-[#c9974f] hover:bg-[#c9974f] hover:text-black transition-all duration-200 cursor-pointer"
          aria-label="Close Project Modal"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        <div className="overflow-y-auto">
          {/* Hero Image */}
          <div className="relative h-60 sm:h-80 md:h-96 w-full overflow-hidden">
            <img
              src={project.image}
              alt={project.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0e0e0e] via-[#0e0e0e]/40 to-transparent" />

            {/* Floating Quick Action Badges */}
            <div className="absolute top-3 left-3 sm:top-4 sm:left-4 flex flex-wrap items-center gap-1.5 sm:gap-2 z-10 max-w-[calc(100%-60px)]">
              <button
                onClick={handleToggleSave}
                className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10.5px] sm:text-xs font-semibold uppercase tracking-wider backdrop-blur-md border transition-all flex items-center gap-1.5 cursor-pointer ${
                  isSaved
                    ? 'bg-[#c9974f] text-black border-[#c9974f]'
                    : 'bg-black/60 text-white border-white/20 hover:border-[#c9974f]'
                }`}
              >
                {isSaved ? (
                  <>
                    <BookmarkCheck className="w-3.5 h-3.5" />
                    <span>Saved in Vault</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>Save to Vault</span>
                  </>
                )}
              </button>

              {onOpenVeoStudio && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenVeoStudio(project.image, project.name);
                  }}
                  className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full bg-black/60 hover:bg-[#c9974f] text-[#c9974f] hover:text-black border border-[#c9974f]/50 text-[10.5px] sm:text-xs font-semibold uppercase tracking-wider backdrop-blur-md transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Film className="w-3.5 h-3.5" />
                  <span>Veo 4K Video</span>
                </button>
              )}
            </div>

            <div className="absolute bottom-4 sm:bottom-6 left-4 sm:left-6 right-4 sm:right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-2 sm:gap-4">
              <div>
                <span className="inline-block px-2.5 py-0.5 sm:px-3 sm:py-1 bg-[#c9974f] text-black text-[9px] sm:text-[10px] font-semibold tracking-widest uppercase rounded-full mb-1 sm:mb-2">
                  {project.statusLabel}
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl text-white font-bold tracking-wide">
                  {project.name}
                </h3>
                <div className="flex items-center gap-2 text-xs sm:text-sm text-[#e0b877] mt-0.5 sm:mt-1 font-sans">
                  <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#c9974f] shrink-0" />
                  <span>{project.location}</span>
                </div>
              </div>

              <div className="text-left sm:text-right mt-1 sm:mt-0">
                <span className="text-[9px] sm:text-[10px] tracking-widest text-[#a0a0a0] uppercase block">Starting Price</span>
                <span className="font-serif text-xl sm:text-2xl md:text-3xl font-semibold text-[#c9974f]">
                  {project.price}
                </span>
              </div>
            </div>
          </div>

          {/* Details & Specs */}
          <div className="p-4 sm:p-6 md:p-8 space-y-5 sm:space-y-6">
            {/* Quick Specs Bar */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 py-3 sm:py-4 px-3 sm:px-6 bg-[#161616] border border-[#252019] rounded-lg text-center">
              <div className="flex flex-col items-center justify-center">
                <div className="flex items-center gap-1 sm:gap-1.5 text-[#c9974f] mb-0.5 sm:mb-1">
                  <Bed className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span className="font-semibold text-base sm:text-lg text-white">{project.bedrooms}</span>
                </div>
                <span className="text-[9px] sm:text-[10px] tracking-widest text-[#8a8a8a] uppercase">Bedrooms</span>
              </div>

              <div className="flex flex-col items-center justify-center border-x border-[#252019]">
                <div className="flex items-center gap-1 sm:gap-1.5 text-[#c9974f] mb-0.5 sm:mb-1">
                  <Bath className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span className="font-semibold text-base sm:text-lg text-white">{project.bathrooms}</span>
                </div>
                <span className="text-[9px] sm:text-[10px] tracking-widest text-[#8a8a8a] uppercase">Bathrooms</span>
              </div>

              <div className="flex flex-col items-center justify-center">
                <div className="flex items-center gap-1 sm:gap-1.5 text-[#c9974f] mb-0.5 sm:mb-1">
                  <Maximize2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span className="font-semibold text-base sm:text-lg text-white">{project.area}</span>
                </div>
                <span className="text-[9px] sm:text-[10px] tracking-widest text-[#8a8a8a] uppercase">Carpet Area</span>
              </div>
            </div>

            {/* AI Assistant Bar */}
            <div className="p-3.5 sm:p-4 rounded-lg bg-gradient-to-r from-[#171410] to-[#1f1911] border border-[#c9974f]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3 text-left">
                <div className="w-8 h-8 rounded-full bg-[#c9974f]/15 border border-[#c9974f] flex items-center justify-center text-[#c9974f] shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="text-xs font-semibold text-white">Have questions about {project.name}?</h5>
                  <p className="text-[11px] text-[#aaa]">Ask our Gemini AI concierge about architectural layouts, neighborhood, or yields.</p>
                </div>
              </div>

              {onOpenGeminiChat && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenGeminiChat(project.name);
                  }}
                  className="w-full sm:w-auto px-3.5 py-1.5 rounded-full bg-[#c9974f] hover:bg-[#e0b877] text-black font-semibold text-[11px] uppercase tracking-wider transition-colors shrink-0 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Ask Concierge</span>
                </button>
              )}
            </div>

            {/* Description */}
            <div>
              <h4 className="text-xs font-semibold tracking-[0.2em] uppercase text-[#c9974f] mb-2">
                Architectural Overview
              </h4>
              <p className="text-xs sm:text-sm md:text-base leading-relaxed text-[#d0d0d0]">
                {project.description} Each residence is crafted with passive bioclimatic ventilation, imported Portuguese laterite stonework, cantilevered infinity verandas, and panoramic vistas framing the tropical landscape.
              </p>
            </div>

            {/* Highlights List */}
            {project.highlights && project.highlights.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold tracking-[0.2em] uppercase text-[#c9974f] mb-3">
                  Signature Highlights
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                  {project.highlights.map((highlight, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 text-xs sm:text-sm text-[#e0e0e0]">
                      <CheckCircle2 className="w-4 h-4 text-[#c9974f] shrink-0" />
                      <span>{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* RERA and Security note */}
            <div className="flex items-start sm:items-center gap-2 text-[11px] sm:text-xs text-[#8a8a8a] pt-2 border-t border-[#221c15]">
              <ShieldCheck className="w-4 h-4 text-[#c9974f] shrink-0 mt-0.5 sm:mt-0" />
              <span>Full legal freehold title · Clear RERA documentation · Complete property management support</span>
            </div>

            {/* Action Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4 pt-4 border-t border-[#252019]">
              <div className="flex items-center gap-2 text-[11px] sm:text-xs text-[#a0a0a0]">
                <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#c9974f] shrink-0" />
                <span>Direct Concierge: +91 77770 00000</span>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 sm:py-3 text-xs uppercase tracking-widest text-[#a0a0a0] hover:text-white border border-[#333] rounded-full transition-colors cursor-pointer text-center"
                >
                  Close
                </button>
                <GoldButton
                  label="REQUEST VIEWING"
                  onClick={() => {
                    onClose();
                    onInquire(project.name);
                  }}
                  variant="solid-gold"
                  size="md"
                  className="w-full sm:w-auto justify-center"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

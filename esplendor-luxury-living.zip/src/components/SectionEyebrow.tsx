import React from 'react';

interface SectionEyebrowProps {
  label: string;
  className?: string;
  theme?: 'gold' | 'dark' | 'cream';
}

export const SectionEyebrow: React.FC<SectionEyebrowProps> = ({
  label,
  className = "",
  theme = 'gold'
}) => {
  const textColor = theme === 'gold' ? 'text-[#c9974f]' : theme === 'cream' ? 'text-[#e0b877]' : 'text-[#2b2b2b]';
  const lineColor = theme === 'gold' ? 'bg-[#c9974f]' : theme === 'cream' ? 'bg-[#e0b877]' : 'bg-[#2b2b2b]';

  return (
    <div className={`flex items-center gap-3.5 ${className}`}>
      <span className={`text-[11px] md:text-xs font-semibold tracking-[0.22em] uppercase ${textColor}`}>
        {label}
      </span>
      <span className={`h-[1px] w-12 md:w-16 ${lineColor} opacity-70`} />
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUp } from 'lucide-react';

interface ScrollToTopButtonProps {
  threshold?: number;
}

export const ScrollToTopButton: React.FC<ScrollToTopButtonProps> = ({ threshold = 350 }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY || document.documentElement.scrollTop;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      
      setIsVisible(scrollY > threshold);

      if (docHeight > 0) {
        const progress = Math.min(Math.max(scrollY / docHeight, 0), 1);
        setScrollProgress(progress);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, [threshold]);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  // SVG circle calculation for subtle circular progress ring
  const radius = 20;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - scrollProgress * circumference;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.75, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.75, y: 16 }}
          transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="fixed bottom-6 right-6 z-40"
        >
          <motion.button
            id="btn-scroll-to-top"
            onClick={scrollToTop}
            whileHover={{ scale: 1.08, y: -2 }}
            whileTap={{ scale: 0.94 }}
            className="group relative w-12 h-12 rounded-full bg-[#120f0c]/90 hover:bg-[#1c1610] border border-[#c9974f]/40 hover:border-[#c9974f] text-[#c9974f] hover:text-[#f5d79e] backdrop-blur-md flex items-center justify-center shadow-[0_8px_25px_rgba(0,0,0,0.6),0_0_15px_rgba(201,151,79,0.15)] hover:shadow-[0_8px_30px_rgba(0,0,0,0.8),0_0_20px_rgba(201,151,79,0.35)] transition-all cursor-pointer overflow-visible"
            aria-label="Scroll to top of page"
            title="Return to top"
          >
            {/* Subtle Circular SVG Scroll Progress Indicator Ring */}
            <svg
              className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none p-0.5"
              viewBox="0 0 48 48"
              aria-hidden="true"
            >
              {/* Background faint track */}
              <circle
                cx="24"
                cy="24"
                r={radius}
                className="stroke-[#c9974f]/15"
                strokeWidth="1.5"
                fill="none"
              />
              {/* Active gold progress ring */}
              <circle
                cx="24"
                cy="24"
                r={radius}
                className="stroke-[#c9974f] transition-all duration-150"
                strokeWidth="1.5"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="none"
              />
            </svg>

            {/* Icon & upward float motion on hover */}
            <motion.div
              className="relative z-10 flex flex-col items-center justify-center"
              whileHover={{ y: -1 }}
            >
              <ArrowUp className="w-4 h-4 transition-transform group-hover:-translate-y-0.5" />
            </motion.div>

            {/* Subtle Gold Ambient Glow Halo */}
            <div className="absolute inset-0 rounded-full bg-[#c9974f]/10 blur-sm opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

import React from 'react';
import { ArrowUpRight, ArrowRight } from 'lucide-react';

interface GoldButtonProps {
  label: string;
  onClick?: () => void;
  href?: string;
  variant?: 'solid-dark' | 'outline-gold' | 'solid-gold' | 'text-link';
  size?: 'sm' | 'md' | 'lg';
  iconType?: 'arrow-up-right' | 'arrow-right' | 'none';
  className?: string;
  id?: string;
}

export const GoldButton: React.FC<GoldButtonProps> = ({
  label,
  onClick,
  href,
  variant = 'solid-dark',
  size = 'md',
  iconType = 'arrow-up-right',
  className = "",
  id
}) => {
  const sizeClasses = {
    sm: 'text-[10px] tracking-[0.14em] py-2.5 px-5 gap-2.5',
    md: 'text-[11px] md:text-xs tracking-[0.18em] py-3.5 px-6 gap-3.5',
    lg: 'text-xs md:text-sm tracking-[0.2em] py-4 px-8 gap-4'
  }[size];

  let variantStyles = '';
  let circleStyles = '';

  if (variant === 'solid-dark') {
    variantStyles = 'bg-[#0a0a0a] text-white border border-[#c9974f]/40 hover:border-[#c9974f] hover:shadow-[0_0_20px_rgba(201,151,79,0.25)]';
    circleStyles = 'border border-[#c9974f] text-[#c9974f] bg-[#141414] group-hover:bg-[#c9974f] group-hover:text-black';
  } else if (variant === 'outline-gold') {
    variantStyles = 'bg-transparent text-[#2b2b2b] border border-[#c9974f] hover:bg-[#c9974f] hover:text-black';
    circleStyles = 'border border-[#c9974f] text-[#c9974f] group-hover:border-black group-hover:text-black';
  } else if (variant === 'solid-gold') {
    variantStyles = 'bg-[#c9974f] text-black font-semibold hover:bg-[#e0b877] shadow-[0_4px_20px_rgba(201,151,79,0.3)]';
    circleStyles = 'bg-black text-[#c9974f] group-hover:scale-105';
  } else if (variant === 'text-link') {
    return (
      <button
        id={id}
        onClick={onClick}
        className={`group inline-flex items-center gap-2 text-xs font-semibold tracking-[0.16em] uppercase text-[#c9974f] hover:text-[#e0b877] transition-all duration-300 ${className}`}
      >
        <span>{label}</span>
        <span className="inline-block transition-transform duration-300 group-hover:translate-x-1">
          →
        </span>
      </button>
    );
  }

  const content = (
    <div className={`group inline-flex items-center rounded-full font-medium uppercase transition-all duration-300 cursor-pointer select-none ${sizeClasses} ${variantStyles} ${className}`}>
      {iconType !== 'none' && (
        <span className={`flex items-center justify-center w-6 h-6 rounded-full transition-all duration-300 shrink-0 ${circleStyles}`}>
          {iconType === 'arrow-up-right' ? (
            <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:rotate-45" />
          ) : (
            <ArrowRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-0.5" />
          )}
        </span>
      )}
      <span className="whitespace-nowrap">{label}</span>
    </div>
  );

  if (href) {
    return (
      <a id={id} href={href} onClick={onClick}>
        {content}
      </a>
    );
  }

  return (
    <button id={id} type="button" onClick={onClick}>
      {content}
    </button>
  );
};

import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  color: string;
  alpha: number;
  vx: number;
  vy: number;
  rotation: number;
  rotationSpeed: number;
  maxLife: number;
  life: number;
}

export const GoldSparkleCursor: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const lastMousePos = useRef<{ x: number; y: number } | null>(null);
  const mousePos = useRef<{ x: number; y: number }>({ x: -100, y: -100 });
  const isHoveredRef = useRef<boolean>(false);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    // Only run cursor particle effects on pointer-capable desktop screens
    if (window.matchMedia('(pointer: coarse)').matches) {
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const handleResize = () => {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const goldColors = [
      'rgba(201, 151, 79, ',  // Luxury base gold #c9974f
      'rgba(245, 215, 158, ', // Light champagne gold #f5d79e
      'rgba(224, 184, 119, ', // Medium amber gold #e0b877
      'rgba(255, 240, 200, ', // Ethereal sparkle white-gold
    ];

    const createParticle = (x: number, y: number, speed = 1) => {
      const angle = Math.random() * Math.PI * 2;
      const velocity = (Math.random() * 0.8 + 0.2) * speed;
      const color = goldColors[Math.floor(Math.random() * goldColors.length)];
      const maxLife = Math.floor(Math.random() * 25 + 25); // 25-50 frames

      return {
        x: x + (Math.random() * 8 - 4),
        y: y + (Math.random() * 8 - 4),
        size: Math.random() * 2.8 + 1.2,
        color,
        alpha: 1,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity - 0.15, // slight upward float
        rotation: Math.random() * Math.PI,
        rotationSpeed: (Math.random() - 0.5) * 0.08,
        maxLife,
        life: maxLife,
      };
    };

    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current = { x: e.clientX, y: e.clientY };
      isHoveredRef.current = true;

      const last = lastMousePos.current;
      if (last) {
        const dx = e.clientX - last.x;
        const dy = e.clientY - last.y;
        const dist = Math.hypot(dx, dy);

        // Spawn sparkle particles along the movement trajectory
        if (dist > 3) {
          const spawnCount = Math.min(Math.floor(dist / 5) + 1, 5);
          for (let i = 0; i < spawnCount; i++) {
            const t = i / spawnCount;
            const px = last.x + dx * t;
            const py = last.y + dy * t;
            if (particlesRef.current.length < 90) {
              particlesRef.current.push(createParticle(px, py, 1.2));
            }
          }
        }
      } else {
        particlesRef.current.push(createParticle(e.clientX, e.clientY));
      }

      lastMousePos.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseLeave = () => {
      isHoveredRef.current = false;
      lastMousePos.current = null;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    document.addEventListener('mouseleave', handleMouseLeave);

    // Draw 4-point star sparkle shape
    const drawSparkle = (
      c: CanvasRenderingContext2D,
      cx: number,
      cy: number,
      spikes: number,
      outerRadius: number,
      innerRadius: number,
      rotation: number
    ) => {
      let rot = (Math.PI / 2) * 3 + rotation;
      let x = cx;
      let y = cy;
      const step = Math.PI / spikes;

      c.beginPath();
      c.moveTo(cx, cy - outerRadius);
      for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        c.lineTo(x, y);
        rot += step;

        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        c.lineTo(x, y);
        rot += step;
      }
      c.lineTo(cx, cy - outerRadius);
      c.closePath();
      c.fill();
    };

    // Render loop
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life -= 1;
        p.alpha = Math.max(0, p.life / p.maxLife);
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.rotationSpeed;

        if (p.life <= 0) {
          particles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.fillStyle = `${p.color}${p.alpha.toFixed(3)})`;
        ctx.shadowColor = 'rgba(201, 151, 79, 0.6)';
        ctx.shadowBlur = 6;

        // Draw glittering 4-point star for sparkles, soft circles for faint dust
        if (p.size > 2.2) {
          drawSparkle(ctx, p.x, p.y, 4, p.size * 1.6, p.size * 0.45, p.rotation);
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.75, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      }

      // Subtle soft glowing halo following current cursor
      if (isHoveredRef.current && mousePos.current.x > 0) {
        ctx.save();
        const gradient = ctx.createRadialGradient(
          mousePos.current.x,
          mousePos.current.y,
          0,
          mousePos.current.x,
          mousePos.current.y,
          18
        );
        gradient.addColorStop(0, 'rgba(201, 151, 79, 0.12)');
        gradient.addColorStop(1, 'rgba(201, 151, 79, 0)');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(mousePos.current.x, mousePos.current.y, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-50 mix-blend-screen"
      style={{ willChange: 'transform' }}
    />
  );
};

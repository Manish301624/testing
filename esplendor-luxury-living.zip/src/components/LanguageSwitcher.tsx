import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Globe, ChevronDown, Check } from 'lucide-react';
import { useLanguage, LanguageCode } from '../lib/LanguageContext';

interface LanguageSwitcherProps {
  variant?: 'compact' | 'expanded';
  className?: string;
  dropdownAlign?: 'left' | 'right';
}

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({
  variant = 'compact',
  className = '',
  dropdownAlign = 'right',
}) => {
  const { language, setLanguage, currentLanguageOption, availableLanguages } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleSelect = (langCode: LanguageCode) => {
    setLanguage(langCode);
    setIsOpen(false);
  };

  if (variant === 'expanded') {
    return (
      <div className={`space-y-2 ${className}`}>
        <span className="text-[10px] uppercase font-mono tracking-widest text-[#c9974f] block">
          Language / Langue / Idioma
        </span>
        <div className="grid grid-cols-3 gap-2">
          {availableLanguages.map((lang) => {
            const isSelected = lang.code === language;
            return (
              <button
                key={lang.code}
                onClick={() => handleSelect(lang.code)}
                className={`py-2 px-3 rounded-lg border text-xs font-mono tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  isSelected
                    ? 'bg-[#c9974f] text-[#0a0a0a] font-bold border-[#c9974f] shadow-[0_0_12px_rgba(201,151,79,0.3)]'
                    : 'bg-[#14100c] border-[#2c2217] text-[#998b7a] hover:border-[#c9974f]/50 hover:text-white'
                }`}
              >
                <span>{lang.flag}</span>
                <span>{lang.code.toUpperCase()}</span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div ref={dropdownRef} className={`relative inline-block ${className}`}>
      {/* Trigger Button */}
      <button
        id="language-switcher-trigger"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="listbox"
        className="px-2.5 py-1.5 rounded-full bg-[#161411] hover:bg-[#201a14] border border-[#33281c] hover:border-[#c9974f] text-[#c9974f] hover:text-[#f5d79e] transition-all duration-200 flex items-center gap-1.5 text-xs font-mono cursor-pointer shadow-sm group"
        title="Select Language / Changer de langue / Cambiar idioma"
      >
        <Globe className="w-3.5 h-3.5 text-[#c9974f] group-hover:rotate-12 transition-transform duration-300" />
        <span className="font-semibold tracking-wider uppercase text-[11px] text-[#e0d6c8] group-hover:text-white">
          {currentLanguageOption.code.toUpperCase()}
        </span>
        <ChevronDown
          className={`w-3 h-3 text-[#c9974f] transition-transform duration-200 ${
            isOpen ? 'rotate-180 text-white' : ''
          }`}
        />
      </button>

      {/* Luxury Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.96 }}
            transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
            role="listbox"
            className={`absolute top-full mt-2 w-44 rounded-xl bg-[#120f0c]/98 border border-[#3d2f20] shadow-[0_12px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(201,151,79,0.15)] backdrop-blur-xl p-1.5 z-50 overflow-hidden ${
              dropdownAlign === 'right' ? 'right-0' : 'left-0'
            }`}
          >
            {/* Header label inside dropdown */}
            <div className="px-2.5 py-1.5 border-b border-[#241c14] mb-1">
              <span className="text-[9px] font-mono tracking-widest text-[#8a7a66] uppercase block">
                Select Language
              </span>
            </div>

            <div className="space-y-1">
              {availableLanguages.map((lang) => {
                const isSelected = lang.code === language;
                return (
                  <button
                    key={lang.code}
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => handleSelect(lang.code)}
                    className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#22180f] text-[#f5d79e] border border-[#c9974f]/40 font-medium'
                        : 'text-[#bbb0a2] hover:bg-[#1b1510] hover:text-white hover:border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{lang.flag}</span>
                      <div className="flex flex-col">
                        <span className="text-xs font-sans font-medium text-white">
                          {lang.nativeName}
                        </span>
                        <span className="text-[9px] font-mono text-[#8a7a66]">
                          {lang.label} ({lang.code.toUpperCase()})
                        </span>
                      </div>
                    </div>

                    {isSelected && (
                      <Check className="w-3.5 h-3.5 text-[#c9974f] shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

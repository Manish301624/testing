import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bot, 
  Send, 
  X, 
  Sparkles, 
  Loader2, 
  Trash2, 
  Minimize2, 
  Maximize2, 
  HelpCircle,
  Building,
  MapPin,
  Clock,
  Zap,
  Flame,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useAuth } from '../lib/AuthContext';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  modelUsed?: string;
}

interface GeminiChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenConsultation?: (subject?: string) => void;
  selectedProjectName?: string;
}

export const GeminiChatDrawer: React.FC<GeminiChatDrawerProps> = ({
  isOpen,
  onClose,
  onOpenConsultation,
  selectedProjectName
}) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'model',
      content: `Welcome to **ESPLENDOR Private Advisory**. I am your dedicated AI Concierge & Architectural Advisor.\n\nI can assist you with comprehensive details regarding our ultra-luxury residences in Assagao, Siolim, Candolim, Moira, and Vagator, including bespoke finishes, yields, site visits, and purchase procedures.\n\nHow may I curate your journey today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [taskComplexity, setTaskComplexity] = useState<'fast' | 'general' | 'complex'>('general');
  const [isMaximized, setIsMaximized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        scrollToBottom();
      }, 200);
    }
  }, [isOpen, messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setIsLoading(true);

    try {
      // Prepare payload for backend proxy
      const apiMessages = newHistory.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          taskComplexity,
          selectedProjectName,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to receive concierge response.');
      }

      const modelMsg: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.modelUsed,
      };

      setMessages((prev) => [...prev, modelMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        content: `*Apologies, our concierge connection encountered a brief delay:* ${err.message || 'Please retry in a moment or schedule a private consultation.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'model',
        content: 'Conversation history refreshed. How may I assist your exploration of ESPLENDOR properties today?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }
    ]);
  };

  const quickPrompts = [
    'Tell me about Casa Bella villa in Assagao',
    'Compare rental yields in Siolim vs Candolim',
    'What turnkey interior concierge services do you provide?',
    'Schedule a private site viewing with director'
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop on mobile */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm lg:hidden"
          />

          {/* Chat Floating Window / Drawer */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.96 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              width: isMaximized ? '94vw' : undefined,
              height: isMaximized ? '90vh' : undefined,
            }}
            exit={{ opacity: 0, y: 30, scale: 0.96 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className={`fixed z-50 bottom-0 left-0 right-0 sm:left-auto sm:right-6 sm:bottom-6 bg-[#0e0e0e] border border-[#c9974f]/40 rounded-t-2xl sm:rounded-xl shadow-[0_10px_40px_rgba(0,0,0,0.85)] flex flex-col overflow-hidden w-full sm:w-[440px] max-w-full sm:max-w-[95vw] h-[85vh] sm:h-[620px] max-h-[95vh]`}
          >
            {/* Header */}
            <div className="px-3.5 sm:px-4 py-3 sm:py-3.5 bg-[#141414] border-b border-[#252019] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                <div className="relative shrink-0">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#1b1712] border border-[#c9974f] flex items-center justify-center text-[#c9974f] shadow-[0_0_12px_rgba(201,151,79,0.3)]">
                    <Bot className="w-4 h-4 sm:w-5 sm:h-5" />
                  </div>
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#141414]" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="font-serif text-xs sm:text-sm font-bold text-white tracking-wide truncate">
                      ESPLENDOR AI Concierge
                    </h3>
                    <span className="px-1.5 py-0.5 rounded text-[8.5px] sm:text-[9px] bg-[#c9974f]/15 border border-[#c9974f]/30 text-[#c9974f] font-mono uppercase shrink-0">
                      Gemini
                    </span>
                  </div>
                  <p className="text-[9.5px] sm:text-[10px] text-[#8e8e8e] flex items-center gap-1 font-sans truncate">
                    <span>Private Advisory</span>
                    {selectedProjectName && (
                      <>
                        <span>•</span>
                        <span className="text-[#c9974f] truncate max-w-[140px]">
                          {selectedProjectName}
                        </span>
                      </>
                    )}
                  </p>
                </div>
              </div>

              {/* Window Controls */}
              <div className="flex items-center gap-1 shrink-0 ml-2">
                <button
                  onClick={handleClearHistory}
                  title="Clear conversation"
                  className="p-1.5 sm:p-2 text-[#888] hover:text-[#c9974f] transition-colors rounded hover:bg-white/5 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsMaximized(!isMaximized)}
                  title={isMaximized ? "Restore size" : "Maximize window"}
                  className="p-1.5 sm:p-2 text-[#888] hover:text-white transition-colors rounded hover:bg-white/5 cursor-pointer hidden sm:block"
                >
                  {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
                <button
                  onClick={onClose}
                  title="Close concierge"
                  className="p-1.5 sm:p-2 text-[#888] hover:text-red-400 transition-colors rounded hover:bg-white/5 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Model Complexity & Role Selector Bar */}
            <div className="px-3 sm:px-4 py-2 bg-[#0a0a0a] border-b border-[#201c17] flex items-center justify-between text-[10px] gap-2 overflow-x-auto scrollbar-none shrink-0">
              <span className="text-[#777] uppercase tracking-wider font-semibold whitespace-nowrap text-[9px] sm:text-[10px]">
                Reasoning:
              </span>
              <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
                <button
                  onClick={() => setTaskComplexity('fast')}
                  className={`px-2 py-0.5 sm:py-1 rounded text-[9.5px] sm:text-[10px] transition-colors flex items-center gap-1 cursor-pointer whitespace-nowrap ${
                    taskComplexity === 'fast'
                      ? 'bg-[#c9974f] text-black font-semibold shadow-[0_0_8px_rgba(201,151,79,0.4)]'
                      : 'text-[#888] hover:text-white bg-[#161616]'
                  }`}
                  title="Fast tasks (gemini-3.1-flash-lite)"
                >
                  <Zap className="w-2.5 h-2.5" />
                  <span>Lite</span>
                </button>
                <button
                  onClick={() => setTaskComplexity('general')}
                  className={`px-2 py-0.5 sm:py-1 rounded text-[9.5px] sm:text-[10px] transition-colors flex items-center gap-1 cursor-pointer whitespace-nowrap ${
                    taskComplexity === 'general'
                      ? 'bg-[#c9974f] text-black font-semibold shadow-[0_0_8px_rgba(201,151,79,0.4)]'
                      : 'text-[#888] hover:text-white bg-[#161616]'
                  }`}
                  title="General tasks (gemini-3.5-flash)"
                >
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Flash</span>
                </button>
                <button
                  onClick={() => setTaskComplexity('complex')}
                  className={`px-2 py-0.5 sm:py-1 rounded text-[9.5px] sm:text-[10px] transition-colors flex items-center gap-1 cursor-pointer whitespace-nowrap ${
                    taskComplexity === 'complex'
                      ? 'bg-[#c9974f] text-black font-semibold shadow-[0_0_8px_rgba(201,151,79,0.4)]'
                      : 'text-[#888] hover:text-white bg-[#161616]'
                  }`}
                  title="Complex tasks (gemini-3.1-pro-preview)"
                >
                  <Flame className="w-2.5 h-2.5" />
                  <span>Pro Deep</span>
                </button>
              </div>
            </div>

            {/* Message Thread */}
            <div className="flex-1 p-3 sm:p-4 overflow-y-auto space-y-3 sm:space-y-4 font-sans text-xs scroll-smooth">
              {messages.map((msg) => {
                const isUser = msg.role === 'user';
                return (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.25 }}
                    className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[90%] sm:max-w-[85%] rounded-2xl px-3.5 py-2.5 sm:px-4 sm:py-3 leading-relaxed break-words ${
                        isUser
                          ? 'bg-[#c9974f] text-black font-medium rounded-br-sm shadow-[0_2px_12px_rgba(201,151,79,0.25)]'
                          : 'bg-[#181818] border border-[#2b251d] text-[#e0e0e0] rounded-bl-sm shadow-md'
                      }`}
                    >
                      {isUser ? (
                        <p className="whitespace-pre-wrap text-xs sm:text-sm">{msg.content}</p>
                      ) : (
                        <div className="space-y-2 prose prose-invert prose-xs max-w-none text-[#e0e0e0] leading-relaxed text-xs sm:text-[13px]">
                          <ReactMarkdown>{msg.content}</ReactMarkdown>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-1 px-1 text-[9px] text-[#666]">
                      <span>{msg.timestamp}</span>
                      {msg.modelUsed && (
                        <span className="text-[#c9974f]/70 font-mono">
                          {msg.modelUsed}
                        </span>
                      )}
                    </div>
                  </motion.div>
                );
              })}

              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2.5 bg-[#181818] border border-[#2b251d] text-[#c9974f] px-3.5 py-2.5 rounded-2xl rounded-bl-sm w-fit text-xs"
                >
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span className="text-[#a0a0a0] font-sans text-xs">
                    Advisor formulating response with Gemini...
                  </span>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Prompt Chips */}
            {messages.length < 4 && (
              <div className="px-3 sm:px-4 py-2 bg-[#0c0c0c] border-t border-[#1e1a14] flex items-center gap-2 overflow-x-auto scrollbar-none shrink-0">
                {quickPrompts.map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(prompt)}
                    className="whitespace-nowrap px-2.5 py-1 rounded-full bg-[#161616] hover:bg-[#c9974f]/15 border border-[#2a241b] hover:border-[#c9974f]/40 text-[10px] sm:text-[10.5px] text-[#aaa] hover:text-[#c9974f] transition-all cursor-pointer shrink-0"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            )}

            {/* Input Form */}
            <div className="p-2.5 sm:p-3 bg-[#121212] border-t border-[#252019] shrink-0">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="flex items-center gap-2"
              >
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about properties, floorplans, or architecture..."
                  className="flex-1 bg-[#1a1a1a] border border-[#2e271f] focus:border-[#c9974f] focus:outline-none px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-lg text-white placeholder-[#555] text-xs transition-colors"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="p-2 sm:p-2.5 rounded-lg bg-[#c9974f] hover:bg-[#e0b877] text-black font-semibold disabled:opacity-40 transition-all cursor-pointer shadow-[0_0_12px_rgba(201,151,79,0.3)] shrink-0"
                  title="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
              <div className="flex flex-col xs:flex-row items-start xs:items-center justify-between mt-2 px-1 text-[9px] sm:text-[9.5px] text-[#666] gap-1">
                <span>Discreet luxury advisory • Gemini AI</span>
                {onOpenConsultation && (
                  <button
                    onClick={() => onOpenConsultation('Direct Inquiry from AI Concierge')}
                    className="text-[#c9974f] hover:underline cursor-pointer font-medium"
                  >
                    Book In-Person Consultation →
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

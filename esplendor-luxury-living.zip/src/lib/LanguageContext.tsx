import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type LanguageCode = 'en' | 'fr' | 'es';

export interface LanguageOption {
  code: LanguageCode;
  label: string;
  nativeName: string;
  flag: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en', label: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'fr', label: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'es', label: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
];

export interface TranslationDictionary {
  [key: string]: string;
}

export const TRANSLATIONS: Record<LanguageCode, TranslationDictionary> = {
  en: {
    // Navigation
    'nav.home': 'HOME',
    'nav.ourStory': 'OUR STORY',
    'nav.luxuryHomes': 'LUXURY HOMES',
    'nav.livingDifference': 'THE LIVING DIFFERENCE',
    'nav.contact': 'CONTACT',
    'nav.aiConcierge': 'AI Concierge',
    'nav.aiConciergeSub': 'Gemini Multi-Turn Advisory',
    'nav.connect': "LET'S CONNECT",
    'nav.scheduleConsultation': 'SCHEDULE A CONSULTATION',
    'nav.brandTagline': 'CRAFTING TIMELESS LIVING',
    'nav.portfolio': 'Client Portfolio',
    'nav.language': 'Language',

    // Hero & Common
    'hero.badge': 'GOA ARCHITECTURAL SANCTUARY',
    'hero.title1': 'Sculpted by Heritage.',
    'hero.title2': 'Defined by Tranquility.',
    'hero.desc': 'A curated collection of bespoke private estates in Goa, honoring Indo-Portuguese craftsmanship and refined modern living.',
    'hero.exploreHomes': 'EXPLORE PRIVATE ESTATES',
    'hero.ourPhilosophy': 'OUR PHILOSOPHY',

    // Stats
    'stats.curatedVillas': 'Curated Estates Delivered',
    'stats.avgPlot': 'Sq.Ft. Average Plot Size',
    'stats.patronSatisfaction': 'Patron Satisfaction',
    'stats.heritageRestoration': 'Portuguese Heritage Roots',

    // Testimonials
    'testimonials.eyebrow': 'DISTINGUISHED PATRONS',
    'testimonials.title1': 'Voices of',
    'testimonials.title2': 'Refined Living',
    'testimonials.desc': 'Reflections from connoisseurs, collectors, and visionary families who have made Esplendor their sanctuary.',
    'testimonials.badge': 'Private Client Endorsement',
    'testimonials.residence': 'Residence',

    // Luxury Insights / FAQ
    'insights.eyebrow': 'CLIENT ADVISORY & BESPOKE PROTOCOLS',
    'insights.title1': 'Luxury',
    'insights.title2': 'Insights & FAQ',
    'insights.desc': 'Transparent answers on bespoke architectural commissions, private NRI conveyancing, and turnkey estate governance.',
    'insights.searchPlaceholder': 'Search bespoke topics...',
    'insights.all': 'All Inquiries',
    'insights.architecture': 'Bespoke Architecture',
    'insights.concierge': 'Asset & Concierge',
    'insights.legal': 'Conveyancing & NRI',
    'insights.climate': 'Climate & Tech',
    'insights.confidentialAdvisory': 'Confidential Advisory',
    'insights.advisoryTitle': 'Have a bespoke architectural inquiry or private viewing request?',
    'insights.advisoryDesc': 'Our founding directors and master architects are available for private consultations under strict NDA.',
    'insights.connectDirectors': 'CONNECT WITH DIRECTORS',
    'insights.keyGuarantee': 'Key Guarantee:',

    // Living Difference
    'living.eyebrow': 'THE LIVING DIFFERENCE',
    'living.heroTitle1': 'Beyond Architecture,',
    'living.heroTitle2': 'An Enduring Legacy',
    'living.heroDesc': 'Every Esplendor villa is envisioned as a generational asset—combining heritage craftsmanship, intuitive smart technology, and six-star estate governance.',

    // Luxury Homes page
    'homes.eyebrow': 'CURATED RESIDENTIAL PORTFOLIO',
    'homes.title1': 'Signature Private',
    'homes.title2': 'Estates & Villas',
    'homes.desc': 'Explore our exclusive collection of completed and commissionable luxury sanctuaries across Goa.',
    'homes.allLocations': 'All Locations',
    'homes.bedrooms': 'Bedrooms',
    'homes.viewDetails': 'VIEW SANCTUARY DETAILS',
    'homes.inquire': 'INQUIRE NOW',
    'homes.filterStatus': 'Status',

    // Story page
    'story.eyebrow': 'OUR HERITAGE & PROMISE',
    'story.title1': 'The Art of',
    'story.title2': 'Timeless Habitation',
    'story.desc': 'Founded with a profound reverence for Goan-Portuguese architectural pedigree and uncompromising luxury construction standards.',

    // Contact page
    'contact.eyebrow': 'DIRECT ENGAGEMENT',
    'contact.title1': 'Begin Your',
    'contact.title2': 'Private Journey',
    'contact.desc': 'Connect directly with our founding principals for confidential estate consultations, site appointments, or bespoke commissions.',
    'contact.formName': 'Full Name',
    'contact.formEmail': 'Email Address',
    'contact.formPhone': 'Phone / WhatsApp',
    'contact.formSubject': 'Area of Interest',
    'contact.formMessage': 'Bespoke Requirements / Message',
    'contact.sendInquiry': 'TRANSMIT CONFIDENTIAL INQUIRY',

    // Footer
    'footer.desc': 'Crafting bespoke luxury residences in Goa where timeless architecture, natural tranquility, and refined hospitality unite.',
    'footer.navigation': 'Navigation',
    'footer.estates': 'Signature Sanctuaries',
    'footer.advisory': 'Private Advisory',
    'footer.rights': 'All rights reserved. Designed for distinguished connoisseurs of architecture.',
    'footer.privacy': 'Privacy Policy',
    'footer.terms': 'Terms of Bespoke Commission',
    'footer.rera': 'RERA Certified Goa',

    // Common UI
    'ui.close': 'Close',
    'ui.back': 'Back',
    'ui.loading': 'Loading Bespoke Sanctuary Assets...',
    'ui.scrollToTop': 'Return to top',
  },
  fr: {
    // Navigation
    'nav.home': 'ACCUEIL',
    'nav.ourStory': 'NOTRE HISTOIRE',
    'nav.luxuryHomes': 'RÉSIDENCES DE LUXE',
    'nav.livingDifference': "L'ART DE VIVRE",
    'nav.contact': 'CONTACT',
    'nav.aiConcierge': 'Concierge IA',
    'nav.aiConciergeSub': 'Conseil Interactif Gemini',
    'nav.connect': 'PRENDRE CONTACT',
    'nav.scheduleConsultation': 'PLANIFIER UNE CONSULTATION',
    'nav.brandTagline': 'FAÇONNER UN ART DE VIVRE INTEMPOREL',
    'nav.portfolio': 'Portefeuille Client',
    'nav.language': 'Langue',

    // Hero & Common
    'hero.badge': 'SANCTUAIRE ARCHITECTURAL À GOA',
    'hero.title1': 'Sculpté par le Patrimoine.',
    'hero.title2': 'Défini par la Sérénité.',
    'hero.desc': 'Une collection exclusive de propriétés privées sur mesure à Goa, célébrant le savoir-faire indo-portugais et un art de vivre contemporain raffiné.',
    'hero.exploreHomes': 'EXPLORER LES DOMAINES PRIVÉS',
    'hero.ourPhilosophy': 'NOTRE PHILOSOPHIE',

    // Stats
    'stats.curatedVillas': 'Domaines Exclusifs Livrés',
    'stats.avgPlot': 'Pieds Carrés Moyens par Parcelle',
    'stats.patronSatisfaction': 'Satisfaction de Nos Patrons',
    'stats.heritageRestoration': 'Héritage Portugais Restauré',

    // Testimonials
    'testimonials.eyebrow': 'DISTINGUÉS PATRONS',
    'testimonials.title1': 'Les Voix du',
    'testimonials.title2': 'Raffinement Vivant',
    'testimonials.desc': 'Témoignages de connaisseurs, collectionneurs et familles visionnaires ayant choisi Esplendor comme sanctuaire.',
    'testimonials.badge': 'Approbation Client Privé',
    'testimonials.residence': 'Résidence',

    // Luxury Insights / FAQ
    'insights.eyebrow': 'CONSEIL CLIENT & PROTOCOLES SUR MESURE',
    'insights.title1': 'Aperçus de Luxe',
    'insights.title2': '& Questions Fréquentes',
    'insights.desc': 'Réponses claires sur les projets architecturaux sur mesure, les actes notariés privés pour non-résidents et la conciergerie clé en main.',
    'insights.searchPlaceholder': 'Rechercher un thème sur mesure...',
    'insights.all': 'Toutes les Demandes',
    'insights.architecture': 'Architecture Sur Mesure',
    'insights.concierge': 'Gestion & Conciergerie',
    'insights.legal': 'Droit & Non-Résidents',
    'insights.climate': 'Climat & Technologies',
    'insights.confidentialAdvisory': 'Conseil Confidentiel',
    'insights.advisoryTitle': 'Une demande architecturale sur mesure ou une visite privée ?',
    'insights.advisoryDesc': 'Nos directeurs fondateurs et maîtres architectes sont disponibles pour des consultations privées sous accord de confidentialité strict.',
    'insights.connectDirectors': 'ÉCHANGER AVEC LES DIRECTEURS',
    'insights.keyGuarantee': 'Garantie Majeure :',

    // Living Difference
    'living.eyebrow': "L'ART DE VIVRE ESPLENDOR",
    'living.heroTitle1': 'Au-delà de l’Architecture,',
    'living.heroTitle2': 'Un Héritage Durable',
    'living.heroDesc': 'Chaque villa Esplendor est pensée comme un bien générationnel—alliant artisanat patrimonial, domotique discrète et conciergerie six étoiles.',

    // Luxury Homes page
    'homes.eyebrow': 'COLLECTION RÉSIDENTIELLE SUR MESURE',
    'homes.title1': 'Domaines Privés',
    'homes.title2': '& Villas de Prestige',
    'homes.desc': 'Découvrez notre sélection exclusive de sanctuaires d’exception achevés et personnalisables à Goa.',
    'homes.allLocations': 'Toutes les Localisations',
    'homes.bedrooms': 'Chambres',
    'homes.viewDetails': 'DÉCOUVRIR LE SANCTUAIRE',
    'homes.inquire': 'FAIRE UNE DEMANDE',
    'homes.filterStatus': 'Statut',

    // Story page
    'story.eyebrow': 'NOTRE HÉRITAGE & NOTRE ENGAGEMENT',
    'story.title1': "L'Art de",
    'story.title2': 'La Demeure Intemporelle',
    'story.desc': 'Fondé sur un respect absolu de la tradition architecturale luso-indienne et des normes de construction de très haut prestige.',

    // Contact page
    'contact.eyebrow': 'RELATION PRIVILÉGIÉE',
    'contact.title1': 'Initiez Votre',
    'contact.title2': 'Voyage Privé',
    'contact.desc': 'Contactez directement nos associés fondateurs pour un échange confidentiel, une visite exclusive ou une commande sur mesure.',
    'contact.formName': 'Nom et Prénom',
    'contact.formEmail': 'Adresse Courriel',
    'contact.formPhone': 'Téléphone / WhatsApp',
    'contact.formSubject': 'Objet d’Intérêt',
    'contact.formMessage': 'Exigences Particulières / Message',
    'contact.sendInquiry': 'ENVOYER LA DEMANDE CONFIDENTIELLE',

    // Footer
    'footer.desc': 'Créateur de résidences de prestige à Goa où convergent architecture intemporelle, sérénité naturelle et hospitalité d’exception.',
    'footer.navigation': 'Navigation',
    'footer.estates': 'Domaines Signatures',
    'footer.advisory': 'Conseil Privé',
    'footer.rights': 'Tous droits réservés. Conçu pour les esthètes et connaisseurs d’architecture.',
    'footer.privacy': 'Politique de Confidentialité',
    'footer.terms': 'Conditions de Réalisation',
    'footer.rera': 'Certifié RERA Goa',

    // Common UI
    'ui.close': 'Fermer',
    'ui.back': 'Retour',
    'ui.loading': 'Chargement des Joyaux Architecturaux...',
    'ui.scrollToTop': 'Remonter en haut',
  },
  es: {
    // Navigation
    'nav.home': 'INICIO',
    'nav.ourStory': 'NUESTRA HISTORIA',
    'nav.luxuryHomes': 'RESIDENCIAS DE LUJO',
    'nav.livingDifference': 'LA DIFERENCIA LIVING',
    'nav.contact': 'CONTACTO',
    'nav.aiConcierge': 'Conserje IA',
    'nav.aiConciergeSub': 'Asesoría Interactiva Gemini',
    'nav.connect': 'CONTACTAR',
    'nav.scheduleConsultation': 'AGENDAR CONSULTA',
    'nav.brandTagline': 'CREANDO UN VIVIR ATEMPORAL',
    'nav.portfolio': 'Portafolio de Cliente',
    'nav.language': 'Idioma',

    // Hero & Common
    'hero.badge': 'SANTUARIO ARQUITECTÓNICO EN GOA',
    'hero.title1': 'Esculpido por el Patrimonio.',
    'hero.title2': 'Definido por la Tranquilidad.',
    'hero.desc': 'Una selecta colección de fincas privadas a medida en Goa, honrando la maestría indo-portuguesa y un refinado estilo de vida moderno.',
    'hero.exploreHomes': 'EXPLORAR FINCAS PRIVADAS',
    'hero.ourPhilosophy': 'NUESTRA FILOSOFÍA',

    // Stats
    'stats.curatedVillas': 'Fincas Exclusivas Entregadas',
    'stats.avgPlot': 'Pies Cuadrados Promedio por Terreno',
    'stats.patronSatisfaction': 'Satisfacción de Nuestros Clientes',
    'stats.heritageRestoration': 'Raíces Lusitanas Restauradas',

    // Testimonials
    'testimonials.eyebrow': 'DIGNOS PATROCINADORES',
    'testimonials.title1': 'Voces de la',
    'testimonials.title2': 'Vida Sofisticada',
    'testimonials.desc': 'Reflexiones de conocedores, coleccionistas y familias visionarias que han hecho de Esplendor su santuario.',
    'testimonials.badge': 'Respaldo de Cliente Privado',
    'testimonials.residence': 'Residencia',

    // Luxury Insights / FAQ
    'insights.eyebrow': 'ASESORÍA PRIVADA Y PROTOCOLOS EXCLUSIVOS',
    'insights.title1': 'Perspectivas de Lujo',
    'insights.title2': 'y Preguntas Frecuentes',
    'insights.desc': 'Respuestas transparentes sobre encargos arquitectónicos a medida, escrituración privada para inversores y gestión patrimonial integral.',
    'insights.searchPlaceholder': 'Buscar temas personalizados...',
    'insights.all': 'Todas las Consultas',
    'insights.architecture': 'Arquitectura a Medida',
    'insights.concierge': 'Patrimonio y Conserjería',
    'insights.legal': 'Legal e Inversión Extranjera',
    'insights.climate': 'Clima y Sostenibilidad',
    'insights.confidentialAdvisory': 'Asesoría Confidencial',
    'insights.advisoryTitle': '¿Tiene una consulta de diseño o desea agendar una visita privada?',
    'insights.advisoryDesc': 'Nuestros directores fundadores y arquitectos principales están disponibles para consultas privadas bajo estricto acuerdo de confidencialidad.',
    'insights.connectDirectors': 'CONTACTAR CON LOS DIRECTORES',
    'insights.keyGuarantee': 'Garantía Clave:',

    // Living Difference
    'living.eyebrow': 'LA DIFERENCIA LIVING',
    'living.heroTitle1': 'Más Allá de la Arquitectura,',
    'living.heroTitle2': 'Un Legado Perdurable',
    'living.heroDesc': 'Cada villa Esplendor está concebida como un activo patrimonial generacional: fusionando artesanía histórica, domótica invisible y hospitalidad de seis estrellas.',

    // Luxury Homes page
    'homes.eyebrow': 'COLECCIÓN RESIDENCIAL EXCLUSIVA',
    'homes.title1': 'Fincas Privadas',
    'homes.title2': 'y Villas de Autor',
    'homes.desc': 'Explore nuestra exclusiva selección de santuarios residenciales listos y personalizables en Goa.',
    'homes.allLocations': 'Todas las Ubicaciones',
    'homes.bedrooms': 'Habitaciones',
    'homes.viewDetails': 'VER DETALLES DEL SANTUARIO',
    'homes.inquire': 'CONSULTAR AHORA',
    'homes.filterStatus': 'Estado',

    // Story page
    'story.eyebrow': 'NUESTRO PATRIMONIO Y COMPROMISO',
    'story.title1': 'El Arte de',
    'story.title2': 'Habitar Atemporalmente',
    'story.desc': 'Fundada con una profunda reverencia por la tradición arquitectónica goano-portuguesa y rigurosos estándares constructivos de lujo.',

    // Contact page
    'contact.eyebrow': 'ATENCIÓN DIRECTA',
    'contact.title1': 'Comience su',
    'contact.title2': 'Viaje Privado',
    'contact.desc': 'Comuníquese directamente con nuestros directores fundadores para consultas privadas, citas exclusivas o encargos a medida.',
    'contact.formName': 'Nombre Completo',
    'contact.formEmail': 'Correo Electrónico',
    'contact.formPhone': 'Teléfono / WhatsApp',
    'contact.formSubject': 'Área de Interés',
    'contact.formMessage': 'Requisitos Especiales / Mensaje',
    'contact.sendInquiry': 'ENVIAR CONSULTA CONFIDENCIAL',

    // Footer
    'footer.desc': 'Creando residencias de lujo a medida en Goa donde la arquitectura atemporal, la tranquilidad natural y la hospitalidad distinguida se unen.',
    'footer.navigation': 'Navegación',
    'footer.estates': 'Santuarios Exclusivos',
    'footer.advisory': 'Asesoría Privada',
    'footer.rights': 'Todos los derechos reservados. Diseñado para distinguidos amantes de la arquitectura.',
    'footer.privacy': 'Política de Privacidad',
    'footer.terms': 'Términos de Encargo a Medida',
    'footer.rera': 'Certificado RERA Goa',

    // Common UI
    'ui.close': 'Cerrar',
    'ui.back': 'Volver',
    'ui.loading': 'Cargando Santuarios de Autor...',
    'ui.scrollToTop': 'Volver arriba',
  },
};

interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string, defaultText?: string) => string;
  currentLanguageOption: LanguageOption;
  availableLanguages: LanguageOption[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem('esplendor_language') as LanguageCode;
      if (saved && (saved === 'en' || saved === 'fr' || saved === 'es')) {
        return saved;
      }
    } catch {
      // ignore
    }
    return 'en';
  });

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('esplendor_language', lang);
    } catch {
      // ignore
    }
  };

  const t = (key: string, defaultText?: string): string => {
    const dict = TRANSLATIONS[language] || TRANSLATIONS.en;
    if (dict[key]) {
      return dict[key];
    }
    // Fallback to English
    if (TRANSLATIONS.en[key]) {
      return TRANSLATIONS.en[key];
    }
    return defaultText || key;
  };

  const currentLanguageOption =
    SUPPORTED_LANGUAGES.find((item) => item.code === language) || SUPPORTED_LANGUAGES[0];

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t,
        currentLanguageOption,
        availableLanguages: SUPPORTED_LANGUAGES,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

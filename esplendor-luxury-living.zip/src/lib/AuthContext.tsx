import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  signInWithPopup, 
  signOut as firebaseSignOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  onSnapshot, 
  deleteDoc, 
  addDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { auth, googleProvider, db } from './firebase';

export interface SavedPropertyItem {
  id: string;
  projectId: string;
  projectName: string;
  location: string;
  price: string;
  image: string;
  bedrooms: number;
  area: string;
  savedAt?: any;
}

export interface UserInquiryItem {
  id: string;
  subject: string;
  message: string;
  status: string;
  createdAt?: any;
}

export interface VideoGenerationItem {
  id: string;
  title: string;
  prompt: string;
  sourceImageUrl?: string;
  videoUrl?: string;
  aspectRatio: '16:9' | '9:16';
  status: 'generating' | 'completed' | 'failed';
  createdAt?: any;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  savedProperties: SavedPropertyItem[];
  userInquiries: UserInquiryItem[];
  userVideos: VideoGenerationItem[];
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  saveProperty: (property: Omit<SavedPropertyItem, 'id' | 'savedAt'>) => Promise<void>;
  unsaveProperty: (projectId: string) => Promise<void>;
  isPropertySaved: (projectId: string) => boolean;
  saveVideoRecord: (video: Omit<VideoGenerationItem, 'id' | 'createdAt'>) => Promise<string>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [savedProperties, setSavedProperties] = useState<SavedPropertyItem[]>([]);
  const [userInquiries, setUserInquiries] = useState<UserInquiryItem[]>([]);
  const [userVideos, setUserVideos] = useState<VideoGenerationItem[]>([]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Sync user profile to Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        try {
          const userDoc = await getDoc(userRef);
          if (!userDoc.exists()) {
            await setDoc(userRef, {
              id: currentUser.uid,
              email: currentUser.email,
              displayName: currentUser.displayName,
              photoURL: currentUser.photoURL,
              role: 'client',
              createdAt: new Date().toISOString(),
            });
          }
        } catch (err) {
          console.error('Error creating user profile in Firestore:', err);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen to user's saved properties in real time
  useEffect(() => {
    if (!user) {
      setSavedProperties([]);
      setUserVideos([]);
      return;
    }

    const savedPropsRef = collection(db, 'users', user.uid, 'savedProperties');
    const unsubProps = onSnapshot(savedPropsRef, (snapshot) => {
      const items: SavedPropertyItem[] = [];
      snapshot.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...(docSnap.data() as any) });
      });
      setSavedProperties(items);
    }, (error) => {
      console.warn('Saved properties snapshot error:', error);
    });

    const videosRef = collection(db, 'users', user.uid, 'cinematicVideos');
    const unsubVideos = onSnapshot(videosRef, (snapshot) => {
      const items: VideoGenerationItem[] = [];
      snapshot.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...(docSnap.data() as any) });
      });
      setUserVideos(items);
    }, (error) => {
      console.warn('Cinematic videos snapshot error:', error);
    });

    return () => {
      unsubProps();
      unsubVideos();
    };
  }, [user]);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.error('Sign-in error:', error);
      throw error;
    }
  };

  const signOut = async () => {
    try {
      await firebaseSignOut(auth);
    } catch (error) {
      console.error('Sign-out error:', error);
    }
  };

  const saveProperty = async (property: Omit<SavedPropertyItem, 'id' | 'savedAt'>) => {
    if (!user) {
      await signInWithGoogle();
      return;
    }
    const propDocRef = doc(db, 'users', user.uid, 'savedProperties', property.projectId);
    await setDoc(propDocRef, {
      ...property,
      userId: user.uid,
      savedAt: new Date().toISOString(),
    });
  };

  const unsaveProperty = async (projectId: string) => {
    if (!user) return;
    const propDocRef = doc(db, 'users', user.uid, 'savedProperties', projectId);
    await deleteDoc(propDocRef);
  };

  const isPropertySaved = (projectId: string) => {
    return savedProperties.some((p) => p.projectId === projectId);
  };

  const saveVideoRecord = async (video: Omit<VideoGenerationItem, 'id' | 'createdAt'>) => {
    if (!user) throw new Error('Authentication required to save video');
    const videosRef = collection(db, 'users', user.uid, 'cinematicVideos');
    const docRef = await addDoc(videosRef, {
      ...video,
      userId: user.uid,
      createdAt: new Date().toISOString(),
    });
    return docRef.id;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        savedProperties,
        userInquiries,
        userVideos,
        signInWithGoogle,
        signOut,
        saveProperty,
        unsaveProperty,
        isPropertySaved,
        saveVideoRecord,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

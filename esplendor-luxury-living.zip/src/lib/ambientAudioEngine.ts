// Web Audio API Organic Ambient Soundscape Synthesizer
// Generates gentle, soothing, high-fidelity luxury soundscapes directly in the browser

export type SoundscapeType = 'coastal-waves' | 'villa-sunset' | 'tropical-breeze';

export interface SoundscapeInfo {
  id: SoundscapeType;
  name: string;
  subtitle: string;
  description: string;
  icon: string;
}

export const SOUNDSCAPES: SoundscapeInfo[] = [
  {
    id: 'coastal-waves',
    name: 'Goan Coastal Waves',
    subtitle: 'Assagao & Candolim Surf',
    description: 'Rhythmic, warm ocean waves breaking softly against golden Goan sands.',
    icon: 'waves',
  },
  {
    id: 'villa-sunset',
    name: 'Sunset Villa Serenity',
    subtitle: 'Warm Harmonic Atmosphere',
    description: 'Ethereal ambient chords and resonant warm pads inspired by Goan twilight.',
    icon: 'sunset',
  },
  {
    id: 'tropical-breeze',
    name: 'Tropical Palm Breeze',
    subtitle: 'Verdant Flora & Soft Wind',
    description: 'Gentle rustling palm fronds with deep resonant acoustic sub-harmonics.',
    icon: 'wind',
  },
];

class AmbientAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isRunning: boolean = false;
  private currentSoundscape: SoundscapeType = 'coastal-waves';
  private volume: number = 0.35;
  private activeNodes: { stop?: () => void; disconnect?: () => void }[] = [];
  private lfoInterval: number | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    if (!this.masterGain && this.ctx) {
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.05);
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public getCurrentSoundscape(): SoundscapeType {
    return this.currentSoundscape;
  }

  public getIsPlaying(): boolean {
    return this.isRunning;
  }

  public async play(type: SoundscapeType = this.currentSoundscape) {
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    this.stopAll();
    this.currentSoundscape = type;
    this.isRunning = true;

    // Smooth fade in
    this.masterGain.gain.setValueAtTime(0.001, this.ctx.currentTime);
    this.masterGain.gain.exponentialRampToValueAtTime(this.volume, this.ctx.currentTime + 1.5);

    switch (type) {
      case 'coastal-waves':
        this.startCoastalWaves();
        break;
      case 'villa-sunset':
        this.startVillaSunset();
        break;
      case 'tropical-breeze':
        this.startTropicalBreeze();
        break;
    }
  }

  public stop() {
    if (!this.isRunning || !this.ctx || !this.masterGain) {
      this.stopAll();
      this.isRunning = false;
      return;
    }

    // Smooth fade out
    this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, this.ctx.currentTime);
    this.masterGain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.8);

    setTimeout(() => {
      this.stopAll();
      this.isRunning = false;
    }, 850);
  }

  private stopAll() {
    if (this.lfoInterval) {
      clearInterval(this.lfoInterval);
      this.lfoInterval = null;
    }
    this.activeNodes.forEach((node) => {
      try {
        if (node.stop) node.stop();
        if (node.disconnect) node.disconnect();
      } catch {
        // Safe discard
      }
    });
    this.activeNodes = [];
  }

  // 1. Coastal Waves Generator
  private startCoastalWaves() {
    if (!this.ctx || !this.masterGain) return;

    // Create Pink/Brown noise buffer for organic sea roar
    const bufferSize = 2 * this.ctx.sampleRate;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.06;
      b6 = white * 0.115926;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    // Filter simulating ocean wash
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, this.ctx.currentTime);
    filter.Q.setValueAtTime(2.5, this.ctx.currentTime);

    // Wave gain node modulated periodically for swell
    const waveGain = this.ctx.createGain();
    waveGain.gain.setValueAtTime(0.15, this.ctx.currentTime);

    whiteNoise.connect(filter);
    filter.connect(waveGain);
    waveGain.connect(this.masterGain);

    whiteNoise.start();
    this.activeNodes.push(whiteNoise, filter, waveGain);

    // Low sub drone (ocean floor depth)
    const subOsc = this.ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(55, this.ctx.currentTime); // A1 note
    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.08, this.ctx.currentTime);
    subOsc.connect(subGain);
    subGain.connect(this.masterGain);
    subOsc.start();
    this.activeNodes.push(subOsc, subGain);

    // Wave swell LFO
    let step = 0;
    this.lfoInterval = window.setInterval(() => {
      if (!this.ctx) return;
      step += 0.04;
      const waveMod = Math.sin(step) * 0.5 + 0.5; // 0 to 1
      const freq = 200 + waveMod * 550;
      const gainVal = 0.08 + Math.pow(waveMod, 2) * 0.28;

      filter.frequency.setTargetAtTime(freq, this.ctx.currentTime, 0.4);
      waveGain.gain.setTargetAtTime(gainVal, this.ctx.currentTime, 0.4);
    }, 150);
  }

  // 2. Villa Sunset Serenity (Warm Ethereal Chord Pad)
  private startVillaSunset() {
    if (!this.ctx || !this.masterGain) return;

    // F#m9 / A major 7th soothing luxury chord frequencies
    const frequencies = [110, 164.81, 220, 277.18, 329.63, 440]; // A2, E3, A3, C#4, E4, A4

    frequencies.forEach((freq, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = i % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq + (Math.random() * 0.4 - 0.2), this.ctx.currentTime);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450 + (i * 80), this.ctx.currentTime);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.04 / frequencies.length, this.ctx.currentTime);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start();
      this.activeNodes.push(osc, filter, gain);
    });

    // Slow ambient shimmer
    let phase = 0;
    this.lfoInterval = window.setInterval(() => {
      if (!this.ctx) return;
      phase += 0.03;
      const modulation = (Math.sin(phase) + 1) / 2;
      this.activeNodes.forEach((node) => {
        if (node instanceof BiquadFilterNode && this.ctx) {
          node.frequency.setTargetAtTime(350 + modulation * 300, this.ctx.currentTime, 0.8);
        }
      });
    }, 200);
  }

  // 3. Tropical Evening Breeze
  private startTropicalBreeze() {
    if (!this.ctx || !this.masterGain) return;

    // Noise for gentle wind
    const bufferSize = 2 * this.ctx.sampleRate;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = (Math.random() * 2 - 1) * 0.05;
    }

    const windSource = this.ctx.createBufferSource();
    windSource.buffer = noiseBuffer;
    windSource.loop = true;

    const bandpass = this.ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.setValueAtTime(400, this.ctx.currentTime);
    bandpass.Q.setValueAtTime(1.2, this.ctx.currentTime);

    const windGain = this.ctx.createGain();
    windGain.gain.setValueAtTime(0.2, this.ctx.currentTime);

    windSource.connect(bandpass);
    bandpass.connect(windGain);
    windGain.connect(this.masterGain);

    windSource.start();
    this.activeNodes.push(windSource, bandpass, windGain);

    // Warm deep harmonic ground
    const warmGround = this.ctx.createOscillator();
    warmGround.type = 'sine';
    warmGround.frequency.setValueAtTime(73.42, this.ctx.currentTime); // D2
    const groundGain = this.ctx.createGain();
    groundGain.gain.setValueAtTime(0.06, this.ctx.currentTime);
    warmGround.connect(groundGain);
    groundGain.connect(this.masterGain);
    warmGround.start();
    this.activeNodes.push(warmGround, groundGain);

    // Wind gust modulation
    let windStep = 0;
    this.lfoInterval = window.setInterval(() => {
      if (!this.ctx) return;
      windStep += 0.05;
      const windGust = Math.sin(windStep * 0.7) * Math.cos(windStep * 0.3) * 0.5 + 0.5;
      bandpass.frequency.setTargetAtTime(300 + windGust * 600, this.ctx.currentTime, 0.6);
      windGain.gain.setTargetAtTime(0.1 + windGust * 0.25, this.ctx.currentTime, 0.6);
    }, 150);
  }
}

export const ambientAudioEngine = new AmbientAudioEngine();

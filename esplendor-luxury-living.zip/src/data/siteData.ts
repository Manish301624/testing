import { FeatureCardItem, LuxuryProject, StatItem } from '../types';

export const STATS_DATA: StatItem[] = [
  {
    textValue: '2025',
    value: 2025,
    label: 'FOUNDED',
    iconName: 'calendar'
  },
  {
    value: 12,
    suffix: '+',
    label: 'YEARS OF EXPERIENCE',
    iconName: 'user'
  },
  {
    value: 20,
    suffix: '+',
    label: 'LUXURY HOMES DELIVERED',
    iconName: 'house'
  },
  {
    value: 5,
    suffix: '+',
    label: 'PROJECTS UNDER DEVELOPMENT',
    iconName: 'crane'
  },
  {
    value: 20,
    suffix: '+',
    label: 'HAPPY FAMILIES',
    iconName: 'family'
  },
  {
    textValue: 'GOA',
    value: 0,
    label: 'OUR FOCUS REGION',
    iconName: 'pin'
  }
];

export const COMMITMENTS_DATA = [
  {
    id: 'exceptional-design',
    title: 'EXCEPTIONAL DESIGN',
    description: 'Spaces designed with purpose and intention.',
    iconName: 'compass-ruler'
  },
  {
    id: 'finest-craftsmanship',
    title: 'FINEST CRAFTSMANSHIP',
    description: 'Thoughtful details and superior craftsmanship.',
    iconName: 'armchair'
  },
  {
    id: 'honest-relationships',
    title: 'HONEST RELATIONSHIPS',
    description: 'Transparency and trust in every interaction.',
    iconName: 'handshake'
  },
  {
    id: 'sustainable-dev',
    title: 'SUSTAINABLE DEVELOPMENT',
    description: 'Building responsibly for a better tomorrow.',
    iconName: 'leaf'
  },
  {
    id: 'timeless-quality',
    title: 'TIMELESS QUALITY',
    description: 'Quality that stands strong through time.',
    iconName: 'shield'
  },
  {
    id: 'lasting-value',
    title: 'LASTING VALUE',
    description: 'Homes that grow in value and in memories.',
    iconName: 'diamond'
  }
];

export const SIGNATURE_FEATURES = [
  {
    id: 'arch-purpose',
    title: 'ARCHITECTURE WITH PURPOSE',
    description: 'Designs that blend beauty with function.',
    iconName: 'pillars'
  },
  {
    id: 'connect-nature',
    title: 'CONNECTED TO NATURE',
    description: 'Homes that breathe with their surroundings.',
    iconName: 'sprout'
  },
  {
    id: 'finer-materials',
    title: 'FINER MATERIALS',
    description: 'Carefully selected for quality that lasts.',
    iconName: 'grid-blocks'
  },
  {
    id: 'everyday-comfort',
    title: 'EVERYDAY COMFORT',
    description: 'Spaces that enhance well-being.',
    iconName: 'sofa-relax'
  },
  {
    id: 'legacy-value',
    title: 'LEGACY OF VALUE',
    description: 'Built with integrity. Created to endure.',
    iconName: 'diamond-sparkle'
  }
];

export const LUXURY_HOMES_FEATURES = [
  {
    id: 'timeless-arch',
    title: 'TIMELESS ARCHITECTURE',
    description: 'Designs that blend beauty with functionality.',
    iconName: 'pillars'
  },
  {
    id: 'nature-int',
    title: 'NATURE INTEGRATED',
    description: "Homes that embrace Goa's serene environment.",
    iconName: 'sprout'
  },
  {
    id: 'qual-craft',
    title: 'QUALITY CRAFTSMANSHIP',
    description: 'Premium materials and meticulous attention to detail.',
    iconName: 'diamond'
  },
  {
    id: 'thoughtful-liv',
    title: 'THOUGHTFUL LIVING',
    description: 'Spaces designed for comfort, privacy and lifestyle.',
    iconName: 'armchair'
  },
  {
    id: 'trust-excel',
    title: 'TRUST & EXCELLENCE',
    description: 'Honest relationships and a legacy of trust.',
    iconName: 'handshake'
  }
];

export const PROJECTS_COLLECTION: LuxuryProject[] = [
  {
    id: 'casa-bella',
    name: 'CASA BELLA',
    location: 'Assagao, North Goa',
    category: 'villas',
    status: 'completed',
    statusLabel: 'Completed Project',
    description: 'A luxurious villa crafted with natural materials, open spaces and lush green surroundings.',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    bedrooms: 5,
    bathrooms: 6,
    area: '6,800 sq.ft',
    price: '₹ 24.5 Cr',
    highlights: ['Private Infinity Pool', 'Portuguese Stone Finish', 'Designer Italian Kitchen', 'Lush Coconut Grove View']
  },
  {
    id: 'vista-verde',
    name: 'VISTA VERDE',
    location: 'Siolim, North Goa',
    category: 'villas',
    status: 'ongoing',
    statusLabel: 'Ongoing Project',
    description: 'Modern tropical residence that blends elegant architecture with breathtaking views.',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
    bedrooms: 4,
    bathrooms: 5,
    area: '5,400 sq.ft',
    price: '₹ 18.2 Cr',
    highlights: ['Panoramic River View', 'Double Height Living Salon', 'Rooftop Sunset Lounge', 'Smart Automation']
  },
  {
    id: 'the-palms',
    name: 'THE PALMS',
    location: 'Candolim, North Goa',
    category: 'luxury-apartments',
    status: 'completed',
    statusLabel: 'Completed Project',
    description: 'Designed for comfort and luxury, offering spacious living with a resort-style experience.',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
    bedrooms: 3,
    bathrooms: 4,
    area: '3,950 sq.ft',
    price: '₹ 12.8 Cr',
    highlights: ['Walk to Beach', 'Private Plunge Pool', '24/7 Concierge Service', 'Full Turnkey Furnished']
  },
  {
    id: 'solace-villa',
    name: 'SOLACE VILLA',
    location: 'Moira, North Goa',
    category: 'villas',
    status: 'upcoming',
    statusLabel: 'Upcoming Home',
    description: 'A perfect balance of luxury and nature, designed to inspire peaceful living.',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80',
    bedrooms: 6,
    bathrooms: 7,
    area: '8,200 sq.ft',
    price: '₹ 31.0 Cr',
    highlights: ['Heritage Courtyard', 'Wellness Pavilion & Sauna', 'Organic Orchard Garden', 'Solar Passive Design']
  },
  {
    id: 'ocean-crest',
    name: 'OCEAN CREST',
    location: 'Vagator, North Goa',
    category: 'luxury-apartments',
    status: 'ongoing',
    statusLabel: 'Ongoing Project',
    description: 'Cliffside oceanview apartments with sweeping 270-degree Arabian Sea horizon vistas.',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
    bedrooms: 4,
    bathrooms: 5,
    area: '4,850 sq.ft',
    price: '₹ 16.5 Cr',
    highlights: ['Private Elevator Access', 'Infinity Glass Jacuzzi', 'Wine Cellar', 'Sunset Deck']
  },
  {
    id: 'serena-estate',
    name: 'SERENA ESTATE',
    location: 'Anjuna, North Goa',
    category: 'villas',
    status: 'upcoming',
    statusLabel: 'Upcoming Home',
    description: 'Exclusive gated sanctuary surrounded by century-old banyans and serene water bodies.',
    image: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80',
    bedrooms: 5,
    bathrooms: 6,
    area: '7,100 sq.ft',
    price: '₹ 27.0 Cr',
    highlights: ['Private Tennis Court', 'Staff Quarters', 'Underground Parking', 'Sub-tropical Landscaping']
  }
];

export const LIVING_DIFFERENCE_CARDS: FeatureCardItem[] = [
  {
    id: 'furnishing-facility',
    number: 1,
    title: 'Furnishing Facility',
    description: 'Move into beautifully furnished homes, designed for comfort and style.',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Luxury furnished modern living room with warm mood lighting and neutral textures',
    iconName: 'sofa',
    badge: 'Turnkey Ready',
    longDescription: 'Every Esplendor residence is curated by world-renowned interior architects. Experience bespoke Italian craftsmanship, custom-built millwork, ambient architectural lighting, and premium European linens ready from day one.'
  },
  {
    id: 'world-class-amenities',
    number: 2,
    title: 'World-Class Amenities',
    description: 'Enjoy a lifestyle enriched with premium amenities for you and your family.',
    image: 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Illuminated resort swimming pool with tropical palm trees at twilight',
    iconName: 'amenities',
    badge: 'Resort Living',
    longDescription: 'Immerse yourself in private clubhouses, temperature-controlled infinity pools overlooking tropical horizons, wellness spas, private fitness studios, and zen meditation groves designed for the whole family.'
  },
  {
    id: 'seamless-purchase',
    number: 3,
    title: 'Seamless Purchase',
    description: 'Transparent process, expert guidance and hassle-free home buying.',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Handover of modern house keys with house pendant',
    iconName: 'handshake',
    badge: 'Frictionless',
    longDescription: 'Our dedicated private client advisors provide clear legal advisory, title verification, customized financial structuring, and bespoke conveyancing support at every step of your acquisition.'
  },
  {
    id: 'concierge-services',
    number: 4,
    title: 'Concierge Services',
    description: 'Personalised assistance for all your day-to-day needs.',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Luxury reception and concierge desk with warm ambient illumination',
    iconName: 'bell',
    badge: '24/7 White Glove',
    longDescription: 'From private chef reservations, yacht chartering, airport transfers to daily lifestyle management, our round-the-clock concierge desk handles every request with discretion and perfection.'
  },
  {
    id: 'property-management',
    number: 5,
    title: 'Property Management',
    description: 'Professional care to keep your home in the best condition, always.',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Property manager overlooking a pristine modern white luxury villa and landscaped lawn',
    iconName: 'shield-house',
    badge: 'Asset Care',
    longDescription: 'Your asset remains pristine whether you reside in it full-time or travel the globe. Our certified property care team conducts weekly preventative inspections, pool maintenance, and horticultural upkeep.'
  },
  {
    id: 'convenient-renting',
    number: 6,
    title: 'Convenient Renting',
    description: 'Effortless rental solutions for better returns and flexible living.',
    image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Spacious luxury master bedroom with glass doors opening onto lush private greenery',
    iconName: 'key',
    badge: 'Yield Optimization',
    longDescription: 'Maximize rental yields through our managed luxury hospitality program. We vet high-net-worth guests, handle check-in, provide daily housekeeping, and optimize revenue with transparent accounting.'
  },
  {
    id: 'optimal-protection',
    number: 7,
    title: 'Optimal Protection',
    description: 'Advanced security and safety measures for complete peace of mind.',
    image: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Modern smart dome surveillance camera and intelligent intercom system',
    iconName: 'camera',
    badge: 'Fortress Security',
    longDescription: 'Multi-tiered security architecture combines biometric access control, 24/7 AI-monitored perimeter surveillance, licensed security personnel, and discrete smart-home intruder alert integration.'
  },
  {
    id: 'entertainment-awareness',
    number: 8,
    title: 'Entertainment & Awareness',
    description: 'Stay connected with the best of lifestyle, culture and community experiences.',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Twilight oceanfront rooftop lounge with cocktail glasses and ambient fire pit',
    iconName: 'cocktail',
    badge: 'Curated Events',
    longDescription: 'Join an exclusive community of discerning tastemakers. Enjoy private art vernissages, wine tastings with master sommeliers, golf tournaments, and curated private soirees designed for meaningful connections.'
  }
];

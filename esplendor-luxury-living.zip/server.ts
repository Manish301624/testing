import express, { Request, Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { z } from "zod";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Lazy Gemini API Client Initialization
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

// In-memory persistent store for contact inquiries and project listings
interface ContactMessage {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  consent: boolean;
  createdAt: string;
}

const contactStore: ContactMessage[] = [];

// Rate limiting map
const ipRequestCount = new Map<string, { count: number; resetTime: number }>();

const ContactSchema = z.object({
  fullName: z.string().min(2, "Full name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(6, "Valid phone number is required"),
  subject: z.string().min(2, "Subject is required"),
  message: z.string().min(5, "Message must be at least 5 characters"),
  consent: z.boolean().refine((val) => val === true, {
    message: "You must agree to receive communications",
  }),
});

const ChatMessageSchema = z.object({
  role: z.enum(["user", "model"]),
  content: z.string(),
});

const ChatRequestSchema = z.object({
  messages: z.array(ChatMessageSchema),
  taskComplexity: z.enum(["fast", "general", "complex"]).optional().default("general"),
  selectedProjectName: z.string().optional(),
});

const VeoGenerateSchema = z.object({
  prompt: z.string().min(3, "Prompt is required"),
  aspectRatio: z.enum(["16:9", "9:16"]).default("16:9"),
  imageBase64: z.string().optional(),
  mimeType: z.string().optional().default("image/jpeg"),
});

const projectsList = [
  {
    id: "casa-bella",
    name: "CASA BELLA",
    location: "Assagao, North Goa",
    category: "villas",
    status: "completed",
    description: "A luxurious villa crafted with natural materials, open spaces and lush green surroundings.",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80",
    bedrooms: 5,
    bathrooms: 6,
    area: "6,800 sq.ft",
    price: "₹ 24.5 Cr",
    highlights: ["Private Infinity Pool", "Portuguese Stone Finish", "Designer Italian Kitchen", "Lush Coconut Grove View"]
  },
  {
    id: "vista-verde",
    name: "VISTA VERDE",
    location: "Siolim, North Goa",
    category: "villas",
    status: "ongoing",
    description: "Modern tropical residence that blends elegant architecture with breathtaking views.",
    image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80",
    bedrooms: 4,
    bathrooms: 5,
    area: "5,400 sq.ft",
    price: "₹ 18.2 Cr",
    highlights: ["Panoramic River View", "Double Height Living Salon", "Rooftop Sunset Lounge", "Smart Automation"]
  },
  {
    id: "the-palms",
    name: "THE PALMS",
    location: "Candolim, North Goa",
    category: "luxury-apartments",
    status: "completed",
    description: "Designed for comfort and luxury, offering spacious living with a resort-style experience.",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80",
    bedrooms: 3,
    bathrooms: 4,
    area: "3,950 sq.ft",
    price: "₹ 12.8 Cr",
    highlights: ["Walk to Beach", "Private Plunge Pool", "24/7 Concierge Service", "Full Turnkey Furnished"]
  },
  {
    id: "solace-villa",
    name: "SOLACE VILLA",
    location: "Moira, North Goa",
    category: "villas",
    status: "upcoming",
    description: "A perfect balance of luxury and nature, designed to inspire peaceful living.",
    image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80",
    bedrooms: 6,
    bathrooms: 7,
    area: "8,200 sq.ft",
    price: "₹ 31.0 Cr",
    highlights: ["Heritage Courtyard", "Wellness Pavilion & Sauna", "Organic Orchard Garden", "Solar Passive Design"]
  },
  {
    id: "ocean-crest",
    name: "OCEAN CREST PENTHOUSE",
    location: "Vagator, North Goa",
    category: "luxury-apartments",
    status: "ongoing",
    description: "Cliffside oceanview penthouse with 270-degree Arabian Sea horizon vistas.",
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80",
    bedrooms: 4,
    bathrooms: 5,
    area: "4,850 sq.ft",
    price: "₹ 16.5 Cr",
    highlights: ["Private Elevator Access", "Infinity Glass Jacuzzi", "Wine Cellar", "Sunset Deck"]
  },
  {
    id: "serena-estate",
    name: "SERENA PRIVATE ESTATE",
    location: "Anjuna, North Goa",
    category: "villas",
    status: "upcoming",
    description: "Exclusive gated sanctuary surrounded by century-old banyans and tranquil water bodies.",
    image: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80",
    bedrooms: 5,
    bathrooms: 6,
    area: "7,100 sq.ft",
    price: "₹ 27.0 Cr",
    highlights: ["Private Tennis Court", "Staff Quarters", "Underground Parking", "Sub-tropical Landscaping"]
  }
];

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Increase payload limit for image base64 uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // Simple in-memory rate limiter middleware
  app.use("/api/contact", (req: Request, res: Response, next) => {
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    const windowMs = 60 * 1000; // 1 minute
    const maxRequests = 10;

    const rate = ipRequestCount.get(ip);
    if (!rate || now > rate.resetTime) {
      ipRequestCount.set(ip, { count: 1, resetTime: now + windowMs });
      return next();
    }

    if (rate.count >= maxRequests) {
      return res.status(429).json({
        success: false,
        error: "Too many inquiries sent. Please wait a moment before sending another request.",
      });
    }

    rate.count += 1;
    next();
  });

  // Health check
  app.get("/api/health", (req: Request, res: Response) => {
    res.json({
      status: "ok",
      brand: "ESPLENDOR",
      tagline: "CRAFTING TIMELESS LIVING",
      timestamp: new Date().toISOString(),
    });
  });

  // Projects endpoint
  app.get("/api/projects", (req: Request, res: Response) => {
    const { status, category } = req.query;

    let results = [...projectsList];

    if (status && typeof status === "string" && status !== "all") {
      results = results.filter(
        (p) => p.status.toLowerCase() === status.toLowerCase()
      );
    }

    if (category && typeof category === "string" && category !== "all") {
      results = results.filter(
        (p) => p.category.toLowerCase() === category.toLowerCase()
      );
    }

    res.json({
      success: true,
      count: results.length,
      data: results,
    });
  });

  // Contact form submission endpoint
  app.post("/api/contact", (req: Request, res: Response) => {
    try {
      const validated = ContactSchema.parse(req.body);

      const newMessage: ContactMessage = {
        id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        ...validated,
        createdAt: new Date().toISOString(),
      };

      contactStore.push(newMessage);

      console.log(`[ESPLENDOR INQUIRY] New submission from ${validated.fullName} (${validated.email}): "${validated.subject}"`);

      // Simulated notification dispatch
      return res.status(201).json({
        success: true,
        message: "Your private viewing & advisory request has been received. Our senior concierge will contact you within 4 business hours.",
        inquiryId: newMessage.id,
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          error: "Validation failed",
          details: err.issues.map((i) => ({ field: i.path.join("."), message: i.message })),
        });
      }

      return res.status(500).json({
        success: false,
        error: "Internal server error processing request",
      });
    }
  });

  // ==========================================
  // 1. GEMINI MULTI-TURN CHATBOT ENDPOINT
  // Models per user requirements:
  // - complex tasks: gemini-3.1-pro-preview
  // - general tasks: gemini-3.5-flash
  // - fast tasks: gemini-3.1-flash-lite
  // ==========================================
  app.post("/api/ai/chat", async (req: Request, res: Response) => {
    try {
      const { messages, taskComplexity, selectedProjectName } = ChatRequestSchema.parse(req.body);

      let modelName = "gemini-2.5-flash"; // Fallback/default alias
      if (taskComplexity === "complex") {
        modelName = "gemini-3.1-pro-preview";
      } else if (taskComplexity === "fast") {
        modelName = "gemini-3.1-flash-lite";
      } else {
        modelName = "gemini-3.5-flash";
      }

      const systemInstruction = `You are the Senior Private Client Concierge & Architectural Advisor for "ESPLENDOR" (Esplendor Homes Pvt. Ltd.), an ultra-luxury real estate brand in North Goa, India.
Tagline: "Crafting Timeless Living".
Locations: Assagao, Siolim, Candolim, Moira, Vagator, and Anjuna in North Goa.

Portfolio Details:
1. Casa Bella (Assagao): 5 BHK Luxury Villa, 6,800 sq.ft, ₹24.5 Cr. Private infinity pool, Portuguese stone masonry, Italian kitchen, coconut grove views. Completed.
2. Vista Verde (Siolim): 4 BHK Modern Residence, 5,400 sq.ft, ₹18.2 Cr. River view, double-height living salon, rooftop sunset deck. Ongoing.
3. The Palms (Candolim): 3 BHK Luxury Residences, 3,950 sq.ft, ₹12.8 Cr. Walk to beach, private plunge pool, turnkey furnished. Completed.
4. Solace Villa (Moira): 6 BHK Heritage Villa, 8,200 sq.ft, ₹31.0 Cr. Organic orchard, wellness pavilion, solar passive design. Upcoming.
5. Ocean Crest Penthouse (Vagator): 4 BHK Cliffside Penthouse, 4,850 sq.ft, ₹16.5 Cr. 270-degree Arabian Sea views, private elevator, sunset jacuzzi. Ongoing.
6. Serena Private Estate (Anjuna): 5 BHK Gated Sanctuary, 7,100 sq.ft, ₹27.0 Cr. Tennis court, century banyans, staff quarters. Upcoming.

Living Pillars:
- Furnishing Facility (Turnkey Italian interior curation)
- World-Class Amenities (Private infinity pools, biometric security, smart climate)
- Seamless Purchase (RERA certified, clear title guarantees)
- Concierge & Asset Management (Turnkey rental yields, 24/7 dedicated estate manager)

Persona & Tone:
- Sophisticated, warm, polite, highly articulate, discreet, and deeply knowledgeable about luxury living, architectural materials, Goan micro-locations, and real-estate investments.
- Offer tailored advice on neighborhood vibes (e.g., quiet charm of Assagao vs scenic cliffs of Vagator).
- Invite clients gracefully to schedule private viewings or connect with the senior director.
- Answer user queries directly and concisely in Markdown formatting.
${selectedProjectName ? `The user is specifically inquiring about or viewing "${selectedProjectName}".` : ""}`;

      const ai = getGeminiClient();

      // Format messages into Gemini contents structure
      const contents = messages.map((m) => ({
        role: m.role === "model" ? "model" : "user",
        parts: [{ text: m.content }],
      }));

      // In case the list was empty or malformed
      if (contents.length === 0) {
        return res.status(400).json({ error: "No messages provided." });
      }

      let response;
      try {
        response = await ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
            maxOutputTokens: 1024,
          },
        });
      } catch (err: any) {
        console.warn(`[GEMINI CHAT] Primary model ${modelName} failed or unavailable, falling back to gemini-2.5-flash:`, err?.message);
        response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
            maxOutputTokens: 1024,
          },
        });
      }

      const replyText = response.text || "Thank you for inquiring. Our private concierge is at your service. How else may I assist you with Esplendor's residences?";

      res.json({
        success: true,
        reply: replyText,
        modelUsed: modelName,
      });
    } catch (err: any) {
      console.error("[GEMINI CHAT ERROR]:", err);
      res.status(500).json({
        success: false,
        error: err.message || "Failed to generate AI concierge response",
      });
    }
  });

  // ==========================================
  // 2. VEO IMAGE-TO-VIDEO GENERATION ENDPOINT
  // Model per requirements: veo-3.1-fast-generate-preview
  // Aspect ratios supported: "16:9" (landscape) or "9:16" (portrait)
  // ==========================================
  app.post("/api/ai/generate-video", async (req: Request, res: Response) => {
    try {
      const { prompt, aspectRatio, imageBase64, mimeType } = VeoGenerateSchema.parse(req.body);

      const ai = getGeminiClient();

      console.log(`[VEO VIDEO GENERATION] Starting video generation with prompt: "${prompt}", aspectRatio: ${aspectRatio}, imageProvided: ${!!imageBase64}`);

      const generateParams: any = {
        model: "veo-3.1-fast-generate-preview",
        prompt,
        config: {
          aspectRatio, // '16:9' or '9:16'
          personGeneration: "allow_adult",
        },
      };

      if (imageBase64) {
        // Strip data:image/*;base64, prefix if present
        const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, "");
        generateParams.image = {
          imageBytes: cleanBase64,
          mimeType: mimeType || "image/jpeg",
        };
      }

      let operation = await ai.models.generateVideos(generateParams);

      // Poll until video generation completes or times out
      let attempts = 0;
      const maxAttempts = 30; // ~60 seconds max
      while (!operation.done && attempts < maxAttempts) {
        await new Promise((resolve) => setTimeout(resolve, 3000));
        operation = await ai.operations.getVideosOperation({
          operation: operation,
        });
        attempts++;
      }

      if (!operation.done) {
        return res.status(504).json({
          success: false,
          error: "Video generation timed out. Please try again with a shorter prompt.",
        });
      }

      if (operation.error) {
        throw new Error((operation.error as any).message || "Veo video generation failed.");
      }

      const generatedVideo = operation.response?.generatedVideos?.[0];
      const videoUri = generatedVideo?.video?.uri;

      if (!videoUri) {
        throw new Error("No video URI returned from Veo generation operation.");
      }

      // Download the video bytes via authenticated API call using fetch with API key appended or proxy
      const downloadUrl = `${videoUri}&key=${process.env.GEMINI_API_KEY}`;
      const videoFetchResponse = await fetch(downloadUrl);
      
      if (!videoFetchResponse.ok) {
        throw new Error(`Failed to fetch generated video from Google storage: ${videoFetchResponse.statusText}`);
      }

      const videoBuffer = await videoFetchResponse.arrayBuffer();
      const videoBase64 = Buffer.from(videoBuffer).toString("base64");
      const videoDataUrl = `data:video/mp4;base64,${videoBase64}`;

      console.log(`[VEO VIDEO GENERATION] Success! Generated video size: ${videoBuffer.byteLength} bytes`);

      return res.json({
        success: true,
        videoUrl: videoDataUrl,
        aspectRatio,
        prompt,
      });
    } catch (err: any) {
      console.error("[VEO VIDEO GENERATION ERROR]:", err);
      return res.status(500).json({
        success: false,
        error: err.message || "Failed to animate image with Veo video generator.",
      });
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[ESPLENDOR] Server running on http://localhost:${PORT}`);
  });
}

startServer();


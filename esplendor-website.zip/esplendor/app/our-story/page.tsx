import type { Metadata } from "next";
import Image from "next/image";
import { Palette, Gem, Handshake, Sprout, Clock, TrendingUp, Eye, Target } from "lucide-react";
import { Hero } from "@/components/Hero";
import { RevealOnScroll } from "@/components/RevealOnScroll";
import { SignatureDivider } from "@/components/SignatureDivider";
import { StatCounter } from "@/components/StatCounter";
import { FeatureTile } from "@/components/FeatureTile";
import { CTASection } from "@/components/CTASection";
import { images } from "@/lib/images";

export const metadata: Metadata = {
  title: "Our Story | ESPLENDOR",
};

const STATS = [
  { value: 2025, label: "Founded" },
  { value: 12, suffix: "+", label: "Years of Experience" },
  { value: 20, suffix: "+", label: "Luxury Homes Delivered" },
  { value: 5, suffix: "+", label: "Projects Under Development" },
  { value: 20, suffix: "+", label: "Happy Families" },
];

const COMMITMENTS = [
  { icon: Palette, title: "Exceptional Design", description: "Architecture and interiors led by clear intention, not passing trends." },
  { icon: Gem, title: "Finest Materials", description: "Specified for how they age, not just how they photograph on day one." },
  { icon: Handshake, title: "Honest Relationships", description: "Transparency and clarity in every conversation, start to finish." },
  { icon: Sprout, title: "Sustainable Development", description: "Building responsibly for the coastline and community we're part of." },
  { icon: Clock, title: "Timeless Quality", description: "Craft that holds up decades from now, not just at handover." },
  { icon: TrendingUp, title: "Lasting Value", description: "Homes designed to be worth more — in every sense — over time." },
];

export default function OurStoryPage() {
  return (
    <>
      <Hero
        compact
        lines={["Our Story"]}
        accentWord=""
        subtext="Rooted in the timeless beauty of Goa. Inspired by a vision to create homes that elevate the way life is lived."
        image={images.heroOurStory}
        imageAlt="Goa coastline at sunset with palm trees"
      />

      {/* About block */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto grid max-w-content gap-10 px-6 lg:grid-cols-2 lg:gap-16 lg:px-10">
          <RevealOnScroll>
            <p className="eyebrow mb-3">About the Company</p>
            <h2 className="font-display text-2xl font-medium text-ink sm:text-3xl">
              About <span className="accent-word">ESPLENDOR</span>
            </h2>
            <p className="mt-5 text-[0.98rem] leading-relaxed text-ink-muted">
              ESPLENDOR was founded in 2025 with homes that celebrate architecture, craftsmanship, and the
              timeless beauty of Goa. Backed by more than 12 years of industry experience, our team blends
              deep expertise, design excellence, and an unwavering commitment to quality with a genuine
              respect for what makes this coastline unique.
            </p>
            <p className="mt-4 text-[0.98rem] leading-relaxed text-ink-muted">
              Every home we build is a reflection of our belief that true luxury is not just what a space
              looks like, but how it makes life feel.
            </p>
          </RevealOnScroll>
          <RevealOnScroll delay={0.15} className="relative aspect-[4/5] overflow-hidden rounded-2xl">
            <Image
              src={images.aboutLobby}
              alt="ESPLENDOR lobby interior with warm lighting and considered materials"
              fill
              sizes="(min-width: 1024px) 45vw, 90vw"
              className="object-cover"
            />
          </RevealOnScroll>
        </div>
      </section>

      <SignatureDivider />

      {/* Stats row */}
      <section className="border-y border-surface-border bg-surface/40 py-14">
        <div className="mx-auto grid max-w-content grid-cols-2 gap-8 px-6 sm:grid-cols-3 lg:grid-cols-5 lg:px-10">
          {STATS.map((s) => (
            <StatCounter key={s.label} {...s} />
          ))}
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-20 lg:py-24">
        <div className="mx-auto grid max-w-content gap-6 px-6 sm:grid-cols-2 lg:px-10">
          <RevealOnScroll className="rounded-2xl border border-surface-border bg-surface p-8">
            <Eye size={22} className="text-accent" strokeWidth={1.6} />
            <h3 className="font-display mt-4 text-xl font-medium text-ink">Our Vision</h3>
            <p className="mt-3 text-sm leading-relaxed text-ink-muted">
              To redefine luxury living by creating homes where architecture, nature and quality
              craftsmanship come together effortlessly.
            </p>
          </RevealOnScroll>
          <RevealOnScroll delay={0.1} className="rounded-2xl border border-surface-border bg-surface p-8">
            <Target size={22} className="text-accent" strokeWidth={1.6} />
            <h3 className="font-display mt-4 text-xl font-medium text-ink">Our Mission</h3>
            <p className="mt-3 text-sm leading-relaxed text-ink-muted">
              To develop exceptional residences with uncompromising quality, sustainable building
              practices, and meaningful design that homeowners and their communities can rely on for years
              to come.
            </p>
          </RevealOnScroll>
        </div>
      </section>

      {/* Our Commitment */}
      <section className="bg-surface/40 py-20 lg:py-24">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <RevealOnScroll className="mb-10 max-w-lg">
            <p className="eyebrow mb-3">Our Commitment</p>
            <h2 className="font-display text-2xl font-medium text-ink sm:text-3xl">
              What we hold ourselves to.
            </h2>
          </RevealOnScroll>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {COMMITMENTS.map((c, i) => (
              <FeatureTile key={c.title} {...c} delay={i * 0.06} />
            ))}
          </div>
        </div>
      </section>

      <CTASection line="Building Homes." accentWord="Creating Legacies." ctaLabel="Let's Connect" />
    </>
  );
}

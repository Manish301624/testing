"use client";

import { Suspense, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Compass, Leaf, Hammer, HeartHandshake, ShieldCheck } from "lucide-react";
import { Hero } from "@/components/Hero";
import { RevealOnScroll } from "@/components/RevealOnScroll";
import { ProjectCard } from "@/components/ProjectCard";
import { FeatureTile } from "@/components/FeatureTile";
import { CTASection } from "@/components/CTASection";
import { images } from "@/lib/images";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

type FilterKey = "all" | "completed" | "ongoing" | "upcoming" | "apartments" | "villas";

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "completed", label: "Completed Projects" },
  { key: "ongoing", label: "Ongoing Projects" },
  { key: "upcoming", label: "Upcoming Homes" },
  { key: "apartments", label: "Luxury Apartments" },
  { key: "villas", label: "Villas" },
  { key: "all", label: "All Projects" },
];

const PROJECTS = [
  {
    name: "Casa Bella",
    location: "Assagao, North Goa",
    description: "A luxurious villa crafted with natural materials, open spaces and lush green surroundings.",
    image: images.projectCasaBella,
    status: "Completed",
    tags: ["completed", "villas"] as FilterKey[],
  },
  {
    name: "Vista Verde",
    location: "Siolim, North Goa",
    description: "Modern tropical residence that blends elegant architecture with breathtaking greenery.",
    image: images.projectVistaVerde,
    status: "Ongoing",
    tags: ["ongoing", "apartments"] as FilterKey[],
  },
  {
    name: "The Palms",
    location: "Candolim, North Goa",
    description: "Designed for comfort and luxury, offering spacious layouts and resort-style amenities.",
    image: images.projectThePalms,
    status: "Upcoming",
    tags: ["upcoming", "villas"] as FilterKey[],
  },
  {
    name: "Solace Villa",
    location: "Morjim, North Goa",
    description: "A perfect blend of luxury and nature, designed to inspire peaceful, private living.",
    image: images.projectSolaceVilla,
    status: "Completed",
    tags: ["completed", "villas"] as FilterKey[],
  },
];

export default function LuxuryHomesPage() {
  return (
    <Suspense fallback={null}>
      <LuxuryHomesContent />
    </Suspense>
  );
}

function LuxuryHomesContent() {
  const searchParams = useSearchParams();
  const initial = (searchParams.get("filter") as FilterKey) ?? "all";
  const [active, setActive] = useState<FilterKey>(FILTERS.some((f) => f.key === initial) ? initial : "all");

  const filtered = useMemo(
    () => (active === "all" ? PROJECTS : PROJECTS.filter((p) => p.tags.includes(active))),
    [active]
  );

  return (
    <>
      <Hero
        compact
        lines={["Crafted for life."]}
        accentWord="Designed for you."
        subtext="Every ESPLENDOR residence blends timeless architecture with Goa's natural beauty."
        image={images.heroLuxuryHomes}
        imageAlt="Contemporary luxury residence in Goa surrounded by palm trees"
      />

      {/* Filter bar */}
      <section className="border-b border-surface-border py-8">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter projects">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                role="tab"
                aria-selected={active === f.key}
                onClick={() => setActive(f.key)}
                className={`relative rounded-full px-4 py-2.5 text-sm font-medium transition-colors min-h-[44px] ${
                  active === f.key ? "bg-accent text-black" : "text-ink-muted hover:text-ink"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Project grid */}
      <section className="py-16 lg:py-20">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <RevealOnScroll className="mb-10 flex flex-wrap items-end justify-between gap-4">
            <h2 className="font-display max-w-md text-[1.7rem] font-medium leading-tight text-ink sm:text-[2.1rem]">
              Spaces that inspire. <span className="accent-word">Homes that last.</span>
            </h2>
            <Link href="/luxury-homes" className="inline-flex items-center gap-1.5 text-sm font-medium text-accent">
              Explore All Projects
              <ArrowRight size={14} />
            </Link>
          </RevealOnScroll>

          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4"
            >
              {filtered.map((p) => (
                <ProjectCard
                  key={p.name}
                  name={p.name}
                  location={p.location}
                  description={p.description}
                  image={p.image}
                  status={p.status}
                  href="#"
                />
              ))}
              {filtered.length === 0 && (
                <p className="col-span-full py-16 text-center text-ink-muted">
                  No projects in this category yet — check back soon.
                </p>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* Feature strip */}
      <section className="bg-surface/40 py-16 lg:py-20">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {[
              { icon: Compass, title: "Timeless Architecture", desc: "Design built to last, with quality functionality." },
              { icon: Leaf, title: "Nature Integrated", desc: "Homes designed to serene environment." },
              { icon: Hammer, title: "Quality Craftsmanship", desc: "Premium construction and meticulous attention to detail." },
              { icon: HeartHandshake, title: "Thoughtful Living", desc: "Spaces designed for comfort, privacy and lifestyle experience." },
              { icon: ShieldCheck, title: "Trust & Excellence", desc: "Transparent relationships and a legacy of trust." },
            ].map((f, i) => (
              <FeatureTile key={f.title} icon={f.icon} title={f.title} description={f.desc} delay={i * 0.06} />
            ))}
          </div>
        </div>
      </section>

      <CTASection
        line="Let's build a home that becomes"
        accentWord="your legacy."
        ctaLabel="Schedule a Consultation"
      />
    </>
  );
}

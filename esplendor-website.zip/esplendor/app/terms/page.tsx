import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms & Conditions | ESPLENDOR",
};

export default function TermsPage() {
  return (
    <section className="mx-auto max-w-2xl px-6 py-24 lg:px-10">
      <h1 className="font-display text-3xl font-medium text-ink">Terms &amp; Conditions</h1>
      <p className="mt-6 text-sm leading-relaxed text-ink-muted">
        This is placeholder legal copy. Replace this page with ESPLENDOR&apos;s actual terms of
        use before launch.
      </p>
    </section>
  );
}

import type { Metadata } from "next";
import {
  Sofa,
  Sparkles,
  FileCheck2,
  ConciergeBell,
  Home,
  KeyRound,
  ShieldCheck,
  PartyPopper,
} from "lucide-react";
import { Hero } from "@/components/Hero";
import { RevealOnScroll } from "@/components/RevealOnScroll";
import { FeatureTile } from "@/components/FeatureTile";
import { CTASection } from "@/components/CTASection";
import { SignatureDivider } from "@/components/SignatureDivider";
import { images } from "@/lib/images";

export const metadata: Metadata = {
  title: "The Living Difference | ESPLENDOR",
};

const FEATURES = [
  { icon: Sofa, title: "Furnishing Facility", desc: "Move in ready — beautifully furnished homes, curated for comfort and style.", image: images.differenceFurnishing },
  { icon: Sparkles, title: "World-Class Amenities", desc: "Enjoy a lifestyle enriched with amenities designed for you and your family.", image: images.differenceAmenities },
  { icon: FileCheck2, title: "Seamless Purchase", desc: "A transparent process with expert guidance and hassle-free home buying.", image: images.differencePurchase },
  { icon: ConciergeBell, title: "Concierge Services", desc: "Personalised assistance for all your day-to-day needs.", image: images.differenceConcierge },
  { icon: Home, title: "Property Management", desc: "Professional care to keep your home in the best condition, always.", image: images.differenceManagement },
  { icon: KeyRound, title: "Convenient Renting", desc: "Effortless rental solutions for better returns and flexible living.", image: images.differenceRenting },
  { icon: ShieldCheck, title: "Optimal Protection", desc: "Advanced security and safety measures for complete peace of mind.", image: images.differenceProtection },
  { icon: PartyPopper, title: "Entertainment & Awareness", desc: "Stay connected with the best of lifestyle, culture and community.", image: images.differenceEntertainment },
];

export default function LivingDifferencePage() {
  return (
    <>
      <Hero
        compact
        lines={["What makes"]}
        accentWord="ESPLENDOR different?"
        subtext="Every detail is designed to give you a life of comfort, convenience and lasting value."
        image={images.heroLivingDifference}
        imageAlt="Warm, sunlit interior lounge with rattan furniture and greenery"
      />

      <SignatureDivider className="mt-16" />

      <section className="py-16 lg:py-20">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <RevealOnScroll className="mx-auto mb-12 max-w-lg text-center">
            <p className="eyebrow mb-3">The Living Difference</p>
            <h2 className="font-display text-2xl font-medium text-ink sm:text-3xl">
              Eight ways we go <span className="accent-word">beyond the build.</span>
            </h2>
          </RevealOnScroll>

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f, i) => (
              <FeatureTile
                key={f.title}
                icon={f.icon}
                title={f.title}
                description={f.desc}
                image={f.image}
                delay={i * 0.05}
              />
            ))}
          </div>
        </div>
      </section>

      <CTASection
        line="Experience a lifestyle that goes"
        accentWord="beyond the ordinary."
        ctaLabel="Explore Our Homes"
        ctaHref="/luxury-homes"
      />
    </>
  );
}

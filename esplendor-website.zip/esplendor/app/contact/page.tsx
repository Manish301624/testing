import type { Metadata } from "next";
import Image from "next/image";
import { Clock, Instagram, Facebook, Linkedin, Mail, MapPin, Phone } from "lucide-react";
import { Hero } from "@/components/Hero";
import { RevealOnScroll } from "@/components/RevealOnScroll";
import { ContactForm } from "@/components/ContactForm";
import { images } from "@/lib/images";

export const metadata: Metadata = {
  title: "Contact Us | ESPLENDOR",
};

export default function ContactPage() {
  return (
    <>
      <Hero
        compact
        eyebrow="Get in Touch"
        lines={["Contact Us"]}
        accentWord=""
        subtext="We're here to help you find your perfect home in Goa. Reach out to our team for any enquiries, site visits or collaborations."
        image={images.heroContact}
        imageAlt="Ocean-view terrace lounge at dusk"
      />

      <section className="py-16 lg:py-24">
        <div className="mx-auto grid max-w-content gap-12 px-6 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16 lg:px-10">
          {/* Let's Connect */}
          <RevealOnScroll>
            <h2 className="font-display text-2xl font-medium text-ink sm:text-3xl">Let&apos;s Connect</h2>
            <p className="mt-3 text-sm text-ink-muted">
              Our team will get back to you at the earliest.
            </p>

            <ul className="mt-8 space-y-6">
              <InfoRow icon={MapPin} title="Visit Us">
                Esplendor Homes Pvt. Ltd.
                <br />
                Baga, North Goa
                <br />
                Goa — 403516, India
              </InfoRow>
              <InfoRow icon={Phone} title="Call Us">
                +91 77770 00000
                <br />
                +91 77770 00001
              </InfoRow>
              <InfoRow icon={Mail} title="Email Us">
                info@esplendorhomes.com
                <br />
                sales@esplendorhomes.com
              </InfoRow>
              <InfoRow icon={Clock} title="Business Hours">
                Monday – Saturday
                <br />
                10:00 AM – 7:00 PM
                <br />
                (Sunday by prior appointment)
              </InfoRow>
            </ul>

            <div className="mt-8">
              <p className="mb-3 text-xs font-medium uppercase tracking-wide text-ink-muted">Follow Us</p>
              <div className="flex gap-3">
                {[Instagram, Facebook, Linkedin].map((Icon, i) => (
                  <a
                    key={i}
                    href="#"
                    aria-label="Social link"
                    className="flex h-11 w-11 items-center justify-center rounded-full border border-surface-border text-ink-muted transition-colors hover:border-accent hover:text-accent"
                  >
                    <Icon size={17} />
                  </a>
                ))}
              </div>
            </div>
          </RevealOnScroll>

          {/* Send Us a Message */}
          <RevealOnScroll delay={0.1} className="rounded-2xl border border-surface-border bg-surface p-6 sm:p-10">
            <h2 className="font-display text-2xl font-medium text-ink sm:text-3xl">Send Us a Message</h2>
            <p className="mt-3 text-sm text-ink-muted">
              Fill in your details and our team will get in touch with you.
            </p>
            <div className="mt-8">
              <ContactForm />
            </div>
          </RevealOnScroll>
        </div>
      </section>

      {/* Map section */}
      <section className="pb-20 lg:pb-28">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <RevealOnScroll className="relative overflow-hidden rounded-2xl border border-surface-border">
            <div className="relative h-[340px] w-full sm:h-[420px]">
              <Image
                src={images.mapPlaceholder}
                alt="Map showing ESPLENDOR's location in North Goa"
                fill
                sizes="100vw"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-black/35" />
            </div>
            <div className="absolute bottom-6 left-6 max-w-xs rounded-xl bg-surface/95 p-6 backdrop-blur">
              <p className="eyebrow mb-2">Visit Us</p>
              <h3 className="font-display text-lg text-ink">
                Explore our experience centre and discover a new standard of luxury living.
              </h3>
              <a href="#" className="btn-pill mt-4 inline-flex bg-accent text-black">
                Get Directions
              </a>
            </div>
          </RevealOnScroll>
        </div>
      </section>
    </>
  );
}

function InfoRow({
  icon: Icon,
  title,
  children,
}: {
  icon: typeof MapPin;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <li className="flex gap-4">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-accent/40 text-accent">
        <Icon size={18} strokeWidth={1.6} />
      </div>
      <div>
        <p className="text-sm font-medium text-ink">{title}</p>
        <p className="mt-0.5 text-sm leading-relaxed text-ink-muted">{children}</p>
      </div>
    </li>
  );
}

import { prisma } from "@/lib/prisma";
import { ShieldAlert } from "lucide-react";
import type { Lead } from "@prisma/client";

export const dynamic = "force-dynamic";

export default async function AdminLeadsPage({
  searchParams,
}: {
  searchParams: { key?: string };
}) {
  const adminSecret = process.env.ADMIN_SECRET;
  const authorized = Boolean(adminSecret) && searchParams.key === adminSecret;

  if (!authorized) {
    return (
      <main className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center">
        <ShieldAlert size={32} className="text-accent" />
        <h1 className="font-display mt-4 text-2xl text-ink">Restricted</h1>
        <p className="mt-2 max-w-sm text-sm text-ink-muted">
          This page requires a valid access key. Append <code>?key=YOUR_ADMIN_SECRET</code> to the URL,
          matching the <code>ADMIN_SECRET</code> set in your environment.
        </p>
      </main>
    );
  }

  const leads = await prisma.lead.findMany({ orderBy: { createdAt: "desc" } });

  return (
    <main className="mx-auto max-w-content px-6 py-16 lg:px-10">
      <h1 className="font-display text-2xl text-ink">Leads</h1>
      <p className="mt-1 text-sm text-ink-muted">{leads.length} submission{leads.length === 1 ? "" : "s"}, newest first.</p>

      <div className="mt-8 overflow-x-auto rounded-2xl border border-surface-border">
        <table className="w-full min-w-[720px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-surface-border bg-surface text-left text-xs uppercase tracking-wide text-ink-muted">
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Contact</th>
              <th className="px-4 py-3">Subject</th>
              <th className="px-4 py-3">Message</th>
              <th className="px-4 py-3">Submitted</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((lead: Lead) => (
              <tr key={lead.id} className="border-b border-surface-border last:border-0">
                <td className="px-4 py-3 align-top font-medium text-ink">{lead.fullName}</td>
                <td className="px-4 py-3 align-top text-ink-muted">
                  <div>{lead.email}</div>
                  <div>{lead.phone}</div>
                </td>
                <td className="px-4 py-3 align-top text-ink-muted">{lead.subject}</td>
                <td className="max-w-xs px-4 py-3 align-top text-ink-muted">{lead.message}</td>
                <td className="whitespace-nowrap px-4 py-3 align-top text-ink-muted">
                  {new Date(lead.createdAt).toLocaleString()}
                </td>
              </tr>
            ))}
            {leads.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-ink-muted">
                  No submissions yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </main>
  );
}

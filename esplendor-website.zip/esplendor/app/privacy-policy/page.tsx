import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy | ESPLENDOR",
};

export default function PrivacyPolicyPage() {
  return (
    <section className="mx-auto max-w-2xl px-6 py-24 lg:px-10">
      <h1 className="font-display text-3xl font-medium text-ink">Privacy Policy</h1>
      <p className="mt-6 text-sm leading-relaxed text-ink-muted">
        This is placeholder legal copy. Replace this page with ESPLENDOR&apos;s actual privacy
        policy — covering what information is collected through this site (including the contact
        form), how it&apos;s stored, who it&apos;s shared with, and how a visitor can request its
        deletion — before launch.
      </p>
    </section>
  );
}

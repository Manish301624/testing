import { Compass, Leaf, Hammer, HeartHandshake, ShieldCheck, Sprout } from "lucide-react";
import { Hero } from "@/components/Hero";
import { CTASection } from "@/components/CTASection";
import { SignatureDivider } from "@/components/SignatureDivider";
import { RevealOnScroll } from "@/components/RevealOnScroll";
import { FeatureTile } from "@/components/FeatureTile";
import { images } from "@/lib/images";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function HomePage() {
  return (
    <>
      <Hero
        eyebrow="Esplendor Homes — Goa"
        lines={["Not just", "where you live,"]}
        accentWord="how you live."
        subtext="Timeless beauty. Natural beauty. Refined living."
        ctaLabel="Explore Our Homes"
        ctaHref="/luxury-homes"
        image={images.heroHome}
        imageAlt="Luxury villa with an infinity pool overlooking the Goan coast at golden hour"
      />

      {/* Manifesto strip */}
      <section className="py-24 lg:py-32">
        <RevealOnScroll className="mx-auto max-w-2xl px-6 text-center lg:px-10">
          <p className="font-display text-2xl leading-snug text-ink sm:text-3xl">
            We believe true luxury is <span className="accent-word">quiet, intentional</span> and
            made to last.
          </p>
          <p className="mt-6 text-[0.95rem] leading-relaxed text-ink-muted">
            Every ESPLENDOR home begins with a site, not a template — the contours of the land, the
            direction of the light, the sound of the sea. We design around what&apos;s already
            there, using craftsmanship and restraint to build homes that feel inevitable rather than
            imposed. It&apos;s an approach that takes longer, and it&apos;s the only one we know.
          </p>
        </RevealOnScroll>
      </section>

      <SignatureDivider />

      {/* Homes Collection */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <RevealOnScroll>
            <h2 className="font-display max-w-lg text-[1.9rem] font-medium leading-tight text-ink sm:text-[2.3rem]">
              Homes, crafted to inspire <span className="accent-word">every chapter.</span>
            </h2>
          </RevealOnScroll>

          <div className="mt-12 grid gap-6 sm:grid-cols-3">
            {[
              {
                title: "Completed Homes",
                blurb: "Delivered, finished, and ready to call yours.",
                href: "/luxury-homes?filter=completed",
                image: images.collectionCompleted,
              },
              {
                title: "Ongoing Homes",
                blurb: "In progress, on track, worth watching.",
                href: "/luxury-homes?filter=ongoing",
                image: images.collectionOngoing,
              },
              {
                title: "Upcoming Homes",
                blurb: "The future, coming soon to Goa.",
                href: "/luxury-homes?filter=upcoming",
                image: images.collectionUpcoming,
              },
            ].map((item, i) => (
              <RevealOnScroll key={item.title} delay={i * 0.1}>
                <Link
                  href={item.href}
                  className="group block overflow-hidden rounded-2xl border border-surface-border"
                >
                  <div className="relative aspect-[4/5] overflow-hidden">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.image}
                      alt=""
                      className="h-full w-full object-cover transition-transform duration-700 ease-signature group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-6">
                      <h3 className="font-display text-lg text-white">{item.title}</h3>
                      <p className="mt-1 text-sm text-white/75">{item.blurb}</p>
                      <span className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-accent-2">
                        View all
                        <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
                      </span>
                    </div>
                  </div>
                </Link>
              </RevealOnScroll>
            ))}
          </div>
        </div>
      </section>

      {/* Feature grid */}
      <section className="bg-surface/40 py-20 lg:py-28">
        <div className="mx-auto max-w-content px-6 lg:px-10">
          <RevealOnScroll>
            <p className="eyebrow mb-3">Why Esplendor</p>
            <h2 className="font-display max-w-lg text-[1.9rem] font-medium leading-tight text-ink sm:text-[2.3rem]">
              What every home is built <span className="accent-word">around.</span>
            </h2>
          </RevealOnScroll>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Compass, title: "Timeless Architecture", desc: "Design that won't date — proportion and material over passing trend." },
              { icon: Leaf, title: "Nature Integrated", desc: "Homes shaped by the land they sit on, not laid over it." },
              { icon: Hammer, title: "Quality Craftsmanship", desc: "Every finish held to a standard that shows up in the details." },
              { icon: HeartHandshake, title: "Thoughtful Living", desc: "Spaces planned around how families actually move through a day." },
              { icon: ShieldCheck, title: "Trust & Excellence", desc: "Transparent process, honest timelines, no surprises." },
              { icon: Sprout, title: "Sustainable Development", desc: "Responsible building practices that protect Goa for the long run." },
            ].map((f, i) => (
              <FeatureTile key={f.title} icon={f.icon} title={f.title} description={f.desc} delay={i * 0.06} />
            ))}
          </div>
        </div>
      </section>

      <CTASection
        line="Begin your journey to"
        accentWord="timeless living."
        ctaLabel="Let's Connect"
      />
    </>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { contactSchema } from "@/lib/validation";
import { prisma } from "@/lib/prisma";
import { sendInternalLeadNotification, sendConfirmationEmail } from "@/lib/email";
import { checkRateLimit } from "@/lib/rate-limit";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";

  const { allowed, retryAfterSeconds } = checkRateLimit(ip);
  if (!allowed) {
    return NextResponse.json(
      {
        ok: false,
        message: "Too many requests from this address. Please try again in a few minutes.",
      },
      { status: 429, headers: retryAfterSeconds ? { "Retry-After": String(retryAfterSeconds) } : {} }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: "Invalid request body." }, { status: 400 });
  }

  const parsed = contactSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, message: "Some fields need a second look.", errors: parsed.error.flatten() },
      { status: 422 }
    );
  }

  const { company, ...lead } = parsed.data;

  // Honeypot tripped — silently pretend success so bots don't learn anything,
  // but never persist or email the submission.
  if (company) {
    return NextResponse.json({ ok: true });
  }

  try {
    await prisma.lead.create({
      data: {
        fullName: lead.fullName,
        email: lead.email,
        phone: lead.phone,
        subject: lead.subject,
        message: lead.message,
        consent: lead.consent,
      },
    });
  } catch (err) {
    console.error("[api/contact] Failed to save lead:", err);
    return NextResponse.json(
      { ok: false, message: "We couldn't save your message — please try again shortly." },
      { status: 500 }
    );
  }

  // Email failures shouldn't fail the request — the lead is already saved
  // and visible in /admin/leads even if notifications don't go out.
  try {
    await Promise.all([sendInternalLeadNotification(lead), sendConfirmationEmail(lead)]);
  } catch (err) {
    console.error("[api/contact] Lead saved, but email sending failed:", err);
  }

  return NextResponse.json({ ok: true });
}

# ESPLENDOR — Crafting Timeless Living

Luxury real-estate marketing site for ESPLENDOR (Goa, India). Next.js 14 (App Router) +
TypeScript + Tailwind + Framer Motion, with a real backend for the contact form
(Postgres via Prisma, Zod validation, Resend email, protected admin leads view).

## Two themes, one token system

Both brand directions from the brief are implemented as CSS variables and can be toggled
live (the sun/moon icon in the navbar), or set as the default in `app/layout.tsx`:

- **Noir & Gold** (`data-theme="noir"`) — dark, luxury. Default.
- **Soft & Warm** (`data-theme="soft"`) — light, editorial.

Tokens live in `app/globals.css` under `[data-theme="noir"]` / `[data-theme="soft"]`, and are
exposed to Tailwind via `tailwind.config.ts` (`bg`, `surface`, `ink`, `accent`, etc.) — so every
component is theme-agnostic by construction.

**Typography:** Fraunces (display serif, used for headings and the italic accent word in every
headline) + Manrope (body sans) — chosen to avoid the generic Playfair+Inter pairing while
staying in the same "elegant serif + clean geometric sans" family the brief asked for.

**Signature element:** the animated "skyline" divider (`components/SignatureDivider.tsx`) —
a row of rising bars that echoes the pillar mark in the logo — used between major sections
instead of numbered markers or plain rules.

## Getting started

```bash
npm install
cp .env.example .env.local   # fill in DATABASE_URL, RESEND_API_KEY, etc.
npx prisma migrate dev --name init
npm run dev
```

Open http://localhost:3000.

## Environment variables

See `.env.example`. You'll need:

- `DATABASE_URL` — your self-hosted Postgres connection string
- `RESEND_API_KEY` — from https://resend.com/api-keys, plus a verified sending domain
- `EMAIL_FROM` / `SALES_NOTIFICATION_EMAIL` — who emails come from / go to
- `ADMIN_SECRET` — a long random string; the leads view lives at `/admin/leads?key=YOUR_SECRET`

## Project structure

```
/app
  page.tsx                     Home
  our-story/page.tsx
  luxury-homes/page.tsx        client component — functional filter tabs
  the-living-difference/page.tsx
  contact/page.tsx             real form, wired to /api/contact
  admin/leads/page.tsx         protected, server-rendered from Prisma
  api/contact/route.ts         validate → rate-limit → save → email
  privacy-policy/page.tsx, terms/page.tsx   legal stubs — replace before launch
/components                    Navbar, Footer, Hero, CTASection, StatCounter,
                                ProjectCard, FeatureTile, ContactForm, etc.
/lib
  theme.ts, images.ts, validation.ts, prisma.ts, email.ts, rate-limit.ts
/prisma/schema.prisma           Lead model
```

## Before you launch

- **Swap placeholder photography.** `lib/images.ts` currently points at Unsplash placeholders —
  replace every entry with real ESPLENDOR photography.
- **Replace the legal pages.** `/privacy-policy` and `/terms` are stubs.
- **Verify your Resend sending domain** or emails will silently fail (the lead is still saved to
  the DB either way — email sending never blocks the DB write).
- **Rate limiting** is in-memory (`lib/rate-limit.ts`), which is fine for a single instance. If
  you deploy across multiple serverless instances, swap it for a shared store (e.g. Upstash
  Redis) — the function signature is designed as a drop-in replacement.
- **Run `npx prisma migrate deploy`** against your production database before first launch.

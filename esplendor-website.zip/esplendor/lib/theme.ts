export type ThemeName = "noir" | "soft";

export const themes: Record<
  ThemeName,
  {
    label: string;
    description: string;
    tokens: Record<string, string>;
  }
> = {
  noir: {
    label: "Noir & Gold",
    description: "Dark, luxury. Near-black surfaces with a gold gradient accent.",
    tokens: {
      bg: "#0B0B0B",
      surface: "#1A1816",
      surfaceBorder: "#2B2723",
      ink: "#F4F1EC",
      inkMuted: "#A8A29B",
      accent: "#C9A44C",
      accent2: "#E8C878",
    },
  },
  soft: {
    label: "Soft & Warm",
    description: "Light, editorial. Warm cream surfaces with terracotta and sage accents.",
    tokens: {
      bg: "#F7F3EC",
      surface: "#FFFFFF",
      surfaceBorder: "#E6DCCB",
      ink: "#1F1D1B",
      inkMuted: "#7A7268",
      accent: "#B8894A",
      accent2: "#6E7A5E",
    },
  },
};

export const DEFAULT_THEME: ThemeName = "noir";

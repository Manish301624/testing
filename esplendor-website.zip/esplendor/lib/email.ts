import { Resend } from "resend";
import type { ContactFormValues } from "./validation";

const resendApiKey = process.env.RESEND_API_KEY;
const resend = resendApiKey ? new Resend(resendApiKey) : null;

const SALES_INBOX = process.env.SALES_NOTIFICATION_EMAIL ?? "sales@esplendorhomes.com";
const FROM_ADDRESS = process.env.EMAIL_FROM ?? "ESPLENDOR <notifications@esplendorhomes.com>";

/**
 * Sends the internal lead notification to the sales inbox.
 * Throws if the provider errors so the caller can decide how to handle it —
 * a failed email should never block the DB write from having already happened.
 */
export async function sendInternalLeadNotification(lead: ContactFormValues) {
  if (!resend) {
    console.warn("[email] RESEND_API_KEY not set — skipping internal notification.");
    return;
  }

  await resend.emails.send({
    from: FROM_ADDRESS,
    to: SALES_INBOX,
    subject: `New enquiry: ${lead.subject}`,
    html: `
      <div style="font-family: sans-serif; max-width: 560px; margin: 0 auto;">
        <h2 style="color:#C9A44C;">New website enquiry</h2>
        <table style="width:100%; border-collapse: collapse;">
          <tr><td style="padding:6px 0; color:#7A7268;">Name</td><td>${escapeHtml(lead.fullName)}</td></tr>
          <tr><td style="padding:6px 0; color:#7A7268;">Email</td><td>${escapeHtml(lead.email)}</td></tr>
          <tr><td style="padding:6px 0; color:#7A7268;">Phone</td><td>${escapeHtml(lead.phone)}</td></tr>
          <tr><td style="padding:6px 0; color:#7A7268;">Subject</td><td>${escapeHtml(lead.subject)}</td></tr>
        </table>
        <p style="color:#7A7268; margin-top:16px;">Message</p>
        <p style="white-space: pre-wrap;">${escapeHtml(lead.message)}</p>
      </div>
    `,
  });
}

/** Sends the auto-reply confirmation to the person who submitted the form. */
export async function sendConfirmationEmail(lead: ContactFormValues) {
  if (!resend) {
    console.warn("[email] RESEND_API_KEY not set — skipping confirmation email.");
    return;
  }

  await resend.emails.send({
    from: FROM_ADDRESS,
    to: lead.email,
    subject: "Thanks for reaching out to ESPLENDOR",
    html: `
      <div style="font-family: sans-serif; max-width: 560px; margin: 0 auto;">
        <h2 style="color:#C9A44C;">Thanks for reaching out, ${escapeHtml(lead.fullName.split(" ")[0])}.</h2>
        <p>Our team will contact you shortly to continue the conversation about "${escapeHtml(
          lead.subject
        )}".</p>
        <p style="color:#7A7268;">— The ESPLENDOR team<br/>Crafting Timeless Living</p>
      </div>
    `,
  });
}

function escapeHtml(input: string) {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

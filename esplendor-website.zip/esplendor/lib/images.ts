// Placeholder photography sourced from Unsplash. Swap every one of these
// for real ESPLENDOR photography before launch — see next.config.js for
// the remotePatterns entry that whitelists images.unsplash.com.

function unsplash(id: string, w = 1600) {
  return `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;
}

export const images = {
  heroHome: unsplash("photo-1613977257363-707ba9348227"), // villa + pool, golden hour
  heroOurStory: unsplash("photo-1573843981267-be1999ff37cd"), // Goa coastline
  heroLuxuryHomes: unsplash("photo-1600607687920-4e2a09cf159d"), // modern residences
  heroLivingDifference: unsplash("photo-1600210492486-724fe5c67fb0"), // interior lounge
  heroContact: unsplash("photo-1600047509807-ba8f99d2cdde"), // terrace ocean view

  manifestoInterior: unsplash("photo-1600585154340-be6161a56a0c"),
  aboutLobby: unsplash("photo-1616486338812-3dadae4b4ace"),

  collectionCompleted: unsplash("photo-1512917774080-9991f1c4c750"),
  collectionOngoing: unsplash("photo-1600607687939-ce8a6c25118c"),
  collectionUpcoming: unsplash("photo-1600566753086-00f18fb6b3ea"),

  projectCasaBella: unsplash("photo-1613490493576-7fde63acd811"),
  projectVistaVerde: unsplash("photo-1600596542815-ffad4c1539a9"),
  projectThePalms: unsplash("photo-1613977257592-4871e5fcaa8c"),
  projectSolaceVilla: unsplash("photo-1613553507747-5f8d62ad5904"),

  differenceFurnishing: unsplash("photo-1616594039964-ae9021a400a0"),
  differenceAmenities: unsplash("photo-1571896349842-33c89424de2d"),
  differencePurchase: unsplash("photo-1560518883-ce09059eeffa"),
  differenceConcierge: unsplash("photo-1551882547-ff40c63fe5fa"),
  differenceManagement: unsplash("photo-1600585154526-990dced4db0d"),
  differenceRenting: unsplash("photo-1560448204-e02f11c3d0e2"),
  differenceProtection: unsplash("photo-1558002038-1055907df827"),
  differenceEntertainment: unsplash("photo-1543007630-9710e4a00a20"),

  mapPlaceholder: unsplash("photo-1524661135-423995f22d0b"),
};

import { z } from "zod";

// Shared between the client form and the /api/contact route handler,
// so validation rules can never drift out of sync.
export const contactSchema = z.object({
  fullName: z
    .string()
    .trim()
    .min(2, "Enter your full name.")
    .max(120, "That name looks too long — double check it."),
  email: z
    .string()
    .trim()
    .email("Enter a valid email address."),
  phone: z
    .string()
    .trim()
    .min(7, "Enter a valid phone number.")
    .max(20, "That phone number looks too long — double check it.")
    .regex(/^[0-9+()\-.\s]+$/, "Use only numbers and phone symbols."),
  subject: z
    .string()
    .trim()
    .min(2, "Tell us what this is about.")
    .max(150, "Keep the subject a little shorter."),
  message: z
    .string()
    .trim()
    .min(10, "Add a few more details so our team can help.")
    .max(2000, "Keep your message under 2000 characters."),
  consent: z.literal(true, {
    errorMap: () => ({ message: "Please agree to be contacted to send this form." }),
  }),
  // Honeypot — real visitors never fill this in. Bots that auto-fill every
  // field will trip it, and the server silently drops the submission.
  company: z.string().max(0).optional().or(z.literal("")),
});

export type ContactFormValues = z.infer<typeof contactSchema>;

import Image from "next/image";
import type { LucideIcon } from "lucide-react";
import { RevealOnScroll } from "./RevealOnScroll";

type Props = {
  icon: LucideIcon;
  title: string;
  description: string;
  image?: string;
  delay?: number;
};

export function FeatureTile({ icon: Icon, title, description, image, delay = 0 }: Props) {
  return (
    <RevealOnScroll
      delay={delay}
      className="group overflow-hidden rounded-2xl border border-surface-border bg-surface transition-shadow duration-500 hover:shadow-[0_20px_40px_-20px_rgba(0,0,0,0.3)]"
    >
      {image && (
        <div className="relative aspect-[16/10] overflow-hidden">
          <Image
            src={image}
            alt=""
            fill
            sizes="(min-width: 1024px) 25vw, 90vw"
            className="object-cover transition-transform duration-700 ease-signature group-hover:scale-105"
          />
        </div>
      )}
      <div className="p-6">
        <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full border border-accent/40 text-accent">
          <Icon size={19} strokeWidth={1.6} />
        </div>
        <h3 className="font-display text-[1.05rem] font-medium text-ink">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-ink-muted">{description}</p>
      </div>
    </RevealOnScroll>
  );
}

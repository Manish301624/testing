import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { RevealOnScroll } from "./RevealOnScroll";

type Props = {
  line: string;
  accentWord: string;
  ctaLabel: string;
  ctaHref?: string;
};

export function CTASection({ line, accentWord, ctaLabel, ctaHref = "/contact" }: Props) {
  return (
    <section className="bg-[var(--footer-bg)] py-20 lg:py-28">
      <RevealOnScroll className="mx-auto flex max-w-content flex-col items-center gap-8 px-6 text-center lg:px-10">
        <h2 className="font-display max-w-2xl text-[2rem] font-medium leading-tight text-footer-ink sm:text-[2.6rem]">
          {line} <span className="accent-word">{accentWord}</span>
        </h2>
        <Link href={ctaHref} className="btn-pill group bg-accent text-black">
          {ctaLabel}
          <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
        </Link>
      </RevealOnScroll>
    </section>
  );
}

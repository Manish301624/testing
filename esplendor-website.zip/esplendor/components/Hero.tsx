"use client";

import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

type Props = {
  eyebrow?: string;
  lines: string[]; // each line rendered on its own row
  accentWord: string; // rendered in italic serif accent, appended after the last line
  subtext: string;
  ctaLabel?: string;
  ctaHref?: string;
  image: string;
  imageAlt: string;
  compact?: boolean;
};

export function Hero({
  eyebrow,
  lines,
  accentWord,
  subtext,
  ctaLabel,
  ctaHref = "/contact",
  image,
  imageAlt,
  compact = false,
}: Props) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section className={`relative overflow-hidden ${compact ? "h-[64vh] min-h-[440px]" : "h-[92vh] min-h-[600px]"}`}>
      <motion.div
        className="absolute inset-0"
        initial={prefersReducedMotion ? undefined : { scale: 1.12, opacity: 0 }}
        animate={prefersReducedMotion ? undefined : { scale: 1, opacity: 1 }}
        transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
      >
        <Image src={image} alt={imageAlt} fill priority sizes="100vw" className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/10" />
      </motion.div>

      <div className="relative z-10 mx-auto flex h-full max-w-content flex-col justify-end px-6 pb-20 lg:px-10 lg:pb-28">
        {eyebrow && (
          <motion.p
            className="eyebrow mb-4 text-white/90"
            initial={prefersReducedMotion ? undefined : { opacity: 0, y: 12 }}
            animate={prefersReducedMotion ? undefined : { opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {eyebrow}
          </motion.p>
        )}

        <h1 className="font-display max-w-2xl text-[2.6rem] font-medium leading-[1.08] text-white sm:text-[3.4rem] lg:text-[4rem]">
          {lines.map((line, i) => (
            <motion.span
              key={i}
              className="block overflow-hidden"
              initial={prefersReducedMotion ? undefined : { opacity: 0 }}
              animate={prefersReducedMotion ? undefined : { opacity: 1 }}
              transition={{ delay: 0.3 + i * 0.12 }}
            >
              <motion.span
                className="block"
                initial={prefersReducedMotion ? undefined : { y: "100%" }}
                animate={prefersReducedMotion ? undefined : { y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
              >
                {line}
              </motion.span>
            </motion.span>
          ))}
          {accentWord && (
            <motion.span
              className="accent-word block"
              initial={prefersReducedMotion ? undefined : { opacity: 0, y: 16 }}
              animate={prefersReducedMotion ? undefined : { opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 + lines.length * 0.12 }}
            >
              {accentWord}
            </motion.span>
          )}
        </h1>

        <motion.p
          className="mt-6 max-w-md text-[0.98rem] leading-relaxed text-white/85"
          initial={prefersReducedMotion ? undefined : { opacity: 0, y: 12 }}
          animate={prefersReducedMotion ? undefined : { opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.7 }}
        >
          {subtext}
        </motion.p>

        {ctaLabel && (
          <motion.div
            initial={prefersReducedMotion ? undefined : { opacity: 0, y: 12 }}
            animate={prefersReducedMotion ? undefined : { opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.85 }}
            className="mt-9"
          >
            <Link href={ctaHref} className="btn-pill group bg-white text-black">
              {ctaLabel}
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </Link>
          </motion.div>
        )}
      </div>
    </section>
  );
}

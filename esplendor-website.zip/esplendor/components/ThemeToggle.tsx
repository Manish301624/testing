"use client";

import { Moon, Sun } from "lucide-react";
import { useTheme } from "./ThemeProvider";

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const isNoir = theme === "noir";

  return (
    <button
      onClick={toggleTheme}
      aria-label={`Switch to ${isNoir ? "Soft & Warm" : "Noir & Gold"} theme`}
      title={`Switch to ${isNoir ? "Soft & Warm" : "Noir & Gold"} theme`}
      className="flex h-11 w-11 items-center justify-center rounded-full border border-surface-border text-ink transition-colors hover:border-accent hover:text-accent"
    >
      {isNoir ? <Sun size={17} strokeWidth={1.75} /> : <Moon size={17} strokeWidth={1.75} />}
    </button>
  );
}

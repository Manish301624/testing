import Link from "next/link";
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "./Logo";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/our-story", label: "Our Story" },
  { href: "/luxury-homes", label: "Luxury Homes" },
  { href: "/the-living-difference", label: "The Living Difference" },
  { href: "/contact", label: "Contact" },
];

const HOME_LINKS = [
  { href: "/luxury-homes?filter=completed", label: "Completed Homes" },
  { href: "/luxury-homes?filter=ongoing", label: "Ongoing Homes" },
  { href: "/luxury-homes?filter=upcoming", label: "Upcoming Homes" },
  { href: "/luxury-homes", label: "All Projects" },
];

const LEGAL_LINKS = [
  { href: "/privacy-policy", label: "Privacy Policy" },
  { href: "/terms", label: "Terms & Conditions" },
];

export function Footer() {
  return (
    <footer data-theme-footer className="bg-footer" style={{ colorScheme: "dark" }}>
      <div className="mx-auto max-w-content px-6 py-16 lg:px-10">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Logo tone="footer" />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-footer-ink-muted">
              A luxury home developer crafting timeless residences along the coast of Goa —
              built with intention, made to last.
            </p>
          </div>

          <FooterColumn title="Navigation" links={NAV_LINKS} />
          <FooterColumn title="Luxury Homes" links={HOME_LINKS} />

          <div>
            <h3 className="eyebrow mb-4 text-footer-ink-muted">Connect</h3>
            <ul className="space-y-3 text-sm text-footer-ink-muted">
              <li className="flex gap-2.5">
                <MapPin size={16} className="mt-0.5 shrink-0 text-accent" />
                Baga, North Goa — 403516, India
              </li>
              <li className="flex gap-2.5">
                <Phone size={16} className="mt-0.5 shrink-0 text-accent" />
                +91 77770 00000
              </li>
              <li className="flex gap-2.5">
                <Mail size={16} className="mt-0.5 shrink-0 text-accent" />
                info@esplendorhomes.com
              </li>
            </ul>
            <div className="mt-5 flex gap-3">
              {[Instagram, Facebook, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social link"
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-footer-ink-muted transition-colors hover:border-accent hover:text-accent"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-white/10 pt-6 text-xs text-footer-ink-muted sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} ESPLENDOR. All Rights Reserved.</p>
          <div className="flex gap-6">
            {LEGAL_LINKS.map((l) => (
              <Link key={l.href} href={l.href} className="hover:text-accent">
                {l.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <h3 className="eyebrow mb-4 text-footer-ink-muted">{title}</h3>
      <ul className="space-y-2.5 text-sm text-footer-ink-muted">
        {links.map((l) => (
          <li key={l.href}>
            <Link href={l.href} className="hover:text-accent">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

import Link from "next/link";

export function Logo({
  className = "",
  tone = "default",
}: {
  className?: string;
  tone?: "default" | "footer";
}) {
  const wordmarkClass = tone === "footer" ? "text-footer-ink" : "text-ink";
  const taglineClass = tone === "footer" ? "text-footer-ink-muted" : "text-ink-muted";

  return (
    <Link href="/" className={`group flex items-center gap-2.5 ${className}`} aria-label="ESPLENDOR home">
      <svg width="26" height="26" viewBox="0 0 26 26" fill="none" aria-hidden="true">
        <rect x="2" y="10" width="2.6" height="12" fill="var(--accent)" />
        <rect x="6.4" y="6" width="2.6" height="16" fill="var(--accent)" />
        <rect x="10.8" y="2" width="2.6" height="20" fill="var(--accent)" />
        <path
          d="M12.1 10c2.4 0 4.2 1.9 4.2 4.3 0 2.9-4.2 6-4.2 6s-4.2-3.1-4.2-6c0-2.4 1.8-4.3 4.2-4.3z"
          fill="var(--accent-2)"
          opacity="0.9"
        />
      </svg>
      <span className="flex flex-col leading-none">
        <span className={`font-display text-[1.05rem] tracking-[0.16em] ${wordmarkClass}`}>ESPLENDOR</span>
        <span className={`mt-1 text-[0.52rem] tracking-[0.22em] ${taglineClass}`}>
          CRAFTING TIMELESS LIVING
        </span>
      </span>
    </Link>
  );
}

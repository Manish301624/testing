"use client";

import { useEffect, useRef } from "react";
import { motion, useInView, useMotionValue, useReducedMotion, useTransform, animate } from "framer-motion";

type Props = {
  value: number;
  suffix?: string;
  prefix?: string;
  label: string;
};

export function StatCounter({ value, suffix = "", prefix = "", label }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });
  const prefersReducedMotion = useReducedMotion();
  const count = useMotionValue(prefersReducedMotion ? value : 0);
  const rounded = useTransform(count, (v) => Math.round(v));

  useEffect(() => {
    if (isInView && !prefersReducedMotion) {
      const controls = animate(count, value, { duration: 1.4, ease: [0.22, 1, 0.36, 1] });
      return controls.stop;
    }
  }, [isInView, value, count, prefersReducedMotion]);

  return (
    <div ref={ref} className="text-center">
      <p className="font-display text-3xl font-medium text-accent sm:text-4xl">
        {prefix}
        <motion.span>{rounded}</motion.span>
        {suffix}
      </p>
      <p className="mt-2 text-[0.72rem] uppercase tracking-[0.14em] text-ink-muted">{label}</p>
    </div>
  );
}

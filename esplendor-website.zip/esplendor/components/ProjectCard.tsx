import Image from "next/image";
import Link from "next/link";
import { ArrowRight, MapPin } from "lucide-react";

type Props = {
  name: string;
  location: string;
  description: string;
  image: string;
  href?: string;
  status?: string;
};

export function ProjectCard({ name, location, description, image, href = "#", status }: Props) {
  return (
    <Link
      href={href}
      className="group block overflow-hidden rounded-2xl border border-surface-border bg-surface transition-all duration-500 ease-signature hover:-translate-y-1.5 hover:shadow-[0_24px_48px_-16px_rgba(0,0,0,0.35)]"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={image}
          alt={`${name} — luxury villa in ${location}`}
          fill
          sizes="(min-width: 1024px) 25vw, 90vw"
          className="object-cover transition-transform duration-700 ease-signature group-hover:scale-105"
        />
        {status && (
          <span className="absolute left-3 top-3 rounded-full bg-black/60 px-3 py-1 text-[0.65rem] font-semibold uppercase tracking-wide text-white backdrop-blur">
            {status}
          </span>
        )}
      </div>
      <div className="p-5">
        <div className="flex items-center gap-1.5 text-[0.72rem] uppercase tracking-wide text-accent">
          <MapPin size={12} />
          {location}
        </div>
        <h3 className="font-display mt-1.5 text-lg font-medium text-ink">{name}</h3>
        <p className="mt-2 text-sm leading-relaxed text-ink-muted">{description}</p>
        <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-accent">
          View Project
          <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
        </span>
      </div>
    </Link>
  );
}

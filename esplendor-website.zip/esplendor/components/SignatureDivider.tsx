"use client";

import { motion, useReducedMotion } from "framer-motion";

const BAR_HEIGHTS = [14, 26, 18, 34, 20, 30, 16, 24, 12];

/**
 * ESPLENDOR's signature moment: a low skyline of rising bars, echoing the
 * pillar mark in the logo and the villas' own clean vertical lines against
 * the horizon. Used to punctuate transitions between major sections instead
 * of a plain rule or numbered marker.
 */
export function SignatureDivider({ className = "" }: { className?: string }) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <div
      className={`mx-auto flex h-10 max-w-content items-end justify-center gap-[3px] px-6 ${className}`}
      aria-hidden="true"
    >
      {BAR_HEIGHTS.map((h, i) => (
        <motion.span
          key={i}
          className="w-[3px] rounded-sm"
          style={{
            background:
              "linear-gradient(180deg, var(--accent-2) 0%, var(--accent) 100%)",
            transformOrigin: "bottom",
          }}
          initial={prefersReducedMotion ? undefined : { scaleY: 0, opacity: 0 }}
          whileInView={prefersReducedMotion ? undefined : { scaleY: 1, opacity: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{
            duration: 0.5,
            delay: i * 0.045,
            ease: [0.22, 1, 0.36, 1],
          }}
          animate={{ height: h }}
        />
      ))}
    </div>
  );
}

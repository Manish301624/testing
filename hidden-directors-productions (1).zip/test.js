const url = "https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=800&q=80";
const tinyUrl = url.replace(/w=\d+/, 'w=20').replace(/q=\d+/, 'q=10') + '&blur=20';
console.log(tinyUrl);

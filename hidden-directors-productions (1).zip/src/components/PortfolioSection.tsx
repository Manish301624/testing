import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, TrendingUp, Flame, Check } from 'lucide-react';
import { ProjectItem } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { ProjectVideoCard } from './ProjectVideoCard';
import { containerStagger, staggerFadeIn, slideUp } from '../utils/motionVariants';

interface PortfolioSectionProps {
  projects: ProjectItem[];
  onSelectProject: (project: ProjectItem) => void;
  onOpenBooking: () => void;
}

// Initial baseline simulated views count
const INITIAL_SIMULATED_VIEWS: Record<string, number> = {
  'proj-1': 124850,
  'proj-2': 450320,
  'proj-3': 892100,
  'proj-4': 310450,
  'proj-5': 620890,
  'proj-6': 278400,
};

export const PortfolioSection: React.FC<PortfolioSectionProps> = ({
  projects,
  onSelectProject,
  onOpenBooking
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const { language } = useLanguage();

  // Simulated state for live project views & popularity
  const [projectViews, setProjectViews] = useState<Record<string, number>>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('hd_project_views');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed && typeof parsed === 'object') {
            return { ...INITIAL_SIMULATED_VIEWS, ...parsed };
          }
        }
      } catch {
        // ignore parse error
      }
    }
    return INITIAL_SIMULATED_VIEWS;
  });

  // Listen for category selection events dispatched from nested navigation
  useEffect(() => {
    const handleCategoryEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ category?: string; subCategory?: string }>;
      if (customEvent.detail?.category) {
        const rawCat = customEvent.detail.category.toLowerCase();
        // Map raw category / slug to matching portfolio category
        if (rawCat.includes('interior') || rawCat.includes('architecture')) {
          setSelectedCategory('Interiors');
        } else if (rawCat.includes('hospitality') || rawCat.includes('food') || rawCat.includes('restaurant') || rawCat.includes('café') || rawCat.includes('cafe')) {
          setSelectedCategory('Cafés & Restaurants');
        } else if (rawCat.includes('ecommerce') || rawCat.includes('product') || rawCat.includes('commercial')) {
          setSelectedCategory('Commercial / Ads');
        } else if (rawCat.includes('fashion') || rawCat.includes('lifestyle')) {
          setSelectedCategory('Fashion & Lifestyle');
        } else if (rawCat.includes('personal') || rawCat.includes('brand')) {
          setSelectedCategory('Personal Branding');
        } else {
          // If direct match with categories list
          const found = categories.find(c => c.toLowerCase() === rawCat);
          if (found) setSelectedCategory(found);
          else setSelectedCategory('All');
        }
      }
    };

    window.addEventListener('hd:select-portfolio-category', handleCategoryEvent);
    return () => {
      window.removeEventListener('hd:select-portfolio-category', handleCategoryEvent);
    };
  }, []);

  // Format views into human readable compact form (e.g. 124.8K, 1.2M)
  const formatViews = (count?: number, fallbackStr?: string): string => {
    if (!count) {
      if (fallbackStr) return fallbackStr;
      return '120K';
    }
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1) + 'M';
    }
    if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toLocaleString();
  };

  // Determine popularity tag based on views
  const getPopularityBadge = (count: number) => {
    if (count >= 800000) {
      return {
        label: language === 'es' ? 'Viral' : 'Viral',
        icon: Flame,
        color: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
      };
    }
    if (count >= 400000) {
      return {
        label: language === 'es' ? 'Tendencia' : 'Trending',
        icon: TrendingUp,
        color: 'text-pink-400 bg-pink-500/10 border-pink-500/30',
      };
    }
    return null;
  };

  const handleCardClick = (project: ProjectItem) => {
    // Increment views on project open
    setProjectViews((prev) => {
      const current = prev[project.id] || 100000;
      const updated = { ...prev, [project.id]: current + 1 };
      try {
        localStorage.setItem('hd_project_views', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
    onSelectProject(project);
  };

  const categories = [
    'All',
    'Interiors',
    'Cafés & Restaurants',
    'Fashion & Lifestyle',
    'Commercial / Ads',
    'Personal Branding'
  ];

  const handleCategorySelect = (cat: string) => {
    setSelectedCategory(cat);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('hd:category-filter', {
        detail: { projectCategory: cat === 'All' ? 'all' : cat }
      }));
    }
  };

  const filteredProjects = selectedCategory === 'All'
    ? projects
    : projects.filter(p => {
        const catTarget = selectedCategory.toLowerCase();
        const primaryMatch = p.category.toLowerCase().includes(catTarget) || catTarget.includes(p.category.toLowerCase());
        const multiMatch = p.categories?.some(c => 
          c.toLowerCase().includes(catTarget) || catTarget.includes(c.toLowerCase())
        );
        return Boolean(primaryMatch || multiMatch);
      });

  return (
    <section id="portfolio" className="py-20 relative bg-[#0a0311]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with whileInView */}
        <motion.div
          variants={slideUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12"
        >
          <div>
            <div className="inline-flex items-center px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-[11px] font-bold tracking-wider text-pink-300 uppercase mb-3">
              {language === 'es' ? 'MUESTRA DE PRODUCCIÓN CURADA' : 'CURATED PRODUCTION SHOWCASE'}
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display">
              {language === 'es' ? 'Nuestros Trabajos Seleccionados' : 'Our Selected Work'}
            </h2>
            <p className="mt-2 text-sm sm:text-base text-gray-400 max-w-xl">
              {language === 'es'
                ? 'Películas cinematográficas de marca, reels para redes y recorridos espaciales diseñados para captar atención y generar conversión.'
                : 'Cinematic brand films, social-first reels, and spatial walkthroughs engineered for attention and conversion.'}
            </p>
          </div>

          <button
            onClick={onOpenBooking}
            className="self-start md:self-auto btn-primary-gradient px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/20 cursor-pointer"
          >
            {language === 'es' ? 'INICIAR PROYECTO' : 'START YOUR PROJECT'}
          </button>
        </motion.div>

        {/* Category Filters with whileInView */}
        <motion.div
          variants={slideUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="flex items-center gap-2 overflow-x-auto pb-4 no-scrollbar mb-8"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => handleCategorySelect(cat)}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#FF007A] text-white shadow-md shadow-pink-500/30 scale-105'
                  : 'bg-[#15071f] text-gray-300 hover:text-white border border-white/5 hover:border-white/20'
              }`}
            >
              {cat === 'All' && language === 'es' ? 'Todos' : cat}
            </button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <motion.div 
          layout 
          variants={containerStagger}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence>
            {filteredProjects.map((project, idx) => {
              const currentViewsCount = projectViews[project.id] || (project.views ? parseInt(project.views.replace(/\D/g, '')) * 1000 : 120000);
              const formattedViewString = formatViews(currentViewsCount, project.views);
              const popularity = getPopularityBadge(currentViewsCount);

              return (
                <ProjectVideoCard
                  key={project.id}
                  project={project}
                  idx={idx}
                  currentViewsCount={currentViewsCount}
                  formattedViewString={formattedViewString}
                  popularity={popularity}
                  language={language}
                  onCardClick={handleCardClick}
                />
              );
            })}
          </AnimatePresence>
        </motion.div>

      </div>
    </section>
  );
};


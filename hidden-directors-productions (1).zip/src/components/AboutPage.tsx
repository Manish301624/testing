import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'motion/react';
import { Helmet } from 'react-helmet-async';
import { 
  Play, 
  Sparkles, 
  ArrowRight, 
  Film, 
  Camera, 
  Layers, 
  Clock, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight, 
  Instagram, 
  Linkedin, 
  Mail, 
  Quote, 
  Compass, 
  Sliders, 
  Video, 
  Maximize2
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { CinematicImage } from './CinematicImage';
import { 
  ABOUT_SHOWREEL, 
  STUDIO_STORY, 
  STUDIO_MILESTONES, 
  CAPABILITIES_SHOWCASE, 
  BTS_GALLERY, 
  FOUNDER_PROFILE 
} from '../data/aboutData';
import { AutoplayVideo } from './AutoplayVideo';
import { FAQAccordion } from './FAQAccordion';
import { ReelItem } from '../types';

interface AboutPageProps {
  onOpenBooking: () => void;
  onOpenCallback?: () => void;
  onSelectReel: (reel: ReelItem) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onOpenBooking,
  onOpenCallback,
  onSelectReel
}) => {
  const navigate = useNavigate();
  const btsScrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  // Scroll to top on route entry
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, []);

  // BTS horizontal scroll helpers
  const checkScroll = () => {
    if (btsScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = btsScrollRef.current;
      setCanScrollLeft(scrollLeft > 20);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 20);
    }
  };

  const handleScrollBts = (direction: 'left' | 'right') => {
    if (btsScrollRef.current) {
      const scrollAmount = btsScrollRef.current.clientWidth * 0.75;
      btsScrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const handleNavigateToProcess = () => {
    navigate('/');
    setTimeout(() => {
      const el = document.getElementById('process');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 200);
  };

  const masterReelItem: ReelItem = {
    id: ABOUT_SHOWREEL.id,
    title: ABOUT_SHOWREEL.title,
    category: 'commercial',
    client: ABOUT_SHOWREEL.client,
    videoUrl: ABOUT_SHOWREEL.videoUrl,
    posterUrl: ABOUT_SHOWREEL.posterUrl,
    description: ABOUT_SHOWREEL.description,
    duration: ABOUT_SHOWREEL.duration,
    resolution: ABOUT_SHOWREEL.resolution,
    clientType: 'Studio Master',
    likes: ABOUT_SHOWREEL.likes,
    tags: ABOUT_SHOWREEL.tags
  };

  const aboutPageTitle = 'About Our Studio & Directors | Hidden Directors Productions';
  const aboutPageDescription = 'Discover the director-led craftsmanship, founding story, cinema camera rigs (RED/ARRI), and commercial visual milestones behind Hidden Directors Productions.';
  const aboutCanonicalUrl = 'https://hiddendirectors.com/about';
  const aboutOgImage = ABOUT_SHOWREEL.posterUrl || 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80';

  const aboutSchemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'AboutPage',
    'name': aboutPageTitle,
    'description': aboutPageDescription,
    'url': aboutCanonicalUrl,
    'mainEntity': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'url': 'https://hiddendirectors.com',
      'logo': 'https://hiddendirectors.com/logo.svg',
      'description': aboutPageDescription,
      'founder': {
        '@type': 'Person',
        'name': FOUNDER_PROFILE.name,
        'jobTitle': FOUNDER_PROFILE.title
      }
    }
  };

  return (
    <div id="about-page" className="pt-24 pb-20 relative overflow-hidden bg-[#09030e] text-[#F3F4F6]">
      {/* Dynamic SEO Metadata via react-helmet-async */}
      <Helmet>
        <title>{aboutPageTitle}</title>
        <meta name="description" content={aboutPageDescription} />

        {/* OpenGraph / Facebook */}
        <meta property="og:type" content="profile" />
        <meta property="og:title" content={aboutPageTitle} />
        <meta property="og:description" content={aboutPageDescription} />
        <meta property="og:image" content={aboutOgImage} />
        <meta property="og:image:alt" content="Hidden Directors Productions Studio" />
        <meta property="og:url" content={aboutCanonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />

        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={aboutPageTitle} />
        <meta name="twitter:description" content={aboutPageDescription} />
        <meta name="twitter:image" content={aboutOgImage} />
        <meta name="twitter:image:alt" content="Hidden Directors Productions Studio" />

        {/* Canonical */}
        <link rel="canonical" href={aboutCanonicalUrl} />

        {/* Schema.org Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(aboutSchemaJsonLd)}
        </script>
      </Helmet>

      {/* Background ambient lighting */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-gradient-to-b from-pink-900/15 via-purple-900/10 to-transparent blur-3xl pointer-events-none -z-10" />

      {/* ========================================================================= */}
      {/* SECTION 1: ABOUT HERO & SINGLE SHOWREEL                                   */}
      {/* ========================================================================= */}
      <section className="relative px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto mb-28">
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs font-mono font-bold tracking-wider text-pink-300 uppercase mb-4"
          >
            <Film className="w-3.5 h-3.5 text-[#FF007A]" />
            <span>DIRECTOR-LED PRODUCTION STUDIO</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.1 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-black text-white font-display tracking-tight leading-[1.1]"
          >
            This Is How We <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF007A] via-[#FF5E62] to-[#FFA07A]">Create</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.2 }}
            className="mt-4 text-base sm:text-lg text-gray-300 max-w-2xl mx-auto leading-relaxed"
          >
            Our master montage reel captures our cinematic range across architectural storytelling, founder personal branding, macro commercial shoots, and luxury dining.
          </motion.p>
        </div>

        {/* Master Showreel Video Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.65, delay: 0.25 }}
          className="relative rounded-3xl overflow-hidden border border-pink-500/30 shadow-[0_0_50px_rgba(255,0,122,0.15)] group bg-[#13061a]"
        >
          <div className="relative aspect-video sm:aspect-[21/9] w-full overflow-hidden">
            <CinematicImage
              src={ABOUT_SHOWREEL.posterUrl}
              alt={ABOUT_SHOWREEL.title}
              containerClassName="absolute inset-0 w-full h-full"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
            />
            {/* Cinematic Gradient Overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#09030e] via-black/40 to-black/20" />
            <div className="absolute inset-0 bg-pink-900/10 mix-blend-overlay" />

            {/* Pulsing Play Trigger */}
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
              <button
                id="btn-play-showreel-hero"
                onClick={() => onSelectReel(masterReelItem)}
                aria-label="Play Studio Master Showreel"
                className="relative group/play flex items-center justify-center cursor-pointer focus:outline-none"
              >
                {/* Outer pulsing ring */}
                <span className="absolute w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-[#FF007A]/30 animate-ping opacity-75" />
                <span className="absolute w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-[#FF007A] to-purple-600 blur-md opacity-80 group-hover/play:opacity-100 transition-opacity" />
                
                {/* Core Play Button */}
                <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-[#FF007A] via-[#FF2E93] to-[#FF5E62] text-white flex items-center justify-center shadow-2xl border-2 border-white/40 group-hover/play:scale-110 transition-transform duration-300">
                  <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-current ml-1 text-white" />
                </div>
              </button>

              <div className="mt-4 text-center">
                <span className="inline-block px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/20 text-xs font-mono font-bold tracking-widest text-pink-300 uppercase">
                  CLICK TO PLAY FULLSCREEN ({ABOUT_SHOWREEL.duration})
                </span>
              </div>
            </div>

            {/* Bottom Metadata Badges */}
            <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-6 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-black/80 backdrop-blur-md border border-pink-500/30 text-xs font-bold text-white">
                  4K DCI Cinema Montage
                </span>
                <span className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-mono text-gray-300 hidden sm:inline-block">
                  DaVinci Resolve Grade
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectReel(masterReelItem);
                  }}
                  className="pointer-events-auto flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-xs font-bold text-white transition-all cursor-pointer"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-pink-400" />
                  <span>Expand Reel</span>
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 2: OUR STORY & MILESTONES TIMELINE                                */}
      {/* ========================================================================= */}
      <section className="py-20 border-t border-white/5 bg-[#0e0416] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            
            {/* Left Column: Founding Story & Philosophy */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-6 space-y-6"
            >
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs font-bold text-pink-400 uppercase tracking-wider">
                OUR PHILOSOPHY & ORIGIN
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display leading-tight">
                {STUDIO_STORY.headline}
              </h2>

              <div className="space-y-4 text-gray-300 text-sm sm:text-base leading-relaxed">
                {STUDIO_STORY.paragraphs.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>

              <div className="p-5 rounded-2xl bg-gradient-to-r from-pink-950/40 to-purple-950/30 border border-pink-500/30 flex items-start gap-4">
                <Quote className="w-6 h-6 text-pink-400 shrink-0 mt-1" />
                <p className="text-xs sm:text-sm text-pink-200 font-medium italic">
                  “We treat every 15-second social cut with the lighting discipline, lens selection, and color calibration of a national commercial campaign.”
                </p>
              </div>
            </motion.div>

            {/* Right Column: Vertical Milestones Timeline */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-6 lg:pl-6"
            >
              <div className="border-b border-white/10 pb-4 mb-8">
                <span className="text-xs font-mono font-bold tracking-widest text-pink-400 uppercase">
                  STUDIO EVOLUTION
                </span>
                <h3 className="text-xl font-bold text-white font-display mt-1">
                  Key Milestones & Growth
                </h3>
              </div>

              <div className="relative pl-8 space-y-10 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-gradient-to-b before:from-[#FF007A] before:via-purple-500 before:to-pink-900">
                {STUDIO_MILESTONES.map((item, idx) => (
                  <motion.div
                    key={item.year}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-40px' }}
                    transition={{ duration: 0.45, delay: idx * 0.1 }}
                    className="relative group"
                  >
                    {/* Glowing Timeline Marker */}
                    <div className="absolute -left-[30px] top-1 w-5 h-5 rounded-full bg-[#100416] border-2 border-[#FF007A] flex items-center justify-center group-hover:scale-125 transition-transform shadow-[0_0_10px_#FF007A]">
                      <div className="w-2 h-2 rounded-full bg-[#FF007A]" />
                    </div>

                    <div className="p-5 rounded-2xl bg-[#14061c] border border-white/10 group-hover:border-pink-500/40 transition-all">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-lg font-black text-pink-400 font-display">
                          {item.year}
                        </span>
                        {item.metric && (
                          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-pink-500/10 text-pink-300 border border-pink-500/20">
                            {item.metric}
                          </span>
                        )}
                      </div>
                      <h4 className="text-base font-bold text-white group-hover:text-pink-100 transition-colors">
                        {item.title}
                      </h4>
                      <p className="text-xs sm:text-sm text-gray-300 mt-1 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 3: WHAT WE DO (CAPABILITIES SHOWCASE WITH AUTOPLAY VIDEO LOOPS)   */}
      {/* ========================================================================= */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs font-bold text-pink-300 uppercase tracking-wider mb-3">
            <Camera className="w-3.5 h-3.5 text-[#FF007A]" />
            <span>FULL-SPECTRUM CINEMA CAPABILITIES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display">
            What We Deliver
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-300">
            Every category is powered by specialized cinema glass, targeted lighting rigs, and category-tuned editing rhythms.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {CAPABILITIES_SHOWCASE.map((cap, idx) => (
            <motion.div
              key={cap.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              whileHover={{ y: -6 }}
              className="group relative rounded-3xl overflow-hidden bg-[#13061a] border border-white/10 hover:border-pink-500/50 shadow-xl transition-all flex flex-col justify-between"
            >
              {/* Autoplay Video Header Layer */}
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-black">
                <AutoplayVideo
                  videoUrl={cap.videoUrl}
                  poster={cap.posterUrl}
                  alt={cap.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#13061a] via-black/20 to-transparent pointer-events-none" />
                
                <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/20 text-[10px] font-mono font-bold uppercase tracking-wider text-pink-300">
                  {cap.tag}
                </span>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <span className="text-xs font-mono text-pink-400 font-semibold uppercase tracking-wider">
                    {cap.category}
                  </span>
                  <h3 className="text-xl font-bold text-white font-display mt-1 group-hover:text-pink-100 transition-colors">
                    {cap.title}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm text-gray-300 leading-relaxed">
                    {cap.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block mb-2">
                    Key Deliverables
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {cap.deliverables.map((item, i) => (
                      <span
                        key={i}
                        className="text-[10px] font-semibold text-gray-300 bg-white/5 border border-white/10 px-2.5 py-1 rounded-full group-hover:border-pink-500/30 transition-colors"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 4: BEHIND THE SCENES GALLERY (HORIZONTAL SCROLL)                  */}
      {/* ========================================================================= */}
      <section className="py-20 border-t border-white/5 bg-[#0b0312] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs font-bold text-pink-300 uppercase tracking-wider mb-2">
              <Layers className="w-3.5 h-3.5 text-[#FF007A]" />
              <span>ON-SET IMMERSION</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
              Behind The Scenes
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-gray-400">
              A look inside our lighting plots, camera rigging, director briefings, and post-production suites.
            </p>
          </div>

          {/* Carousel Arrows */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleScrollBts('left')}
              disabled={!canScrollLeft}
              aria-label="Scroll left in gallery"
              className="p-3 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 disabled:opacity-30 disabled:cursor-not-allowed text-white transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => handleScrollBts('right')}
              disabled={!canScrollRight}
              aria-label="Scroll right in gallery"
              className="p-3 rounded-full bg-[#FF007A]/20 hover:bg-[#FF007A]/30 border border-pink-500/40 disabled:opacity-30 disabled:cursor-not-allowed text-pink-300 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scroll Container */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            ref={btsScrollRef}
            onScroll={checkScroll}
            className="flex gap-6 overflow-x-auto pb-6 scrollbar-none snap-x snap-mandatory"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {BTS_GALLERY.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: '-20px' }}
                transition={{ duration: 0.45, delay: idx * 0.08 }}
                className="w-[300px] sm:w-[380px] shrink-0 snap-start relative rounded-3xl overflow-hidden bg-[#14061c] border border-white/10 hover:border-pink-500/50 group shadow-lg transition-all"
              >
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-black">
                  {item.isVideo ? (
                    <AutoplayVideo
                      videoUrl={item.mediaUrl}
                      poster={item.posterUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <CinematicImage
                      src={item.mediaUrl}
                      alt={item.title}
                      containerClassName="absolute inset-0 w-full h-full"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent opacity-85 group-hover:opacity-95 transition-opacity" />
                  
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md border border-white/20 text-[10px] font-mono font-bold text-pink-400">
                    {item.tag}
                  </span>
                </div>

                <div className="p-5 space-y-1 bg-[#14061c]">
                  <h4 className="text-base font-bold text-white group-hover:text-pink-200 transition-colors">
                    {item.title}
                  </h4>
                  <p className="text-xs text-gray-300 leading-relaxed line-clamp-2">
                    {item.caption}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 5: MEET THE FOUNDER (SINGLE PROMINENT SPOTLIGHT)                 */}
      {/* ========================================================================= */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.6 }}
          className="relative rounded-3xl bg-gradient-to-br from-[#170622] via-[#100318] to-[#1c0729] border border-pink-500/40 p-8 sm:p-12 lg:p-16 shadow-[0_0_60px_rgba(255,0,122,0.12)] overflow-hidden"
        >
          {/* Ambient Glows */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-pink-600/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center relative z-10">
            
            {/* Founder Portrait Frame */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative group w-full max-w-sm">
                {/* Glowing Outline */}
                <div className="absolute -inset-1.5 bg-gradient-to-r from-[#FF007A] via-purple-600 to-[#FF5E62] rounded-3xl blur opacity-75 group-hover:opacity-100 transition duration-500" />
                
                <div className="relative rounded-2xl overflow-hidden aspect-[4/5] bg-black border border-white/20">
                  <CinematicImage
                    src={FOUNDER_PROFILE.photoUrl}
                    alt={FOUNDER_PROFILE.name}
                    containerClassName="absolute inset-0 w-full h-full"
                    className="w-full h-full object-cover grayscale-[15%] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="text-xs font-mono font-bold text-pink-400 uppercase tracking-widest block">
                      {FOUNDER_PROFILE.role}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-black text-white font-display">
                      {FOUNDER_PROFILE.name}
                    </h3>
                  </div>
                </div>
              </div>
            </div>

            {/* Founder Biography & Quote */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs font-bold text-pink-300 uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-[#FF007A]" />
                <span>STUDIO LEADERSHIP</span>
              </div>

              <div>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
                  {FOUNDER_PROFILE.name}
                </h2>
                <p className="text-base text-pink-400 font-medium mt-1">
                  {FOUNDER_PROFILE.title}
                </p>
              </div>

              {/* Personal Statement Quote */}
              <div className="p-5 rounded-2xl bg-black/50 border-l-4 border-[#FF007A] border-y border-r border-white/10">
                <p className="text-sm sm:text-base text-gray-200 italic leading-relaxed">
                  {FOUNDER_PROFILE.quote}
                </p>
              </div>

              {/* Bio Paragraphs */}
              <div className="space-y-3 text-sm sm:text-base text-gray-300 leading-relaxed">
                {FOUNDER_PROFILE.bio.map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>

              {/* Experience Highlights & Socials */}
              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-6">
                  <div>
                    <span className="text-2xl font-black text-white font-display block">
                      {FOUNDER_PROFILE.experienceYears}
                    </span>
                    <span className="text-[11px] text-gray-400 uppercase font-mono">Behind The Lens</span>
                  </div>
                  <div className="w-px h-8 bg-white/10" />
                  <div>
                    <span className="text-2xl font-black text-pink-400 font-display block">
                      {FOUNDER_PROFILE.projectsDirected}
                    </span>
                    <span className="text-[11px] text-gray-400 uppercase font-mono">Films Directed</span>
                  </div>
                </div>

                {/* Social Channels */}
                <div className="flex items-center gap-2.5">
                  <a
                    href={FOUNDER_PROFILE.socialLinks.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Aryan Varma on Instagram"
                    className="p-2.5 rounded-full bg-white/5 hover:bg-pink-500/20 text-gray-300 hover:text-white border border-white/10 hover:border-pink-500/40 transition-colors"
                  >
                    <Instagram className="w-4 h-4" />
                  </a>
                  <a
                    href={FOUNDER_PROFILE.socialLinks.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Aryan Varma on LinkedIn"
                    className="p-2.5 rounded-full bg-white/5 hover:bg-pink-500/20 text-gray-300 hover:text-white border border-white/10 hover:border-pink-500/40 transition-colors"
                  >
                    <Linkedin className="w-4 h-4" />
                  </a>
                  <a
                    href={FOUNDER_PROFILE.socialLinks.email}
                    aria-label="Email Aryan Varma"
                    className="p-2.5 rounded-full bg-white/5 hover:bg-pink-500/20 text-gray-300 hover:text-white border border-white/10 hover:border-pink-500/40 transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                  </a>
                </div>
              </div>

            </div>

          </div>
        </motion.div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 6: OUR PROCESS (LINK, DON'T DUPLICATE)                            */}
      {/* ========================================================================= */}
      <section className="py-16 border-t border-white/5 bg-[#0c0314] relative">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs font-bold text-pink-300 uppercase tracking-wider">
            <Compass className="w-3.5 h-3.5 text-[#FF007A]" />
            <span>HOW WE OPERATE</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            A Frictionless 4-Step Production Blueprint
          </h2>

          <p className="text-sm sm:text-base text-gray-300 max-w-2xl mx-auto leading-relaxed">
            From initial Discovery Brief & Moodboarding to 4K Cinema Shoot and DaVinci Resolve Master Delivery, our standardized workflow guarantees clarity and viral aesthetic execution.
          </p>

          <div className="pt-2">
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
              onClick={handleNavigateToProcess}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer shadow-lg"
            >
              <span>See Full Process Breakdown</span>
              <ArrowRight className="w-4 h-4 text-pink-400" />
            </motion.button>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 6.5: FREQUENTLY ASKED QUESTIONS ACCORDION                         */}
      {/* ========================================================================= */}
      <FAQAccordion
        onOpenBooking={onOpenBooking}
        onOpenCallback={onOpenCallback}
        className="border-t border-white/5 bg-[#09030e]"
      />

      {/* ========================================================================= */}
      {/* SECTION 7: CLOSING CTA                                                    */}
      {/* ========================================================================= */}
      <section className="py-20 relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="rounded-3xl bg-gradient-to-r from-[#20072b] via-[#290a38] to-[#170520] border border-pink-500/40 p-8 sm:p-14 text-center space-y-6 shadow-2xl relative overflow-hidden"
        >
          {/* Ambient Glow */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-pink-500/20 via-transparent to-transparent pointer-events-none" />

          <span className="inline-block text-xs font-mono font-bold tracking-widest text-pink-400 uppercase">
            LET&apos;S CREATE TOGETHER
          </span>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-display max-w-3xl mx-auto leading-tight">
            Ready to give your brand the cinema-grade visual authority it deserves?
          </h2>

          <p className="text-sm sm:text-base text-gray-300 max-w-xl mx-auto">
            Book a 15-minute concept call with our directors to discuss shot lists, creative direction, and shoot scheduling.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.96 }}
              onClick={onOpenBooking}
              className="btn-primary-gradient px-8 py-4 rounded-full text-xs sm:text-sm font-extrabold tracking-wider uppercase text-white shadow-xl shadow-pink-600/30 flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>BOOK A DISCOVERY CALL</span>
            </motion.button>

            {onOpenCallback && (
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={onOpenCallback}
                className="px-6 py-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/20 text-xs sm:text-sm font-bold uppercase tracking-wider text-gray-200 transition-colors cursor-pointer"
              >
                REQUEST INSTANT CALLBACK (15 MIN)
              </motion.button>
            )}
          </div>
        </motion.div>
      </section>

    </div>
  );
};

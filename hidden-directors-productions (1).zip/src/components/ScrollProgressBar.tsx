import React from 'react';
import { motion, useScroll } from 'motion/react';

export const ScrollProgressBar: React.FC = () => {
  const { scrollYProgress } = useScroll();

  return (
    <motion.div
      style={{ scaleX: scrollYProgress }}
      className="fixed top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#FF007A] via-pink-500 to-violet-500 z-[100] origin-left shadow-[0_0_12px_rgba(255,0,122,0.8)] pointer-events-none"
    />
  );
};

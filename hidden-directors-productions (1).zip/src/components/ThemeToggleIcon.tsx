import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface ThemeToggleIconProps {
  theme: 'dark' | 'light';
  size?: number;
  className?: string;
}

/**
 * Animated Theme Toggle Icon (Sun <-> Moon morphing)
 * Uses Framer Motion spring physics, angular momentum, ray retraction,
 * and celestial aura morphing.
 */
export const ThemeToggleIcon: React.FC<ThemeToggleIconProps> = ({ 
  theme, 
  size = 18,
  className = "" 
}) => {
  const isDark = theme === 'dark';

  return (
    <div 
      className={`relative flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <AnimatePresence mode="wait" initial={false}>
        {isDark ? (
          <motion.div
            key="theme-sun"
            initial={{ rotate: -90, scale: 0.2, opacity: 0 }}
            animate={{ rotate: 0, scale: 1, opacity: 1 }}
            exit={{ rotate: 90, scale: 0.2, opacity: 0 }}
            transition={{
              type: 'spring',
              stiffness: 380,
              damping: 22,
              mass: 0.6
            }}
            className="w-full h-full flex items-center justify-center relative"
          >
            {/* Ambient Sun Glow */}
            <motion.div
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 0.4, scale: 1.2 }}
              exit={{ opacity: 0, scale: 0.6 }}
              className="absolute inset-0 rounded-full bg-amber-400 blur-sm pointer-events-none"
            />

            <svg
              width={size}
              height={size}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-amber-300 relative z-10"
            >
              {/* Sun Core Center Orb */}
              <motion.circle
                cx="12"
                cy="12"
                r="4.5"
                fill="currentColor"
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              />

              {/* Radiant Sun Rays with staggered spring emergence */}
              <motion.g
                initial={{ opacity: 0, scale: 0.6 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.25, delay: 0.05 }}
              >
                <line x1="12" y1="1.5" x2="12" y2="4" />
                <line x1="12" y1="20" x2="12" y2="22.5" />
                <line x1="4.22" y1="4.22" x2="5.99" y2="5.99" />
                <line x1="18.01" y1="18.01" x2="19.78" y2="19.78" />
                <line x1="1.5" y1="12" x2="4" y2="12" />
                <line x1="20" y1="12" x2="22.5" y2="12" />
                <line x1="4.22" y1="19.78" x2="5.99" y2="18.01" />
                <line x1="18.01" y1="5.99" x2="19.78" y2="4.22" />
              </motion.g>
            </svg>
          </motion.div>
        ) : (
          <motion.div
            key="theme-moon"
            initial={{ rotate: 90, scale: 0.2, opacity: 0 }}
            animate={{ rotate: 0, scale: 1, opacity: 1 }}
            exit={{ rotate: -90, scale: 0.2, opacity: 0 }}
            transition={{
              type: 'spring',
              stiffness: 380,
              damping: 22,
              mass: 0.6
            }}
            className="w-full h-full flex items-center justify-center relative"
          >
            {/* Ambient Moon Neon Glow */}
            <motion.div
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 0.35, scale: 1.2 }}
              exit={{ opacity: 0, scale: 0.6 }}
              className="absolute inset-0 rounded-full bg-pink-500 blur-sm pointer-events-none"
            />

            <svg
              width={size}
              height={size}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-[#FF007A] relative z-10"
            >
              {/* Crescent Moon Path */}
              <motion.path
                d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"
                fill="currentColor"
                fillOpacity="0.25"
                initial={{ pathLength: 0.3, scale: 0.8 }}
                animate={{ pathLength: 1, scale: 1 }}
                transition={{ type: 'spring', stiffness: 350, damping: 20 }}
              />

              {/* Celestial Star Sparkles */}
              <motion.circle
                cx="18"
                cy="6"
                r="1"
                fill="currentColor"
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: [0, 1.3, 1], opacity: [0, 1, 0.9] }}
                transition={{ delay: 0.15, duration: 0.3 }}
              />
              <motion.circle
                cx="14"
                cy="3"
                r="0.7"
                fill="currentColor"
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: [0, 1.2, 1], opacity: [0, 1, 0.7] }}
                transition={{ delay: 0.22, duration: 0.3 }}
              />
            </svg>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

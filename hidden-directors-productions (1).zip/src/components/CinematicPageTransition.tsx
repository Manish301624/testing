import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLocation } from 'react-router-dom';
import { Film, Sparkles, Camera } from 'lucide-react';
import { prefetchRouteAssets } from '../lib/pageTransitionLoader';
import { LoadingSpinner } from './LoadingSpinner';

interface CinematicPageTransitionProps {
  children: React.ReactNode;
}

export const CinematicPageTransition: React.FC<CinematicPageTransitionProps> = ({ children }) => {
  const location = useLocation();
  const [showShutterOverlay, setShowShutterOverlay] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Map route to cinematic scene identification
  const sceneInfo = useMemo(() => {
    const path = location.pathname;
    if (path === '/') {
      if (location.hash === '#portfolio') return { code: 'TAKE // 02', name: 'PORTFOLIO REEL' };
      if (location.hash === '#personal-branding') return { code: 'TAKE // 03', name: 'PERSONAL BRANDING' };
      if (location.hash === '#blog') return { code: 'TAKE // 04', name: 'EDITORIAL INSIGHTS' };
      return { code: 'TAKE // 01', name: 'HOME OVERVIEW' };
    }
    if (path === '/about') {
      return { code: 'TAKE // 05', name: 'STUDIO & DIRECTORS' };
    }
    if (path === '/blog') {
      return { code: 'TAKE // 06', name: 'INSIGHTS ARCHIVE' };
    }
    if (path.startsWith('/blog/')) {
      return { code: 'TAKE // 07', name: 'PRODUCTION ESSAY' };
    }
    if (path.startsWith('/project/') || path.startsWith('/projects/')) {
      return { code: 'TAKE // 08', name: 'CASE STUDY SHOWCASE' };
    }
    if (path.includes('/photography')) {
      return { code: 'TAKE // 09', name: 'EDITORIAL PHOTOGRAPHY' };
    }
    if (path.includes('/films')) {
      return { code: 'TAKE // 10', name: 'CINEMATIC FILMS' };
    }
    return { code: 'TAKE // 00', name: 'DIRECTOR CUT' };
  }, [location.pathname, location.hash]);

  // Trigger cinematic shutter effect, resource pre-fetching via requestIdleCallback, and scroll reset on route change
  useEffect(() => {
    setShowShutterOverlay(true);
    setIsTransitioning(true);

    // Pre-fetch critical route assets using requestIdleCallback
    prefetchRouteAssets(location.pathname);

    // Scroll to target hash or top
    if (location.hash) {
      const timer = setTimeout(() => {
        const el = document.querySelector(location.hash);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 160);
      const hideTimer = setTimeout(() => {
        setShowShutterOverlay(false);
        setIsTransitioning(false);
      }, 750);
      return () => {
        clearTimeout(timer);
        clearTimeout(hideTimer);
      };
    } else {
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      const hideTimer = setTimeout(() => {
        setShowShutterOverlay(false);
        setIsTransitioning(false);
      }, 750);
      return () => clearTimeout(hideTimer);
    }
  }, [location.pathname, location.hash]);

  return (
    <div className="relative w-full min-h-screen">
      {/* Cinematic Film Shutter Flash Overlay (Simulating 1/48s shutter angle) */}
      <AnimatePresence>
        {isTransitioning && (
          <motion.div
            key={`shutter-${location.pathname}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.35, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 bg-[#050109] pointer-events-none z-40"
          />
        )}
      </AnimatePresence>

      {/* Minimalist High-End Loading Spinner in Center of Viewport during route navigation */}
      <AnimatePresence>
        {isTransitioning && (
          <LoadingSpinner
            key={`route-transition-spinner-${location.pathname}`}
            fullScreen
            size="md"
            className="pointer-events-none !bg-black/40 !backdrop-blur-[2px] z-[90]"
          />
        )}
      </AnimatePresence>

      {/* Cinematic HUD Scene & Camera Slate Badge */}
      <AnimatePresence>
        {showShutterOverlay && (
          <motion.div
            key={`slate-${location.pathname}`}
            initial={{ opacity: 0, y: -16, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-24 right-4 sm:right-8 z-50 pointer-events-none"
          >
            <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/85 border border-pink-500/50 backdrop-blur-md shadow-2xl shadow-black text-[10.5px] font-mono tracking-wider text-gray-200">
              <span className="w-2 h-2 rounded-full bg-[#FF007A] animate-ping shadow-[0_0_8px_#FF007A]" />
              <span className="font-extrabold text-pink-300">{sceneInfo.code}</span>
              <span className="text-gray-600">|</span>
              <span className="text-white font-semibold">{sceneInfo.name}</span>
              <span className="hidden sm:inline text-[9px] text-gray-400 font-mono pl-1 border-l border-white/10">
                24 FPS • 4K DCI
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Anamorphic Lens Flare Light Streak Wipe */}
      <AnimatePresence>
        {showShutterOverlay && (
          <motion.div
            key={`flare-${location.pathname}`}
            initial={{ opacity: 0, scaleX: 0.1, x: '-100%' }}
            animate={{ 
              opacity: [0, 0.9, 0.9, 0], 
              scaleX: [0.2, 1, 1.4, 2.2],
              x: ['-50%', '20%', '80%', '160%']
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-transparent via-[#FF007A] via-pink-400 via-violet-300 to-transparent shadow-[0_0_25px_#FF007A,0_0_50px_rgba(255,0,122,0.9)] z-50 pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Main Animated View Routing Container with Smooth Wait Transition */}
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 12, scale: 0.995, filter: 'blur(4px)' }}
          animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -8, scale: 0.995, filter: 'blur(4px)' }}
          transition={{ 
            duration: 0.36, 
            ease: [0.22, 1, 0.36, 1] 
          }}
          className="w-full will-change-[transform,opacity,filter]"
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

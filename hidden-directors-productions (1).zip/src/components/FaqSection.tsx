import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HelpCircle, ChevronDown, Sparkles, MessageCircle, ArrowRight, Video, Calendar, ShieldCheck, Clock, Zap, MessageSquare } from 'lucide-react';
import { buildWhatsAppUrl, getInitialWhatsAppNumber, getContextualWhatsAppMessage, fetchConfiguredWhatsAppNumber } from '../utils/whatsapp';

interface FaqItem {
  id: string;
  category: 'production' | 'booking' | 'retainer' | 'licensing';
  question: string;
  answer: string;
  highlights?: string[];
}

const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'production',
    question: 'How does your production timeline work from concept to final cut?',
    answer:
      'Our standard turnaround is 7–10 business days for commercial short-form reels. From the moment we complete your discovery strategy call, our creative directors script viral hooks (Days 1–3), film on cinema RED/ARRI/Sony FX rigs with cinematic lighting (Days 4–5), and perform dynamic color grading, sound design, and motion subtitles (Days 6–8) before client review.',
    highlights: ['7-10 days standard turnaround', 'Cinema RED & Sony FX cameras', 'Complete sound & color grading included']
  },
  {
    id: 'faq-2',
    category: 'booking',
    question: 'How do I book a consultation and prepare for our strategy call?',
    answer:
      'Click "Book a Strategy Call" anywhere on the site. You can select your industry, target timeline, and budget tier—or use our hands-free voice dictation to speak your concept directly into the brief. Our executive director will review your brand identity and email you a tailored pitch with availability within 24 hours.',
    highlights: ['24-hour response guarantee', 'Voice-to-text brief support', '15-min discovery call']
  },
  {
    id: 'faq-3',
    category: 'retainer',
    question: 'What is included in a monthly content retainer package?',
    answer:
      'Our monthly retainers are designed for scaling luxury, lifestyle, and high-growth brands. Retainers include dedicated monthly shoot days, 8 to 20 polished reels/commercials, prioritized 5-day rush editing, dynamic creative iteration based on performance metrics, and 20–30% cost savings compared to one-off shoots.',
    highlights: ['8-20 reels per month', 'Dedicated monthly shoot days', '5-day priority rush turnaround']
  },
  {
    id: 'faq-4',
    category: 'production',
    question: 'Do you provide casting for actors, voice talent, and studio locations?',
    answer:
      'Yes, we handle complete end-to-end production logistics. We source and vet professional commercial models, brand presenters, voiceover artists, and secure high-end architectural villas, luxury apartments, and boutique studio sets across major creative hubs.',
    highlights: ['Full model/actor casting', 'Luxury location scouting', 'Props & styling coordination']
  },
  {
    id: 'faq-5',
    category: 'licensing',
    question: 'What formats do you deliver and who owns the commercial rights?',
    answer:
      'You receive full, perpetual worldwide commercial rights for digital advertising, paid media, organic social, and website usage upon final sign-off. We deliver master ProRes & H.264 exports formatted in 9:16 vertical (Reels/TikTok/Shorts), 1:1 square, and 16:9 widescreen 4K.',
    highlights: ['100% Perpetual commercial rights', '4K master exports in 9:16 & 16:9', 'Clean versions without subtitles included']
  },
  {
    id: 'faq-6',
    category: 'booking',
    question: 'What is your revision and creative satisfaction policy?',
    answer:
      'Every project includes 2 complimentary revision rounds for color grading, sound mixing, text animations, and pacing adjustments via timestamped Frame.io links. We work closely until the final cut matches your exact aesthetic standards.',
    highlights: ['2 complimentary revision rounds', 'Frame.io timestamped feedback', 'Dedicated post-producer']
  }
];

interface FaqSectionProps {
  onOpenBooking: () => void;
  isLoading?: boolean;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ onOpenBooking, isLoading = false }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [openFaqId, setOpenFaqId] = useState<string | null>('faq-1');
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);

  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) setWhatsappNumber(num);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const categories = [
    { key: 'all', label: 'All Questions' },
    { key: 'production', label: 'Production & Rigs' },
    { key: 'booking', label: 'Booking & Strategy' },
    { key: 'retainer', label: 'Monthly Retainers' },
    { key: 'licensing', label: 'Rights & Formats' },
  ];

  const filteredFaqs = activeCategory === 'all'
    ? FAQ_ITEMS
    : FAQ_ITEMS.filter((item) => item.category === activeCategory);

  const toggleFaq = (id: string) => {
    setOpenFaqId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="faq" className="py-24 sm:py-32 bg-[#0c0413] relative overflow-hidden border-t border-white/5">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-[#FF007A]/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute bottom-10 -right-32 w-96 h-96 bg-purple-600/10 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.55, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="text-center max-w-2xl mx-auto mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-pink-500/10 border border-pink-500/20 text-[#FF007A] text-xs font-bold uppercase tracking-widest mb-4">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Frequently Asked Questions</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight leading-tight">
            Everything You Need <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF007A] via-[#FF2E93] to-purple-400">
              To Know Before Shooting
            </span>
          </h2>

          <p className="mt-4 text-gray-400 text-sm sm:text-base leading-relaxed">
            Clear answers about our cinematic production turnaround, pricing retainers, casting logistics, and worldwide licensing.
          </p>

          {/* Category Filter Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => {
                  setActiveCategory(cat.key);
                  setOpenFaqId(null);
                }}
                className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeCategory === cat.key
                    ? 'bg-gradient-to-r from-[#FF007A] to-purple-600 text-white shadow-lg shadow-pink-500/25 scale-105'
                    : 'bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/5'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Accordion FAQ Container */}
        <div className="space-y-4 max-w-3xl mx-auto">
          {isLoading ? (
            // Skeleton Loading State for FAQ Accordion Items
            Array.from({ length: 5 }).map((_, idx) => (
              <div
                key={`faq-skeleton-${idx}`}
                className="rounded-2xl bg-[#13051a]/80 border border-white/10 p-5 sm:p-6 animate-pulse"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3.5 flex-1 pr-4">
                    <div className="w-7 h-7 rounded-full bg-pink-500/15 border border-pink-500/20 shrink-0" />
                    <div className="space-y-1.5 flex-1 max-w-lg">
                      <div className="h-4 rounded bg-white/15 w-4/5" />
                      {idx === 0 && <div className="h-3 rounded bg-white/5 w-1/2 mt-1" />}
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-white/5 shrink-0" />
                </div>
              </div>
            ))
          ) : (
            filteredFaqs.map((faq, index) => {
              const isOpen = openFaqId === faq.id;

              return (
                <motion.div
                  key={faq.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-30px' }}
                  transition={{ duration: 0.45, delay: (index % 6) * 0.08, ease: [0.21, 0.45, 0.27, 0.9] }}
                  className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
                    isOpen
                      ? 'bg-[#180720] border-pink-500/40 shadow-[0_4px_30px_rgba(255,0,122,0.15)]'
                      : 'bg-[#13051a]/80 hover:bg-[#16061e] border-white/10'
                  }`}
                >
                  {/* Trigger Button */}
                  <button
                    type="button"
                    onClick={() => toggleFaq(faq.id)}
                    aria-expanded={isOpen}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left cursor-pointer focus:outline-none select-none"
                  >
                    <div className="flex items-center gap-3.5 pr-4">
                      <span className="flex-shrink-0 w-7 h-7 rounded-full bg-pink-500/10 border border-pink-500/20 text-[#FF007A] text-xs font-bold flex items-center justify-center font-mono">
                        0{index + 1}
                      </span>
                      <span className="text-base sm:text-lg font-bold text-white leading-snug">
                        {faq.question}
                      </span>
                    </div>

                    <motion.div
                      animate={{ rotate: isOpen ? 180 : 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                      className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                        isOpen ? 'bg-[#FF007A]/20 text-[#FF007A]' : 'bg-white/5 text-gray-400'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </motion.div>
                  </button>

                  {/* Collapsible Content */}
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        key={`content-${faq.id}`}
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                      >
                        <div className="px-5 sm:px-6 pb-6 pt-1 text-sm text-gray-300 leading-relaxed border-t border-white/5 mt-1">
                          <p>{faq.answer}</p>

                          {faq.highlights && faq.highlights.length > 0 && (
                            <div className="mt-4 pt-3 border-t border-white/5 flex flex-wrap gap-2">
                              {faq.highlights.map((highlight, hIdx) => (
                                <span
                                  key={hIdx}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-pink-500/10 border border-pink-500/20 text-pink-300 text-xs font-medium"
                                >
                                  <Zap className="w-3 h-3 text-[#FF007A]" />
                                  <span>{highlight}</span>
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })
          )}
        </div>

        {/* Bottom CTA Card */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.55, delay: 0.15, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="mt-14 max-w-3xl mx-auto rounded-3xl bg-gradient-to-r from-[#1d0727] via-[#14061a] to-[#1d0727] border border-pink-500/20 p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl shadow-pink-500/5"
        >
          <div className="space-y-1 text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-pink-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Still Have Questions?</span>
            </div>
            <h4 className="text-xl font-extrabold text-white">
              Speak directly with our Executive Producer
            </h4>
            <p className="text-xs sm:text-sm text-gray-400 max-w-md">
              Schedule a 15-minute consultation to discuss your custom creative vision, script ideas, and timeline.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href={buildWhatsAppUrl(
                whatsappNumber,
                getContextualWhatsAppMessage('faq')
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-3.5 rounded-full border border-[#25D366]/40 bg-[#0e2418]/80 hover:bg-[#133623] text-emerald-300 hover:text-white text-xs font-extrabold tracking-wider uppercase flex items-center gap-2 shadow-lg shadow-emerald-950/40 cursor-pointer whitespace-nowrap transition-all group/wacta"
            >
              <span className="w-2 h-2 rounded-full bg-[#25D366] group-hover/wacta:scale-125 transition-transform" />
              <span>Ask on WhatsApp</span>
            </a>

            <button
              onClick={onOpenBooking}
              className="btn-primary-gradient px-7 py-3.5 rounded-full text-xs font-extrabold tracking-wider uppercase flex items-center gap-2 shadow-lg shadow-pink-500/25 cursor-pointer whitespace-nowrap group hover:scale-105 transition-all"
            >
              <span>Book A Strategy Call</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </motion.div>

      </div>
    </section>
  );
};

export default FaqSection;

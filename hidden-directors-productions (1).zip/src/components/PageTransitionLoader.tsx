import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { prefetchRouteAssets } from '../lib/pageTransitionLoader';

export const PageTransitionLoader: React.FC = () => {
  const location = useLocation();

  useEffect(() => {
    // Utilize browser's requestIdleCallback to pre-fetch critical assets (hero images, fonts)
    // for the upcoming route before navigation transition completes
    prefetchRouteAssets(location.pathname);
  }, [location.pathname]);

  return null;
};

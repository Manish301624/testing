import React, { useEffect, useCallback, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  MapPin, 
  Camera, 
  Calendar, 
  Info, 
  Maximize2, 
  Minimize2, 
  Share2, 
  Check, 
  Sparkles,
  CalendarCheck
} from 'lucide-react';
import { WorkPhotoItem } from '../types';
import { backdropBlurIn } from '../utils/motionVariants';

interface PhotographyLightboxProps {
  photos: WorkPhotoItem[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (newIndex: number) => void;
  onOpenBooking: () => void;
  categoryName: string;
}

export const PhotographyLightbox: React.FC<PhotographyLightboxProps> = ({
  photos,
  currentIndex,
  isOpen,
  onClose,
  onNavigate,
  onOpenBooking,
  categoryName
}) => {
  const [showInfo, setShowInfo] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [isZoomed, setIsZoomed] = useState<boolean>(false);
  const [touchStart, setTouchStart] = useState<number | null>(null);

  const currentPhoto = photos[currentIndex];

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      onNavigate(currentIndex - 1);
    } else {
      onNavigate(photos.length - 1); // Loop to last
    }
  }, [currentIndex, photos.length, onNavigate]);

  const handleNext = useCallback(() => {
    if (currentIndex < photos.length - 1) {
      onNavigate(currentIndex + 1);
    } else {
      onNavigate(0); // Loop to first
    }
  }, [currentIndex, photos.length, onNavigate]);

  // Keyboard navigation: ESC to close, Arrow keys to navigate
  useEffect(() => {
    if (!isOpen) {
      document.body.style.overflow = '';
      return;
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === 'i' || e.key === 'I') {
        setShowInfo(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    // Lock background body scroll while lightbox is open
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, handlePrev, handleNext, onClose]);

  // Touch gesture listeners for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.touches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStart === null) return;
    const touchEnd = e.changedTouches[0].clientX;
    const diff = touchStart - touchEnd;
    // 50px threshold for swipe detection
    if (diff > 50) {
      handleNext();
    } else if (diff < -50) {
      handlePrev();
    }
    setTouchStart(null);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && currentPhoto && (
        <motion.div
          id="photography-lightbox-backdrop"
          variants={backdropBlurIn}
          initial="hidden"
          animate="visible"
          exit="exit"
          className="fixed inset-0 z-50 bg-[#060209]/92 flex flex-col justify-between select-none"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {/* Top Header Bar */}
        <div className="relative z-20 flex items-center justify-between px-4 sm:px-8 py-4 border-b border-white/10 bg-[#09030e]/80 backdrop-blur-md">
          <div className="flex items-center gap-3 sm:gap-4">
            <span className="text-xs font-mono uppercase tracking-wider text-pink-400 font-bold">
              {categoryName}
            </span>
            <span className="text-gray-600 hidden sm:inline">|</span>
            <div className="px-2.5 py-0.5 rounded-full bg-white/10 text-white text-xs font-mono font-medium">
              {currentIndex + 1} / {photos.length}
            </div>
            <span className="hidden md:inline-block text-xs text-gray-400 capitalize px-2 py-0.5 rounded bg-white/5 border border-white/10">
              {currentPhoto.type}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Toggle Details Info */}
            <button
              onClick={() => setShowInfo(!showInfo)}
              aria-label="Toggle photo metadata"
              className={`p-2 rounded-full border transition-all cursor-pointer ${
                showInfo 
                  ? 'bg-pink-500/20 text-pink-300 border-pink-500/40' 
                  : 'bg-white/5 text-gray-400 hover:text-white border-white/10'
              }`}
              title="Toggle photo details (Press 'I')"
            >
              <Info className="w-4 h-4" />
            </button>

            {/* Toggle Zoom */}
            <button
              onClick={() => setIsZoomed(!isZoomed)}
              aria-label="Toggle zoom scale"
              className="p-2 rounded-full bg-white/5 text-gray-400 hover:text-white border border-white/10 hover:border-white/20 transition-all cursor-pointer hidden sm:flex"
              title={isZoomed ? 'Reset zoom' : 'Fit / Fill'}
            >
              {isZoomed ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Share link */}
            <button
              onClick={handleShare}
              aria-label="Share photo"
              className="p-2 rounded-full bg-white/5 text-gray-400 hover:text-white border border-white/10 hover:border-white/20 transition-all cursor-pointer"
              title="Copy link"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>

            {/* Close Button */}
            <button
              id="lightbox-close-btn"
              onClick={onClose}
              aria-label="Close Lightbox (ESC)"
              className="p-2 rounded-full bg-white/10 hover:bg-pink-600/30 text-white border border-white/20 hover:border-pink-500/40 transition-all ml-2 cursor-pointer group"
              title="Close (ESC)"
            >
              <X className="w-5 h-5 group-hover:rotate-90 transition-transform duration-200" />
            </button>
          </div>
        </div>

        {/* Center Main Image Canvas */}
        <div className="relative flex-1 flex items-center justify-center p-3 sm:p-6 overflow-hidden">
          {/* Previous Arrow Button */}
          <button
            id="lightbox-prev-btn"
            onClick={(e) => {
              e.stopPropagation();
              handlePrev();
            }}
            aria-label="Previous photo"
            className="absolute left-3 sm:left-6 z-30 p-3 sm:p-4 rounded-full bg-black/50 hover:bg-[#FF007A]/40 text-white/80 hover:text-white border border-white/10 hover:border-[#FF007A]/50 backdrop-blur-md transition-all shadow-xl hover:scale-110 active:scale-95 cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          {/* Active Photo with Motion Transition and Drag-to-Swipe */}
          <div className="relative max-w-full max-h-full flex items-center justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentPhoto.id}
                layoutId={`card-${currentPhoto.id}`}
                initial={{ opacity: 0, scale: 0.96, x: 20 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.96, x: -20 }}
                transition={{ duration: 0.24, ease: 'easeOut' }}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.2}
                onDragEnd={(_, info) => {
                  if (info.offset.x < -60 || info.velocity.x < -300) {
                    handleNext();
                  } else if (info.offset.x > 60 || info.velocity.x > 300) {
                    handlePrev();
                  }
                }}
                className={`relative cursor-grab active:cursor-grabbing flex items-center justify-center ${
                  isZoomed ? 'max-w-none' : 'max-w-[92vw] max-h-[75vh]'
                }`}
              >
                <motion.img
                  layoutId={`img-${currentPhoto.id}`}
                  src={currentPhoto.imageUrl}
                  alt={currentPhoto.title}
                  draggable={false}
                  className={`rounded-xl object-contain shadow-2xl shadow-black/80 border border-white/10 transition-all duration-300 ${
                    isZoomed ? 'max-h-[90vh] scale-105' : 'max-h-[75vh] w-auto max-w-[90vw]'
                  }`}
                />
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Next Arrow Button */}
          <button
            id="lightbox-next-btn"
            onClick={(e) => {
              e.stopPropagation();
              handleNext();
            }}
            aria-label="Next photo"
            className="absolute right-3 sm:right-6 z-30 p-3 sm:p-4 rounded-full bg-black/50 hover:bg-[#FF007A]/40 text-white/80 hover:text-white border border-white/10 hover:border-[#FF007A]/50 backdrop-blur-md transition-all shadow-xl hover:scale-110 active:scale-95 cursor-pointer"
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        </div>

        {/* Bottom Details Bar & Inquiry Action */}
        <AnimatePresence>
          {showInfo && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
              transition={{ duration: 0.2 }}
              className="relative z-20 bg-[#0c0413]/95 border-t border-white/10 px-4 sm:px-8 py-3.5 backdrop-blur-xl"
            >
              <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">
                      {currentPhoto.title}
                    </h2>
                    <span className="text-gray-500 text-xs hidden sm:inline">•</span>
                    <span className="text-xs sm:text-sm font-semibold text-pink-400">
                      {currentPhoto.client}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 sm:gap-4 text-[11px] sm:text-xs text-gray-400 flex-wrap">
                    {currentPhoto.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-pink-400/80" />
                        <span>{currentPhoto.location}</span>
                      </span>
                    )}
                    {currentPhoto.camera && (
                      <span className="flex items-center gap-1 font-mono">
                        <Camera className="w-3 h-3 text-pink-400/80" />
                        <span>{currentPhoto.camera}</span>
                      </span>
                    )}
                    {currentPhoto.year && (
                      <span className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3 text-pink-400/80" />
                        <span>{currentPhoto.year}</span>
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenBooking();
                    }}
                    id="lightbox-book-aesthetic-btn"
                    className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold text-white bg-gradient-to-r from-[#FF007A] to-[#D60065] hover:opacity-95 shadow-md shadow-pink-600/30 transition-all cursor-pointer shrink-0"
                  >
                    <CalendarCheck className="w-3.5 h-3.5" />
                    <span>Book This Style</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
      )}
    </AnimatePresence>
  );
};

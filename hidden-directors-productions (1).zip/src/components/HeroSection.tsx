import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Volume2, Sparkles, ArrowRight, Heart, LayoutGrid, MoveVertical, PhoneCall } from 'lucide-react';
import { ReelItem } from '../types';
import { VerticalVideoCarousel, DEFAULT_COLUMNS_DATA, VideoCardData } from './VerticalVideoCarousel';
import { useLanguage } from '../context/LanguageContext';

interface HeroSectionProps {
  reels: ReelItem[];
  onSelectReel: (reel: ReelItem) => void;
  onOpenBooking: () => void;
  onExploreWork: () => void;
  onOpenCallback?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  reels,
  onSelectReel,
  onOpenBooking,
  onExploreWork,
  onOpenCallback,
}) => {
  const [viewMode, setViewMode] = useState<'marquee' | 'grid'>('marquee');
  const [unmutedReelId, setUnmutedReelId] = useState<string | null>(null);
  const [hoveredReelId, setHoveredReelId] = useState<string | null>(null);
  const { language } = useLanguage();

  const toggleSound = (e: React.MouseEvent, reelId: string) => {
    e.stopPropagation();
    setUnmutedReelId((prev) => (prev === reelId ? null : reelId));
  };

  const handleMarqueeCardClick = (card: VideoCardData) => {
    const matchedReel = reels.find(
      (r) =>
        r.client.toLowerCase().includes(card.category.toLowerCase()) ||
        r.title.toLowerCase() === card.title.toLowerCase()
    );
    if (matchedReel) {
      onSelectReel(matchedReel);
    } else {
      const validCategories = ['interior', 'salon', 'product', 'fashion', 'branding', 'commercial'] as const;
      const lowerCat = card.category.toLowerCase();
      const matchedCat = validCategories.find(c => lowerCat.includes(c)) || 'commercial';

      onSelectReel({
        id: card.id || 'custom-card',
        client: card.category,
        title: card.title,
        videoUrl: card.videoUrl,
        posterUrl: card.posterUrl || '',
        category: matchedCat,
        views: '150K',
        likes: 12400,
        tags: ['#Featured', '#Cinematic'],
        description: `Visual production crafted for ${card.category}.`
      });
    }
  };

  return (
    <section id="home" className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden">
      {/* Ambient background glow matching Screenshot */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-hero-glow pointer-events-none -z-10" />
      <div className="absolute top-40 right-10 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-20 left-10 w-96 h-96 bg-purple-900/15 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Center Pill Badge */}
        <div className="flex justify-center mb-6">
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            id="hero-welcome-badge"
            className="inline-flex items-center px-4 py-1.5 rounded-full border border-pink-500/40 bg-[#160620]/80 shadow-[0_0_15px_rgba(255,0,122,0.15)] text-[11px] sm:text-xs font-semibold tracking-wider text-gray-200 uppercase"
          >
            {language === 'es' ? 'BIENVENIDO A HIDDEN DIRECTORS' : 'WELCOME TO HIDDEN DIRECTORS'}
          </motion.div>
        </div>

        {/* Hero Headline */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-center max-w-4xl mx-auto"
        >
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-white font-display leading-[1.12]">
            {language === 'es' ? (
              <>
                Visuales Que Definen Tu <span className="text-[#FF2A85]">Marca</span>
                <br />
                <span className="text-[#FF2A85]">Historia y Producto</span>
              </>
            ) : (
              <>
                Visuals That Define Your <span className="text-[#FF2A85]">Brand</span>
                <br />
                <span className="text-[#FF2A85]">Story Product</span>
              </>
            )}
          </h1>

          {/* Subtitle description */}
          <p className="mt-6 text-sm sm:text-base md:text-lg text-gray-300 font-normal leading-relaxed max-w-3xl mx-auto">
            {language === 'es'
              ? 'Creamos contenido visual de alta gama mediante rodajes cuidadosamente planificados y ejecutados. Desde comprender la visión de la marca hasta capturar los detalles, la atmósfera y la composición adecuados, nuestro trabajo se enfoca en presentar cada proyecto de forma premium, consistente y memorable.'
              : 'We create high-quality visual content through carefully planned and executed shoots. From understanding the brand’s vision to capturing the right details, mood and composition, our work focuses on presenting each project in a way that feels premium, consistent and noticeable.'}
          </p>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <motion.button
              id="hero-get-started-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.96 }}
              onClick={onOpenBooking}
              className="btn-primary-gradient px-8 py-3.5 rounded-full text-xs sm:text-sm font-bold tracking-wider text-white uppercase shadow-xl shadow-pink-600/30 cursor-pointer"
            >
              {language === 'es' ? 'COMENZAR PROYECTO' : 'GET STARTED'}
            </motion.button>

            <motion.button
              id="hero-explore-work-btn"
              whileHover={{ scale: 1.05, backgroundColor: 'rgba(255, 255, 255, 0.08)' }}
              whileTap={{ scale: 0.96 }}
              onClick={onExploreWork}
              className="px-7 py-3.5 rounded-full border border-pink-500/40 bg-[#14061a]/70 hover:border-pink-400 text-xs sm:text-sm font-semibold text-gray-200 hover:text-white flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-black/40"
            >
              <Sparkles className="w-4 h-4 text-pink-400" />
              <span>{language === 'es' ? 'EXPLORAR TRABAJOS' : 'EXPLORE OUR WORK'}</span>
            </motion.button>

            {onOpenCallback && (
              <motion.button
                id="hero-instant-callback-btn"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.96 }}
                onClick={onOpenCallback}
                className="px-7 py-3.5 rounded-full border border-pink-500/40 bg-[#190623]/80 hover:bg-[#250933] text-xs sm:text-sm font-semibold text-white flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-pink-950/40 group"
              >
                <PhoneCall className="w-4 h-4 text-[#FF007A] group-hover:rotate-12 transition-transform" />
                <span>{language === 'es' ? 'LLAMADA RÁPIDA (15 MIN)' : 'REQUEST INSTANT CALLBACK'}</span>
              </motion.button>
            )}
          </div>
        </motion.div>
      </div>

      {/* Premium Cinematic Featured Work Carousel Section */}
      <div className="mt-16 sm:mt-24 w-full">
        {/* Conditional Display: Auto-scrolling Vertical Carousel OR Static Grid */}
        {viewMode === 'marquee' ? (
          <VerticalVideoCarousel
            columns={DEFAULT_COLUMNS_DATA}
            onCardClick={handleMarqueeCardClick}
            onCtaClick={onExploreWork}
            ctaLabel={language === 'es' ? 'VER PORTAFOLIO' : 'EXPLORE ALL WORK'}
            heading={language === 'es' ? 'TRABAJOS DESTACADOS' : 'FEATURED WORK'}
            subheading={language === 'es' ? 'COMISIONES SELECCIONADAS // ARCHIVO 2026' : 'SELECTED COMMISSIONS // ARCHIVE 2026'}
            headerRight={
              <div className="flex items-center bg-white/5 p-1 rounded-full border border-white/10 text-xs">
                <button
                  onClick={() => setViewMode('marquee')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full font-bold uppercase tracking-wide text-[11px] transition-all cursor-pointer bg-[#FF2D78] text-white shadow-sm"
                >
                  <MoveVertical className="w-3.5 h-3.5" />
                  <span>{language === 'es' ? 'Desplazamiento' : 'Auto Scroll'}</span>
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full font-bold uppercase tracking-wide text-[11px] transition-all cursor-pointer text-gray-400 hover:text-white"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span>{language === 'es' ? 'Cuadrícula' : 'Grid View'}</span>
                </button>
              </div>
            }
          />
        ) : (
          <div className="w-full bg-[#0a0a0a] py-20 sm:py-28 px-4 sm:px-6 lg:px-8 border-t border-white/10">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-16">
                <div>
                  <div className="flex items-center gap-2.5 mb-3">
                    <span className="w-2 h-2 rounded-full bg-[#FF2D78] shadow-[0_0_8px_#FF2D78]" />
                    <span className="text-xs sm:text-sm font-bold uppercase tracking-wide text-gray-400">
                      {language === 'es' ? 'VISTA EN CUADRÍCULA // ARCHIVO' : 'GRID ARCHIVE // 2026'}
                    </span>
                  </div>
                  <h2 className="text-5xl sm:text-7xl lg:text-8xl font-black uppercase tracking-tight text-white leading-[0.9] font-['Bebas_Neue',sans-serif]">
                    {language === 'es' ? 'TRABAJOS DESTACADOS' : 'FEATURED WORK'}
                  </h2>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center bg-white/5 p-1 rounded-full border border-white/10 text-xs">
                    <button
                      onClick={() => setViewMode('marquee')}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full font-bold uppercase tracking-wide text-[11px] transition-all cursor-pointer text-gray-400 hover:text-white"
                    >
                      <MoveVertical className="w-3.5 h-3.5" />
                      <span>{language === 'es' ? 'Desplazamiento' : 'Auto Scroll'}</span>
                    </button>
                    <button
                      onClick={() => setViewMode('grid')}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full font-bold uppercase tracking-wide text-[11px] transition-all cursor-pointer bg-[#FF2D78] text-white shadow-sm"
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                      <span>{language === 'es' ? 'Cuadrícula' : 'Grid View'}</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 md:gap-5">
                {reels.map((reel, index) => {
                  const isUnmuted = unmutedReelId === reel.id;

                  return (
                    <motion.div
                      key={reel.id}
                      id={`reel-card-${reel.id}`}
                      initial={{ opacity: 0, y: 24 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.15 + index * 0.08 }}
                      whileHover={{ y: -6 }}
                      onMouseEnter={() => setHoveredReelId(reel.id)}
                      onMouseLeave={() => setHoveredReelId(null)}
                      onClick={() => onSelectReel(reel)}
                      className="group relative aspect-[3/4] rounded-[16px] overflow-hidden bg-[#111111] border border-white/10 hover:border-white/25 shadow-2xl shadow-black/80 transition-all duration-300 cursor-pointer"
                    >
                      {/* Background Video */}
                      <video
                        src={reel.videoUrl}
                        poster={reel.posterUrl}
                        autoPlay
                        loop
                        muted={!isUnmuted}
                        playsInline
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />

                      {/* Gradient Overlay: darkens on hover */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/85 to-transparent opacity-80 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

                      {/* Top Unmute Button in Grid mode */}
                      <div className="absolute top-3 left-0 right-0 flex justify-center z-20">
                        <button
                          id={`unmute-btn-${reel.id}`}
                          onClick={(e) => toggleSound(e, reel.id)}
                          className={`flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide transition-all shadow-md ${
                            isUnmuted
                              ? 'bg-[#FF2D78] text-white shadow-[#FF2D78]/40'
                              : 'bg-black/80 hover:bg-black text-white border border-white/20'
                          }`}
                          title={isUnmuted ? 'Mute Audio' : 'Unmute Audio'}
                        >
                          {isUnmuted ? (
                            <>
                              <Volume2 className="w-3 h-3" />
                              <span>Mute</span>
                            </>
                          ) : (
                            <>
                              <span>Unmute</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* Cinematic Viewfinder Corner Brackets on Hover */}
                      <div className="absolute inset-2 border border-white/0 group-hover:border-white/10 rounded-[12px] pointer-events-none z-20 transition-all duration-300">
                        <div className="absolute top-1 left-1 w-2.5 h-2.5 border-t border-l border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        <div className="absolute top-1 right-1 w-2.5 h-2.5 border-t border-r border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        <div className="absolute bottom-1 left-1 w-2.5 h-2.5 border-b border-l border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        <div className="absolute bottom-1 right-1 w-2.5 h-2.5 border-b border-r border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      </div>

                      {/* Technical Metadata Production Tooltip / HUD Overlay on Hover */}
                      <div className="absolute top-12 inset-x-2.5 z-30 opacity-0 group-hover:opacity-100 translate-y-[-4px] group-hover:translate-y-0 transition-all duration-300 pointer-events-none">
                        <div className="bg-black/92 backdrop-blur-md border border-white/20 rounded-xl p-2.5 shadow-2xl shadow-black/90">
                          {/* Header Row: Spec Badge & 4K Resolution */}
                          <div className="flex items-center justify-between border-b border-white/10 pb-1.5 mb-1.5">
                            <div className="flex items-center gap-1.5">
                              <span className="relative flex h-1.5 w-1.5">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF2D78] opacity-75" />
                                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#FF2D78]" />
                              </span>
                              <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-gray-300">
                                PROD SPECS
                              </span>
                            </div>
                            <span className="text-[9px] font-mono font-extrabold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-500/30 tracking-tight">
                              {reel.resolution || '4K UHD'}
                            </span>
                          </div>

                          {/* Technical Specs: Duration & Client Type */}
                          <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px]">
                            <div>
                              <div className="text-[8px] font-mono uppercase text-gray-400 tracking-wider">Duration</div>
                              <div className="font-mono font-bold text-white flex items-center gap-1">
                                <span>{reel.duration || '0:20'}</span>
                              </div>
                            </div>
                            <div>
                              <div className="text-[8px] font-mono uppercase text-gray-400 tracking-wider">Client Type</div>
                              <div className="font-semibold text-gray-200 truncate" title={reel.clientType || reel.category}>
                                {reel.clientType || reel.category}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Reel Card Bottom Info */}
                      <div className="absolute bottom-0 left-0 right-0 p-3.5 z-10">
                        <p className="text-[10px] sm:text-[11px] font-extrabold text-[#FF2D78] uppercase tracking-wide truncate">
                          {reel.client}
                        </p>
                        <p className="relative inline-block text-xs sm:text-[13px] font-semibold text-white truncate mt-0.5 max-w-full">
                          <span className="relative inline-block max-w-full truncate">
                            <span className="truncate">{reel.title}</span>
                            {/* Subtle underline animation drawing in from left to right */}
                            <span className="absolute left-0 -bottom-0.5 h-[1.5px] w-full bg-[#FF2D78] rounded-full origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ease-out pointer-events-none" />
                          </span>
                        </p>
                        
                        <div className="flex items-center justify-between text-[10px] text-gray-400 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="flex items-center gap-1">
                            <Heart className="w-3 h-3 text-[#FF2D78] fill-[#FF2D78]" />
                            {reel.likes.toLocaleString()}
                          </span>
                          <span className="text-gray-300 font-medium tracking-wide">Watch ↗</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

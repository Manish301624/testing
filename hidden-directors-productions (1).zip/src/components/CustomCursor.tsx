import React, { useEffect, useState, useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform, useReducedMotion, AnimatePresence } from 'motion/react';

export type CursorMode = 'default' | 'view' | 'play' | 'magnetic' | 'link' | 'drag';

/**
 * 📸 Camera Viewfinder Custom Cursor
 * 
 * 1. Dual-Spring System:
 *    - Position Spring: `followerX`/`followerY` track the mouse position with a trailing, 
 *      fluid delay to create a cinematic feel.
 *    - Focus-Lock Spring: `smoothFocus` tracks a state value (0 = default, 1 = hover, 2 = click). 
 *      We map this spring to the `bracketOffset` using `useTransform`, creating a snappy, 
 *      camera-autofocus style physical bracket movement independently of the position physics.
 * 
 * 2. Data-Cursor Attribute System:
 *    - Add `data-cursor="view"` to gallery cards, `data-cursor="play"` to video elements.
 *    - Add `data-cursor="magnetic"` to CTA buttons (like "Book a Call"). 
 *    - Add `data-cursor="link"` to standard links (fallback).
 *    - The cursor automatically detects these via `e.target.closest('[data-cursor]')`.
 * 
 * 3. Examples of Wiring:
 *    - PhotographyGalleryPage.tsx (Image Card):
 *      <motion.div data-cursor="view" onClick={...} className="card"> ... </motion.div>
 *    
 *    - HomePage.tsx (Video Reel Card):
 *      <div data-cursor="play" onClick={...}> <video src="..." /> </div>
 * 
 *    - Navbar.tsx (Book a Call Button):
 *      <button data-cursor="magnetic" onClick={...}> Book a Call </button>
 */
export const CustomCursor: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isMobile, setIsMobile] = useState(true);
  const [cursorMode, setCursorMode] = useState<CursorMode>('default');
  const prefersReducedMotion = useReducedMotion();

  // --- POSITION PHYSICS (Fluid trailing) ---
  const mouseX = useMotionValue(typeof window !== 'undefined' ? window.innerWidth / 2 : 0);
  const mouseY = useMotionValue(typeof window !== 'undefined' ? window.innerHeight / 2 : 0);

  const positionConfig = { damping: 25, stiffness: 300, mass: 0.5 };
  const followerX = useSpring(mouseX, positionConfig);
  const followerY = useSpring(mouseY, positionConfig);

  // --- FOCUS-LOCK PHYSICS (Snappy bracket animation) ---
  // 0 = Wide (Default)
  // 1 = Locked (Hover)
  // 2 = Confirmed (Clicked)
  const focusValue = useMotionValue(0);
  const focusConfig = { damping: 20, stiffness: 450, mass: 0.3 };
  const smoothFocus = useSpring(focusValue, focusConfig);

  // Map the smooth focus spring to the physical bracket offset in pixels
  const bracketOffset = useTransform(smoothFocus, [0, 1, 2], [24, 16, 12]);
  
  const bracketOffsetNeg = useTransform(bracketOffset, (v) => -v);
  const bracketOffsetPos = useTransform(bracketOffset, (v) => v);

  useEffect(() => {
    const checkPointer = () => {
      const isCoarse = window.matchMedia('(pointer: coarse)').matches;
      setIsMobile(isCoarse);
      setIsVisible(!isCoarse); // Auto-hide on mobile
    };
    
    checkPointer();
    window.addEventListener('resize', checkPointer);

    if (isMobile) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!isVisible) setIsVisible(true);

      const target = e.target as HTMLElement | null;
      if (!target) return;

      const customTarget = target.closest('[data-cursor]');
      
      if (customTarget) {
        const mode = customTarget.getAttribute('data-cursor') as CursorMode;
        setCursorMode(mode);
        focusValue.set(1); // Snap inward to "Locked" state
        
        // Handle Magnetic Pull
        if (mode === 'magnetic') {
           const rect = customTarget.getBoundingClientRect();
           const centerX = rect.left + rect.width / 2;
           const centerY = rect.top + rect.height / 2;
           
           // Pull the raw mouse coordinate 40% towards the button center
           const pullX = e.clientX + (centerX - e.clientX) * 0.4;
           const pullY = e.clientY + (centerY - e.clientY) * 0.4;
           mouseX.set(pullX);
           mouseY.set(pullY);
        } else {
           mouseX.set(e.clientX);
           mouseY.set(e.clientY);
        }
      } else {
        // Standard interactive fallbacks
        const isStandardInteractive = target.closest('a, button, [role="button"], input, textarea, select');
        if (isStandardInteractive) {
           setCursorMode('link');
           focusValue.set(1);
           mouseX.set(e.clientX);
           mouseY.set(e.clientY);
        } else {
           setCursorMode('default');
           focusValue.set(0); // Relax back to "Wide" state
           mouseX.set(e.clientX);
           mouseY.set(e.clientY);
        }
      }
    };

    const handleMouseDown = () => focusValue.set(2); // Snap inward for click feedback
    const handleMouseUp = () => focusValue.set(cursorMode !== 'default' ? 1 : 0);
    const handleMouseLeave = () => setIsVisible(false); // Hide when leaving window
    const handleMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('resize', checkPointer);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [mouseX, mouseY, isVisible, isMobile, cursorMode, focusValue]);

  if (isMobile) return null;

  const finalX = prefersReducedMotion ? mouseX : followerX;
  const finalY = prefersReducedMotion ? mouseY : followerY;

  const isHovered = cursorMode !== 'default';
  const isLink = cursorMode === 'link';
  const isDrag = cursorMode === 'drag';

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          style={{
            x: finalX,
            y: finalY,
            translateX: '-50%',
            translateY: '-50%',
          }}
          className="pointer-events-none fixed top-0 left-0 z-[10000] mix-blend-difference flex items-center justify-center w-32 h-32"
        >
          {/* Main SVG Viewfinder Canvas */}
          <svg width="100" height="100" viewBox="-50 -50 100 100" className="overflow-visible">
            
            {/* Center Precision Dot */}
            <motion.circle 
              cx="0" cy="0" r="2" fill="white" 
              animate={{ opacity: isDrag ? 0 : 1 }} 
              transition={{ duration: 0.2 }}
            />
            
            {/* Crosshair Lines (Fade out on hover) */}
            <motion.g 
              animate={{ opacity: isHovered ? 0 : 1 }}
              transition={{ duration: 0.2 }}
            >
                <line x1="0" y1="-5" x2="0" y2="-12" stroke="white" strokeWidth="1" />
                <line x1="0" y1="5" x2="0" y2="12" stroke="white" strokeWidth="1" />
                <line x1="-5" y1="0" x2="-12" y2="0" stroke="white" strokeWidth="1" />
                <line x1="5" y1="0" x2="12" y2="0" stroke="white" strokeWidth="1" />
            </motion.g>

            {/* Corner Brackets (Animated via bracketOffset transform) */}
            <motion.g 
              animate={{ opacity: isLink ? 0 : 1 }}
              transition={{ duration: 0.2 }}
            >
                {/* Top Left */}
                <motion.g style={prefersReducedMotion ? {} : { x: bracketOffsetNeg, y: bracketOffsetNeg }}>
                   <path d="M 6,0 L 0,0 L 0,6" stroke="white" strokeWidth="1.5" fill="none" />
                </motion.g>
                {/* Top Right */}
                <motion.g style={prefersReducedMotion ? {} : { x: bracketOffsetPos, y: bracketOffsetNeg }}>
                   <path d="M -6,0 L 0,0 L 0,6" stroke="white" strokeWidth="1.5" fill="none" />
                </motion.g>
                {/* Bottom Left */}
                <motion.g style={prefersReducedMotion ? {} : { x: bracketOffsetNeg, y: bracketOffsetPos }}>
                   <path d="M 0,-6 L 0,0 L 6,0" stroke="white" strokeWidth="1.5" fill="none" />
                </motion.g>
                {/* Bottom Right */}
                <motion.g style={prefersReducedMotion ? {} : { x: bracketOffsetPos, y: bracketOffsetPos }}>
                   <path d="M 0,-6 L 0,0 L -6,0" stroke="white" strokeWidth="1.5" fill="none" />
                </motion.g>
            </motion.g>

            {/* Link Hover Underline Indicator */}
            <motion.line
               initial={{ scaleX: 0, opacity: 0 }}
               animate={{ scaleX: isLink ? 1 : 0, opacity: isLink ? 1 : 0 }}
               x1="-8" y1="8" x2="8" y2="8"
               stroke="white" strokeWidth="1.5"
               transition={{ duration: 0.2 }}
            />

            {/* Drag Mode Arrows (Center) */}
            <motion.g
               initial={{ opacity: 0, scale: 0.5 }}
               animate={{ opacity: isDrag ? 1 : 0, scale: isDrag ? 1 : 0.5 }}
               transition={{ duration: 0.2 }}
            >
                <path d="M -6,-3 L -10,0 L -6,3 M 6,-3 L 10,0 L 6,3" stroke="white" fill="none" strokeWidth="1.5" />
                <line x1="-10" y1="0" x2="10" y2="0" stroke="white" strokeWidth="1.5" />
            </motion.g>
          </svg>

          {/* Text Labels (Below Crosshair) */}
          <AnimatePresence>
            {isHovered && !isLink && !isDrag && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  transition={{ duration: 0.2 }}
                  className="absolute top-[60px] whitespace-nowrap text-[10px] font-bold tracking-[0.2em] text-white"
                >
                   {cursorMode === 'view' && 'VIEW'}
                   {cursorMode === 'play' && (
                     <span className="flex items-center gap-1">
                        <svg width="8" height="8" viewBox="0 0 24 24" fill="white"><path d="M5 3l14 9-14 9V3z"/></svg>
                        PLAY
                     </span>
                   )}
                   {cursorMode === 'magnetic' && 'CLICK'}
                </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CustomCursor;

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, HTMLMotionProps } from 'motion/react';

interface CinematicImageProps extends Omit<HTMLMotionProps<"img">, "src" | "alt"> {
  src: string;
  alt: string;
  containerClassName?: string;
}

export const CinematicImage: React.FC<CinematicImageProps> = ({ 
  src, 
  alt, 
  containerClassName = "",
  className = "",
  ...props 
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [lowResSrc, setLowResSrc] = useState<string>('');

  useEffect(() => {
    // Generate a low-res blurred version if it's an Unsplash URL
    if (src && src.includes('images.unsplash.com')) {
      const tinyUrl = src
        .replace(/w=\d+/, 'w=30')
        .replace(/q=\d+/, 'q=10');
      setLowResSrc(tinyUrl);
    }
  }, [src]);

  return (
    <div className={`relative overflow-hidden w-full h-full bg-[#12071a] theme-light:bg-[#FAF7FD] ${containerClassName}`}>
      {/* Heavy Blur Placeholder layer utilizing dominant colors via scaled down image */}
      <AnimatePresence>
        {!isLoaded && lowResSrc && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0 z-0 overflow-hidden"
          >
            <div 
              className="absolute inset-[-10%] bg-center bg-cover bg-no-repeat blur-2xl scale-110 opacity-70"
              style={{ backgroundImage: `url(${lowResSrc})` }}
            />
            {/* Soft pulsing overlay for cinematic effect */}
            <motion.div 
              className="absolute inset-0 bg-black/10 mix-blend-overlay"
              animate={{ opacity: [0.1, 0.3, 0.1] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Actual Image */}
      <motion.img
        src={src}
        alt={alt}
        onLoad={() => setIsLoaded(true)}
        className={`relative z-10 w-full h-full object-cover transition-opacity duration-1000 ease-[0.22,1,0.36,1] ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        } ${className}`}
        {...props}
      />
    </div>
  );
};

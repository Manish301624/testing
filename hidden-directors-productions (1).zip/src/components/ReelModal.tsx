import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Volume2, VolumeX, Heart, Share2, Sparkles, Play, Pause, Gauge, Scissors, RotateCcw, SlidersHorizontal, Clock, Activity } from 'lucide-react';
import { ReelItem } from '../types';
import { CinematicImage } from './CinematicImage';
import { AudioWaveform } from './AudioWaveform';
import { buildWhatsAppUrl, getInitialWhatsAppNumber, getContextualWhatsAppMessage, fetchConfiguredWhatsAppNumber } from '../utils/whatsapp';
import { backdropBlurIn, modalContentEntrance } from '../utils/motionVariants';

interface ReelModalProps {
  reel: ReelItem | null;
  /** High-resolution preview image to display while video buffer loads */
  poster?: string;
  onClose: () => void;
  onBookShoot: () => void;
}

export const ReelModal: React.FC<ReelModalProps> = ({ reel, poster, onClose, onBookShoot }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [volume, setVolume] = useState<number>(0.85);
  const [showWaveform, setShowWaveform] = useState<boolean>(true);
  const [showAudioToast, setShowAudioToast] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(reel?.likes || 0);
  const [isBufferLoading, setIsBufferLoading] = useState<boolean>(true);
  const [loadProgress, setLoadProgress] = useState<number>(0);
  const progressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);

  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) setWhatsappNumber(num);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Active high-resolution poster
  const effectivePoster = poster || reel?.posterUrl;
  
  // Trim slider states
  const [duration, setDuration] = useState<number>(15);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [trimStart, setTrimStart] = useState<number>(0);
  const [trimEnd, setTrimEnd] = useState<number>(15);
  const [showTrimControl, setShowTrimControl] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const speedOptions = [
    { label: '0.5x Slow-Mo', value: 0.5 },
    { label: '1x Standard', value: 1.0 },
    { label: '2x Fast Cut', value: 2.0 },
  ];

  // Reset states when a new reel is opened
  useEffect(() => {
    if (reel) {
      setTrimStart(0);
      setTrimEnd(15);
      setCurrentTime(0);
      setLiked(false);
      setLikeCount(reel.likes || 120);
      setIsPlaying(true);
      setIsMuted(true); // default to muted as requested
      setShowAudioToast(false);
      setShowWaveform(true);
      setVolume(0.85);
      setIsBufferLoading(true);
      setLoadProgress(15);

      // Incremental simulation to ensure smooth visual circular progress while downloading
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
      progressTimerRef.current = setInterval(() => {
        setLoadProgress((prev) => {
          if (prev >= 92) {
            if (progressTimerRef.current) clearInterval(progressTimerRef.current);
            return prev;
          }
          const step = Math.floor(Math.random() * 12) + 8;
          return Math.min(92, prev + step);
        });
      }, 100);

      return () => {
        if (progressTimerRef.current) clearInterval(progressTimerRef.current);
      };
    }
  }, [reel]);

  // Clean up toast and progress timers on unmount
  useEffect(() => {
    return () => {
      if (toastTimeoutRef.current) {
        clearTimeout(toastTimeoutRef.current);
      }
      if (progressTimerRef.current) {
        clearInterval(progressTimerRef.current);
      }
    };
  }, []);

  // Video buffering & playback ready listeners
  const handleProgress = () => {
    if (videoRef.current && videoRef.current.duration > 0) {
      const buffered = videoRef.current.buffered;
      if (buffered.length > 0) {
        const bufferedEnd = buffered.end(buffered.length - 1);
        const pct = Math.min(100, Math.round((bufferedEnd / videoRef.current.duration) * 100));
        setLoadProgress((prev) => Math.max(prev, pct));
        if (pct >= 90 || videoRef.current.readyState >= 3) {
          if (progressTimerRef.current) clearInterval(progressTimerRef.current);
          setIsBufferLoading(false);
        }
      }
    }
  };

  const handleCanPlay = () => {
    if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    setLoadProgress(100);
    setTimeout(() => {
      setIsBufferLoading(false);
    }, 200);
  };

  const handlePlaying = () => {
    if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    setLoadProgress(100);
    setIsBufferLoading(false);
  };

  const handleWaiting = () => {
    setIsBufferLoading(true);
    setLoadProgress((prev) => (prev >= 100 ? 55 : prev));
  };

  // Handle video metadata loaded to capture true duration
  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const vidDur = videoRef.current.duration;
      if (vidDur && !isNaN(vidDur) && isFinite(vidDur) && vidDur > 0) {
        setDuration(vidDur);
        setTrimEnd(vidDur);
        setTrimStart(0);
      }
      videoRef.current.volume = volume;
    }
  };

  // Enforce loop within trim boundaries [trimStart, trimEnd]
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const current = videoRef.current.currentTime;
    setCurrentTime(current);

    // If past trimEnd or before trimStart, loop back to trimStart
    if (current >= trimEnd) {
      videoRef.current.currentTime = trimStart;
      if (isPlaying) {
        videoRef.current.play().catch(() => {});
      }
    } else if (current < trimStart - 0.2) {
      videoRef.current.currentTime = trimStart;
    }
  };

  const togglePlay = useCallback(() => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  }, [isPlaying]);

  // Adjust volume level dynamically (0 to 1)
  const handleVolumeChange = useCallback((newVolume: number) => {
    const clamped = Math.max(0, Math.min(1, newVolume));
    setVolume(clamped);
    if (videoRef.current) {
      videoRef.current.volume = clamped;
      if (clamped > 0 && isMuted) {
        videoRef.current.muted = false;
        setIsMuted(false);
      } else if (clamped === 0 && !isMuted) {
        videoRef.current.muted = true;
        setIsMuted(true);
      }
    }
  }, [isMuted]);

  const toggleMute = useCallback((e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    if (!videoRef.current) return;
    const nextMuted = !isMuted;
    videoRef.current.muted = nextMuted;
    setIsMuted(nextMuted);

    // If unmuting with zero volume, set volume to default 0.85
    if (!nextMuted && volume === 0) {
      setVolume(0.85);
      videoRef.current.volume = 0.85;
    }

    // Trigger transient HUD feedback
    setShowAudioToast(true);
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    toastTimeoutRef.current = setTimeout(() => {
      setShowAudioToast(false);
    }, 1400);

    // If unmuting, make sure video continues playing smoothly
    if (!nextMuted) {
      videoRef.current.play().catch(() => {});
    }
  }, [isMuted, volume]);

  // Close on Escape key press, toggle mute on 'M', toggle play on Spacebar
  useEffect(() => {
    if (!reel) {
      document.body.style.overflow = '';
      return;
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept typing if focused on inputs
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        toggleMute();
      } else if (e.key === ' ' || e.key === 'k' || e.key === 'K') {
        e.preventDefault();
        togglePlay();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [reel, onClose, toggleMute, togglePlay]);

  // Sync video playback rate whenever playbackSpeed changes
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed, reel]);

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  };

  const handleLike = () => {
    if (liked) {
      setLiked(false);
      setLikeCount(prev => prev - 1);
    } else {
      setLiked(true);
      setLikeCount(prev => prev + 1);
    }
  };

  const handleTrimStartChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    const newStart = Math.min(val, trimEnd - 0.5);
    setTrimStart(newStart);
    if (videoRef.current) {
      videoRef.current.currentTime = newStart;
    }
  };

  const handleTrimEndChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    const newEnd = Math.max(val, trimStart + 0.5);
    setTrimEnd(newEnd);
    if (videoRef.current && videoRef.current.currentTime > newEnd) {
      videoRef.current.currentTime = trimStart;
    }
  };

  const resetTrim = () => {
    setTrimStart(0);
    setTrimEnd(duration);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
    }
  };

  const applyPreset = (startRatio: number, endRatio: number) => {
    const start = duration * startRatio;
    const end = duration * endRatio;
    setTrimStart(start);
    setTrimEnd(end);
    if (videoRef.current) {
      videoRef.current.currentTime = start;
    }
  };

  const formatSeconds = (sec: number) => {
    const s = Math.max(0, sec);
    const mins = Math.floor(s / 60);
    const remainingSecs = (s % 60).toFixed(1);
    return `${mins > 0 ? `${mins}:` : ''}${remainingSecs.padStart(4, '0')}s`;
  };

  const trimmedLength = Math.max(0, trimEnd - trimStart);
  const startPercent = (trimStart / (duration || 1)) * 100;
  const endPercent = (trimEnd / (duration || 1)) * 100;
  const currentPercent = Math.min(100, Math.max(0, (currentTime / (duration || 1)) * 100));

  return (
    <AnimatePresence>
      {reel && (
        <motion.div
          key="reel-modal-backdrop"
          variants={backdropBlurIn}
          initial="hidden"
          animate="visible"
          exit="exit"
          onClick={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
          className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 select-none"
        >
          <motion.div
            variants={modalContentEntrance}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="relative w-full max-w-sm sm:max-w-md h-[92vh] sm:h-[88vh] rounded-3xl overflow-hidden bg-[#100416] border border-white/20 shadow-2xl flex flex-col justify-between"
          >
        {/* Top Control Bar */}
        <div className="absolute top-4 left-4 right-4 z-30 flex items-center justify-between pointer-events-auto">
          <div className="flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
            <span className="text-[11px] font-bold text-pink-400 uppercase tracking-wider">{reel.client}</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Audio Waveform Visualization Toggle */}
            <button
              onClick={() => setShowWaveform(!showWaveform)}
              aria-label={showWaveform ? "Hide audio waveform" : "Show audio waveform"}
              title={showWaveform ? "Hide dynamic audio waveform" : "Show dynamic audio waveform"}
              className={`p-2 rounded-full backdrop-blur-md border transition-all cursor-pointer ${
                showWaveform 
                  ? 'bg-gradient-to-r from-[#FF007A] to-purple-600 text-white border-pink-400 shadow-md shadow-pink-500/40' 
                  : 'bg-black/60 hover:bg-black text-gray-300 hover:text-white border-white/10'
              }`}
            >
              <Activity className="w-4 h-4" />
            </button>

            {/* Trim Toggle Button */}
            <button
              onClick={() => setShowTrimControl(!showTrimControl)}
              aria-label="Toggle trim controls"
              title="Trim Video Loop"
              className={`p-2 rounded-full backdrop-blur-md border transition-all cursor-pointer ${
                showTrimControl 
                  ? 'bg-[#FF007A] text-white border-pink-400 shadow-md shadow-pink-500/40' 
                  : 'bg-black/60 hover:bg-black text-gray-300 hover:text-white border-white/10'
              }`}
            >
              <Scissors className="w-4 h-4" />
            </button>

            {/* Explicit Mute/Unmute Control with Text, Icon & Animated Visualizer */}
            <button
              onClick={toggleMute}
              aria-label={isMuted ? "Unmute audio" : "Mute audio"}
              title={isMuted ? "Unmute audio (Press 'M')" : "Mute audio (Press 'M')"}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full backdrop-blur-md border text-xs font-bold transition-all duration-200 cursor-pointer select-none shadow-lg ${
                isMuted
                  ? 'bg-black/75 hover:bg-black text-pink-400 hover:text-pink-300 border-pink-500/40 hover:border-pink-400 shadow-pink-500/10'
                  : 'bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 hover:text-emerald-200 border-emerald-500/50 hover:border-emerald-400 shadow-emerald-500/10'
              }`}
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-[#FF007A]" />
                  <span className="text-[10px] sm:text-[11px] font-mono font-extrabold uppercase tracking-wider">UNMUTE</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[10px] sm:text-[11px] font-mono font-extrabold uppercase tracking-wider">MUTE</span>
                  {/* Dynamic Sound Wave Indicator */}
                  <div className="flex items-end gap-0.5 h-3 ml-0.5">
                    <motion.span
                      animate={{ height: ['4px', '12px', '5px', '12px', '4px'] }}
                      transition={{ repeat: Infinity, duration: 0.8, ease: 'easeInOut' }}
                      className="w-0.5 bg-emerald-400 rounded-full"
                    />
                    <motion.span
                      animate={{ height: ['10px', '4px', '12px', '6px', '10px'] }}
                      transition={{ repeat: Infinity, duration: 0.6, ease: 'easeInOut', delay: 0.1 }}
                      className="w-0.5 bg-emerald-400 rounded-full"
                    />
                    <motion.span
                      animate={{ height: ['6px', '12px', '4px', '10px', '6px'] }}
                      transition={{ repeat: Infinity, duration: 0.7, ease: 'easeInOut', delay: 0.2 }}
                      className="w-0.5 bg-emerald-400 rounded-full"
                    />
                  </div>
                </>
              )}
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              aria-label="Close reel"
              className="p-2 rounded-full bg-black/60 hover:bg-black text-white backdrop-blur-md border border-white/10 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Video Canvas */}
        <div 
          onClick={togglePlay}
          className="relative flex-1 w-full h-full bg-black cursor-pointer flex items-center justify-center overflow-hidden"
        >
          {/* High-Resolution Preview Poster while video buffer loads to improve perceived performance */}
          <AnimatePresence>
            {isBufferLoading && effectivePoster && (
              <motion.div
                key={`poster-preview-${reel.id}`}
                initial={{ opacity: 1 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.35, ease: 'easeOut' }}
                className="absolute inset-0 z-10 pointer-events-none overflow-hidden"
              >
                <CinematicImage
                  src={effectivePoster}
                  alt={reel.title}
                  containerClassName="absolute inset-0 w-full h-full"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px]" />
              </motion.div>
            )}
          </AnimatePresence>

          <video
            ref={videoRef}
            src={reel.videoUrl}
            poster={effectivePoster}
            autoPlay
            loop
            playsInline
            muted={isMuted}
            onLoadStart={() => {
              setIsBufferLoading(true);
              setLoadProgress(15);
            }}
            onProgress={handleProgress}
            onWaiting={handleWaiting}
            onCanPlay={handleCanPlay}
            onPlaying={handlePlaying}
            onLoadedMetadata={handleLoadedMetadata}
            onTimeUpdate={handleTimeUpdate}
            className="w-full h-full object-cover"
          />

          {/* Center Play Button with Circular Progress Bar Indicator */}
          <AnimatePresence>
            {(isBufferLoading || !isPlaying) && (
              <motion.div
                key="reel-center-play-progress"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 z-30 pointer-events-auto select-none"
              >
                <div className="relative flex items-center justify-center">
                  {/* Ambient background glow */}
                  <div className="absolute w-28 h-28 rounded-full bg-gradient-to-tr from-[#FF007A]/40 to-[#FF5E62]/20 blur-xl pointer-events-none" />

                  {/* Circular Progress SVG Ring */}
                  <svg
                    className="w-24 h-24 sm:w-28 sm:h-28 -rotate-90 transform pointer-events-none"
                    viewBox="0 0 100 100"
                  >
                    <defs>
                      <linearGradient id="reel-circular-progress-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#FF007A" />
                        <stop offset="50%" stopColor="#FF2E93" />
                        <stop offset="100%" stopColor="#FFA07A" />
                      </linearGradient>
                      <filter id="reel-glow" x="-20%" y="-20%" width="140%" height="140%">
                        <feGaussianBlur stdDeviation="1.5" result="blur" />
                        <feComposite in="SourceGraphic" in2="blur" operator="over" />
                      </filter>
                    </defs>

                    {/* Background Track Circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="44"
                      className="stroke-white/20"
                      strokeWidth="3.5"
                      fill="none"
                    />

                    {/* Dynamic Animated Circular Progress Stroke */}
                    <circle
                      cx="50"
                      cy="50"
                      r="44"
                      stroke="url(#reel-circular-progress-grad)"
                      strokeWidth="4"
                      strokeLinecap="round"
                      fill="none"
                      strokeDasharray={276.46}
                      strokeDashoffset={
                        276.46 - (276.46 * Math.min(100, Math.max(isBufferLoading ? 8 : 0, isBufferLoading ? loadProgress : 100))) / 100
                      }
                      filter="url(#reel-glow)"
                      className="transition-all duration-150 ease-out"
                    />
                  </svg>

                  {/* Center Play Button inside the ring */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      togglePlay();
                    }}
                    aria-label={isPlaying ? "Pause video" : "Play video"}
                    className="absolute w-16 h-16 sm:w-18 sm:h-18 rounded-full bg-gradient-to-tr from-[#FF007A] via-[#FF2E93] to-[#FF5E62] text-white flex items-center justify-center shadow-[0_0_25px_rgba(255,0,122,0.6)] border-2 border-white/40 hover:scale-105 active:scale-95 transition-transform duration-200 cursor-pointer"
                  >
                    {isBufferLoading ? (
                      <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-current ml-1 text-white animate-pulse" />
                    ) : (
                      <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-current ml-1 text-white" />
                    )}
                  </button>
                </div>

                {/* Status Badge below the circular progress bar */}
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-3.5 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-pink-500/30 text-white shadow-2xl pointer-events-none"
                >
                  {isBufferLoading ? (
                    <>
                      <span className="w-2 h-2 rounded-full bg-[#FF007A] animate-ping" />
                      <span className="font-mono text-[10px] sm:text-[11px] font-bold text-pink-200 tracking-wider uppercase">
                        Buffering HD Video {Math.min(100, Math.max(5, Math.round(loadProgress)))}%
                      </span>
                    </>
                  ) : (
                    <span className="font-mono text-[10px] sm:text-[11px] font-bold text-gray-200 tracking-wider uppercase">
                      Tap anywhere to play
                    </span>
                  )}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Floating Audio State Banner / Quick Unmute Pill */}
          <AnimatePresence>
            {isMuted ? (
              <motion.button
                key="audio-muted-pill"
                initial={{ opacity: 0, y: -8, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.95 }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={(e) => {
                  e.stopPropagation();
                  toggleMute();
                }}
                className="absolute top-16 left-4 z-30 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/85 hover:bg-black text-white backdrop-blur-md border border-[#FF007A]/60 hover:border-[#FF007A] shadow-xl text-xs font-semibold cursor-pointer select-none group transition-all"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF007A] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#FF007A]" />
                </span>
                <VolumeX className="w-3.5 h-3.5 text-[#FF007A] group-hover:scale-110 transition-transform" />
                <span className="text-[11px] font-medium tracking-wide">Video is muted &bull; Tap to unmute</span>
              </motion.button>
            ) : (
              <motion.button
                key="audio-active-pill"
                initial={{ opacity: 0, y: -8, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.95 }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={(e) => {
                  e.stopPropagation();
                  toggleMute();
                }}
                className="absolute top-16 left-4 z-30 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/75 hover:bg-black/90 text-emerald-300 backdrop-blur-md border border-emerald-500/40 shadow-lg text-xs cursor-pointer select-none transition-all"
                title="Audio is playing • Tap to mute"
              >
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[11px] font-mono font-bold tracking-wider uppercase">
                  AUDIO ACTIVE ({Math.round(volume * 100)}%)
                </span>
                <div className="flex items-end gap-0.5 h-3">
                  <motion.span
                    animate={{ height: ['3px', `${Math.max(4, Math.round(12 * volume))}px`, '4px', `${Math.max(4, Math.round(11 * volume))}px`, '3px'] }}
                    transition={{ repeat: Infinity, duration: 0.8, ease: 'easeInOut' }}
                    className="w-0.5 bg-emerald-400 rounded-full"
                  />
                  <motion.span
                    animate={{ height: [`${Math.max(3, Math.round(9 * volume))}px`, '3px', `${Math.max(4, Math.round(12 * volume))}px`, '5px', `${Math.max(3, Math.round(9 * volume))}px`] }}
                    transition={{ repeat: Infinity, duration: 0.6, ease: 'easeInOut', delay: 0.15 }}
                    className="w-0.5 bg-emerald-400 rounded-full"
                  />
                  <motion.span
                    animate={{ height: ['5px', `${Math.max(4, Math.round(11 * volume))}px`, '3px', `${Math.max(3, Math.round(8 * volume))}px`, '5px'] }}
                    transition={{ repeat: Infinity, duration: 0.7, ease: 'easeInOut', delay: 0.25 }}
                    className="w-0.5 bg-emerald-400 rounded-full"
                  />
                </div>
              </motion.button>
            )}
          </AnimatePresence>

          {/* Transient Center Audio HUD Overlay */}
          <AnimatePresence>
            {showAudioToast && (
              <motion.div
                initial={{ opacity: 0, scale: 0.75 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.75 }}
                transition={{ type: 'spring', stiffness: 450, damping: 28 }}
                className="absolute inset-0 flex items-center justify-center pointer-events-none z-40"
              >
                <div className="flex flex-col items-center gap-2 px-5 py-4 rounded-2xl bg-black/90 backdrop-blur-xl border border-white/20 shadow-2xl shadow-black">
                  {isMuted ? (
                    <>
                      <div className="w-12 h-12 rounded-full bg-pink-500/20 border border-pink-500/30 flex items-center justify-center text-[#FF007A]">
                        <VolumeX className="w-6 h-6" />
                      </div>
                      <span className="text-xs font-mono font-bold tracking-wider uppercase text-pink-300">
                        AUDIO MUTED
                      </span>
                    </>
                  ) : (
                    <>
                      <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <Volume2 className="w-6 h-6" />
                      </div>
                      <span className="text-xs font-mono font-bold tracking-wider uppercase text-emerald-300">
                        AUDIO ACTIVE
                      </span>
                    </>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Side Action Floating Icons */}
          <div className="absolute right-4 bottom-48 flex flex-col items-center gap-3.5 z-30">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleLike();
              }}
              className="flex flex-col items-center gap-1 group cursor-pointer"
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-all ${
                liked ? 'bg-pink-600 text-white shadow-lg shadow-pink-500/50' : 'bg-black/60 text-white group-hover:bg-pink-500/30'
              }`}>
                <Heart className={`w-4 h-4 ${liked ? 'fill-white text-white' : 'text-white'}`} />
              </div>
              <span className="text-[10px] font-bold text-white drop-shadow">
                {likeCount.toLocaleString()}
              </span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                navigator.clipboard?.writeText(window.location.href);
              }}
              className="flex flex-col items-center gap-1 group cursor-pointer"
              title="Share Reel"
            >
              <div className="w-10 h-10 rounded-full bg-black/60 group-hover:bg-white/20 text-white flex items-center justify-center backdrop-blur-md transition-all">
                <Share2 className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold text-white drop-shadow">Share</span>
            </button>
          </div>
        </div>

        {/* Bottom Details, Trim Editor & Controls */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/90 to-transparent z-20 space-y-2.5">
          
          {/* Dynamic CSS-Based Audio Waveform Visualization reacting to volume */}
          <AnimatePresence>
            {showWaveform && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.98 }}
                transition={{ duration: 0.2 }}
              >
                <AudioWaveform
                  videoRef={videoRef}
                  isPlaying={isPlaying}
                  isMuted={isMuted}
                  volume={volume}
                  onVolumeChange={handleVolumeChange}
                  onToggleMute={toggleMute}
                  playbackSpeed={playbackSpeed}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Interactive Trim Slider Control Panel */}
          <AnimatePresence>
            {showTrimControl && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                onClick={(e) => e.stopPropagation()}
                className="p-3 rounded-2xl bg-black/85 backdrop-blur-xl border border-pink-500/30 shadow-2xl space-y-2.5"
              >
                {/* Header: Trim info & Reset */}
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-pink-400 font-bold uppercase tracking-wider text-[11px]">
                    <Scissors className="w-3.5 h-3.5 text-[#FF007A]" />
                    <span>Trim Clip Range</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold text-gray-300 bg-white/10 px-2 py-0.5 rounded-full">
                      {formatSeconds(trimStart)} - {formatSeconds(trimEnd)} ({formatSeconds(trimmedLength)})
                    </span>
                    <button
                      type="button"
                      onClick={resetTrim}
                      title="Reset to Full Length"
                      className="text-[10px] font-semibold text-gray-400 hover:text-white flex items-center gap-1 hover:bg-white/10 px-1.5 py-0.5 rounded transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3 text-pink-400" />
                      <span>Reset</span>
                    </button>
                  </div>
                </div>

                {/* Multi-Handle Range Visual Track */}
                <div className="relative h-6 flex items-center select-none py-1">
                  {/* Background Track */}
                  <div className="absolute inset-x-0 h-2 rounded-full bg-white/10 overflow-hidden">
                    {/* Active Trimmed Range Highlight */}
                    <div
                      className="absolute top-0 bottom-0 bg-gradient-to-r from-[#FF007A] to-purple-500 rounded-full"
                      style={{
                        left: `${startPercent}%`,
                        width: `${Math.max(2, endPercent - startPercent)}%`,
                      }}
                    />
                  </div>

                  {/* Playhead Indicator */}
                  <div
                    className="absolute top-0 bottom-0 w-1 bg-white rounded-full shadow-[0_0_8px_#ffffff] z-10 pointer-events-none transition-all duration-75"
                    style={{ left: `${currentPercent}%` }}
                  />

                  {/* Dual Sliders Overlay */}
                  <div className="relative w-full h-full flex items-center pointer-events-none">
                    {/* Start Point Handle Slider */}
                    <input
                      type="range"
                      min={0}
                      max={duration || 15}
                      step={0.1}
                      value={trimStart}
                      onChange={handleTrimStartChange}
                      aria-label="Trim Start Time"
                      className="absolute inset-x-0 w-full pointer-events-auto appearance-none bg-transparent cursor-pointer z-20 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-[#FF007A] [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-grab"
                    />

                    {/* End Point Handle Slider */}
                    <input
                      type="range"
                      min={0}
                      max={duration || 15}
                      step={0.1}
                      value={trimEnd}
                      onChange={handleTrimEndChange}
                      aria-label="Trim End Time"
                      className="absolute inset-x-0 w-full pointer-events-auto appearance-none bg-transparent cursor-pointer z-20 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-purple-500 [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-grab"
                    />
                  </div>
                </div>

                {/* Quick Presets Buttons */}
                <div className="flex items-center justify-between gap-1 pt-1 border-t border-white/5">
                  <span className="text-[9px] font-bold uppercase tracking-wider text-gray-400">Presets:</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => applyPreset(0, 0.3)}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-pink-300 transition-colors"
                    >
                      Hook (0-30%)
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPreset(0.2, 0.7)}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-pink-300 transition-colors"
                    >
                      Climax (20-70%)
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPreset(0.65, 1)}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-pink-300 transition-colors"
                    >
                      CTA (65-100%)
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Director's Cut Speed Control Segmented Switch */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="flex items-center justify-between px-3 py-1.5 rounded-2xl bg-black/75 backdrop-blur-md border border-white/10"
          >
            <div className="flex items-center gap-1.5 text-xs font-bold text-gray-300 uppercase tracking-wider">
              <Gauge className="w-3.5 h-3.5 text-[#FF007A]" />
              <span className="text-[10px]">Speed</span>
            </div>

            <div className="flex items-center bg-white/10 rounded-xl p-0.5 border border-white/10">
              {speedOptions.map((opt) => {
                const isSelected = playbackSpeed === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => handleSpeedChange(opt.value)}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-r from-[#FF007A] to-purple-600 text-white shadow-md shadow-pink-500/40'
                        : 'text-gray-300 hover:text-white hover:bg-white/5'
                    }`}
                    title={`Play at ${opt.label}`}
                  >
                    {opt.value}x
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title & Metadata */}
          <div className="pr-12">
            <h3 className="text-sm font-bold text-white leading-tight">
              {reel.title}
            </h3>
            <p className="text-[11px] text-gray-300 mt-0.5 line-clamp-1">
              {reel.description}
            </p>
          </div>

          <div className="pt-0.5 flex gap-2">
            <a
              href={buildWhatsAppUrl(
                whatsappNumber,
                getContextualWhatsAppMessage('reel', { reelTitle: reel.title })
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-full border border-[#25D366]/40 bg-[#0e2418]/80 hover:bg-[#133623] text-emerald-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-md group/wareel"
              title="Chat on WhatsApp about this reel"
            >
              <span className="w-2 h-2 rounded-full bg-[#25D366] group-hover/wareel:scale-125 transition-transform" />
              <span className="hidden xs:inline">WhatsApp</span>
            </a>

            <button
              onClick={() => {
                onClose();
                onBookShoot();
              }}
              className="flex-1 btn-primary-gradient py-2 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/30 flex items-center justify-center gap-1.5 cursor-pointer hover:scale-[1.02] transition-transform"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>BOOK SIMILAR SHOOT</span>
            </button>
          </div>
        </div>

      </motion.div>
    </motion.div>
    )}
    </AnimatePresence>
  );
};


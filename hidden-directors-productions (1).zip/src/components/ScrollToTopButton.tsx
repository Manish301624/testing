import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronUp } from 'lucide-react';

interface ScrollToTopButtonProps {
  /** Scroll offset in pixels after which button appears (default: 500px) */
  threshold?: number;
  className?: string;
}

export const ScrollToTopButton: React.FC<ScrollToTopButtonProps> = ({
  threshold = 500,
  className = 'fixed bottom-22 right-6 sm:bottom-24 sm:right-7 z-40'
}) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Check if user scrolled past hero section (~500px or past #home)
      const heroElement = document.getElementById('home');
      const heroBottom = heroElement ? heroElement.offsetHeight : 500;
      const targetThreshold = threshold || heroBottom;

      if (window.scrollY > targetThreshold) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [threshold]);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          id="scroll-to-top-btn"
          initial={{ opacity: 0, scale: 0.8, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 12 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          whileHover={{ scale: 1.1, y: -2 }}
          whileTap={{ scale: 0.94 }}
          onClick={scrollToTop}
          aria-label="Scroll to top of page"
          title="Scroll to top"
          className={`${className} p-3 rounded-full bg-[#180720]/90 hover:bg-[#250a32] text-white border border-pink-500/30 hover:border-pink-500/70 shadow-[0_8px_25px_rgba(255,0,122,0.35)] backdrop-blur-md transition-all cursor-pointer group flex items-center justify-center`}
        >
          <ChevronUp className="w-5 h-5 text-pink-400 group-hover:text-pink-200 transition-colors" />
        </motion.button>
      )}
    </AnimatePresence>
  );
};

export default ScrollToTopButton;

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Sparkles, User, Bot, PhoneCall, Calendar } from 'lucide-react';
import { ChatMessage } from '../types';

interface ChatWidgetProps {
  onOpenBooking: () => void;
  onExploreWork: () => void;
}

export const ChatWidget: React.FC<ChatWidgetProps> = ({ onOpenBooking, onExploreWork }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'assistant',
      text: "Hello! Welcome to Hidden Directors Productions 👋 How can we help bring your brand's visual story to life?",
      timestamp: 'Just now',
      suggestedActions: [
        { label: 'Shoot Packages & Pricing', action: 'pricing' },
        { label: 'Book a Consultation Call', action: 'book_call' },
        { label: 'Turnaround Timeline', action: 'timeline' }
      ]
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const messageText = textToSend || inputValue;
    if (!messageText.trim()) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!textToSend) setInputValue('');
    setIsTyping(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: messageText })
      });

      const data = await res.json();
      if (data) {
        setMessages((prev) => [...prev, data]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'assistant',
          text: "Thanks for reaching out! Our directors are on a live shoot, but you can book a 15-min consultation call directly.",
          timestamp: 'Just now',
          suggestedActions: [{ label: 'Book Consultation Call', action: 'book_call' }]
        }
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleActionClick = (action: string) => {
    if (action === 'book_call' || action === 'open_booking') {
      setIsOpen(false);
      onOpenBooking();
    } else if (action === 'view_work') {
      setIsOpen(false);
      onExploreWork();
    } else if (action === 'pricing') {
      handleSendMessage('What are your package prices and options?');
    } else if (action === 'timeline') {
      handleSendMessage('What is your turnaround timeline for reels and master commercials?');
    } else {
      handleSendMessage(action);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Floating Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="w-[90vw] sm:w-[380px] h-[480px] rounded-3xl bg-[#110416] border border-pink-500/30 shadow-2xl shadow-purple-950/70 mb-4 flex flex-col overflow-hidden backdrop-blur-xl"
          >
            {/* Header */}
            <div className="p-4 bg-gradient-to-r from-[#20072b] to-[#120317] border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#FF007A] text-white flex items-center justify-center font-bold text-xs shadow-md shadow-pink-500/40">
                  HD
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>HD Production Desk</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  </div>
                  <div className="text-[10px] text-gray-400">Creative Directors Online</div>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white rounded-tr-xs'
                        : 'bg-[#1e0a29] text-gray-200 border border-white/10 rounded-tl-xs shadow'
                    }`}
                  >
                    {msg.text}
                  </div>

                  <span className="text-[9px] text-gray-500 mt-1 px-1">{msg.timestamp}</span>

                  {/* Quick Action Pills */}
                  {msg.suggestedActions && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {msg.suggestedActions.map((act, i) => (
                        <button
                          key={i}
                          onClick={() => handleActionClick(act.action)}
                          className="text-[10px] font-semibold bg-pink-500/15 hover:bg-pink-500/30 text-pink-300 border border-pink-500/30 px-2.5 py-1 rounded-full transition-all cursor-pointer"
                        >
                          {act.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {isTyping && (
                <div className="flex items-center gap-1 bg-[#1e0a29] px-3 py-2 rounded-2xl w-16 border border-white/10">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce [animation-delay:0.4s]" />
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Bar */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="p-3 bg-[#170520] border-t border-white/10 flex items-center gap-2"
            >
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about shoots, packages, dates..."
                className="flex-1 bg-[#0d0212] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
              />

              <button
                type="submit"
                className="btn-primary-gradient p-2 rounded-xl text-white shadow-md cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Trigger - Exact "Chat with us 👋" badge & Blue Icon from Screenshot 2 */}
      <div className="flex items-center gap-2.5">
        {!isOpen && (
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            className="hidden sm:flex items-center bg-white text-gray-900 font-bold text-xs px-3.5 py-2 rounded-full shadow-2xl shadow-black/60 border border-gray-100 cursor-pointer"
            onClick={() => setIsOpen(true)}
          >
            Chat with us 👋
          </motion.div>
        )}

        {/* Circular Blue/Indigo Button Matching Screenshot 2 */}
        <motion.button
          id="floating-chat-trigger-btn"
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.94 }}
          onClick={() => setIsOpen(!isOpen)}
          className="w-13 h-13 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-2xl shadow-blue-600/50 cursor-pointer transition-all border border-blue-400/30"
          title="Chat with Hidden Directors"
        >
          {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6 fill-white text-white" />}
        </motion.button>
      </div>

    </div>
  );
};

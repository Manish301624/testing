import { CinematicImage } from "./CinematicImage";
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'motion/react';
import Markdown from 'react-markdown';
import { 
  ArrowLeft, 
  ArrowRight,
  Calendar, 
  Clock, 
  Share2, 
  Check, 
  Copy, 
  Sparkles, 
  ArrowUpRight,
  BookOpen,
  ChevronRight
} from 'lucide-react';
import { BlogPost } from '../types';
import { BLOG_POSTS } from '../data/mockData';
import { useLanguage } from '../context/LanguageContext';

interface BlogPostPageProps {
  onOpenBooking?: () => void;
}

export const BlogPostPage: React.FC<BlogPostPageProps> = ({ onOpenBooking }) => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [copied, setCopied] = useState<boolean>(false);

  // Find post from mockData or state
  const post = BLOG_POSTS.find((p) => p.slug === slug);
  const relatedPosts = BLOG_POSTS.filter((p) => p.slug !== slug).slice(0, 3);

  // Scroll to top on slug change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [slug]);

  if (!post) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 py-32 text-center">
        <Helmet>
          <title>Article Not Found | Hidden Directors</title>
          <meta name="description" content="The requested production insight article could not be found." />
        </Helmet>
        <div className="w-16 h-16 rounded-full bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-[#FF007A] mb-4">
          <BookOpen className="w-8 h-8" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white mb-2">
          {language === 'es' ? 'Artículo No Encontrado' : 'Article Not Found'}
        </h1>
        <p className="text-gray-400 max-w-md mb-8">
          {language === 'es'
            ? 'El artículo que buscas ha sido movido o su enlace ha cambiado.'
            : 'The production insight article you are looking for does not exist or has been relocated.'}
        </p>
        <button
          onClick={() => navigate('/')}
          className="btn-primary-gradient px-6 py-3 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg cursor-pointer"
        >
          {language === 'es' ? 'VOLVER AL INICIO' : 'RETURN TO HOME'}
        </button>
      </div>
    );
  }

  const pageTitle = post.seo?.metaTitle || `${post.title} | Hidden Directors`;
  const pageDescription = post.seo?.metaDescription || post.excerpt;
  const canonicalUrl = `https://hiddendirectors.com/blog/${post.slug}`;

  const handleCopyLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleShareTwitter = () => {
    if (typeof window !== 'undefined') {
      const url = encodeURIComponent(window.location.href);
      const text = encodeURIComponent(`"${post.title}" by Hidden Directors Productions:`);
      window.open(`https://twitter.com/intent/tweet?url=${url}&text=${text}`, '_blank');
    }
  };

  const handleShareLinkedIn = () => {
    if (typeof window !== 'undefined') {
      const url = encodeURIComponent(window.location.href);
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, '_blank');
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString(language === 'es' ? 'es-ES' : 'en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  const blogPostSchemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    'headline': post.title,
    'description': pageDescription,
    'image': post.coverImage,
    'datePublished': post.publishedDate,
    'dateModified': post.publishedDate,
    'author': {
      '@type': 'Person',
      'name': post.author.name,
      'jobTitle': post.author.role
    },
    'publisher': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'logo': {
        '@type': 'ImageObject',
        'url': 'https://hiddendirectors.com/logo.svg'
      }
    },
    'mainEntityOfPage': {
      '@type': 'WebPage',
      '@id': canonicalUrl
    }
  };

  return (
    <div id="blog-post-page" className="pt-28 pb-24 bg-[#09030e] min-h-screen text-[#F3F4F6]">
      {/* Dynamic SEO Metadata via react-helmet-async */}
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="article" />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:image" content={post.coverImage} />
        <meta property="og:image:alt" content={post.title} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />
        <meta property="article:published_time" content={post.publishedDate} />
        <meta property="article:author" content={post.author.name} />
        {post.category && <meta property="article:section" content={post.category} />}
        {post.tags && post.tags.map((tag) => (
          <meta key={tag} property="article:tag" content={tag} />
        ))}

        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content={post.coverImage} />
        <meta name="twitter:image:alt" content={post.title} />

        {/* Keywords & Canonical */}
        {post.seo?.keywords && (
          <meta name="keywords" content={post.seo.keywords.join(', ')} />
        )}
        <link rel="canonical" href={canonicalUrl} />

        {/* Schema.org BlogPosting Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(blogPostSchemaJsonLd)}
        </script>
      </Helmet>

      {/* Main Container */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb Navigation */}
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="flex items-center gap-2 text-xs text-gray-400 mb-8 overflow-x-auto whitespace-nowrap"
        >
          <Link to="/" className="hover:text-white transition-colors">
            {language === 'es' ? 'Inicio' : 'Home'}
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <Link to="/#blog" className="hover:text-white transition-colors">
            {language === 'es' ? 'Blog & Artículos' : 'Insights'}
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <span className="text-[#FF007A] font-semibold truncate max-w-xs">{post.title}</span>
        </motion.div>

        {/* Back Link Button */}
        <motion.button
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          onClick={() => navigate('/#blog')}
          className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-gray-400 hover:text-white mb-6 group cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-[#FF007A] group-hover:-translate-x-1 transition-transform" />
          <span>{language === 'es' ? 'VOLVER A TODOS LOS ARTÍCULOS' : 'BACK TO ALL INSIGHTS'}</span>
        </motion.button>

        {/* Header Badges: Category & Reading Time */}
        <div className="flex flex-wrap items-center gap-3 mb-4">
          {post.category && (
            <span className="px-3 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider bg-pink-500/15 text-pink-300 border border-pink-500/30">
              {post.category}
            </span>
          )}
          {post.readTime && (
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-white/5 text-gray-300 border border-white/10">
              <Clock className="w-3.5 h-3.5 text-pink-400" />
              <span>{post.readTime}</span>
            </span>
          )}
        </div>

        {/* Article Headline */}
        <motion.h1 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-display tracking-tight leading-tight mb-6"
        >
          {post.title}
        </motion.h1>

        {/* Author Bio & Date Bar with Share Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-4 border-y border-white/10 mb-8">
          <div className="flex items-center gap-3.5">
            {post.author.avatarUrl && (
              <img
                src={post.author.avatarUrl}
                alt={post.author.name}
                referrerPolicy="no-referrer"
                className="w-11 h-11 rounded-full object-cover border-2 border-pink-500/40"
              />
            )}
            <div>
              <p className="text-sm font-bold text-white leading-snug">{post.author.name}</p>
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <span>{post.author.role}</span>
                <span>•</span>
                <time dateTime={post.publishedDate} className="font-mono text-gray-300">
                  {formatDate(post.publishedDate)}
                </time>
              </div>
            </div>
          </div>

          {/* Share Buttons */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={handleCopyLink}
              title="Copy link"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-gray-300 hover:text-white transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">{language === 'es' ? 'Copiado' : 'Copied'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-gray-400" />
                  <span>{language === 'es' ? 'Copiar Enlace' : 'Copy Link'}</span>
                </>
              )}
            </button>

            <button
              onClick={handleShareTwitter}
              title="Share on X / Twitter"
              className="p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <span className="text-xs font-bold">𝕏</span>
            </button>

            <button
              onClick={handleShareLinkedIn}
              title="Share on LinkedIn"
              className="px-2.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
            >
              in
            </button>
          </div>
        </div>

        {/* Featured Cover Image */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden border border-white/10 shadow-2xl mb-12 bg-black/40"
        >
          <img
            src={post.coverImage}
            alt={post.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09030e] via-transparent to-transparent opacity-60" />
        </motion.div>

        {/* Excerpt Lead Paragraph */}
        <div className="p-6 rounded-2xl bg-gradient-to-r from-pink-500/10 via-purple-500/5 to-transparent border-l-4 border-[#FF007A] mb-10">
          <p className="text-base sm:text-lg text-gray-200 font-medium leading-relaxed italic">
            "{post.excerpt}"
          </p>
        </div>

        {/* Markdown Rendered Article Body */}
        <article className="prose prose-invert max-w-none prose-headings:font-display prose-headings:tracking-tight prose-headings:text-white prose-p:text-gray-300 prose-p:leading-relaxed prose-p:text-base sm:prose-p:text-lg prose-a:text-[#FF007A] prose-a:underline hover:prose-a:text-pink-300 prose-blockquote:border-l-4 prose-blockquote:border-[#FF007A] prose-blockquote:bg-white/5 prose-blockquote:py-2 prose-blockquote:px-4 prose-blockquote:rounded-r-xl prose-blockquote:italic prose-li:text-gray-300 prose-hr:border-white/10 prose-strong:text-white prose-strong:font-bold prose-code:text-pink-300 prose-code:bg-white/5 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:before:content-none prose-code:after:content-none">
          <div className="markdown-body">
            <Markdown>{post.content}</Markdown>
          </div>
        </article>

        {/* Tags Row */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 pt-10 mt-12 border-t border-white/10">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-400 mr-2">
              {language === 'es' ? 'Temas Relacionados:' : 'Tagged:'}
            </span>
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full text-xs font-medium bg-white/5 text-gray-300 border border-white/10 hover:border-pink-500/40 transition-colors"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* High-Impact Production CTA Banner */}
        <div className="mt-16 p-8 sm:p-10 rounded-3xl bg-gradient-to-br from-[#1b0726] via-[#12051c] to-[#0a0210] border border-pink-500/30 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#FF007A]/15 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/20 text-pink-300 text-xs font-bold uppercase tracking-wider mb-3">
                <Sparkles className="w-3.5 h-3.5 text-[#FF007A]" />
                <span>{language === 'es' ? 'ELEVACIÓN VISUAL' : 'CINEMATIC IMPACT'}</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display mb-2">
                {language === 'es'
                  ? '¿Listo para producir contenido cinematográfico para tu marca?'
                  : 'Ready to produce category-defining brand films & reels?'}
              </h3>
              <p className="text-sm text-gray-400">
                {language === 'es'
                  ? 'Colabora directamente con nuestros directores y directores de fotografía para elevar la presencia de tu marca.'
                  : 'Collaborate directly with our directors to script, shoot, and deliver 4K cinematic assets within 72 hours.'}
              </p>
            </div>

            {onOpenBooking && (
              <button
                onClick={onOpenBooking}
                className="self-start md:self-auto btn-primary-gradient px-8 py-4 rounded-full text-xs sm:text-sm font-bold uppercase tracking-wider text-white shadow-xl shadow-pink-600/30 hover:scale-105 transition-transform cursor-pointer"
              >
                {language === 'es' ? 'RESERVAR LLAMADA' : 'BOOK A PRODUCTION CALL'}
              </button>
            )}
          </div>
        </div>

        {/* Related Articles Section */}
        {relatedPosts.length > 0 && (
          <div className="mt-20 pt-12 border-t border-white/10">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-bold text-white font-display">
                {language === 'es' ? 'Más Artículos & Análisis' : 'Related Insights'}
              </h3>
              <Link
                to="/#blog"
                className="flex items-center gap-1 text-xs font-bold text-[#FF007A] hover:text-pink-300 transition-colors uppercase tracking-wider"
              >
                <span>{language === 'es' ? 'Ver Todos' : 'View All'}</span>
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedPosts.map((related) => (
                <div
                  key={related.id}
                  onClick={() => navigate(`/blog/${related.slug}`)}
                  className="group bg-[#12061b]/80 hover:bg-[#180924] border border-white/10 hover:border-pink-500/40 rounded-2xl overflow-hidden transition-all duration-300 cursor-pointer flex flex-col"
                >
                  <div className="aspect-[16/10] overflow-hidden bg-black/40">
                    <img
                      src={related.coverImage}
                      alt={related.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-[10px] text-gray-400 font-mono mb-2">
                        <Calendar className="w-3 h-3 text-pink-400" />
                        <time dateTime={related.publishedDate}>{formatDate(related.publishedDate)}</time>
                      </div>
                      <h4 className="text-sm font-bold text-white group-hover:text-pink-300 transition-colors line-clamp-2 mb-2">
                        {related.title}
                      </h4>
                    </div>
                    <div className="flex items-center gap-1 text-xs font-bold text-[#FF007A] mt-3">
                      <span>{language === 'es' ? 'Leer' : 'Read'}</span>
                      <ArrowRight className="w-3 h-3" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

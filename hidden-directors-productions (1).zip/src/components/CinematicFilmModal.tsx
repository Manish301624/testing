import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  ChevronRight, 
  ChevronLeft, 
  CalendarCheck, 
  Film, 
  Sparkles, 
  Camera, 
  Share2, 
  Check,
  Clock,
  Layers
} from 'lucide-react';
import { WorkFilmItem } from '../types';
import { backdropBlurIn, modalContentEntrance } from '../utils/motionVariants';

interface CinematicFilmModalProps {
  films: WorkFilmItem[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (newIndex: number) => void;
  onOpenBooking: () => void;
  categoryName: string;
}

export const CinematicFilmModal: React.FC<CinematicFilmModalProps> = ({
  films,
  currentIndex,
  isOpen,
  onClose,
  onNavigate,
  onOpenBooking,
  categoryName
}) => {
  const currentFilm = films[currentIndex];

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false); // Unmuted since user intentionally clicked to watch!
  const [volume, setVolume] = useState<number>(0.85);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isBuffering, setIsBuffering] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  // Navigate to Next
  const handleNext = useCallback(() => {
    if (currentIndex < films.length - 1) {
      onNavigate(currentIndex + 1);
    } else {
      onNavigate(0); // Cycle to start
    }
  }, [currentIndex, films.length, onNavigate]);

  // Navigate to Prev
  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      onNavigate(currentIndex - 1);
    } else {
      onNavigate(films.length - 1); // Cycle to end
    }
  }, [currentIndex, films.length, onNavigate]);

  // Reset playback when currentFilm changes
  useEffect(() => {
    if (currentFilm && videoRef.current) {
      setCurrentTime(0);
      setIsPlaying(true);
      setIsBuffering(true);
      videoRef.current.currentTime = 0;
      videoRef.current.volume = volume;
      videoRef.current.muted = isMuted;

      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsBuffering(false))
          .catch((err) => {
            console.log('Autoplay audio policy restriction fallback:', err);
            // If browser blocks unmuted autoplay, mute and play
            if (videoRef.current) {
              videoRef.current.muted = true;
              setIsMuted(true);
              videoRef.current.play().catch(() => {});
            }
          });
      }
    }
  }, [currentFilm]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) {
      document.body.style.overflow = '';
      return;
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === ' ' || e.key === 'k' || e.key === 'K') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, handleNext, handlePrev, onClose]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    const newMuted = !isMuted;
    videoRef.current.muted = newMuted;
    setIsMuted(newMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      if (val === 0) {
        videoRef.current.muted = true;
        setIsMuted(true);
      } else if (isMuted) {
        videoRef.current.muted = false;
        setIsMuted(false);
      }
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      if (videoRef.current.duration && !duration) {
        setDuration(videoRef.current.duration);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setIsBuffering(false);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const seekTo = parseFloat(e.target.value);
    setCurrentTime(seekTo);
    if (videoRef.current) {
      videoRef.current.currentTime = seekTo;
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const mins = Math.floor(secs / 60);
    const remainder = Math.floor(secs % 60);
    return `${mins}:${remainder < 10 ? '0' : ''}${remainder}`;
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && currentFilm && (
        <motion.div
          id="cinematic-film-modal"
          variants={backdropBlurIn}
          initial="hidden"
          animate="visible"
          exit="exit"
          className="fixed inset-0 z-50 bg-[#06010a]/90 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto"
        >
          {/* Main Modal Container */}
          <motion.div
            ref={containerRef}
            variants={modalContentEntrance}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="relative w-full max-w-6xl bg-[#0f0717] border border-white/10 rounded-3xl overflow-hidden shadow-2xl shadow-pink-950/50 flex flex-col my-auto max-h-[95vh]"
          >
          {/* Modal Header Bar */}
          <div className="flex items-center justify-between px-5 sm:px-8 py-4 border-b border-white/10 bg-[#14081f]/80 backdrop-blur-md shrink-0">
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono uppercase tracking-wider text-pink-400 font-bold">
                {categoryName}
              </span>
              <span className="text-gray-600 hidden sm:inline">•</span>
              <div className="px-2.5 py-0.5 rounded-full bg-white/10 text-white text-xs font-mono font-medium">
                {currentIndex + 1} / {films.length}
              </div>
              {currentFilm.resolution && (
                <span className="hidden md:inline-block px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-pink-500/20 text-pink-300 border border-pink-500/30">
                  {currentFilm.resolution}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShare}
                aria-label="Share this film"
                className="p-2 rounded-full bg-white/5 text-gray-300 hover:text-white border border-white/10 hover:border-white/20 transition-all cursor-pointer"
                title="Copy link"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              </button>

              <button
                id="film-modal-close-btn"
                onClick={onClose}
                aria-label="Close Film Player (ESC)"
                className="p-2 rounded-full bg-white/10 hover:bg-pink-600/30 text-white border border-white/20 hover:border-pink-500/40 transition-all cursor-pointer group"
                title="Close Player (ESC)"
              >
                <X className="w-5 h-5 group-hover:rotate-90 transition-transform duration-200" />
              </button>
            </div>
          </div>

          {/* Scrollable Content Area */}
          <div className="overflow-y-auto flex-1 custom-scrollbar">
            {/* 16:9 Cinematic Video Player Canvas */}
            <div className="relative w-full aspect-video bg-black flex items-center justify-center group/player">
              <video
                ref={videoRef}
                src={currentFilm.videoUrl}
                poster={currentFilm.posterUrl}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onWaiting={() => setIsBuffering(true)}
                onPlaying={() => setIsBuffering(false)}
                onClick={togglePlay}
                loop
                playsInline
                className="w-full h-full object-cover cursor-pointer"
              />

              {/* Buffering Spinner */}
              {isBuffering && (
                <div className="absolute inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center pointer-events-none">
                  <div className="w-12 h-12 rounded-full border-3 border-pink-500/30 border-t-pink-500 animate-spin" />
                </div>
              )}

              {/* Center Play/Pause indicator on click */}
              {!isPlaying && !isBuffering && (
                <button
                  onClick={togglePlay}
                  aria-label="Play video"
                  className="absolute p-5 rounded-full bg-[#FF007A]/90 text-white shadow-2xl shadow-pink-600/50 hover:scale-110 active:scale-95 transition-all cursor-pointer"
                >
                  <Play className="w-8 h-8 fill-white translate-x-0.5" />
                </button>
              )}

              {/* Player Bottom Control Bar (Glassmorphic) */}
              <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-95 group-hover/player:opacity-100 transition-opacity flex flex-col gap-2">
                {/* Timeline Scrubber */}
                <div className="relative w-full flex items-center">
                  <input
                    type="range"
                    min={0}
                    max={duration || 100}
                    step={0.1}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full h-1.5 bg-white/20 hover:h-2 rounded-lg appearance-none cursor-pointer accent-[#FF007A] transition-all"
                  />
                </div>

                {/* Controls Row */}
                <div className="flex items-center justify-between text-white text-xs">
                  <div className="flex items-center gap-3 sm:gap-4">
                    {/* Play/Pause */}
                    <button
                      onClick={togglePlay}
                      aria-label={isPlaying ? 'Pause' : 'Play'}
                      className="p-1.5 rounded-lg hover:bg-white/10 text-white transition-colors cursor-pointer"
                    >
                      {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
                    </button>

                    {/* Mute / Volume */}
                    <div className="flex items-center gap-2 group/vol">
                      <button
                        onClick={toggleMute}
                        aria-label={isMuted ? 'Unmute' : 'Mute'}
                        className="p-1.5 rounded-lg hover:bg-white/10 text-white transition-colors cursor-pointer"
                      >
                        {isMuted || volume === 0 ? (
                          <VolumeX className="w-5 h-5 text-pink-400" />
                        ) : (
                          <Volume2 className="w-5 h-5" />
                        )}
                      </button>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={isMuted ? 0 : volume}
                        onChange={handleVolumeChange}
                        className="w-16 sm:w-20 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer accent-[#FF007A] hidden sm:inline"
                      />
                    </div>

                    {/* Time Counter */}
                    <div className="font-mono text-gray-300 text-[11px] sm:text-xs">
                      <span>{formatTime(currentTime)}</span>
                      <span className="text-gray-500 mx-1">/</span>
                      <span>{formatTime(duration)}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Resolution Pill */}
                    <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] font-mono uppercase font-bold text-gray-300 hidden sm:inline">
                      {currentFilm.resolution || '4K UHD'}
                    </span>

                    {/* Fullscreen */}
                    <button
                      onClick={toggleFullscreen}
                      aria-label="Toggle Fullscreen"
                      className="p-1.5 rounded-lg hover:bg-white/10 text-white transition-colors cursor-pointer"
                    >
                      {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Project Details Panel Below Video */}
            <div className="p-6 sm:p-8 space-y-6">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 pb-6 border-b border-white/10">
                <div className="space-y-2 max-w-2xl">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-mono uppercase font-bold bg-pink-500/15 text-pink-400 border border-pink-500/30">
                      {currentFilm.type}
                    </span>
                    <span className="text-gray-500 text-xs">•</span>
                    <span className="flex items-center gap-1 text-xs text-gray-400 font-mono">
                      <Clock className="w-3.5 h-3.5 text-pink-400" />
                      <span>{currentFilm.duration}</span>
                    </span>
                    {currentFilm.year && (
                      <span className="text-xs text-gray-400 font-mono">
                        ({currentFilm.year})
                      </span>
                    )}
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                    {currentFilm.title}
                  </h2>

                  <p className="text-sm sm:text-base font-semibold text-pink-400">
                    Client: {currentFilm.client}
                  </p>

                  <p className="text-sm text-gray-300 font-light leading-relaxed pt-1">
                    {currentFilm.briefText}
                  </p>
                </div>

                {/* Action CTA and Project Cycling Controls */}
                <div className="shrink-0 flex flex-col sm:flex-row md:flex-col gap-3 w-full md:w-auto">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenBooking();
                    }}
                    id="film-modal-book-cta-btn"
                    className="w-full px-6 py-3 rounded-full text-xs sm:text-sm font-bold tracking-wider text-white uppercase bg-gradient-to-r from-[#FF007A] to-[#D60065] shadow-lg shadow-pink-600/30 hover:opacity-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CalendarCheck className="w-4 h-4" />
                    <span>Book This Aesthetic</span>
                  </button>

                  <div className="flex items-center gap-2 w-full">
                    <button
                      onClick={handlePrev}
                      aria-label="Previous project"
                      className="flex-1 py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      <span>Previous</span>
                    </button>
                    <button
                      onClick={handleNext}
                      aria-label="Next project"
                      className="flex-1 py-2.5 px-3 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 hover:text-white border border-pink-500/30 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>Next Project</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Technical Specifications & Services Provided */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-mono uppercase font-bold text-gray-400">
                    <Layers className="w-3.5 h-3.5 text-pink-400" />
                    <span>Services & Disciplines Provided</span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {currentFilm.servicesProvided.map((service, sIdx) => (
                      <span
                        key={sIdx}
                        className="px-3 py-1 rounded-lg text-xs font-medium bg-white/5 text-gray-200 border border-white/10"
                      >
                        {service}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-mono uppercase font-bold text-gray-400">
                    <Camera className="w-3.5 h-3.5 text-pink-400" />
                    <span>Cinema Gear & Direction</span>
                  </div>
                  <div className="space-y-1.5 text-xs text-gray-300">
                    {currentFilm.director && (
                      <p>
                        <span className="text-gray-500">Director: </span>
                        <span className="font-semibold text-white">{currentFilm.director}</span>
                      </p>
                    )}
                    {currentFilm.gearUsed && (
                      <div className="flex items-center gap-1.5 flex-wrap pt-1">
                        {currentFilm.gearUsed.map((gear, gIdx) => (
                          <span
                            key={gIdx}
                            className="px-2 py-0.5 rounded bg-pink-500/10 text-pink-300 border border-pink-500/20 font-mono text-[11px]"
                          >
                            {gear}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
      )}
    </AnimatePresence>
  );
};

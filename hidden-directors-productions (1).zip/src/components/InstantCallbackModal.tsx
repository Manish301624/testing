import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, PhoneCall, User, Phone, CheckCircle2, Loader2, Sparkles } from 'lucide-react';
import { CallbackRequest } from '../types';
import { buildWhatsAppUrl, fetchConfiguredWhatsAppNumber, getInitialWhatsAppNumber, logWhatsAppInquiry } from '../utils/whatsapp';
import { backdropBlurIn, modalContentEntrance } from '../utils/motionVariants';

interface InstantCallbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (request: CallbackRequest) => void;
}

export const InstantCallbackModal: React.FC<InstantCallbackModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [submittedData, setSubmittedData] = useState<CallbackRequest | null>(null);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);

  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) {
        setWhatsappNumber(num);
      }
    });
    
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      isMounted = false;
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const resetAndClose = () => {
    setName('');
    setPhone('');
    setErrorMsg('');
    setSubmittedData(null);
    onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!name.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }

    const digits = phone.replace(/[^0-9]/g, '');
    if (!phone.trim() || digits.length < 7) {
      setErrorMsg('Please enter a valid phone number (at least 7 digits).');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/callback-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          phone: phone.trim()
        })
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit callback request.');
      }

      setSubmittedData(data.callback);
      if (onSuccess) {
        onSuccess(data.callback);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            variants={backdropBlurIn}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={resetAndClose}
            className="fixed inset-0 bg-black/85"
          />
          <motion.div
            id="instant-callback-modal-card"
            variants={modalContentEntrance}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="relative w-full max-w-md bg-[#130519] border border-pink-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-purple-950/80 overflow-hidden text-white z-10"
          >
            {/* Glow ambient accent */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-[#FF007A]/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="close-callback-modal-btn"
          onClick={resetAndClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submittedData ? (
          /* Confirmation Success State */
          <div className="text-center py-4 space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-400 font-mono">
                CALLBACK CONFIRMED
              </span>
              <h2 className="text-2xl font-bold text-white font-display mt-1">
                We'll Call You in 15 Minutes!
              </h2>
              <p className="text-xs text-gray-300 mt-2 max-w-sm mx-auto leading-relaxed">
                A creative director from Hidden Directors is reviewing your request now.
              </p>
            </div>

            <div className="bg-[#1c0825] p-4 rounded-2xl border border-white/10 text-left space-y-2 text-xs text-gray-300">
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-gray-400">Name:</span>
                <span className="font-semibold text-white">{submittedData.name}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-gray-400">Phone:</span>
                <span className="font-semibold text-pink-300">{submittedData.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Call ETA:</span>
                <span className="font-semibold text-emerald-400">Within 15 Mins</span>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="space-y-3 pt-2">
              <motion.a
                id="callback-whatsapp-connect-btn"
                href={buildWhatsAppUrl(
                  whatsappNumber,
                  `Hi Hidden Directors! I just requested an instant callback for ${submittedData.name} (${submittedData.phone}). Connecting here directly on WhatsApp as well.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  logWhatsAppInquiry(
                    'callback',
                    { sourceSection: 'Instant Callback Submission' },
                    `Hi Hidden Directors! I just requested an instant callback for ${submittedData.name} (${submittedData.phone}). Connecting here directly on WhatsApp as well.`,
                    { clientName: submittedData.name, clientPhone: submittedData.phone }
                  );
                }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-3 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/30 cursor-pointer transition-all border border-emerald-300/30"
              >
                <svg className="w-4 h-4 fill-current text-white" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.711 1.457h.005c6.554 0 11.89-5.335 11.893-11.893a11.82 11.82 0 00-3.488-8.414z"/>
                </svg>
                <span>Chat Instantly on WhatsApp</span>
              </motion.a>

              <button
                id="close-callback-success-btn"
                onClick={resetAndClose}
                className="w-full py-3 rounded-full bg-white/10 hover:bg-white/15 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Close & Return
              </button>
            </div>
          </div>
        ) : (
          /* Form Entry State (Name + Phone only) */
          <div>
            <div className="flex items-center gap-2 text-pink-400 mb-2">
              <PhoneCall className="w-5 h-5 text-[#FF007A]" />
              <span className="text-[11px] font-bold uppercase tracking-widest">
                RAPID RESPONSE
              </span>
            </div>

            <h2 className="text-2xl font-bold font-display text-white">
              Request Instant Callback
            </h2>
            <p className="text-xs text-gray-400 mt-1.5 leading-relaxed">
              Skip the scheduling form. Share your contact details and our senior director will call you directly in 15 minutes.
            </p>

            {errorMsg && (
              <div className="mt-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-medium">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              {/* Name Field */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Your Full Name <span className="text-pink-400">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="callback-input-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Vikram Singhania"
                    className="w-full bg-[#1e0a29] border border-white/15 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-pink-500 transition-colors"
                  />
                </div>
              </div>

              {/* Phone Field */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Phone Number <span className="text-pink-400">*</span>
                </label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="callback-input-phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full bg-[#1e0a29] border border-white/15 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-pink-500 transition-colors font-mono text-sm"
                  />
                </div>
                <p className="text-[10px] text-gray-400 mt-1">
                  We'll call this number directly — no automated bots or spam.
                </p>
              </div>

              <div className="pt-2">
                <button
                  id="submit-callback-request-btn"
                  type="submit"
                  disabled={loading}
                  className="w-full btn-primary-gradient py-3.5 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-xl shadow-pink-500/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 transition-opacity"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Connecting with Director...</span>
                    </>
                  ) : (
                    <>
                      <PhoneCall className="w-4 h-4" />
                      <span>Request 15-Min Callback</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-gray-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Available 10 AM – 10 PM IST
              </span>
              <a
                href={buildWhatsAppUrl(whatsappNumber, 'Hi, I need an instant callback for my shoot.')}
                target="_blank"
                rel="noopener noreferrer"
                className="text-pink-400 hover:text-pink-300 font-semibold underline cursor-pointer"
              >
                Or WhatsApp Us
              </a>
            </div>
          </div>
        )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

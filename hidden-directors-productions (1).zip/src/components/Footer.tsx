import { CinematicImage } from "./CinematicImage";
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Instagram, 
  Linkedin, 
  Mail, 
  MapPin, 
  Sparkles, 
  CheckCircle2, 
  ArrowUpRight, 
  MessageCircle, 
  QrCode, 
  Smartphone, 
  Copy, 
  Check, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import QRCode from 'qrcode';
import { Logo } from './Logo';
import { 
  buildWhatsAppUrl, 
  getInitialWhatsAppNumber, 
  getContextualWhatsAppMessage, 
  fetchConfiguredWhatsAppNumber,
  WhatsAppContextType
} from '../utils/whatsapp';

interface FooterProps {
  onOpenBooking: () => void;
}

// Custom Behance Icon matching Lucide standard SVG styling
const BehanceIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    {/* 'B' letter shape */}
    <path d="M3 6h4.5c1.8 0 3 1 3 2.5 0 1.2-.8 2-2 2.3 1.5.3 2.5 1.4 2.5 2.8 0 1.8-1.5 3-3.8 3H3V6z" />
    <path d="M3 11.5h4.5" />
    <path d="M3 16.6h5" />
    {/* 'e' letter shape */}
    <path d="M14 13.5h7c0-2.5-1.8-4.5-4.5-4.5S12 11 12 13.5s2 4.5 4.8 4.5c2 0 3.5-1 4-2.5" />
    {/* 'e' top bar */}
    <path d="M14 7h6" />
  </svg>
);

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);
  const [qrContext, setQrContext] = useState<WhatsAppContextType>('general');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) setWhatsappNumber(num);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Compute active contextual message and URL for QR Code
  const activeQrMessage = React.useMemo(() => {
    return getContextualWhatsAppMessage(qrContext);
  }, [qrContext]);

  const activeQrUrl = React.useMemo(() => {
    return buildWhatsAppUrl(whatsappNumber, activeQrMessage);
  }, [whatsappNumber, activeQrMessage]);

  // Generate QR Code data URL whenever activeQrUrl changes
  useEffect(() => {
    let isMounted = true;
    QRCode.toDataURL(activeQrUrl, {
      width: 320,
      margin: 1.5,
      color: {
        dark: '#120419',
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'M'
    })
      .then((url) => {
        if (isMounted) setQrDataUrl(url);
      })
      .catch((err) => {
        console.error('Failed to generate QR Code in footer', err);
      });

    return () => {
      isMounted = false;
    };
  }, [activeQrUrl]);

  const handleCopyLink = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(activeQrUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setTimeout(() => {
      setSubscribed(false);
      setEmail('');
    }, 4000);
  };

  const socialLinks = [
    {
      name: 'Instagram',
      handle: '@hiddendirectors',
      label: 'Behind-The-Scenes & Reels',
      href: 'https://instagram.com/hiddendirectors',
      icon: Instagram,
      accent: 'hover:border-pink-500/60 hover:shadow-[0_0_20px_rgba(255,0,122,0.3)] hover:text-pink-400',
      badge: '180K+ Views',
    },
    {
      name: 'LinkedIn',
      handle: 'Hidden Directors Productions',
      label: 'Agency Insights & Retainers',
      href: 'https://linkedin.com/company/hidden-directors',
      icon: Linkedin,
      accent: 'hover:border-blue-500/60 hover:shadow-[0_0_20px_rgba(59,130,246,0.3)] hover:text-blue-400',
      badge: 'Corporate Network',
    },
    {
      name: 'Behance',
      handle: 'Hidden Directors Studio',
      label: 'Cinema Stills & Moodboards',
      href: 'https://behance.net/hiddendirectors',
      icon: BehanceIcon,
      accent: 'hover:border-purple-500/60 hover:shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:text-purple-400',
      badge: 'Curated Portfolio',
    },
  ];

  return (
    <footer className="w-full bg-[#07020b] border-t border-white/10 pt-16 pb-12 relative overflow-hidden text-gray-400">
      {/* Background glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-40 bg-pink-900/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Dedicated Social Media Spotlight Bar */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.55, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="mb-12 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#170522]/90 via-[#100318]/90 to-[#170522]/90 border border-white/10 backdrop-blur-md shadow-2xl"
        >
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-white/5">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/20 text-pink-400 text-xs font-bold uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Connect With The Studio</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-display">
                Follow Our Creative Production Journey
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-gray-400 max-w-md">
              Explore daily director breakdowns, cinema-grade color grading tests, and high-impact reel case studies across our official channels.
            </p>
          </div>

          {/* Clickable Social Platform Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6">
            {socialLinks.map((social, idx) => {
              const IconComp = social.icon;
              return (
                <motion.a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Visit our ${social.name} page`}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: idx * 0.08 }}
                  className={`group relative flex items-center justify-between p-4 rounded-2xl bg-[#0f0417] border border-white/10 transition-all duration-300 ${social.accent}`}
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-white/5 group-hover:bg-white/10 flex items-center justify-center text-white transition-colors border border-white/10">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-bold text-white group-hover:text-pink-300 transition-colors">
                          {social.name}
                        </span>
                        <span className="text-[10px] font-medium text-gray-400 px-1.5 py-0.5 rounded bg-white/5">
                          {social.badge}
                        </span>
                      </div>
                      <span className="text-[11px] text-gray-400 block group-hover:text-gray-300 transition-colors">
                        {social.handle}
                      </span>
                    </div>
                  </div>

                  <div className="w-7 h-7 rounded-full bg-white/5 group-hover:bg-white/15 flex items-center justify-center text-gray-400 group-hover:text-white transition-all transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </div>
                </motion.a>
              );
            })}
          </div>
        </motion.div>

        {/* Dedicated Contextual WhatsApp QR Code Mobile Handover Card */}
        <motion.div
          id="whatsapp-qr-handover"
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.55, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="mb-14 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#0c1f15]/90 via-[#100318]/95 to-[#1a0823]/90 border border-[#25D366]/30 backdrop-blur-md shadow-2xl relative overflow-hidden"
        >
          {/* Subtle background ambient pulse */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Column: Context Selection & Live Message Preview */}
            <div className="lg:col-span-8 space-y-5">
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Instant Mobile-to-Mobile Handover</span>
                </span>
                <span className="inline-flex items-center gap-1.5 text-xs text-gray-400">
                  <Smartphone className="w-3.5 h-3.5 text-pink-400" />
                  <span>Scan with any phone camera or WhatsApp</span>
                </span>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-display">
                  Scan to Continue Consultation on WhatsApp
                </h3>
                <p className="text-xs sm:text-sm text-gray-400 mt-1.5 max-w-2xl leading-relaxed">
                  Switch seamlessly from your laptop to your smartphone. Select your inquiry context below to dynamically update the QR code with a pre-filled prompt.
                </p>
              </div>

              {/* Context Selector Chips */}
              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-wider text-gray-400 block">
                  Select Inquiry Context:
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { key: 'general' as WhatsAppContextType, label: 'General Inquiry' },
                    { key: 'portfolio' as WhatsAppContextType, label: 'Portfolio Discussion' },
                    { key: 'booking' as WhatsAppContextType, label: 'Shoot Booking' },
                    { key: 'services' as WhatsAppContextType, label: 'Packages & Services' },
                    { key: 'process' as WhatsAppContextType, label: 'Production Roadmap' },
                    { key: 'reel' as WhatsAppContextType, label: 'Reels & Direction' },
                  ].map((tab) => {
                    const isActive = qrContext === tab.key;
                    return (
                      <button
                        key={tab.key}
                        onClick={() => setQrContext(tab.key)}
                        className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                          isActive
                            ? 'bg-[#25D366] text-[#0a1b10] shadow-lg shadow-emerald-500/30 scale-105'
                            : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 hover:border-emerald-500/40'
                        }`}
                      >
                        {isActive && <span className="w-1.5 h-1.5 rounded-full bg-[#0a1b10]" />}
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Live Pre-Filled Message Preview Box */}
              <div className="p-3.5 rounded-2xl bg-[#09030d]/80 border border-white/10 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-gray-400">
                  <span className="flex items-center gap-1.5 font-semibold text-emerald-400">
                    <MessageCircle className="w-3.5 h-3.5" />
                    Pre-filled Message Preview:
                  </span>
                  <span className="text-[10px] font-mono text-gray-500">Ready to Send</span>
                </div>
                <p className="text-xs text-gray-200 font-mono italic bg-white/5 p-2.5 rounded-xl border border-white/5 leading-relaxed">
                  "{activeQrMessage}"
                </p>
              </div>

              {/* Quick Actions */}
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  onClick={handleCopyLink}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-200 hover:text-white border border-white/10 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Link Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Direct WhatsApp Link</span>
                    </>
                  )}
                </button>

                <a
                  href={activeQrUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-xs font-bold text-emerald-300 hover:text-emerald-200 border border-emerald-500/30 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Test Flow in Browser</span>
                </a>
              </div>
            </div>

            {/* Right Column: High-Res QR Code Scanner Presentation */}
            <div className="lg:col-span-4 flex flex-col items-center justify-center">
              <div className="relative p-5 rounded-3xl bg-gradient-to-b from-[#14061a] to-[#0d0213] border-2 border-emerald-500/40 shadow-2xl shadow-emerald-950/60 group">
                
                {/* Viewfinder Decorative Corner Reticles */}
                <div className="absolute top-2.5 left-2.5 w-4 h-4 border-t-2 border-l-2 border-[#25D366] rounded-tl pointer-events-none" />
                <div className="absolute top-2.5 right-2.5 w-4 h-4 border-t-2 border-r-2 border-[#25D366] rounded-tr pointer-events-none" />
                <div className="absolute bottom-2.5 left-2.5 w-4 h-4 border-b-2 border-l-2 border-[#25D366] rounded-bl pointer-events-none" />
                <div className="absolute bottom-2.5 right-2.5 w-4 h-4 border-b-2 border-r-2 border-[#25D366] rounded-br pointer-events-none" />

                {/* QR Canvas / Image Render */}
                <div className="relative bg-white p-3 rounded-2xl shadow-inner flex items-center justify-center">
                  {qrDataUrl ? (
                    <img
                      src={qrDataUrl}
                      alt="WhatsApp Contextual QR Code"
                      className="w-48 h-48 sm:w-52 sm:h-52 object-contain select-none"
                    />
                  ) : (
                    <div className="w-48 h-48 sm:w-52 sm:h-52 flex items-center justify-center text-gray-400 text-xs font-mono">
                      Generating QR...
                    </div>
                  )}

                  {/* Center WhatsApp Mini Badge */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-10 h-10 rounded-full bg-[#25D366] border-2 border-white flex items-center justify-center shadow-lg">
                      <MessageCircle className="w-5 h-5 text-white fill-white" />
                    </div>
                  </div>
                </div>

                {/* Status bar below QR */}
                <div className="mt-3.5 flex items-center justify-between text-[11px] text-gray-400 px-1">
                  <span className="flex items-center gap-1.5 font-bold text-gray-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Live WhatsApp Bridge
                  </span>
                  <span className="font-mono text-emerald-400 font-semibold uppercase text-[10px]">
                    {qrContext}
                  </span>
                </div>
              </div>

              <span className="text-[11px] text-gray-400 mt-3 text-center flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-pink-400" />
                Auto-opens WhatsApp app instantly
              </span>
            </div>

          </div>
        </motion.div>

        {/* Main Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.55, delay: 0.1, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10"
        >
          
          {/* Col 1 & 2: Brand Identity */}
          <div className="lg:col-span-2 space-y-4">
            <a href="#home" aria-label="Hidden Directors Productions Home" className="inline-block transition-transform duration-200 hover:scale-[1.02]">
              <Logo className="h-10 sm:h-11 w-auto text-white" />
            </a>

            <p className="text-xs sm:text-sm text-gray-400 leading-relaxed max-w-sm">
              We craft cinematic brand films, high-converting social reels, architectural walkthroughs, and executive personal branding visuals that turn passive attention into commercial authority.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <a
                href="https://instagram.com/hiddendirectors"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="w-9 h-9 rounded-full bg-white/5 hover:bg-pink-600/30 text-gray-300 hover:text-white flex items-center justify-center transition-all border border-white/10"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com/company/hidden-directors"
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
                className="w-9 h-9 rounded-full bg-white/5 hover:bg-pink-600/30 text-gray-300 hover:text-white flex items-center justify-center transition-all border border-white/10"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://behance.net/hiddendirectors"
                target="_blank"
                rel="noreferrer"
                aria-label="Behance"
                className="w-9 h-9 rounded-full bg-white/5 hover:bg-pink-600/30 text-gray-300 hover:text-white flex items-center justify-center transition-all border border-white/10"
              >
                <BehanceIcon className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 3: Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white font-display">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#home" className="hover:text-pink-300 transition-colors">Home</a></li>
              <li><a href="/about" className="hover:text-pink-300 transition-colors">About Us</a></li>
              <li><a href="#portfolio" className="hover:text-pink-300 transition-colors">Selected Work</a></li>
              <li><a href="#personal-branding" className="hover:text-pink-300 transition-colors">Personal Branding</a></li>
              <li>
                <a href="/#blog" className="hover:text-pink-300 transition-colors flex items-center gap-1.5 font-semibold text-pink-400">
                  <span>Insights & Blog</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-pink-500/20 border border-pink-500/30 uppercase">New</span>
                </a>
              </li>
              <li><a href="#reviews" className="hover:text-pink-300 transition-colors">Client Testimonials</a></li>
              <li><a href="#faq" className="hover:text-pink-300 transition-colors">FAQ & Process Details</a></li>
            </ul>
          </div>

          {/* Col 4: Production Disciplines */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white font-display">
              Services
            </h4>
            <ul className="space-y-2 text-xs">
              <li><span className="text-gray-300">Interiors & Architecture</span></li>
              <li><span className="text-gray-300">Cafés, Dining & Food Styling</span></li>
              <li><span className="text-gray-300">Fashion Editorial & Lookbooks</span></li>
              <li><span className="text-gray-300">High-Speed Commercial Ads</span></li>
              <li><span className="text-gray-300">Executive Social Presence</span></li>
            </ul>
          </div>

          {/* Col 5: Newsletter & Contact */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white font-display">
              Studio Dispatch
            </h4>
            <p className="text-xs text-gray-400">
              Get our monthly breakdown on visual hooks, viral reel structures & lighting formulas.
            </p>

            {subscribed ? (
              <div className="flex items-center gap-1.5 text-xs text-pink-300 font-semibold bg-pink-500/10 p-2.5 rounded-xl border border-pink-500/30">
                <CheckCircle2 className="w-4 h-4" />
                <span>Subscribed to Studio Dispatch!</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletter} className="flex gap-2">
                <input
                  type="email"
                  required
                  placeholder="name@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 bg-[#15071f] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-pink-500"
                />
                <button
                  type="submit"
                  className="btn-primary-gradient px-3 py-2 rounded-xl text-white hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}

            <div className="pt-2 text-xs text-gray-400 space-y-1.5">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3 h-3 text-pink-400" />
                <span>Delhi NCR • Mumbai, India</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Mail className="w-3 h-3 text-pink-400" />
                <a href="mailto:hello@hiddendirectors.com" className="hover:text-pink-300 transition-colors">
                  hello@hiddendirectors.com
                </a>
              </div>
              <div className="flex items-center gap-1.5">
                <MessageCircle className="w-3 h-3 text-emerald-400" />
                <a
                  href={buildWhatsAppUrl(whatsappNumber, getContextualWhatsAppMessage('general'))}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors flex items-center gap-1"
                >
                  <span>Chat on WhatsApp</span>
                  <ArrowUpRight className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

        </motion.div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <div>
            © {new Date().getFullYear()} Hidden Directors Productions. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-gray-300 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-gray-300 cursor-pointer">Terms of Production</span>
            <span className="hover:text-gray-300 cursor-pointer">Client NDA Policy</span>
          </div>
        </div>

      </div>
    </footer>
  );
};

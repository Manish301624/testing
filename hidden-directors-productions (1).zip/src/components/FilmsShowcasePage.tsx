import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'motion/react';
import { 
  Film, 
  ChevronRight, 
  Home, 
  Sparkles, 
  CalendarCheck, 
  ArrowRight, 
  RefreshCw, 
  Play, 
  AlertCircle,
  Clock,
  Camera,
  PhoneCall,
  SlidersHorizontal
} from 'lucide-react';
import { WorkFilmItem, WorkCategoryMeta } from '../types';
import { CinematicImage } from './CinematicImage';
import { getFilmsByCategory, getCategoryMeta } from '../data/workData';
import { CinematicFilmModal } from './CinematicFilmModal';
import { SectionDivider } from './SectionDivider';
import { useLanguage } from '../context/LanguageContext';
import { LoadingSpinner } from './LoadingSpinner';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { ScrollProgressBar } from './ScrollProgressBar';
import { containerStagger, staggerFadeIn, slideUp, fadeIn, scaleIn } from '../utils/motionVariants';

interface FilmsShowcasePageProps {
  onOpenBooking: () => void;
  onOpenCallback?: () => void;
}

export const FilmsShowcasePage: React.FC<FilmsShowcasePageProps> = ({
  onOpenBooking,
  onOpenCallback
}) => {
  const { category = 'interior-architecture' } = useParams<{ category: string }>();
  const { language } = useLanguage();

  const [films, setFilms] = useState<WorkFilmItem[]>([]);
  const [categoryMeta, setCategoryMeta] = useState<WorkCategoryMeta>(() => getCategoryMeta(category));
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Modal State
  const [modalIndex, setModalIndex] = useState<number>(0);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  // Fetch films from backend API with fallback
  const fetchFilms = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/work/${category}/films`);
      if (!res.ok) {
        throw new Error(`Failed to load films showcase (${res.status})`);
      }
      const data = await res.json();
      setFilms(data.items || []);
      if (data.category) {
        setCategoryMeta(data.category);
      }
    } catch (err: any) {
      console.warn('Backend API fetch error, using local fallback:', err);
      const fallbackItems = getFilmsByCategory(category);
      const fallbackMeta = getCategoryMeta(category);
      setFilms(fallbackItems);
      setCategoryMeta(fallbackMeta);
      if (!fallbackItems || fallbackItems.length === 0) {
        setError(err.message || 'Failed to load films showcase');
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFilms();
    setActiveFilter('all');
  }, [category]);

  // Filter items
  const filteredFilms = activeFilter === 'all'
    ? films
    : films.filter(f => f.type.toLowerCase() === activeFilter.toLowerCase());

  // Infinite Scroll / Preloading State
  const [visibleCount, setVisibleCount] = useState<number>(6);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  const loadMoreEntry = useIntersectionObserver(loadMoreRef, { rootMargin: '600px' });

  // Reset visible count when filter or category changes
  useEffect(() => {
    setVisibleCount(6);
  }, [activeFilter, category]);

  // Handle intersection for preloading
  useEffect(() => {
    if (loadMoreEntry?.isIntersecting && visibleCount < filteredFilms.length) {
      const nextCount = Math.min(visibleCount + 6, filteredFilms.length);
      
      // We don't necessarily preload videos in background due to high bandwidth cost,
      // but we reveal the next batch of elements early which handles the perceived performance
      setVisibleCount(nextCount);
    }
  }, [loadMoreEntry?.isIntersecting, filteredFilms, visibleCount]);

  // Scroll to top on mount and category change
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [category]);

  // Dynamic filter tabs
  const filterCounts = {
    all: films.length,
    residential: films.filter(f => f.type.toLowerCase() === 'residential').length,
    commercial: films.filter(f => f.type.toLowerCase() === 'commercial').length,
    hospitality: films.filter(f => f.type.toLowerCase() === 'hospitality').length,
  };

  const filterTabs = [
    { id: 'all', label: language === 'es' ? 'Todos' : 'All', count: filterCounts.all },
    { id: 'residential', label: language === 'es' ? 'Residencial' : 'Residential', count: filterCounts.residential },
    { id: 'commercial', label: language === 'es' ? 'Comercial' : 'Commercial', count: filterCounts.commercial },
    { id: 'hospitality', label: language === 'es' ? 'Hospitalidad' : 'Hospitality', count: filterCounts.hospitality },
  ].filter(tab => tab.id === 'all' || tab.count > 0);

  const heroHeading = language === 'es' 
    ? categoryMeta.filmsHeroTitleEs 
    : categoryMeta.filmsHeroTitleEn;

  const heroDescription = language === 'es'
    ? categoryMeta.shortDescEs
    : categoryMeta.shortDescEn;

  // Distinct Category-Specific SEO Titles & Descriptions for Films
  const categoryName = language === 'es' && categoryMeta.nameEs ? categoryMeta.nameEs : categoryMeta.name;

  const seoTitle = language === 'es'
    ? `${categoryName} — Películas Cinematográficas, Comerciales y Recorridos | Hidden Directors`
    : `${categoryMeta.name} Brand Films, Commercials & Spatial Video | Hidden Directors Productions`;

  const getFilmsSeoDescription = (catSlug: string, isEs: boolean) => {
    switch (catSlug) {
      case 'interior-architecture':
        return isEs
          ? 'Recorridos arquitectónicos cinemáticos en 4K y películas espaciales de interiorismo con movimientos fluidos de cámara, luz natural y diseño sonoro inmersivo.'
          : 'Cinematic 4K spatial architectural walkthroughs and interior design films crafted with fluid camera motion, natural lighting, and immersive soundscapes.';
      case 'hospitality-food':
        return isEs
          ? 'Películas gastronómicas sensoriales, comerciales de restaurantes y perfiles de chefs de autor con ritmo cinematográfico y estética de alta cocina.'
          : 'Sensory dining films, culinary commercials, and chef profiles with master pacing and high-contrast cinema visuals for luxury hospitality destinations.';
      case 'ecommerce-product':
        return isEs
          ? 'Comerciales macro de alta velocidad, películas de producto y reels 9:16 diseñados para máxima conversión digital y prestigio de marca.'
          : 'High-speed macro commercial films, product motion campaigns, and viral 9:16 advertising reels designed for high digital conversion and prestige.';
      case 'personal-branding':
        return isEs
          ? 'Películas documentales de visión, series de liderazgo intelectual y comerciales ejecutivos dirigidos por Hidden Directors Productions.'
          : 'Documentary-style visionary profiles, thought-leadership video series, and executive brand commercials directed by Hidden Directors Productions.';
      default:
        return isEs
          ? `Visualiza las películas cinematográficas, comerciales y producciones en video de ${categoryName} dirigidas por Hidden Directors Productions.`
          : `Stream master 4K cinematic films, high-impact social reels, and spatial walkthroughs in ${categoryMeta.name} directed by Hidden Directors Productions.`;
    }
  };

  const seoDescription = getFilmsSeoDescription(category, language === 'es');
  const canonicalUrl = `https://hiddendirectors.com/work/${category}/films`;
  const ogImageUrl = films.length > 0 && films[0].posterUrl
    ? films[0].posterUrl
    : 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80';

  const filmsSchemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    'name': seoTitle,
    'description': seoDescription,
    'url': canonicalUrl,
    'publisher': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'url': 'https://hiddendirectors.com',
      'logo': 'https://hiddendirectors.com/logo.svg'
    },
    'about': categoryMeta.name,
    'genre': 'Cinematic Video Production',
    'keywords': `${categoryMeta.name} films, commercial video, architectural walkthrough, brand films, 4K production studio`
  };

  return (
    <div id="films-showcase" className="min-h-screen bg-[#09030e] text-[#F3F4F6] pt-24 pb-20 selection:bg-pink-600 selection:text-white">
      <ScrollProgressBar />
      {/* SEO Meta Tags */}
      <Helmet>
        <title>{seoTitle}</title>
        <meta name="description" content={seoDescription} />
        <meta name="keywords" content={`${categoryMeta.name} films, commercials, brand film production, architectural video, commercial reels, 4K cinema visuals, Hidden Directors`} />

        {/* Open Graph / Facebook */}
        <meta property="og:type" content="video.movie" />
        <meta property="og:title" content={seoTitle} />
        <meta property="og:description" content={seoDescription} />
        <meta property="og:image" content={ogImageUrl} />
        <meta property="og:image:alt" content={`${categoryMeta.name} Films by Hidden Directors`} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={seoTitle} />
        <meta name="twitter:description" content={seoDescription} />
        <meta name="twitter:image" content={ogImageUrl} />
        <meta name="twitter:image:alt" content={`${categoryMeta.name} Film Showcase`} />

        {/* Canonical Link */}
        <link rel="canonical" href={canonicalUrl} />

        {/* Schema.org Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(filmsSchemaJsonLd)}
        </script>
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav 
          id="films-breadcrumbs"
          aria-label="Breadcrumbs"
          className="flex items-center gap-2 text-xs text-gray-400 py-3 mb-4 overflow-x-auto whitespace-nowrap"
        >
          <Link to="/" className="hover:text-white transition-colors flex items-center gap-1">
            <Home className="w-3.5 h-3.5 text-pink-400" />
            <span>Home</span>
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <Link to="/#portfolio" className="hover:text-white transition-colors">
            Our Work
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <span className="text-gray-300 font-medium">
            {categoryMeta.name}
          </span>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <span className="text-pink-400 font-semibold">
            {language === 'es' ? 'Películas' : "Film's"}
          </span>
        </nav>

        {/* Page Hero Header */}
        <motion.header 
          variants={slideUp}
          initial="hidden"
          animate="visible"
          className="relative pt-4 pb-12 border-b border-white/10 mb-10"
        >
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/20 text-pink-300 text-xs font-mono font-bold tracking-wider uppercase">
                <Film className="w-3.5 h-3.5 text-[#FF007A]" />
                <span>Cinematic Video Showcase</span>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-[1.15]">
                {heroHeading}
              </h1>

              <p className="text-base sm:text-lg text-gray-300 font-light leading-relaxed">
                {heroDescription}
              </p>
            </div>

            {/* Switch to Photography Button */}
            <div className="shrink-0 flex items-center gap-3">
              <Link
                to={`/work/${category}/photography`}
                className="group flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/5 hover:bg-[#FF007A]/15 border border-white/10 hover:border-[#FF007A]/40 text-xs sm:text-sm font-semibold text-gray-300 hover:text-white transition-all cursor-pointer shadow-sm"
              >
                <span>Switch to {categoryMeta.name} Photography</span>
                <ArrowRight className="w-3.5 h-3.5 text-pink-400 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>

          {/* Filter Bar & Layout Controls */}
          <div className="mt-8 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-1.5 flex-wrap">
              <SlidersHorizontal className="w-3.5 h-3.5 text-gray-500 mr-1 hidden sm:inline" />
              {filterTabs.map((tab) => {
                const isActive = activeFilter === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveFilter(tab.id)}
                    className={`relative px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      isActive 
                        ? 'text-white bg-[#FF007A] shadow-lg shadow-pink-600/30' 
                        : 'text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/5'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                      isActive ? 'bg-black/30 text-white' : 'bg-white/10 text-gray-400'
                    }`}>
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="text-xs text-gray-400 font-mono flex items-center gap-3">
              <span>Showing {filteredFilms.length} {filteredFilms.length === 1 ? 'Production' : 'Productions'}</span>
              <span className="hidden md:inline text-gray-600">•</span>
              <span className="hidden md:inline">Click card for unmuted cinema player</span>
            </div>
          </div>
        </motion.header>

        <SectionDivider />

        {/* Loading State: Centered Minimalist Loading Spinner */}
        {isLoading && (
          <LoadingSpinner 
            fullScreen={false} 
            size="md" 
            message="PREPARING CINEMATIC ARCHIVE" 
          />
        )}

        {/* Error State */}
        {!isLoading && error && films.length === 0 && (
          <div className="py-20 text-center max-w-md mx-auto space-y-4">
            <div className="w-14 h-14 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mx-auto text-rose-400">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold text-white">Unable to Load Films</h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              {error}. Please check your connection or retry.
            </p>
            <button
              onClick={fetchFilms}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/40 text-pink-300 font-semibold text-xs transition-all cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Retry Loading Showcase</span>
            </button>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !error && filteredFilms.length === 0 && (
          <div className="py-24 text-center max-w-lg mx-auto space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-pink-400">
              <Film className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-white">
                {language === 'es' ? 'Próximamente' : 'Films Coming Soon'}
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                Our directors are currently wrapping post-production and color grading for this category.
              </p>
            </div>
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={onOpenBooking}
                className="w-full sm:w-auto px-6 py-3 rounded-full text-xs font-bold text-white bg-gradient-to-r from-[#FF007A] to-[#D60065] shadow-lg shadow-pink-600/30 cursor-pointer"
              >
                Inquire About a Commissioned Film
              </button>
              <Link
                to="/#portfolio"
                className="w-full sm:w-auto px-5 py-3 rounded-full text-xs font-semibold text-gray-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
              >
                Browse All Portfolio Reels
              </Link>
            </div>
          </div>
        )}

        {/* Video Cards Grid */}
        <div className="pb-24">
          {!isLoading && filteredFilms.length > 0 && (
            <>
              <motion.div 
                id="films-showcase-grid"
                variants={containerStagger}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7"
              >
                {filteredFilms.slice(0, visibleCount).map((film, index) => (
                  <FilmProjectCard
                    key={film.id}
                    film={film}
                    index={index}
                    onClick={() => {
                      setModalIndex(index);
                      setIsModalOpen(true);
                    }}
                  />
                ))}
              </motion.div>
              
              {/* Intersection Observer Sentinel for Infinite Scroll */}
              {visibleCount < filteredFilms.length && (
                <div ref={loadMoreRef} className="h-10 w-full mt-10 pointer-events-none" aria-hidden="true" />
              )}
            </>
          )}
        </div>

        {/* Bottom CTA Section */}
        <motion.section 
          id="films-bottom-cta"
          variants={slideUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="mt-24 rounded-3xl bg-gradient-to-br from-[#180820] via-[#100316] to-[#07010b] border border-pink-500/20 p-8 sm:p-12 relative overflow-hidden shadow-2xl shadow-pink-950/40"
        >
          <div className="absolute top-0 right-0 w-80 h-80 bg-pink-500/10 rounded-full blur-[90px] pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-500/10 rounded-full blur-[90px] pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/15 border border-pink-500/30 text-pink-300 text-xs font-mono font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-[#FF007A]" />
              <span>Full-Stack Cinema Production</span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
              Love what you see? <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-pink-400 via-rose-300 to-white bg-clip-text text-transparent">
                Let's create yours.
              </span>
            </h2>

            <p className="text-sm sm:text-base text-gray-300 leading-relaxed font-light">
              Elevate your architectural spaces or commercial products with cinema-grade motion picture storytelling, HDR color grading, and perpetual commercial licensing.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2">
              <button
                id="films-cta-book-btn"
                onClick={onOpenBooking}
                className="w-full sm:w-auto px-7 py-3.5 rounded-full text-xs sm:text-sm font-bold tracking-wider text-white uppercase bg-gradient-to-r from-[#FF007A] to-[#D60065] hover:opacity-95 shadow-xl shadow-pink-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <CalendarCheck className="w-4 h-4" />
                <span>{language === 'es' ? 'RESERVAR LLAMADA DE PRODUCCIÓN' : 'BOOK A PRODUCTION CALL'}</span>
              </button>

              {onOpenCallback && (
                <button
                  id="films-cta-callback-btn"
                  onClick={onOpenCallback}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-full text-xs sm:text-sm font-bold tracking-wider text-gray-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/15 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <PhoneCall className="w-4 h-4 text-pink-400" />
                  <span>15-Min Quick Consultation</span>
                </button>
              )}
            </div>
          </div>
        </motion.section>
      </div>

      {/* Cinematic Modal Player */}
      <CinematicFilmModal
        films={filteredFilms}
        currentIndex={modalIndex}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onNavigate={(newIdx) => setModalIndex(newIdx)}
        onOpenBooking={onOpenBooking}
        categoryName={categoryMeta.name}
      />
    </div>
  );
};

/**
 * Sub-component for individual video project card with Intersection Observer autoplay/pause
 */
interface FilmProjectCardProps {
  film: WorkFilmItem;
  index: number;
  onClick: () => void;
}

const FilmProjectCard: React.FC<FilmProjectCardProps> = ({ film, index, onClick }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const [isIntersecting, setIsIntersecting] = useState<boolean>(false);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);
  const [isHovered, setIsHovered] = useState<boolean>(false);

  // Intersection Observer for autoplay when visible and pause when scrolled out of viewport
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsIntersecting(true);
            if (videoRef.current) {
              videoRef.current.play().catch(() => {});
            }
          } else {
            setIsIntersecting(false);
            if (videoRef.current) {
              videoRef.current.pause();
            }
          }
        });
      },
      { threshold: 0.25 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <motion.div
      ref={cardRef}
      variants={staggerFadeIn}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-50px' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      data-cursor="play"
      className="group relative rounded-3xl overflow-hidden border border-white/10 bg-[#12071a] cursor-pointer shadow-xl hover:shadow-2xl hover:shadow-pink-950/40 transition-all duration-300 flex flex-col"
    >
      {/* Aspect-Ratio Video Container */}
      <div className="relative aspect-video sm:aspect-[16/10] w-full overflow-hidden bg-black/60">
        {/* Poster Image while video loads or when offscreen */}
        <CinematicImage
          src={film.posterUrl}
          alt={film.title}
          loading="lazy"
          containerClassName={`absolute inset-0 w-full h-full transition-opacity duration-700 pointer-events-none ${
            isLoaded ? 'opacity-0' : 'opacity-100'
          }`}
          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 pointer-events-none"
        />

        {/* Looping Muted Preview Video */}
        {isIntersecting && (
          <video
            ref={videoRef}
            src={film.videoUrl}
            poster={film.posterUrl}
            muted
            loop
            playsInline
            onLoadedData={() => setIsLoaded(true)}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          />
        )}

        {/* Dark Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#09030e] via-black/30 to-black/40 group-hover:from-[#09030e] group-hover:via-black/20 transition-all duration-300" />

        {/* Top Badges */}
        <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between z-10">
          <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-mono uppercase font-bold bg-pink-500/80 text-white shadow-md backdrop-blur-md">
            {film.type}
          </span>
          <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-mono font-medium bg-black/60 text-white border border-white/15 backdrop-blur-md">
            <Clock className="w-3 h-3 text-pink-400" />
            <span>{film.duration}</span>
          </span>
        </div>

        {/* Center Hover Play Button */}
        <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#FF007A]/90 text-white flex items-center justify-center shadow-xl shadow-pink-600/40 transform scale-90 opacity-80 group-hover:scale-100 group-hover:opacity-100 transition-all duration-300">
            <Play className="w-6 h-6 fill-white translate-x-0.5" />
          </div>
        </div>

        {/* Bottom Details Overlay on Card */}
        <div className="absolute bottom-0 left-0 right-0 p-5 z-10 space-y-1.5 transform group-hover:-translate-y-0.5 transition-transform duration-300">
          <div className="flex items-center justify-between text-xs text-pink-400 font-semibold">
            <span>{film.client}</span>
            {film.resolution && (
              <span className="text-[10px] font-mono text-gray-400">
                {film.resolution}
              </span>
            )}
          </div>
          <h3 className="text-base sm:text-lg font-bold text-white leading-snug group-hover:text-pink-100 transition-colors line-clamp-1">
            {film.title}
          </h3>
          <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed font-light">
            {film.briefText}
          </p>
        </div>
      </div>

      {/* Services tags footer inside card */}
      <div className="p-3.5 px-5 bg-[#0f0516] border-t border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-1.5 overflow-hidden">
          {film.servicesProvided.slice(0, 2).map((srv, idx) => (
            <span
              key={idx}
              className="text-[10.5px] text-gray-400 bg-white/5 px-2 py-0.5 rounded border border-white/5 whitespace-nowrap"
            >
              {srv}
            </span>
          ))}
          {film.servicesProvided.length > 2 && (
            <span className="text-[10px] text-pink-400 font-mono">
              +{film.servicesProvided.length - 2}
            </span>
          )}
        </div>
        <div className="text-[11px] font-bold text-pink-400 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
          <span>Watch</span>
          <ChevronRight className="w-3 h-3" />
        </div>
      </div>
    </motion.div>
  );
};

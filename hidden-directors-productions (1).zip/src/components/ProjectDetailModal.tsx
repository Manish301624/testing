import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { 
  X, Sparkles, CheckCircle, Eye, Share2, Check, FileText, 
  Layers, TrendingUp, Quote, Star, MessageCircle, ArrowRight,
  Award, Play, ExternalLink
} from 'lucide-react';
import { ProjectItem, ProjectMetric } from '../types';
import { CinematicImage } from './CinematicImage';
import { buildWhatsAppUrl, fetchConfiguredWhatsAppNumber, getInitialWhatsAppNumber, getContextualWhatsAppMessage, logWhatsAppInquiry } from '../utils/whatsapp';
import { backdropBlurIn, modalContentEntrance } from '../utils/motionVariants';

interface ProjectDetailModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onBookShoot: () => void;
}

// Animated Counter Component for Result Metrics
const MetricCounter: React.FC<{ metric: ProjectMetric }> = ({ metric }) => {
  const [displayValue, setDisplayValue] = useState<string>('0');
  const countRef = useRef<number>(0);

  useEffect(() => {
    // If numValue is provided, animate smoothly from 0 to numValue
    if (typeof metric.numValue === 'number') {
      const target = metric.numValue;
      const isDecimal = !Number.isInteger(target);
      const duration = 1400; // ms
      const startTime = performance.now();

      const updateCount = (currentTime: number) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(1, elapsed / duration);
        // Smooth ease-out cubic curve
        const easeProgress = 1 - Math.pow(1 - progress, 3);
        const currentVal = easeProgress * target;

        countRef.current = currentVal;
        const formatted = isDecimal ? currentVal.toFixed(1) : Math.round(currentVal).toString();
        setDisplayValue(formatted);

        if (progress < 1) {
          requestAnimationFrame(updateCount);
        } else {
          setDisplayValue(isDecimal ? target.toFixed(1) : target.toString());
        }
      };

      const animId = requestAnimationFrame(updateCount);
      return () => cancelAnimationFrame(animId);
    } else {
      // Fallback to static value if no numeric value is parsed
      setDisplayValue(metric.value);
    }
  }, [metric]);

  return (
    <div className="relative p-5 rounded-2xl bg-[#160620]/90 border border-pink-500/25 shadow-lg overflow-hidden group hover:border-pink-500/50 transition-all">
      <div className="absolute top-0 right-0 w-24 h-24 bg-pink-500/10 rounded-full blur-xl pointer-events-none group-hover:bg-pink-500/20 transition-all" />
      
      {/* Animated Counter Display */}
      <div className="flex items-baseline gap-0.5">
        {metric.prefix && (
          <span className="text-2xl sm:text-3xl font-extrabold text-[#FF007A] font-display">
            {metric.prefix}
          </span>
        )}
        <span className="text-3xl sm:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-pink-100 to-pink-300 font-display tracking-tight">
          {typeof metric.numValue === 'number' ? displayValue : metric.value}
        </span>
        {metric.suffix && (
          <span className="text-2xl sm:text-3xl font-extrabold text-[#FF5E62] font-display">
            {metric.suffix}
          </span>
        )}
      </div>

      {/* Label */}
      <div className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider mt-1.5 font-display">
        {metric.label}
      </div>

      {/* Subtext description */}
      {metric.subtext && (
        <p className="text-[11px] text-gray-400 mt-1 leading-relaxed">
          {metric.subtext}
        </p>
      )}
    </div>
  );
};

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onBookShoot
}) => {
  const navigate = useNavigate();
  const [copied, setCopied] = useState<boolean>(false);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);

  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) setWhatsappNumber(num);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!project) {
      document.body.style.overflow = '';
      return;
    }
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [project, onClose]);

  const handleShare = async () => {
    if (!project) return;
    let shareUrl = '';
    if (typeof window !== 'undefined') {
      try {
        shareUrl = `${window.location.origin}/project/${project.id}`;
      } catch {
        shareUrl = `https://hiddendirectors.com/project/${project.id}`;
      }
    }

    const shareData = {
      title: `${project.title} - ${project.client} | Case Study`,
      text: `Explore the "${project.title}" video production case study by Hidden Directors:`,
      url: shareUrl,
    };

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        if (navigator.canShare && !navigator.canShare(shareData)) {
          await navigator.share({ title: shareData.title, url: shareUrl });
        } else {
          await navigator.share(shareData);
        }
        setCopied(true);
        setTimeout(() => setCopied(false), 2400);
        return;
      } catch (err: any) {
        if (err?.name === 'AbortError') return;
      }
    }

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(shareUrl);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2400);
    } catch {
      // ignore
    }
  };

  const pageTitle = `${project?.title || ''} — ${project?.client || ''} | Case Study | Hidden Directors`;
  const pageDescription = `${project?.description || ''} Commercial visual case study by Hidden Directors Productions.`;
  const canonicalUrl = `https://hiddendirectors.com/project/${project?.id || ''}`;

  return (
    <AnimatePresence>
      {project && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          {/* Dynamic SEO Tags when Case Study Modal is active */}
          <Helmet>
            <title>{pageTitle}</title>
            <meta name="description" content={pageDescription} />
            <meta property="og:type" content="video.other" />
            <meta property="og:title" content={pageTitle} />
            <meta property="og:description" content={pageDescription} />
            <meta property="og:image" content={project.thumbnailUrl} />
            <meta property="og:url" content={canonicalUrl} />
            <meta name="twitter:card" content="summary_large_image" />
            <meta name="twitter:title" content={pageTitle} />
            <meta name="twitter:description" content={pageDescription} />
            <meta name="twitter:image" content={project.thumbnailUrl} />
            <link rel="canonical" href={canonicalUrl} />
          </Helmet>

          {/* Backdrop with framer-motion blur-in */}
          <motion.div
            variants={backdropBlurIn}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={onClose}
            className="fixed inset-0 bg-black/85"
          />

          {/* Modal Container */}
          <motion.div
            variants={modalContentEntrance}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="relative w-full max-w-4xl max-h-[90vh] rounded-3xl bg-[#110416] border border-pink-500/30 overflow-y-auto shadow-[0_25px_70px_rgba(255,0,122,0.2)] my-auto z-10 custom-scrollbar"
          >
          {/* Top Control Bar */}
          <div className="sticky top-0 z-30 flex items-center justify-between px-6 py-4 bg-[#110416]/95 backdrop-blur-md border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-pink-500 animate-pulse" />
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wider font-mono">
                CASE STUDY SPOTLIGHT • {project.category}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onClose();
                  navigate(`/project/${project.id}`);
                }}
                title="Open dedicated project page"
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/10 hover:border-pink-500/50 bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-200 hover:text-white transition-all cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5 text-pink-400" />
                <span className="font-mono text-[11px]">FULL PAGE</span>
              </button>

              <button
                onClick={handleShare}
                title="Share case study"
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border text-xs font-bold transition-all cursor-pointer ${
                  copied
                    ? 'bg-emerald-950/80 border-emerald-500/60 text-emerald-300'
                    : 'bg-white/5 hover:bg-white/10 border-white/20 hover:border-pink-500/50 text-gray-200 hover:text-white'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="font-mono text-[11px]">COPIED</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5 text-pink-400" />
                    <span className="font-mono text-[11px]">SHARE</span>
                  </>
                )}
              </button>

              <button
                onClick={onClose}
                aria-label="Close modal"
                className="p-1.5 rounded-full bg-white/5 hover:bg-white/15 text-white border border-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Hero Video / Image Showcase */}
          <div className="relative aspect-video w-full bg-black">
            {project.videoUrl ? (
              <video
                src={project.videoUrl}
                poster={project.thumbnailUrl}
                controls
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
            ) : (
              <CinematicImage
                src={project.thumbnailUrl}
                alt={project.title}
                containerClassName="absolute inset-0 w-full h-full"
                className="w-full h-full object-cover"
              />
            )}
          </div>

          {/* Body Content */}
          <div className="p-6 sm:p-8 space-y-10">
            
            {/* Title & Client Overview Section */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="flex flex-col md:flex-row md:items-start justify-between gap-6 pb-6 border-b border-white/10"
            >
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="px-3 py-1 rounded-full bg-pink-500/15 border border-pink-500/30 text-xs font-bold text-pink-300 uppercase tracking-wider">
                    {project.category}
                  </span>
                  <span className="text-xs font-semibold text-gray-400">
                    Year: {project.year}
                  </span>
                  {project.views && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-gray-300">
                      <Eye className="w-3.5 h-3.5 text-pink-400" />
                      <span>{project.views} views</span>
                    </span>
                  )}
                </div>

                <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display tracking-tight mt-1">
                  {project.title}
                </h1>
                
                <p className="text-sm font-semibold text-pink-300 mt-1">
                  Client: <span className="text-white font-bold">{project.client}</span>
                </p>

                <p className="text-sm text-gray-300 leading-relaxed mt-3 max-w-2xl">
                  {project.description}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row md:flex-col gap-3 shrink-0">
                <a
                  href={buildWhatsAppUrl(
                    whatsappNumber,
                    getContextualWhatsAppMessage('portfolio', { projectName: project.title })
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    logWhatsAppInquiry(
                      'portfolio',
                      { projectName: project.title, sourceSection: `Case Study: ${project.title}` },
                      getContextualWhatsAppMessage('portfolio', { projectName: project.title })
                    );
                  }}
                  className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-full border border-[#25D366]/40 bg-[#0e2418]/90 hover:bg-[#133623] text-emerald-300 hover:text-white text-xs font-bold transition-all shadow-md group cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 text-[#25D366] group-hover:scale-110 transition-transform" />
                  <span>WhatsApp Inquiry</span>
                </a>

                <button
                  onClick={() => {
                    onClose();
                    onBookShoot();
                  }}
                  className="btn-primary-gradient px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/30 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Request Similar Shoot</span>
                </button>
              </div>
            </motion.div>

            {/* Deliverables Pills */}
            {project.deliverables && project.deliverables.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.05 }}
              >
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                  Production Deliverables
                </h4>
                <div className="flex flex-wrap gap-2.5">
                  {project.deliverables.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-gray-200 hover:border-pink-500/40 transition-colors"
                    >
                      <CheckCircle className="w-3.5 h-3.5 text-pink-400 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* SECTION 1: THE BRIEF & CHALLENGE */}
            {project.briefText && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.45, ease: [0.21, 0.45, 0.27, 0.9] }}
                className="p-6 rounded-2xl bg-[#160620]/70 border border-pink-500/20 relative overflow-hidden"
              >
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-500/30">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-pink-300 uppercase tracking-widest">
                      Stage 01
                    </span>
                    <h3 className="text-lg font-bold text-white font-display">
                      The Challenge & Creative Brief
                    </h3>
                  </div>
                </div>

                <p className="text-sm text-gray-200 leading-relaxed pl-1 sm:pl-10 font-normal">
                  {project.briefText}
                </p>
              </motion.div>
            )}

            {/* SECTION 2: OUR PRODUCTION PROCESS */}
            {project.processSteps && project.processSteps.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.45, delay: 0.1, ease: [0.21, 0.45, 0.27, 0.9] }}
                className="space-y-4"
              >
                <div className="flex items-center gap-2.5 mb-4">
                  <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-500/30">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-pink-300 uppercase tracking-widest">
                      Stage 02
                    </span>
                    <h3 className="text-lg font-bold text-white font-display">
                      Our Production Process & Blueprint
                    </h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {project.processSteps.map((step, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.35, delay: idx * 0.08 }}
                      className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-pink-500/30 transition-all flex items-start gap-3.5"
                    >
                      <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-[#FF007A] to-[#FF5E62] text-white text-xs font-bold flex items-center justify-center shrink-0 shadow-md">
                        {idx + 1}
                      </div>
                      <p className="text-xs sm:text-sm text-gray-200 leading-relaxed font-normal">
                        {step}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* SECTION 3: MEASURABLE RESULTS & METRICS */}
            {project.resultMetrics && project.resultMetrics.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.45, delay: 0.15, ease: [0.21, 0.45, 0.27, 0.9] }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-500/30">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-pink-300 uppercase tracking-widest">
                        Stage 03
                      </span>
                      <h3 className="text-lg font-bold text-white font-display">
                        Measurable Impact & Key Results
                      </h3>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {project.resultMetrics.map((metric, idx) => (
                    <MetricCounter key={idx} metric={metric} />
                  ))}
                </div>
              </motion.div>
            )}

            {/* SECTION 4: CLIENT TESTIMONIAL QUOTE */}
            {project.clientQuote && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.45, delay: 0.2, ease: [0.21, 0.45, 0.27, 0.9] }}
                className="p-6 sm:p-7 rounded-2xl bg-gradient-to-r from-[#170522] to-[#12031a] border border-pink-500/30 shadow-xl relative overflow-hidden"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/30 text-[10px] font-bold text-pink-300 uppercase tracking-wider">
                    <Quote className="w-3 h-3 text-pink-400" />
                    <span>Client Verdict</span>
                  </div>

                  <div className="flex items-center text-[#FF007A]">
                    {[...Array(project.clientQuote.rating || 5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-[#FF007A]" />
                    ))}
                  </div>
                </div>

                <p className="text-sm sm:text-base text-gray-200 leading-relaxed italic font-normal">
                  &ldquo;{project.clientQuote.quote}&rdquo;
                </p>

                <div className="mt-5 pt-4 border-t border-white/10 flex items-center gap-3.5">
                  {project.clientQuote.avatarUrl && (
                    <img
                      src={project.clientQuote.avatarUrl}
                      alt={project.clientQuote.author}
                      referrerPolicy="no-referrer"
                      className="w-11 h-11 rounded-full object-cover border border-pink-500/40 shadow-md"
                    />
                  )}
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span>{project.clientQuote.author}</span>
                      <CheckCircle className="w-3.5 h-3.5 text-pink-400 shrink-0" />
                    </div>
                    <div className="text-xs text-gray-400">
                      {project.clientQuote.role} • <span className="text-pink-300 font-medium">{project.clientQuote.company || project.client}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Bottom CTA Banner */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-pink-900/30 via-[#190623] to-[#110416] border border-pink-500/40 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="text-base font-bold text-white font-display">
                  Ready for a similar visual production?
                </h4>
                <p className="text-xs text-gray-300 mt-0.5">
                  Book a direct 15-minute consultation to scope your campaign.
                </p>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onBookShoot();
                }}
                className="w-full sm:w-auto btn-primary-gradient px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book Shoot Consultation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </motion.div>
      </div>
      )}
    </AnimatePresence>
  );
};

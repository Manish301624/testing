import { CinematicImage } from "./CinematicImage";
import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Search, 
  Sparkles, 
  Calendar, 
  Clock, 
  ArrowRight, 
  Tag, 
  BookOpen, 
  SlidersHorizontal, 
  Film, 
  CheckCircle2,
  TrendingUp,
  Share2
} from 'lucide-react';
import { BlogPost } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface BlogPageProps {
  posts: BlogPost[];
  onOpenBooking?: () => void;
}

export const BlogPage: React.FC<BlogPageProps> = ({ posts, onOpenBooking }) => {
  const { language } = useLanguage();
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Production Strategy',
    'Cinematography',
    'Interiors & Architecture',
    'Personal Branding',
    'Audio & Post-Production'
  ];

  // Filter posts based on search query and category
  const filteredPosts = useMemo(() => {
    return posts.filter((post) => {
      const matchesCategory = selectedCategory === 'All' || 
        post.category?.toLowerCase() === selectedCategory.toLowerCase();

      const matchesSearch = searchQuery.trim() === '' || 
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.tags?.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchesCategory && matchesSearch;
    });
  }, [posts, selectedCategory, searchQuery]);

  const featuredPost = posts[0];
  const gridPosts = filteredPosts.length > 0 ? filteredPosts : [];

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString(language === 'es' ? 'es-ES' : 'en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  const blogTitle = language === 'es'
    ? 'Perspectivas Cinematográficas & Estrategia de Producción | Hidden Directors'
    : 'Cinematic Insights & Production Strategy | Hidden Directors';

  const blogDescription = language === 'es'
    ? 'Desgloses técnicos de dirección cinematográfica, iluminación comercial de alta velocidad, retención en 9:16 y marca personal para fundadores.'
    : 'Director-level breakdowns on high-speed commercial lighting, short-form reel retention, spatial architecture films, and founder personal branding.';

  const blogCanonicalUrl = 'https://hiddendirectors.com/blog';
  const blogOgImage = featuredPost?.coverImage || 'https://images.unsplash.com/photo-1518135714426-c18f5ffb6f4d?auto=format&fit=crop&w=1200&q=80';

  const blogSchemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Blog',
    'name': blogTitle,
    'description': blogDescription,
    'url': blogCanonicalUrl,
    'publisher': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'logo': 'https://hiddendirectors.com/logo.svg'
    }
  };

  return (
    <main id="blog-page" className="min-h-screen bg-[#07010c] text-gray-100 pt-28 pb-24 overflow-hidden relative">
      {/* Dynamic SEO Metadata via react-helmet-async */}
      <Helmet>
        <title>{blogTitle}</title>
        <meta name="description" content={blogDescription} />

        {/* OpenGraph / Facebook */}
        <meta property="og:type" content="blog" />
        <meta property="og:title" content={blogTitle} />
        <meta property="og:description" content={blogDescription} />
        <meta property="og:image" content={blogOgImage} />
        <meta property="og:image:alt" content="Cinematic Insights & Strategy" />
        <meta property="og:url" content={blogCanonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />

        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={blogTitle} />
        <meta name="twitter:description" content={blogDescription} />
        <meta name="twitter:image" content={blogOgImage} />
        <meta name="twitter:image:alt" content="Cinematic Insights & Strategy" />

        {/* Canonical */}
        <link rel="canonical" href={blogCanonicalUrl} />

        {/* Schema.org Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(blogSchemaJsonLd)}
        </script>
      </Helmet>

      {/* Atmospheric Background Ambient Blurs */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-pink-600/10 rounded-full blur-[160px] pointer-events-none -z-10" />
      <div className="absolute top-[600px] right-10 w-[450px] h-[350px] bg-purple-600/10 rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-2 text-xs text-gray-400">
          <Link to="/" className="hover:text-pink-400 transition-colors">
            {language === 'es' ? 'Inicio' : 'Home'}
          </Link>
          <span className="text-gray-600">/</span>
          <span className="text-pink-300 font-semibold">
            {language === 'es' ? 'Perspectivas & Blog' : 'Insights & Strategy'}
          </span>
        </nav>

        {/* Page Hero Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-3xl mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-pink-500/30 bg-pink-500/10 text-[11px] font-bold tracking-widest text-pink-300 uppercase mb-4 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#FF007A]" />
            <span>{language === 'es' ? 'EDITORIAL DE PRODUCCIÓN // 24 FPS' : 'DIRECTORS JOURNAL // 24 FPS'}</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white font-display tracking-tight leading-[1.1]">
            {language === 'es' ? 'Perspectivas, Cine & Estrategia' : 'Cinematic Insights & Strategy'}
          </h1>
          
          <p className="mt-4 text-base sm:text-lg text-gray-300 font-normal leading-relaxed">
            {language === 'es'
              ? 'Desgloses técnicos del set, psicología de retención en 9:16 y el arte de posicionar marcas de lujo a través de la dirección cinematográfica.'
              : 'Technical lighting breakdowns, 9:16 retention psychology, and the craft of establishing category dominance through commercial cinema direction.'}
          </p>
        </motion.div>

        {/* Search & Category Filter Ribbon */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10 pb-6 border-b border-white/10">
          
          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            {categories.map((cat) => {
              const isActive = selectedCategory.toLowerCase() === cat.toLowerCase();
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                    isActive
                      ? 'btn-primary-gradient text-white border-pink-500/60 shadow-md shadow-pink-500/20'
                      : 'bg-white/5 border-white/10 text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72 shrink-0">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={language === 'es' ? 'Buscar artículos...' : 'Search insights...'}
              className="w-full pl-10 pr-4 py-2 rounded-full bg-white/5 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-pink-500/60 focus:ring-1 focus:ring-pink-500/40 transition-all"
            />
          </div>
        </div>

        {/* Featured Post Spotlight (When looking at 'All' and no search query) */}
        {selectedCategory === 'All' && searchQuery === '' && featuredPost && (
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mb-14"
          >
            <div 
              onClick={() => navigate(`/blog/${featuredPost.slug}`)}
              className="group relative rounded-3xl bg-[#110519]/90 border border-white/10 hover:border-pink-500/50 p-5 sm:p-8 transition-all duration-300 backdrop-blur-md shadow-xl overflow-hidden cursor-pointer grid grid-cols-1 lg:grid-cols-12 gap-6 items-center"
            >
              {/* Cover Media Spotlight */}
              <div className="lg:col-span-7 relative aspect-[16/10] sm:aspect-[16/9] rounded-2xl overflow-hidden bg-black/50 border border-white/10">
                <img 
                  src={featuredPost.coverImage} 
                  alt={featuredPost.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-pink-500 text-white shadow-lg">
                    {language === 'es' ? 'ARTÍCULO DESTACADO' : 'FEATURED DEEP DIVE'}
                  </span>
                </div>
              </div>

              {/* Text Info */}
              <div className="lg:col-span-5 flex flex-col justify-between h-full py-2">
                <div>
                  <div className="flex items-center gap-3 text-xs text-gray-400 mb-3">
                    <span className="text-pink-400 font-bold font-mono uppercase tracking-wider">
                      {featuredPost.category}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {featuredPost.readTime}
                    </span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display leading-snug group-hover:text-pink-200 transition-colors mb-3">
                    {featuredPost.title}
                  </h2>

                  <p className="text-sm text-gray-300 leading-relaxed line-clamp-3 mb-4">
                    {featuredPost.excerpt}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    {featuredPost.author.avatarUrl ? (
                      <img
                        src={featuredPost.author.avatarUrl}
                        alt={featuredPost.author.name}
                        className="w-8 h-8 rounded-full border border-pink-500/40 object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-pink-600/30 border border-pink-500/40 flex items-center justify-center text-xs font-bold text-pink-300">
                        {featuredPost.author.name.charAt(0)}
                      </div>
                    )}
                    <div className="text-left">
                      <div className="text-xs font-bold text-white leading-tight">
                        {featuredPost.author.name}
                      </div>
                      <div className="text-[10px] text-gray-400">
                        {featuredPost.author.role}
                      </div>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-pink-400 group-hover:translate-x-1 transition-transform">
                    <span>Read Article</span>
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {gridPosts.map((post, index) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              onClick={() => navigate(`/blog/${post.slug}`)}
              className="group flex flex-col justify-between rounded-2xl bg-[#110519]/70 border border-white/10 hover:border-pink-500/40 p-4 sm:p-5 transition-all duration-300 backdrop-blur-md shadow-lg hover:-translate-y-1 hover:shadow-[0_8px_30px_rgba(255,0,122,0.15)] cursor-pointer overflow-hidden"
            >
              <div>
                {/* Thumbnail Image */}
                <div className="relative aspect-[16/10] rounded-xl overflow-hidden bg-black/40 mb-4 border border-white/5">
                  <img
                    src={post.coverImage}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold tracking-tight bg-black/70 backdrop-blur-md text-pink-300 border border-white/10 uppercase">
                      {post.category}
                    </span>
                  </div>
                </div>

                {/* Meta info */}
                <div className="flex items-center gap-3 text-[11px] text-gray-400 mb-2">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-pink-400" />
                    {formatDate(post.publishedDate)}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {post.readTime}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold text-white font-display leading-snug group-hover:text-pink-200 transition-colors mb-2 line-clamp-2">
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-xs text-gray-400 leading-relaxed line-clamp-3 mb-4">
                  {post.excerpt}
                </p>
              </div>

              {/* Card Footer */}
              <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  {post.author.avatarUrl ? (
                    <img
                      src={post.author.avatarUrl}
                      alt={post.author.name}
                      className="w-6 h-6 rounded-full border border-pink-500/30 object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-pink-600/30 border border-pink-500/30 flex items-center justify-center text-[10px] font-bold text-pink-300">
                      {post.author.name.charAt(0)}
                    </div>
                  )}
                  <span className="text-[11px] text-gray-300 font-medium">
                    {post.author.name}
                  </span>
                </div>

                <span className="flex items-center gap-1 text-[11px] font-bold text-pink-400 group-hover:translate-x-1 transition-transform">
                  <span>Read</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </motion.article>
          ))}
        </div>

        {/* Empty state if search returns nothing */}
        {gridPosts.length === 0 && (
          <div className="text-center py-20 bg-white/[0.02] rounded-3xl border border-white/5">
            <BookOpen className="w-12 h-12 text-pink-400/50 mx-auto mb-3" />
            <h4 className="text-lg font-bold text-white">
              {language === 'es' ? 'No se encontraron artículos' : 'No articles found'}
            </h4>
            <p className="text-xs text-gray-400 max-w-sm mx-auto mt-1 mb-6">
              {language === 'es'
                ? 'Intenta con otros términos de búsqueda o cambia la categoría seleccionada.'
                : 'Try adjusting your search query or selecting a different category filter.'}
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="px-4 py-2 rounded-full bg-white/10 text-xs font-bold text-white hover:bg-white/15 transition-colors cursor-pointer"
            >
              {language === 'es' ? 'Restablecer Filtros' : 'Reset Filters'}
            </button>
          </div>
        )}

        {/* Bottom Consultation Banner */}
        {onOpenBooking && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-20 p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-[#1b0526] via-[#12031a] to-[#200424] border border-pink-500/30 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute -right-10 -bottom-10 w-60 h-60 bg-pink-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="max-w-2xl relative z-10">
              <span className="text-[11px] font-mono uppercase tracking-widest text-pink-400 font-bold">
                {language === 'es' ? 'COLABORACIÓN EN SET' : 'PRODUCTION INQUIRY'}
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-white font-display mt-2 mb-3">
                {language === 'es' 
                  ? '¿Tienes un proyecto o visión que necesita dirección cinematográfica?' 
                  : 'Have a visual concept that demands high-caliber cinematic direction?'}
              </h3>
              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed mb-6">
                {language === 'es'
                  ? 'Agenda una llamada directa de 15 minutos con nuestros directores para evaluar tu marca y definir el plan de rodaje.'
                  : 'Schedule a 15-minute concept discovery session with our directors to review moodboards, technical scope, and production timelines.'}
              </p>
              <button
                onClick={onOpenBooking}
                className="btn-primary-gradient px-7 py-3 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/30 cursor-pointer"
              >
                {language === 'es' ? 'AGENDAR SESIÓN DE DIRECCIÓN' : 'BOOK DIRECTORS CALL'}
              </button>
            </div>
          </motion.div>
        )}

      </div>
    </main>
  );
};

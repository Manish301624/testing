import { CinematicImage } from "./CinematicImage";
import React, { useRef, useEffect, useState, useCallback } from 'react';

export interface AutoplayVideoProps extends React.VideoHTMLAttributes<HTMLVideoElement> {
  src?: string;
  videoUrl?: string;
  imageUrl?: string;
  poster?: string;
  className?: string;
  alt?: string;
  /** Maximum number of silent retry attempts before switching to image fallback (default: 2) */
  maxRetries?: number;
  /** Delay in milliseconds before attempting silent retry (default: 1000ms) */
  retryDelayMs?: number;
  /** Root margin for intersection preloading before entering viewport (default: '300px 0px 300px 0px') */
  preloadRootMargin?: string;
}

/**
 * Robust, cross-browser Video-First Autoplay Component with Zero-Black-Screen Preload & Silent Retry.
 * 
 * PRELOAD & SEAMLESS PLAYBACK STRATEGY:
 * 1. Layered Poster Architecture: Always mounts the poster/image in an underlying layer (z-0).
 *    The <video> (z-10) starts at opacity-0 and smoothly transitions to opacity-100 once `onPlaying`
 *    or `onTimeUpdate` fires. This guarantees 100% elimination of black screens or buffering flashes.
 * 2. Intersection Preload: Uses IntersectionObserver with a generous vertical rootMargin (300px)
 *    to pre-buffer and trigger video playback before the card crosses into the visible frame.
 * 3. Silent Retry on Error: Re-buffers and retries failed video streams silently before falling back.
 */
export const AutoplayVideo: React.FC<AutoplayVideoProps> = ({
  src,
  videoUrl,
  imageUrl,
  poster,
  className = '',
  alt = 'Media preview',
  maxRetries = 2,
  retryDelayMs = 1000,
  preloadRootMargin = '300px 0px 300px 0px',
  ...props
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const [hasVideoError, setHasVideoError] = useState<boolean>(false);
  const [isVideoReady, setIsVideoReady] = useState<boolean>(false);
  const [retryCount, setRetryCount] = useState<number>(0);
  const [isNearViewport, setIsNearViewport] = useState<boolean>(false);
  const retryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Resolve effective video and image sources
  const effectiveVideoSrc = videoUrl || src;
  const effectiveImageSrc = imageUrl || poster;

  // Reset retry, readiness, and error state when video source changes
  useEffect(() => {
    setHasVideoError(false);
    setIsVideoReady(false);
    setRetryCount(0);
    if (retryTimeoutRef.current) {
      clearTimeout(retryTimeoutRef.current);
      retryTimeoutRef.current = null;
    }
  }, [effectiveVideoSrc]);

  // Clean up pending timeouts on unmount
  useEffect(() => {
    return () => {
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current);
      }
    };
  }, []);

  // 1. Intersection Observer: Lazy load and play only when card enters viewport, pause when out
  useEffect(() => {
    const target = containerRef.current;
    if (!target || typeof IntersectionObserver === 'undefined') {
      setIsNearViewport(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsNearViewport(true);
          if (videoRef.current && isVideoReady) {
            videoRef.current.play().catch(() => {});
          }
        } else {
          // Pause when outside viewport to save memory and battery
          if (videoRef.current) {
            videoRef.current.pause();
          }
        }
      },
      {
        rootMargin: preloadRootMargin,
        threshold: 0.05,
      }
    );

    observer.observe(target);
    return () => observer.disconnect();
  }, [preloadRootMargin, isVideoReady]);

  // 2. Silent retry handler on video error
  const handleVideoError = useCallback(() => {
    const video = videoRef.current;
    
    if (retryCount < maxRetries) {
      const nextAttempt = retryCount + 1;
      setRetryCount(nextAttempt);

      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current);
      }

      retryTimeoutRef.current = setTimeout(() => {
        if (video && effectiveVideoSrc) {
          try {
            video.load();
            video.muted = true;
            const playPromise = video.play();
            if (playPromise !== undefined) {
              playPromise.catch(() => {});
            }
          } catch {
            setHasVideoError(true);
          }
        }
      }, retryDelayMs * nextAttempt);
    } else {
      setHasVideoError(true);
    }
  }, [retryCount, maxRetries, retryDelayMs, effectiveVideoSrc]);

  // 3. Autoplay & playback initialization
  useEffect(() => {
    if (!effectiveVideoSrc || hasVideoError || !isNearViewport) return;
    const video = videoRef.current;
    if (!video) return;

    // Force strict muted properties at the DOM level for reliable cross-browser autoplay
    video.muted = true;
    video.defaultMuted = true;
    video.setAttribute('muted', '');
    video.setAttribute('playsinline', '');
    video.setAttribute('webkit-playsinline', '');
    video.setAttribute('disablepictureinpicture', '');

    const attemptPlay = () => {
      if (!video) return;
      video.muted = true;
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsVideoReady(true);
          })
          .catch(() => {
            // Unlock on user interaction if browser policy strictly blocked initial autoplay
            const unlockAutoplay = () => {
              if (video) {
                video.muted = true;
                video.play()
                  .then(() => setIsVideoReady(true))
                  .catch(() => {});
              }
              window.removeEventListener('click', unlockAutoplay);
              window.removeEventListener('touchstart', unlockAutoplay);
              window.removeEventListener('scroll', unlockAutoplay);
            };

            window.addEventListener('click', unlockAutoplay, { once: true, passive: true });
            window.addEventListener('touchstart', unlockAutoplay, { once: true, passive: true });
            window.addEventListener('scroll', unlockAutoplay, { once: true, passive: true });
          });
      }
    };

    attemptPlay();
    video.addEventListener('loadeddata', attemptPlay);
    video.addEventListener('canplay', attemptPlay);
    video.addEventListener('playing', () => setIsVideoReady(true));

    return () => {
      video.removeEventListener('loadeddata', attemptPlay);
      video.removeEventListener('canplay', attemptPlay);
    };
  }, [effectiveVideoSrc, hasVideoError, isNearViewport]);

  return (
    <div ref={containerRef} className={`relative overflow-hidden w-full h-full ${className}`}>
      {/* UNDERLYING POSTER/IMAGE LAYER: Prevents any black screen during initial load or decode */}
      {effectiveImageSrc && (
        <CinematicImage
          src={effectiveImageSrc}
          alt={alt}
          loading="eager"
          decoding="async"
          containerClassName="absolute inset-0 w-full h-full z-0 pointer-events-none"
          className="w-full h-full object-cover"
        />
      )}

      {/* PRIMARY VIDEO LAYER: Smoothly fades in over the poster image once the stream is active */}
      {effectiveVideoSrc && !hasVideoError && isNearViewport && (
        <video
          ref={videoRef}
          src={effectiveVideoSrc}
          poster={effectiveImageSrc}
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          onPlaying={() => setIsVideoReady(true)}
          onTimeUpdate={() => {
            if (!isVideoReady) setIsVideoReady(true);
          }}
          onError={handleVideoError}
          className={`absolute inset-0 w-full h-full object-cover z-10 pointer-events-none transition-opacity duration-500 ease-out ${
            isVideoReady ? 'opacity-100' : 'opacity-0'
          }`}
          {...props}
        />
      )}
    </div>
  );
};

export default AutoplayVideo;

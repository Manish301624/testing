import { CinematicImage } from "./CinematicImage";
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Sparkles, 
  Share2, 
  Check, 
  Calendar, 
  Eye, 
  Clock, 
  Layers, 
  Award, 
  Star, 
  Play, 
  MessageCircle, 
  ArrowRight,
  TrendingUp,
  CheckCircle,
  FileText
} from 'lucide-react';
import { ProjectItem, ProjectMetric } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { buildWhatsAppUrl, fetchConfiguredWhatsAppNumber, getInitialWhatsAppNumber, logWhatsAppInquiry } from '../utils/whatsapp';
import { containerStagger, staggerFadeIn, slideUp } from '../utils/motionVariants';

interface ProjectPageProps {
  projects: ProjectItem[];
  onOpenBooking: () => void;
  onOpenCallback?: () => void;
}

// Animated Metric Counter Component
const MetricCounter: React.FC<{ metric: ProjectMetric }> = ({ metric }) => {
  const [displayValue, setDisplayValue] = useState<string>('0');
  const countRef = useRef<number>(0);

  useEffect(() => {
    if (typeof metric.numValue === 'number') {
      const target = metric.numValue;
      const isDecimal = !Number.isInteger(target);
      const duration = 1400;
      const startTime = performance.now();

      const updateCount = (currentTime: number) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(1, elapsed / duration);
        const easeProgress = 1 - Math.pow(1 - progress, 3);
        const currentVal = easeProgress * target;

        countRef.current = currentVal;
        const formatted = isDecimal ? currentVal.toFixed(1) : Math.round(currentVal).toString();
        setDisplayValue(formatted);

        if (progress < 1) {
          requestAnimationFrame(updateCount);
        } else {
          setDisplayValue(isDecimal ? target.toFixed(1) : target.toString());
        }
      };

      const animId = requestAnimationFrame(updateCount);
      return () => cancelAnimationFrame(animId);
    } else {
      setDisplayValue(metric.value);
    }
  }, [metric]);

  return (
    <div className="relative p-5 sm:p-6 rounded-2xl bg-[#14051c]/90 border border-pink-500/25 shadow-xl overflow-hidden group hover:border-pink-500/50 transition-all">
      <div className="absolute top-0 right-0 w-28 h-28 bg-pink-500/10 rounded-full blur-2xl pointer-events-none group-hover:bg-pink-500/20 transition-all" />
      
      <div className="flex items-baseline gap-0.5">
        {metric.prefix && (
          <span className="text-2xl sm:text-3xl font-extrabold text-[#FF007A] font-display">
            {metric.prefix}
          </span>
        )}
        <span className="text-3xl sm:text-4xl lg:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-pink-100 to-pink-300 font-display tracking-tight">
          {typeof metric.numValue === 'number' ? displayValue : metric.value}
        </span>
        {metric.suffix && (
          <span className="text-2xl sm:text-3xl font-extrabold text-[#FF007A] font-display">
            {metric.suffix}
          </span>
        )}
      </div>

      <div className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider mt-2 font-display">
        {metric.label}
      </div>

      {metric.subtext && (
        <p className="text-xs text-gray-400 mt-1 leading-relaxed">
          {metric.subtext}
        </p>
      )}
    </div>
  );
};

export const ProjectPage: React.FC<ProjectPageProps> = ({
  projects,
  onOpenBooking,
  onOpenCallback
}) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { language } = useLanguage();

  const [copied, setCopied] = useState<boolean>(false);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Fetch whatsapp number
  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) setWhatsappNumber(num);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Find target project
  const project = projects.find((p) => p.id === id);
  const relatedProjects = projects.filter((p) => p.id !== id).slice(0, 3);

  // Scroll to top on id change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
    setIsPlaying(false);
  }, [id]);

  if (!project) {
    return (
      <main className="min-h-[70vh] flex flex-col items-center justify-center px-4 py-32 text-center bg-[#07010c]">
        <Helmet>
          <title>Case Study Not Found | Hidden Directors</title>
          <meta name="description" content="The requested video production project or case study could not be found." />
        </Helmet>
        <div className="w-16 h-16 rounded-full bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-[#FF007A] mb-4">
          <Layers className="w-8 h-8" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white mb-2">
          {language === 'es' ? 'Proyecto No Encontrado' : 'Project Not Found'}
        </h1>
        <p className="text-gray-400 max-w-md mb-8 text-sm">
          {language === 'es'
            ? 'El caso de estudio que buscas no está disponible o ha cambiado de identificador.'
            : 'The portfolio project you are searching for is unavailable or has been relocated.'}
        </p>
        <button
          onClick={() => navigate('/#portfolio')}
          className="btn-primary-gradient px-6 py-3 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg cursor-pointer"
        >
          {language === 'es' ? 'VER PORTAFOLIO' : 'EXPLORE PORTFOLIO'}
        </button>
      </main>
    );
  }

  // Dynamic SEO variables based on active project data
  const pageTitle = `${project.title} — ${project.client} | Case Study | Hidden Directors`;
  const pageDescription = project.briefText 
    ? `${project.briefText.slice(0, 155)}... Directed by Hidden Directors Productions.`
    : `${project.description} Full production case study by Hidden Directors.`;
  const canonicalUrl = `https://hiddendirectors.com/project/${project.id}`;
  const ogImageUrl = project.thumbnailUrl;

  const handleCopyShareLink = async () => {
    const shareUrl = typeof window !== 'undefined' ? window.location.href : canonicalUrl;
    const shareData = {
      title: pageTitle,
      text: `${project.title} - ${project.client} production case study by Hidden Directors.`,
      url: shareUrl
    };

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        if (navigator.canShare && !navigator.canShare(shareData)) {
          await navigator.share({ title: pageTitle, url: shareUrl });
        } else {
          await navigator.share(shareData);
        }
        setCopied(true);
        setTimeout(() => setCopied(false), 2400);
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2400);
    }
  };

  const handleWhatsAppInquiry = () => {
    const text = language === 'es'
      ? `Hola Hidden Directors, vi el caso de estudio de "${project.title}" para ${project.client}. Me gustaría cotizar una producción similar para mi marca.`
      : `Hello Hidden Directors, I saw your case study for "${project.title}" (${project.client}). I would like to explore a similar cinematic production for my brand.`;
    
    logWhatsAppInquiry('portfolio', {
      projectName: `${project.client} - ${project.title}`,
      sourceSection: 'project_page'
    }, text);

    const url = buildWhatsAppUrl(whatsappNumber, text);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const toggleVideoPlayback = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  // Structured Data Schema for Project Case Study
  const schemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'CreativeWork',
    'name': `${project.title} — ${project.client}`,
    'headline': project.title,
    'description': project.description,
    'image': project.thumbnailUrl,
    'dateCreated': project.year,
    'creator': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'url': 'https://hiddendirectors.com'
    },
    'publisher': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'logo': {
        '@type': 'ImageObject',
        'url': 'https://hiddendirectors.com/logo.svg'
      }
    },
    'genre': project.category,
    'url': canonicalUrl
  };

  return (
    <main id="project-page" className="min-h-screen bg-[#07010c] text-gray-100 pt-28 pb-24 overflow-hidden relative">
      {/* Dynamic SEO Tags via react-helmet-async */}
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        
        {/* OpenGraph / Facebook */}
        <meta property="og:type" content="video.other" />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:image" content={ogImageUrl} />
        <meta property="og:image:alt" content={`${project.title} by Hidden Directors`} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />

        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content={ogImageUrl} />
        <meta name="twitter:image:alt" content={`${project.title} Production Still`} />

        {/* Canonical Link */}
        <link rel="canonical" href={canonicalUrl} />

        {/* Schema.org Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(schemaJsonLd)}
        </script>
      </Helmet>

      {/* Atmospheric Ambient Glow */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-pink-600/10 rounded-full blur-[170px] pointer-events-none -z-10" />
      <div className="absolute top-[800px] right-10 w-[500px] h-[400px] bg-purple-600/10 rounded-full blur-[150px] pointer-events-none -z-10" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Breadcrumb & Return Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8 pb-4 border-b border-white/10">
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-gray-400">
            <Link to="/" className="hover:text-pink-400 transition-colors">
              {language === 'es' ? 'Inicio' : 'Home'}
            </Link>
            <span className="text-gray-600">/</span>
            <Link to="/#portfolio" className="hover:text-pink-400 transition-colors">
              {language === 'es' ? 'Portafolio' : 'Portfolio'}
            </Link>
            <span className="text-gray-600">/</span>
            <span className="text-pink-300 font-semibold truncate max-w-[200px] sm:max-w-xs">
              {project.client}
            </span>
          </nav>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCopyShareLink}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-pink-500/40 text-xs font-semibold text-gray-200 hover:text-white transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-green-400" />
                  <span className="text-green-300">{language === 'es' ? '¡Enlace Copiado!' : 'Link Copied!'}</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5 text-pink-400" />
                  <span>{language === 'es' ? 'Compartir Caso' : 'Share Case'}</span>
                </>
              )}
            </button>

            <button
              onClick={() => navigate('/#portfolio')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-gray-300 hover:text-white transition-all cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{language === 'es' ? 'Volver al Portafolio' : 'All Projects'}</span>
            </button>
          </div>
        </div>

        {/* Project Header Title & Category */}
        <motion.div 
          variants={slideUp}
          initial="hidden"
          animate="visible"
          className="max-w-3xl mb-8"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-[11px] font-bold tracking-widest text-pink-300 uppercase mb-4 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#FF007A]" />
            <span>{project.category} // CASE STUDY</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white font-display tracking-tight leading-[1.1]">
            {project.title}
          </h1>

          <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-gray-400 mt-4">
            <span className="text-white font-bold text-base font-display tracking-wide text-pink-200">
              {project.client}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-pink-400" />
              {project.year}
            </span>
            {project.views && (
              <>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-pink-400" />
                  {project.views} {language === 'es' ? 'vistas' : 'views'}
                </span>
              </>
            )}
            {project.duration && (
              <>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-pink-400" />
                  {project.duration}
                </span>
              </>
            )}
            {project.resolution && (
              <>
                <span>•</span>
                <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] font-mono font-bold text-gray-300 uppercase">
                  {project.resolution}
                </span>
              </>
            )}
          </div>
        </motion.div>

        {/* Hero Video Player Showcase */}
        <motion.div 
          variants={slideUp}
          initial="hidden"
          animate="visible"
          className="relative rounded-3xl overflow-hidden bg-black/80 border border-white/10 shadow-2xl mb-12 aspect-[16/9] group"
        >
          {project.videoUrl ? (
            <>
              <video
                ref={videoRef}
                src={project.videoUrl}
                poster={project.thumbnailUrl}
                controls={isPlaying}
                playsInline
                className="w-full h-full object-cover"
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
              />

              {!isPlaying && (
                <div 
                  onClick={toggleVideoPlayback}
                  className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col items-center justify-center cursor-pointer transition-all hover:bg-black/40"
                >
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-full btn-primary-gradient flex items-center justify-center text-white shadow-2xl shadow-pink-600/50"
                  >
                    <Play className="w-9 h-9 sm:w-11 sm:h-11 fill-white ml-1" />
                  </motion.div>
                  <span className="mt-4 text-xs sm:text-sm font-bold tracking-wider uppercase text-white font-mono bg-black/60 px-4 py-1.5 rounded-full border border-white/10 backdrop-blur-md">
                    {language === 'es' ? 'REPRODUCIR CASO 4K' : 'WATCH 4K MASTER FILM'}
                  </span>
                </div>
              )}
            </>
          ) : (
            <img
              src={project.thumbnailUrl}
              alt={project.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          )}
        </motion.div>

        {/* Results Metrics Banner */}
        {project.resultMetrics && project.resultMetrics.length > 0 && (
          <motion.div 
            variants={slideUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-50px' }}
            className="mb-14"
          >
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-4 h-4 text-[#FF007A]" />
              <h2 className="text-xs font-mono uppercase tracking-widest text-pink-400 font-bold">
                {language === 'es' ? 'IMPACTO COMERCIAL & RESULTADOS' : 'PERFORMANCE METRICS & COMMERCIAL IMPACT'}
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {project.resultMetrics.map((metric, idx) => (
                <MetricCounter key={idx} metric={metric} />
              ))}
            </div>
          </motion.div>
        )}

        {/* Narrative Grid: Brief & Execution */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mb-14">
          
          {/* Left Column: Brief & Process */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* The Challenge / Brief */}
            <div className="p-6 sm:p-8 rounded-3xl bg-[#110519]/80 border border-white/10 backdrop-blur-md">
              <div className="flex items-center gap-2 text-pink-400 text-xs font-mono font-bold uppercase tracking-wider mb-3">
                <FileText className="w-4 h-4" />
                <span>{language === 'es' ? 'EL BRIEF & VISIÓN' : 'THE BRIEF & OBJECTIVE'}</span>
              </div>
              <h3 className="text-2xl font-bold text-white font-display mb-4">
                {language === 'es' ? 'Dirección Cinematográfica de Alto Impacto' : 'The Creative Challenge'}
              </h3>
              <p className="text-sm sm:text-base text-gray-300 leading-relaxed">
                {project.briefText || project.description}
              </p>
            </div>

            {/* Direction & Process Timeline */}
            {project.processSteps && project.processSteps.length > 0 && (
              <div className="p-6 sm:p-8 rounded-3xl bg-[#110519]/80 border border-white/10 backdrop-blur-md">
                <div className="flex items-center gap-2 text-pink-400 text-xs font-mono font-bold uppercase tracking-wider mb-4">
                  <Layers className="w-4 h-4" />
                  <span>{language === 'es' ? 'EJECUCIÓN TÉCNICA EN SET' : 'PRODUCTION PROCESS & EXECUTION'}</span>
                </div>
                <h3 className="text-2xl font-bold text-white font-display mb-6">
                  {language === 'es' ? 'De la Idea al Master 4K' : 'From Moodboard to Final Cut'}
                </h3>
                <div className="space-y-4">
                  {project.processSteps.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-3.5 p-3 rounded-2xl bg-white/[0.02] border border-white/5">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-pink-500/20 text-[#FF007A] text-xs font-mono font-bold flex items-center justify-center border border-pink-500/30">
                        0{idx + 1}
                      </span>
                      <p className="text-xs sm:text-sm text-gray-300 leading-relaxed pt-0.5">
                        {step}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Client Testimonial Card */}
            {project.clientQuote && (
              <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#1c0624] to-[#12031a] border border-pink-500/30 shadow-xl relative overflow-hidden">
                <div className="flex items-center gap-1 text-[#FF007A] mb-3">
                  {[...Array(project.clientQuote.rating || 5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#FF007A]" />
                  ))}
                </div>
                <blockquote className="text-base sm:text-lg text-white font-medium italic leading-relaxed mb-6">
                  "{project.clientQuote.quote}"
                </blockquote>
                <div className="flex items-center gap-3">
                  {project.clientQuote.avatarUrl && (
                    <img
                      src={project.clientQuote.avatarUrl}
                      alt={project.clientQuote.author}
                      className="w-11 h-11 rounded-full object-cover border border-pink-500/40"
                      referrerPolicy="no-referrer"
                    />
                  )}
                  <div>
                    <div className="text-sm font-bold text-white font-display">
                      {project.clientQuote.author}
                    </div>
                    <div className="text-xs text-gray-400">
                      {project.clientQuote.role} • {project.clientQuote.company || project.client}
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* Right Column: Deliverables & Direct Inquiries */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Deliverables Card */}
            <div className="p-6 rounded-3xl bg-[#110519]/90 border border-white/10 backdrop-blur-md">
              <h4 className="text-xs font-mono uppercase tracking-widest text-pink-400 font-bold mb-4">
                {language === 'es' ? 'ENTREGABLES DE PRODUCCIÓN' : 'DELIVERABLES & FORMATS'}
              </h4>
              <ul className="space-y-2.5">
                {project.deliverables.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-xs sm:text-sm text-gray-300">
                    <CheckCircle className="w-4 h-4 text-pink-400 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Direct Booking Action Card */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-[#23052a] to-[#14021a] border border-pink-500/40 shadow-xl text-center">
              <div className="w-12 h-12 rounded-full bg-pink-500/20 border border-pink-500/40 flex items-center justify-center text-[#FF007A] mx-auto mb-3">
                <Sparkles className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-white font-display mb-2">
                {language === 'es' ? '¿Quieres una producción similar?' : 'Commission a Similar Shoot'}
              </h4>
              <p className="text-xs text-gray-300 leading-relaxed mb-6">
                {language === 'es'
                  ? 'Agenda una llamada de descubrimiento de 15 minutos para planificar el moodboard y la dirección de tu marca.'
                  : 'Schedule a 15-minute director consultation to define the moodboard, lighting, and timeline.'}
              </p>
              <div className="space-y-2.5">
                <button
                  onClick={onOpenBooking}
                  className="w-full btn-primary-gradient py-3 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/30 cursor-pointer"
                >
                  {language === 'es' ? 'AGENDAR LLAMADA DE DIRECCIÓN' : 'BOOK DIRECTORS CALL'}
                </button>
                <button
                  onClick={handleWhatsAppInquiry}
                  className="w-full py-2.5 rounded-full bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-xs font-bold text-emerald-300 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp VIP Direct</span>
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* Related Projects Grid */}
        {relatedProjects.length > 0 && (
          <div className="mt-20 pt-12 border-t border-white/10">
            <div className="flex items-center justify-between mb-8">
              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-pink-400 font-bold">
                  {language === 'es' ? 'MÁS CASOS DE ESTUDIO' : 'MORE CINEMATIC WORK'}
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display mt-1">
                  {language === 'es' ? 'Proyectos Relacionados' : 'Related Case Studies'}
                </h3>
              </div>
              <button
                onClick={() => navigate('/#portfolio')}
                className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold text-pink-400 hover:text-pink-300 transition-colors"
              >
                <span>{language === 'es' ? 'Ver Todo' : 'View All Portfolio'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <motion.div 
              variants={containerStagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-50px' }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              {relatedProjects.map((rel) => (
                <motion.div
                  key={rel.id}
                  variants={staggerFadeIn}
                  onClick={() => navigate(`/project/${rel.id}`)}
                  className="group rounded-2xl bg-[#110519]/70 border border-white/10 hover:border-pink-500/40 p-4 transition-all duration-300 cursor-pointer overflow-hidden shadow-lg hover:-translate-y-1"
                >
                  <div className="relative aspect-[16/10] rounded-xl overflow-hidden bg-black/40 mb-3 border border-white/5">
                    <img
                      src={rel.thumbnailUrl}
                      alt={rel.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                    />
                    <div className="absolute top-2.5 left-2.5">
                      <span className="px-2 py-0.5 rounded-full text-[9.5px] font-mono font-bold tracking-tight bg-black/70 backdrop-blur-md text-pink-300 border border-white/10 uppercase">
                        {rel.category}
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-gray-400 mb-1">{rel.client}</div>
                  <h4 className="text-sm font-bold text-white font-display group-hover:text-pink-200 transition-colors line-clamp-1">
                    {rel.title}
                  </h4>
                </motion.div>
              ))}
            </motion.div>
          </div>
        )}

      </div>
    </main>
  );
};

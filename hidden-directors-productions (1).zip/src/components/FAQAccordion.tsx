import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronDown, 
  HelpCircle, 
  Sparkles, 
  Search, 
  CheckCircle2, 
  MessageCircle, 
  ShieldCheck, 
  Film, 
  Clock, 
  Zap, 
  Layers, 
  CreditCard 
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { buildWhatsAppUrl, getInitialWhatsAppNumber, logWhatsAppInquiry } from '../utils/whatsapp';

export interface FAQItem {
  id: string;
  category: 'production' | 'timeline' | 'rights' | 'pricing' | 'logistics';
  questionEn: string;
  questionEs: string;
  answerEn: string;
  answerEs: string;
  highlightsEn?: string[];
  highlightsEs?: string[];
  icon?: React.ElementType;
}

export const DEFAULT_FAQ_ITEMS: FAQItem[] = [
  {
    id: 'faq-process',
    category: 'production',
    questionEn: 'How does your production process work and how much time does my team need to invest?',
    questionEs: '¿Cómo funciona su proceso de producción y cuánto tiempo debe invertir mi equipo?',
    answerEn: 'Our process is designed for maximum efficiency. Your total involvement is typically just 30–45 minutes: a 15-minute concept discovery call to align on aesthetics and brand hooks, plus quick timestamped review via Frame.io. Our directors handle all concept development, moodboards, shot lists, set lighting, filming, DaVinci Resolve color grading, and sound design.',
    answerEs: 'Nuestro proceso está diseñado para la máxima eficiencia. La inversión de tu equipo es usualmente de solo 30–45 minutos: una llamada de descubrimiento de 15 minutos para alinear el concepto estético y los ganchos de marca, más revisiones rápidas con marcas de tiempo en Frame.io. Nuestros directores gestionan el guión visual, iluminación, rodaje, corrección de color en DaVinci Resolve y diseño sonoro.',
    highlightsEn: ['Only 30–45 min total client commitment', 'Complete turnkey director execution', 'Seamless Frame.io timestamped reviews'],
    highlightsEs: ['Solo 30–45 min de tiempo del cliente', 'Ejecución integral por directores', 'Revisiones interactivas en Frame.io'],
    icon: Film
  },
  {
    id: 'faq-gear',
    category: 'production',
    questionEn: 'What camera systems and cinema gear do you shoot with?',
    questionEs: '¿Con qué sistemas de cámara y equipo de cine filman?',
    answerEn: 'We film strictly on industry-standard cinema bodies including RED V-Raptor / Komodo-X and Sony FX6 / FX3 rigs paired with high-speed cinema prime and anamorphic lenses. Our lighting packages feature wireless Aputure/Amaran RGBWW fixtures, motorized sliders, and DJI Ronin gimbals to deliver broadcast-caliber motion and luxury skin tones.',
    answerEs: 'Filmamos estrictamente con cuerpos de cine de estándar industrial, incluyendo RED V-Raptor / Komodo-X y Sony FX6 / FX3 acompañados de ópticas fijas de cine y lentes anamórficos. Nuestros paquetes de iluminación incluyen tecnología inalámbrica Aputure/Amaran RGBWW, sliders motorizados y gimbals DJI Ronin para garantizar tonos de piel impecables y movimiento fluido.',
    highlightsEn: ['RED & Sony FX cinema sensor systems', 'High-end cinema primes & anamorphic glass', 'Aputure wireless studio lighting'],
    highlightsEs: ['Sistemas de sensor de cine RED y Sony FX', 'Lentes fijas de cine y ópticas anamórficas', 'Iluminación de estudio inalámbrica Aputure'],
    icon: Layers
  },
  {
    id: 'faq-turnaround',
    category: 'timeline',
    questionEn: 'What is your typical delivery turnaround from shoot day to final master?',
    questionEs: '¿Cuál es el tiempo promedio de entrega desde el rodaje hasta el máster final?',
    answerEn: 'Standard turnaround for commercial short-form reels and brand films is 7 to 10 business days. For urgent launch campaigns or time-sensitive product drops, we provide a 5-day priority rush workflow with an expedited post-production pipeline.',
    answerEs: 'El tiempo de entrega estándar para reels comerciales de alta gama y películas de marca es de 7 a 10 días hábiles. Para lanzamientos prioritarios o activaciones con fechas límite inmediatas, ofrecemos un flujo urgente prioritario de 5 días hábiles.',
    highlightsEn: ['7–10 business days standard turnaround', '5-day expedited rush queue available', 'Timestamped milestone updates'],
    highlightsEs: ['7–10 días hábiles estándar', 'Opción urgente de 5 días disponible', 'Actualizaciones en cada hito'],
    icon: Clock
  },
  {
    id: 'faq-rights',
    category: 'rights',
    questionEn: 'Who owns the commercial rights and licensing to the delivered videos?',
    questionEs: '¿Quién posee los derechos comerciales y licencias del material final?',
    answerEn: 'You own 100% perpetual, worldwide commercial rights for digital advertising, paid performance marketing, organic social media, and web usage upon final sign-off. We deliver uncompressed ProRes 422 HQ and web-optimized 4K H.264 exports, with options for clean uncaptioned masters and raw camera files.',
    answerEs: 'Posees el 100% de los derechos comerciales mundiales y perpetuos para pauta publicitaria digital, marketing de rendimiento, redes orgánicas y sitio web tras la aprobación final. Entregamos archivos maestros en ProRes 422 HQ sin compresión y exportaciones 4K H.264 optimizadas.',
    highlightsEn: ['100% Perpetual worldwide commercial rights', 'Full paid media & advertising clearance', 'Master ProRes 422 HQ & 4K exports'],
    highlightsEs: ['100% Derechos comerciales perpetuos y mundiales', 'Libre de restricciones para publicidad y pauta', 'Archivos maestros en ProRes 422 HQ y 4K'],
    icon: ShieldCheck
  },
  {
    id: 'faq-retainer',
    category: 'pricing',
    questionEn: 'How does pricing work—do you offer monthly retainers or single project packages?',
    questionEs: '¿Cómo funciona el precio: ofrecen paquetes por proyecto o igualas mensuales?',
    answerEn: 'We provide both dedicated single-campaign productions (ideal for product launches, brand films, and architectural showcases) and recurring monthly content retainers. Our retainers deliver 8 to 20 polished cinema-grade reels per month with dedicated shoot days, prioritized post-production queues, and 20–30% cost savings compared to one-off shoots.',
    answerEs: 'Ofrecemos tanto producciones dedicadas por campaña (ideales para lanzamientos de producto, brand films o proyectos arquitectónicos) como igualas mensuales continuas. Nuestros retainers entregan de 8 a 20 reels cinematográficos mensuales con días de filmación dedicados y un ahorro del 20–30% respecto a rodajes individuales.',
    highlightsEn: ['Bespoke single projects or monthly retainers', '8–20 reels/month for recurring clients', 'Dedicated monthly studio shoot dates'],
    highlightsEs: ['Proyectos individuales o paquetes mensuales', '8–20 reels mensuales para clientes frecuentes', 'Fechas de rodaje mensuales garantizadas'],
    icon: CreditCard
  },
  {
    id: 'faq-talent',
    category: 'logistics',
    questionEn: 'Do you provide casting for actors, voiceover talent, and luxury locations?',
    questionEs: '¿Gestionan el casting de actores, locutores y locaciones de lujo?',
    answerEn: 'Yes. We manage turnkey production logistics including scouting and booking luxury villas, architectural spaces, and professional studios, as well as vetting commercial actors, lifestyle models, and voiceover artists. We also coordinate props, wardrobe palettes, and set styling.',
    answerEs: 'Sí. Coordinamos toda la logística de producción: búsqueda y reserva de villas de lujo, espacios arquitectónicos y estudios profesionales, además de selección de modelos comerciales, actores y locutores profesionales.',
    highlightsEn: ['Curated luxury location scouting', 'Commercial actor & voice talent casting', 'Turnkey styling & prop coordination'],
    highlightsEs: ['Scouting de locaciones arquitectónicas y de lujo', 'Casting de actores y locución profesional', 'Coordinación completa de atrezzo y vestuario'],
    icon: Zap
  },
  {
    id: 'faq-revisions',
    category: 'timeline',
    questionEn: 'What is your revision policy if adjustments are needed?',
    questionEs: '¿Cuál es su política de revisiones si requerimos ajustes en el corte?',
    answerEn: 'Every production package includes 2 complimentary revision cycles. Through our interactive Frame.io review workspace, your team can pause the cut at any exact second and leave precise visual notes. We iterate color grade, audio mixing, pacing, and graphic animations until you are completely satisfied.',
    answerEs: 'Cada producción incluye 2 rondas completas de revisiones sin costo adicional. Mediante nuestra plataforma interactiva en Frame.io, tu equipo puede pausar el video en el segundo exacto y dejar notas visuales precisas.',
    highlightsEn: ['2 Complimentary revision rounds included', 'Interactive second-by-second Frame.io notes', 'Dedicated post-production director'],
    highlightsEs: ['2 Rondas de revisión incluidas', 'Anotaciones al segundo exacto en Frame.io', 'Director de postproducción dedicado'],
    icon: CheckCircle2
  },
  {
    id: 'faq-travel',
    category: 'logistics',
    questionEn: 'Can your directors travel for on-location or international commercial shoots?',
    questionEs: '¿Pueden sus directores viajar para rodajes en locación o internacionales?',
    answerEn: 'Absolutely. Our directors and cinema crew regularly travel for destination hospitality shoots, international brand campaigns, architecture projects, and founder masterminds. We deploy flight-ready, Pelican-cased cinema packages that travel seamlessly as carry-on and priority cargo.',
    answerEs: 'Totalmente. Nuestros directores y crew de cámara viajan con frecuencia para proyectos hoteleros, campañas internacionales de marca, arquitectura y eventos de fundadores. Contamos con paquetes de cine en maletas Pelican listas para vuelo que viajan como equipaje prioritario.',
    highlightsEn: ['Worldwide flight-ready cinema packages', 'Experienced with global travel logistics', 'On-location commercial shoots anywhere'],
    highlightsEs: ['Equipos de cine aptos para viajes aéreos', 'Experiencia en logística internacional', 'Filmación en cualquier locación o país'],
    icon: Sparkles
  }
];

export interface FAQAccordionProps {
  items?: FAQItem[];
  title?: string;
  subtitle?: string;
  badge?: string;
  onOpenBooking?: () => void;
  onOpenCallback?: () => void;
  className?: string;
  showSupportCta?: boolean;
}

export const FAQAccordion: React.FC<FAQAccordionProps> = ({
  items = DEFAULT_FAQ_ITEMS,
  title,
  subtitle,
  badge,
  onOpenBooking,
  onOpenCallback,
  className = '',
  showSupportCta = true
}) => {
  const { language } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({ [items[0]?.id || 'faq-process']: true });
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [whatsappNumber] = useState<string>(getInitialWhatsAppNumber);

  const categories = useMemo(() => [
    { key: 'all', labelEn: 'All Questions', labelEs: 'Todas' },
    { key: 'production', labelEn: 'Production & Rigs', labelEs: 'Producción y Rigs' },
    { key: 'timeline', labelEn: 'Turnaround & Revisions', labelEs: 'Tiempos y Revisiones' },
    { key: 'rights', labelEn: 'Rights & Licensing', labelEs: 'Derechos y Licencias' },
    { key: 'pricing', labelEn: 'Pricing & Retainers', labelEs: 'Precios e Igualas' },
    { key: 'logistics', labelEn: 'Casting & Logistics', labelEs: 'Casting y Logística' },
  ], []);

  const toggleItem = (id: string) => {
    setOpenIds((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const expandAll = () => {
    const allExpanded: Record<string, boolean> = {};
    items.forEach((item) => {
      allExpanded[item.id] = true;
    });
    setOpenIds(allExpanded);
  };

  const collapseAll = () => {
    setOpenIds({});
  };

  // Filter items by category and query
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
      if (!matchesCategory) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      const matchEn = item.questionEn.toLowerCase().includes(q) || 
                      item.answerEn.toLowerCase().includes(q) ||
                      item.highlightsEn?.some(h => h.toLowerCase().includes(q));
      const matchEs = item.questionEs.toLowerCase().includes(q) || 
                      item.answerEs.toLowerCase().includes(q) ||
                      item.highlightsEs?.some(h => h.toLowerCase().includes(q));
      return matchEn || matchEs;
    });
  }, [items, activeCategory, searchQuery]);

  const handleWhatsAppHelp = () => {
    const defaultText = language === 'es'
      ? 'Hola Hidden Directors, estuve revisando las preguntas frecuentes y me gustaría hacer una consulta rápida sobre una producción para mi marca.'
      : 'Hello Hidden Directors, I was reviewing your FAQ and had a quick question about commission details for my brand.';

    logWhatsAppInquiry('general', {
      sourceSection: 'about_faq_accordion'
    }, defaultText);

    const url = buildWhatsAppUrl(whatsappNumber, defaultText);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section 
      id="faq-accordion-section"
      className={`py-16 sm:py-20 relative text-gray-100 ${className}`}
      aria-labelledby="faq-heading"
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Header & Badge */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs font-mono font-bold tracking-wider text-pink-300 uppercase mb-4 shadow-sm">
            <HelpCircle className="w-3.5 h-3.5 text-[#FF007A]" />
            <span>{badge || (language === 'es' ? 'RESPUESTAS FRECUENTES' : 'CLIENT INQUIRIES & FAQ')}</span>
          </div>

          <h2 
            id="faq-heading"
            className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-display tracking-tight leading-tight mb-4"
          >
            {title || (language === 'es' ? 'Todo lo que necesitas saber antes de rodar' : 'Everything You Need to Know Before Set Day')}
          </h2>

          <p className="text-sm sm:text-base text-gray-300 max-w-2xl mx-auto leading-relaxed">
            {subtitle || (language === 'es'
              ? 'Respuestas claras sobre nuestros flujos de dirección, cámaras de cine, derechos comerciales y tiempos de entrega.'
              : 'Direct answers regarding our director-led workflows, cinema camera rigs, full commercial rights, and delivery guarantees.')}
          </p>
        </div>

        {/* Search & Category Filter Toolbar */}
        <div className="mb-8 space-y-4">
          
          {/* Search Input Bar */}
          <div className="relative max-w-lg mx-auto">
            <Search className="w-4 h-4 text-pink-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="faq-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={language === 'es' ? 'Buscar dudas (ej. tiempos, precios, derechos, cámaras)...' : 'Search questions (e.g., turnaround, pricing, rights, RED)...'}
              className="w-full pl-11 pr-10 py-3 rounded-full bg-[#14051d]/90 border border-white/15 focus:border-pink-500 text-xs sm:text-sm text-white placeholder-gray-400 outline-none transition-all shadow-inner focus:ring-2 focus:ring-pink-500/20"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 hover:text-white px-1.5 py-0.5 rounded bg-white/10"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category Pills & Expand/Collapse Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              {categories.map((cat) => {
                const isActive = activeCategory === cat.key;
                return (
                  <button
                    key={cat.key}
                    onClick={() => setActiveCategory(cat.key)}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                      isActive
                        ? 'bg-pink-500 text-white shadow-lg shadow-pink-600/30'
                        : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white border border-white/10'
                    }`}
                  >
                    {language === 'es' ? cat.labelEs : cat.labelEn}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 text-xs text-gray-400 ml-auto">
              <button
                onClick={expandAll}
                className="hover:text-pink-300 underline transition-colors cursor-pointer"
              >
                {language === 'es' ? 'Expandir todo' : 'Expand all'}
              </button>
              <span>•</span>
              <button
                onClick={collapseAll}
                className="hover:text-pink-300 underline transition-colors cursor-pointer"
              >
                {language === 'es' ? 'Colapsar todo' : 'Collapse all'}
              </button>
            </div>

          </div>

        </div>

        {/* Accordion Item List */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-12 px-4 rounded-3xl bg-white/[0.02] border border-white/10 my-4">
            <HelpCircle className="w-8 h-8 text-pink-400/60 mx-auto mb-2" />
            <p className="text-sm text-gray-300 font-semibold mb-1">
              {language === 'es' ? 'No encontramos preguntas que coincidan con tu búsqueda.' : 'No matching questions found.'}
            </p>
            <p className="text-xs text-gray-400 mb-4">
              {language === 'es' ? 'Prueba con otro término o contáctanos directamente.' : 'Try adjusting your search keywords or chat with our team.'}
            </p>
            <button
              onClick={() => { setSearchQuery(''); setActiveCategory('all'); }}
              className="px-4 py-2 rounded-full bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/40 text-xs font-bold text-pink-300 transition-colors"
            >
              {language === 'es' ? 'Restablecer Filtros' : 'Reset Filters'}
            </button>
          </div>
        ) : (
          <div className="space-y-3.5">
            {filteredItems.map((item, idx) => {
              const isOpen = !!openIds[item.id];
              const Icon = item.icon || HelpCircle;
              const question = language === 'es' ? item.questionEs : item.questionEn;
              const answer = language === 'es' ? item.answerEs : item.answerEn;
              const highlights = language === 'es' ? item.highlightsEs : item.highlightsEn;

              return (
                <div
                  key={item.id}
                  id={`faq-item-${item.id}`}
                  className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
                    isOpen 
                      ? 'bg-gradient-to-r from-[#170522] via-[#12031a] to-[#15041f] border-pink-500/40 shadow-xl shadow-pink-900/10' 
                      : 'bg-[#100318]/70 hover:bg-[#15041f]/80 border-white/10 hover:border-white/20'
                  }`}
                >
                  <button
                    onClick={() => toggleItem(item.id)}
                    aria-expanded={isOpen}
                    aria-controls={`faq-answer-${item.id}`}
                    className="w-full p-4 sm:p-5 flex items-start justify-between gap-4 text-left cursor-pointer group select-none"
                  >
                    <div className="flex items-start gap-3 sm:gap-4 flex-1">
                      <div className={`mt-0.5 p-2 rounded-xl border flex-shrink-0 transition-colors ${
                        isOpen 
                          ? 'bg-pink-500/20 border-pink-500/50 text-[#FF007A]' 
                          : 'bg-white/5 border-white/10 text-gray-400 group-hover:text-pink-300 group-hover:border-pink-500/30'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-pink-400/80">
                            FAQ // 0{idx + 1}
                          </span>
                        </div>
                        <h3 className={`text-sm sm:text-base font-bold font-display transition-colors ${
                          isOpen ? 'text-white' : 'text-gray-200 group-hover:text-white'
                        }`}>
                          {question}
                        </h3>
                      </div>
                    </div>

                    <div className={`p-1.5 rounded-full border transition-all duration-300 flex-shrink-0 ${
                      isOpen 
                        ? 'bg-pink-500 text-white border-pink-400 rotate-180' 
                        : 'bg-white/5 border-white/10 text-gray-400 group-hover:text-white'
                    }`}>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        id={`faq-answer-${item.id}`}
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                      >
                        <div className="px-4 sm:px-5 pb-5 pt-1 border-t border-white/5 space-y-4">
                          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed pl-1 sm:pl-11">
                            {answer}
                          </p>

                          {highlights && highlights.length > 0 && (
                            <div className="pl-1 sm:pl-11 flex flex-wrap gap-2 pt-1">
                              {highlights.map((highlight, hIdx) => (
                                <span
                                  key={hIdx}
                                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-pink-500/20 text-[11px] font-medium text-pink-200"
                                >
                                  <CheckCircle2 className="w-3 h-3 text-pink-400 shrink-0" />
                                  <span>{highlight}</span>
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        )}

        {/* Live Director Support Escape Card (Reduces Support Queries) */}
        {showSupportCta && (
          <div className="mt-12 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#1a0524] to-[#0f0217] border border-pink-500/30 shadow-2xl relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center sm:text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[11px] font-bold text-emerald-400 uppercase tracking-wide">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>{language === 'es' ? 'RESPUESTA RÁPIDA DE DIRECCIÓN' : 'FAST DIRECTOR RESPONSE'}</span>
              </div>
              <h4 className="text-xl sm:text-2xl font-black text-white font-display">
                {language === 'es' ? '¿Tienes un brief o pregunta no listada?' : 'Have a custom brief or unlisted question?'}
              </h4>
              <p className="text-xs sm:text-sm text-gray-300 max-w-lg leading-relaxed">
                {language === 'es'
                  ? 'Escríbenos directamente por WhatsApp para resolver especificaciones técnicas o agenda una llamada de 15 minutos.'
                  : 'Reach our executive director directly on WhatsApp for technical questions or book a 15-minute concept discovery.'}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto flex-shrink-0">
              <button
                onClick={handleWhatsAppHelp}
                className="w-full sm:w-auto px-5 py-2.5 rounded-full bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-xs font-bold text-emerald-300 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp VIP</span>
              </button>

              {onOpenBooking && (
                <button
                  onClick={onOpenBooking}
                  className="w-full sm:w-auto btn-primary-gradient px-6 py-2.5 rounded-full text-xs font-extrabold uppercase tracking-wider text-white transition-all shadow-lg shadow-pink-600/30 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{language === 'es' ? 'Agendar Llamada' : 'Book 15-Min Call'}</span>
                </button>
              )}
            </div>
          </div>
        )}

      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, Sparkles, Check, ArrowRight, Play, Camera, Film, Users, Layers } from 'lucide-react';
import { SERVICE_OFFERS } from '../data/mockData';
import { ServiceOffer } from '../types';

interface WhatWeOfferProps {
  onOpenBooking: () => void;
  onSelectServiceDetail?: (service: ServiceOffer) => void;
}

export const WhatWeOfferSection: React.FC<WhatWeOfferProps> = ({
  onOpenBooking,
  onSelectServiceDetail
}) => {
  const [activeServiceId, setActiveServiceId] = useState<string>('personal-branding');
  const [isMuted, setIsMuted] = useState<boolean>(true);

  const activeService = SERVICE_OFFERS.find(s => s.id === activeServiceId) || SERVICE_OFFERS[0];

  return (
    <section id="personal-branding" className="py-20 relative overflow-hidden scroll-mt-24">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-0 w-96 h-96 bg-purple-900/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Service Category Switcher Tabs with whileInView */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12"
        >
          {SERVICE_OFFERS.map((service) => (
            <button
              key={service.id}
              onClick={() => setActiveServiceId(service.id)}
              className={`px-4 sm:px-5 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeServiceId === service.id
                  ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-lg shadow-pink-500/25 scale-105'
                  : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10'
              }`}
            >
              {service.title.split('&')[0].trim()}
            </button>
          ))}
        </motion.div>

        {/* Main Content Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeService.id}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.5, ease: [0.21, 0.45, 0.27, 0.9] }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center"
          >
            
            {/* Left Column: Narrative Content */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.55, delay: 0.1 }}
              className="lg:col-span-6 space-y-6"
            >
              
              {/* Badge: "WHAT WE OFFER" */}
              <div className="inline-flex items-center px-4 py-1.5 rounded-full border border-pink-500/40 bg-[#160620] text-xs font-bold tracking-wider text-pink-300 uppercase">
                {activeService.badge}
              </div>

              {/* Title */}
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight leading-[1.15]">
                {activeService.title}
              </h2>

              {/* Narrative Paragraphs */}
              <div className="space-y-4 text-sm sm:text-base text-gray-300 font-normal leading-relaxed">
                {activeService.paragraphs.map((para, idx) => (
                  <p key={idx} className={idx === 2 ? 'text-pink-300 font-medium' : ''}>
                    {para}
                  </p>
                ))}
              </div>

              {/* Key Deliverables Bullet Points */}
              <div className="pt-2 space-y-2.5">
                {activeService.features.map((feat, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.35, delay: 0.15 + i * 0.06 }}
                    className="flex items-start gap-2.5 text-xs sm:text-sm text-gray-200"
                  >
                    <span className="w-5 h-5 rounded-full bg-pink-500/20 text-[#FF007A] flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5" />
                    </span>
                    <span>{feat}</span>
                  </motion.div>
                ))}
              </div>

              {/* CTA Action */}
              <div className="pt-4 flex flex-wrap items-center gap-4">
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={onOpenBooking}
                  className="btn-primary-gradient px-7 py-3 rounded-full text-xs sm:text-sm font-bold tracking-wider text-white uppercase shadow-lg shadow-pink-600/30 cursor-pointer"
                >
                  BOOK A PRODUCTION CALL
                </motion.button>
              </div>

            </motion.div>

            {/* Right Column: Studio Shoot Video Preview Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.55, delay: 0.2 }}
              className="lg:col-span-6"
            >
              <div className="relative rounded-2xl bg-[#12061a] border border-white/15 p-3 sm:p-4 shadow-2xl shadow-black/80 overflow-hidden group">
                
                {/* Video Container */}
                <div className="relative aspect-[4/3] sm:aspect-[16/11] rounded-xl overflow-hidden bg-black">
                  <video
                    src={activeService.videoUrl}
                    poster={activeService.posterUrl}
                    autoPlay
                    loop
                    muted={isMuted}
                    playsInline
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-700"
                  />

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

                  {/* Top Center Unmute Pill - Matching Screenshot */}
                  <div className="absolute top-4 left-0 right-0 flex justify-center z-20">
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold tracking-wide transition-all shadow-lg ${
                        !isMuted
                          ? 'bg-[#FF007A] text-white shadow-pink-500/50'
                          : 'bg-black/80 hover:bg-black text-white border border-white/20'
                      }`}
                    >
                      {!isMuted ? (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Muted</span>
                        </>
                      ) : (
                        <>
                          <span>Unmute</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Micro stats overlay */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white">
                    <div className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                      🎬 4K Cinema Rig + Studio Godox Softboxes
                    </div>
                  </div>
                </div>

                {/* Bottom Action - "LEARN MORE" matching Screenshot */}
                <div className="mt-4 pt-2 flex items-center justify-between px-2">
                  <button
                    id="what-we-offer-learn-more-btn"
                    onClick={onOpenBooking}
                    className="text-xs sm:text-sm font-extrabold tracking-widest text-white uppercase hover:text-pink-400 transition-colors flex items-center gap-2 cursor-pointer font-display"
                  >
                    <span>LEARN MORE</span>
                    <ArrowRight className="w-4 h-4 text-pink-400" />
                  </button>

                  <div className="flex items-center gap-4 text-xs text-gray-400">
                    {activeService.stats.map((st, i) => (
                      <div key={i} className="text-right">
                        <span className="font-bold text-white block">{st.value}</span>
                        <span className="text-[10px] text-gray-400">{st.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </motion.div>

          </motion.div>
        </AnimatePresence>

      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, CheckCircle, Plus, Send, X, Play, Video, Sparkles, MessageSquare } from 'lucide-react';
import { ReviewItem } from '../types';
import { VideoReviewModal } from './VideoReviewModal';
import { InfiniteLogoCarousel } from './InfiniteLogoCarousel';
import { CinematicImage } from './CinematicImage';

interface ReviewsSectionProps {
  reviews: ReviewItem[];
  onAddReview: (review: { name: string; role: string; company: string; rating: number; comment: string; videoUrl?: string }) => Promise<void>;
  isLoading?: boolean;
  onBookShoot?: () => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({
  reviews,
  onAddReview,
  isLoading = false,
  onBookShoot
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVideoReview, setSelectedVideoReview] = useState<ReviewItem | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'video' | 'written'>('all');
  
  // Form State
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [company, setCompany] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !comment) return;

    setIsSubmitting(true);
    try {
      await onAddReview({
        name,
        role,
        company,
        rating,
        comment,
        ...(videoUrl.trim() ? { videoUrl: videoUrl.trim() } : {})
      });
      setSuccessMsg('Thank you! Your testimonial has been submitted.');
      setTimeout(() => {
        setIsModalOpen(false);
        setSuccessMsg('');
        setName('');
        setRole('');
        setCompany('');
        setComment('');
        setVideoUrl('');
      }, 1500);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredReviews = reviews.filter((r) => {
    if (filterType === 'video') return Boolean(r.videoUrl);
    if (filterType === 'written') return !r.videoUrl;
    return true;
  });

  const videoCount = reviews.filter(r => Boolean(r.videoUrl)).length;

  return (
    <section id="reviews" className="py-20 relative bg-[#0d0414] border-t border-white/5 scroll-mt-20">
      {/* Background ambient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.55, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10"
        >
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-[11px] font-bold tracking-wider text-pink-300 uppercase mb-3">
              <Sparkles className="w-3 h-3 text-pink-400" />
              <span>CLIENT TESTIMONIALS & CASE STORIES</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight">
              Loved by Visionary Brands
            </h2>
            <div className="flex flex-wrap items-center gap-3 mt-2.5">
              <div className="flex items-center text-[#FF007A]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#FF007A]" />
                ))}
              </div>
              <span className="text-sm font-semibold text-gray-200">
                4.9 / 5.0 Average Rating across 500+ Projects
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-pink-500/15 border border-pink-500/30 text-pink-300 font-bold">
                {videoCount} Video Stories
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 self-start md:self-auto">
            {/* Filter Pill Switcher */}
            <div className="inline-flex flex-wrap items-center p-1 rounded-2xl md:rounded-full bg-[#15061e] border border-white/10 text-xs gap-1">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3.5 py-2 rounded-full font-bold transition-all cursor-pointer min-h-[40px] flex items-center ${
                  filterType === 'all'
                    ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                All ({reviews.length})
              </button>
              <button
                onClick={() => setFilterType('video')}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full font-bold transition-all cursor-pointer min-h-[40px] ${
                  filterType === 'video'
                    ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                <span>Video Stories ({videoCount})</span>
              </button>
              <button
                onClick={() => setFilterType('written')}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full font-bold transition-all cursor-pointer min-h-[40px] ${
                  filterType === 'written'
                    ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Written</span>
              </button>
            </div>

            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-full border border-pink-500/40 hover:bg-pink-500/10 text-xs sm:text-sm font-semibold text-pink-200 hover:text-white transition-all cursor-pointer min-h-[44px]"
            >
              <Plus className="w-4 h-4" />
              <span>Leave a Review</span>
            </button>
          </div>
        </motion.div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {isLoading ? (
            // Skeleton Loading State for Review Cards
            Array.from({ length: 4 }).map((_, idx) => (
              <div
                key={`review-skeleton-${idx}`}
                className="rounded-2xl bg-[#14061b] border border-white/10 p-6 flex flex-col justify-between h-[280px] animate-pulse shadow-lg"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, sIdx) => (
                        <div key={sIdx} className="w-3.5 h-3.5 rounded bg-pink-500/20" />
                      ))}
                    </div>
                    <div className="w-16 h-3 rounded bg-white/10" />
                  </div>
                  <div className="space-y-2 mt-2">
                    <div className="w-full h-3 rounded bg-white/10" />
                    <div className="w-5/6 h-3 rounded bg-white/10" />
                    <div className="w-4/6 h-3 rounded bg-white/5" />
                  </div>
                </div>
                <div className="mt-6 pt-4 border-t border-white/5 space-y-1.5">
                  <div className="w-24 h-3.5 rounded bg-white/15" />
                  <div className="w-32 h-2.5 rounded bg-white/10" />
                </div>
              </div>
            ))
          ) : (
            filteredReviews.map((rev, index) => {
              const hasVideo = Boolean(rev.videoUrl);

              if (hasVideo) {
                // Video Testimonial Card with Thumbnail, Play Button Overlay & Text-Only Author Meta
                return (
                  <motion.div
                    key={rev.id}
                    initial={{ opacity: 0, y: 25 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-40px' }}
                    transition={{ duration: 0.45, delay: (index % 4) * 0.08, ease: [0.21, 0.45, 0.27, 0.9] }}
                    whileHover={{ y: -6 }}
                    onClick={() => setSelectedVideoReview(rev)}
                    className="group relative rounded-2xl bg-[#14061b] border border-pink-500/30 overflow-hidden flex flex-col justify-between hover:border-pink-500/70 transition-all shadow-[0_10px_30px_rgba(255,0,122,0.15)] cursor-pointer"
                  >
                    {/* Top Video Preview Header with Play Icon Overlay */}
                    <div className="relative aspect-[16/10] w-full bg-black overflow-hidden group">
                      <CinematicImage
                        src={rev.videoPosterUrl || rev.avatarUrl}
                        alt={`${rev.name} testimonial`}
                        containerClassName="absolute inset-0 w-full h-full"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 brightness-90 group-hover:brightness-100"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#14061b] via-black/40 to-black/20" />

                      {/* Video Story Tag */}
                      <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md border border-pink-500/40 text-[10px] font-bold uppercase tracking-wider text-pink-300">
                        <Video className="w-3 h-3 text-[#FF007A]" />
                        <span>Video Story</span>
                        {rev.videoDuration && <span className="text-gray-400">• {rev.videoDuration}</span>}
                      </div>

                      {/* Center Glowing Play Button */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="relative flex items-center justify-center">
                          <div className="absolute w-14 h-14 rounded-full bg-pink-500/30 blur-md group-hover:scale-125 transition-transform" />
                          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#FF007A] to-[#FF5E62] text-white flex items-center justify-center shadow-[0_0_20px_rgba(255,0,122,0.6)] border-2 border-white/40 group-hover:scale-110 transition-transform">
                            <Play className="w-5 h-5 fill-current ml-0.5" />
                          </div>
                        </div>
                      </div>

                      {/* Floating Prompt on hover */}
                      <div className="absolute bottom-2.5 inset-x-3 text-center">
                        <span className="inline-block text-[11px] font-bold text-gray-200 bg-black/80 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 group-hover:border-pink-500/40 transition-colors">
                          Watch Video Testimonial ↗
                        </span>
                      </div>
                    </div>

                    {/* Card Content & Text-Only Author Details */}
                    <div className="p-5 flex flex-col justify-between flex-1">
                      <div>
                        {/* Rating Stars & Date */}
                        <div className="flex items-center justify-between mb-2.5">
                          <div className="flex items-center text-[#FF007A]">
                            {[...Array(rev.rating)].map((_, i) => (
                              <Star key={i} className="w-3.5 h-3.5 fill-[#FF007A]" />
                            ))}
                          </div>
                          <span className="text-[10px] text-gray-500">{rev.date}</span>
                        </div>

                        {/* Comment Snippet */}
                        <p className="text-xs sm:text-sm text-gray-300 leading-relaxed italic line-clamp-3">
                          &ldquo;{rev.comment}&rdquo;
                        </p>
                      </div>

                      {/* Text-Only Client Identity Section with subtle top divider */}
                      <div className="mt-4 pt-3.5 border-t border-white/10 flex flex-col">
                        <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 truncate">
                          <span className="truncate">{rev.name}</span>
                          {rev.verified && <CheckCircle className="w-3.5 h-3.5 text-pink-400 shrink-0" />}
                        </div>
                        <div className="text-[11px] text-gray-400 mt-0.5 truncate">
                          {rev.role} • <span className="text-pink-300 font-medium">{rev.company}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              }

              // Text-only Review Card Fallback (Text-Only Author Meta, No Avatar)
              return (
                <motion.div
                  key={rev.id}
                  initial={{ opacity: 0, y: 25 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-40px' }}
                  transition={{ duration: 0.45, delay: (index % 4) * 0.08, ease: [0.21, 0.45, 0.27, 0.9] }}
                  whileHover={{ y: -4 }}
                  className="rounded-2xl bg-[#14061b] border border-white/10 p-6 flex flex-col justify-between hover:border-pink-500/40 transition-all shadow-lg"
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center text-[#FF007A]">
                        {[...Array(rev.rating)].map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-[#FF007A]" />
                        ))}
                      </div>
                      <span className="text-[10px] text-gray-500">{rev.date}</span>
                    </div>

                    <p className="text-xs sm:text-sm text-gray-300 leading-relaxed italic">
                      &ldquo;{rev.comment}&rdquo;
                    </p>
                  </div>

                  {/* Text-Only Client Identity Section with subtle top divider */}
                  <div className="mt-6 pt-4 border-t border-white/10 flex flex-col">
                    <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 truncate">
                      <span className="truncate">{rev.name}</span>
                      {rev.verified && <CheckCircle className="w-3.5 h-3.5 text-pink-400 shrink-0" />}
                    </div>
                    <div className="text-[11px] text-gray-400 mt-0.5 truncate">
                      {rev.role} • <span className="text-pink-300 font-medium">{rev.company}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>

        {/* Brand Logos Infinite Ribbon in Testimonials Section */}
        <div className="mt-16 pt-10 border-t border-white/5">
          <InfiniteLogoCarousel
            variant="testimonial"
            direction="right"
            speedSeconds={40}
            title="BRANDS FEATURED IN TESTIMONIALS & CASE FILMS"
            subtitle="Category-defining businesses who scaled digital presence and client acquisition through our films."
            onOpenBooking={onBookShoot}
            showPill={false}
          />
        </div>

      </div>

      {/* Video Review Playback Modal */}
      <VideoReviewModal
        review={selectedVideoReview}
        onClose={() => setSelectedVideoReview(null)}
        onBookShoot={onBookShoot}
      />

      {/* Leave Review Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-md rounded-2xl bg-[#15071f] border border-pink-500/30 p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white font-display">
                  Share Your Experience
                </h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 rounded-lg text-gray-400 hover:text-white bg-white/5 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {successMsg ? (
                <div className="py-8 text-center text-pink-300 font-medium">
                  {successMsg}
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full px-3.5 py-2 rounded-lg bg-[#0e0314] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-300 mb-1">Role</label>
                      <input
                        type="text"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                        placeholder="e.g. Founder / Director"
                        className="w-full px-3.5 py-2 rounded-lg bg-[#0e0314] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-300 mb-1">Brand / Company</label>
                      <input
                        type="text"
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        placeholder="e.g. Acme Studio"
                        className="w-full px-3.5 py-2 rounded-lg bg-[#0e0314] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">Rating</label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          type="button"
                          key={star}
                          onClick={() => setRating(star)}
                          className="p-1 text-pink-400 hover:scale-110 transition-transform cursor-pointer"
                        >
                          <Star className={`w-5 h-5 ${rating >= star ? 'fill-[#FF007A] text-[#FF007A]' : 'text-gray-600'}`} />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">Video Reel / Review URL (Optional)</label>
                    <input
                      type="url"
                      value={videoUrl}
                      onChange={(e) => setVideoUrl(e.target.value)}
                      placeholder="e.g. https://.../video.mp4"
                      className="w-full px-3.5 py-2 rounded-lg bg-[#0e0314] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">Review Details *</label>
                    <textarea
                      required
                      rows={3}
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="How was your production experience and content performance?"
                      className="w-full px-3.5 py-2 rounded-lg bg-[#0e0314] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full btn-primary-gradient py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider text-white flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSubmitting ? 'Posting...' : 'Submit Review Cards'}</span>
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, DollarSign, Film, Sparkles, CheckCircle2, ArrowRight, ArrowLeft, Phone, Mail, User, Building, Instagram } from 'lucide-react';
import confetti from 'canvas-confetti';
import { BookingSubmission } from '../types';
import { buildWhatsAppUrl, fetchConfiguredWhatsAppNumber, getInitialWhatsAppNumber, logWhatsAppInquiry } from '../utils/whatsapp';
import { backdropBlurIn, modalContentEntrance } from '../utils/motionVariants';

interface BookCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBookingSuccess: (booking: BookingSubmission) => void;
}

export const BookCallModal: React.FC<BookCallModalProps> = ({
  isOpen,
  onClose,
  onBookingSuccess
}) => {
  const [step, setStep] = useState<number>(1);
  const [formData, setFormData] = useState<BookingSubmission>({
    fullName: '',
    email: '',
    phone: '',
    companyName: '',
    serviceCategory: 'Personal Branding & Social Media',
    budgetRange: '$2,000 - $5,000',
    targetDate: '',
    projectDetails: '',
    instagramHandle: '',
  });

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [confirmedBooking, setConfirmedBooking] = useState<BookingSubmission | null>(null);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);

  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) {
        setWhatsappNumber(num);
      }
    });
    
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      isMounted = false;
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const serviceOptions = [
    {
      title: 'Personal Branding & Social Media',
      desc: 'Reels, talking head, thought-leadership & monthly content batching',
      icon: '👤'
    },
    {
      title: 'Interiors & Architectural Films',
      desc: 'Luxury homes, villas, cafés, furniture & spatial walkthroughs',
      icon: '🏛️'
    },
    {
      title: 'Product & Commercial Ads',
      desc: 'Macro cinema shots, e-commerce PDP video & Meta/TikTok ads',
      icon: '✨'
    },
    {
      title: 'Fashion & Lookbooks',
      desc: 'Studio editorial, streetwear & lifestyle campaign shoots',
      icon: '👗'
    },
    {
      title: 'Hospitality & Dining',
      desc: 'Cafés, bar ambience, cocktail styling & menu launch reels',
      icon: '☕'
    }
  ];

  const budgetOptions = [
    '$1,200 - $2,500 (Starter Batch)',
    '$2,500 - $5,000 (Growth Campaign)',
    '$5,000 - $10,000 (Cinema Production)',
    '$10,000+ (Comprehensive Brand Series)'
  ];

  const handleServiceSelect = (title: string) => {
    setFormData(prev => ({ ...prev, serviceCategory: title }));
    setStep(2);
  };

  const handleBudgetSelect = (budget: string) => {
    setFormData(prev => ({ ...prev, budgetRange: budget }));
    setStep(3);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!formData.fullName || !formData.email || !formData.phone) {
      setErrorMsg('Please complete your name, email, and contact phone number.');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit booking');
      }

      setConfirmedBooking(data.booking);
      onBookingSuccess(data.booking);

      // Trigger Confetti
      try {
        confetti({
          particleCount: 90,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FF007A', '#FF5E62', '#FFFFFF', '#A855F7']
        });
      } catch {
        // Safe fallback
      }

    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const resetAndClose = () => {
    setConfirmedBooking(null);
    setStep(1);
    setErrorMsg('');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          {/* Backdrop with framer-motion blur-in */}
          <motion.div
            variants={backdropBlurIn}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={resetAndClose}
            className="fixed inset-0 bg-black/85"
          />

          <motion.div
            variants={modalContentEntrance}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="relative w-full max-w-2xl rounded-3xl bg-[#12051a] border border-pink-500/30 p-6 sm:p-8 shadow-2xl shadow-purple-950/50 my-8 overflow-hidden z-10"
          >
            {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-32 bg-pink-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={resetAndClose}
          className="absolute top-6 right-6 p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {confirmedBooking ? (
          /* Confirmation State */
          <div className="py-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-pink-500/20 border border-pink-500 text-[#FF007A] flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-pink-400">
                BOOKING CONFIRMED
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display mt-1">
                Your Visual Session is Scheduled!
              </h2>
              <p className="text-sm text-gray-300 mt-2 max-w-md mx-auto">
                Reference ID: <span className="text-pink-300 font-mono font-bold">{confirmedBooking.id}</span>
              </p>
            </div>

            <div className="bg-[#190823] p-5 rounded-2xl border border-white/10 text-left max-w-md mx-auto space-y-2 text-xs text-gray-300">
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-gray-400">Client:</span>
                <span className="font-semibold text-white">{confirmedBooking.fullName}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-gray-400">Service:</span>
                <span className="font-semibold text-pink-300">{confirmedBooking.serviceCategory}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-gray-400">Budget Tier:</span>
                <span className="font-semibold text-white">{confirmedBooking.budgetRange}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Next Step:</span>
                <span className="font-semibold text-emerald-400">Creative Director Call in 4 hrs</span>
              </div>
            </div>

            {/* Post-Booking Action Buttons: WhatsApp Fast-Track and Done */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <motion.a
                id="booking-continue-whatsapp-btn"
                href={buildWhatsAppUrl(
                  whatsappNumber,
                  [
                    `Hi Hidden Directors Productions! I just scheduled a shoot consultation on your website (Ref: ${confirmedBooking.id}).`,
                    '',
                    `• Name: ${confirmedBooking.fullName}`,
                    `• Service: ${confirmedBooking.serviceCategory}`,
                    `• Budget: ${confirmedBooking.budgetRange}`,
                    confirmedBooking.companyName ? `• Brand: ${confirmedBooking.companyName}` : '',
                    confirmedBooking.targetDate ? `• Target Date: ${confirmedBooking.targetDate}` : '',
                    '',
                    `I would love to fast-track details and share our moodboard references with the director!`
                  ].filter(Boolean).join('\n')
                )}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  const msg = [
                    `Hi Hidden Directors Productions! I just scheduled a shoot consultation on your website (Ref: ${confirmedBooking.id}).`,
                    '',
                    `• Name: ${confirmedBooking.fullName}`,
                    `• Service: ${confirmedBooking.serviceCategory}`,
                    `• Budget: ${confirmedBooking.budgetRange}`,
                    confirmedBooking.companyName ? `• Brand: ${confirmedBooking.companyName}` : '',
                    confirmedBooking.targetDate ? `• Target Date: ${confirmedBooking.targetDate}` : '',
                    '',
                    `I would love to fast-track details and share our moodboard references with the director!`
                  ].filter(Boolean).join('\n');

                  logWhatsAppInquiry(
                    'booking',
                    { 
                      bookingRef: confirmedBooking.id, 
                      serviceName: confirmedBooking.serviceCategory,
                      sourceSection: 'Booking Confirmation Screen'
                    },
                    msg,
                    { clientName: confirmedBooking.fullName, clientPhone: confirmedBooking.phone }
                  );
                }}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="w-full sm:w-auto px-6 py-3 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-lg shadow-[#25D366]/30 cursor-pointer transition-all border border-emerald-300/30 group"
              >
                <svg className="w-4 h-4 fill-current text-white group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.711 1.457h.005c6.554 0 11.89-5.335 11.893-11.893a11.82 11.82 0 00-3.488-8.414z"/>
                </svg>
                <span>Continue on WhatsApp</span>
              </motion.a>

              <button
                id="booking-done-return-btn"
                onClick={resetAndClose}
                className="w-full sm:w-auto btn-primary-gradient px-8 py-3 rounded-full text-xs font-bold uppercase tracking-wider text-white cursor-pointer"
              >
                DONE & RETURN
              </button>
            </div>
          </div>
        ) : (
          <div>
            {/* Header & Step Tracker */}
            <div className="mb-6">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-pink-400 uppercase tracking-widest">
                  STEP {step} OF 4
                </span>
                <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#FF007A] to-[#FF5E62] transition-all duration-300"
                    style={{ width: `${(step / 4) * 100}%` }}
                  />
                </div>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display mt-2">
                {step === 1 && 'Select Your Shoot Focus'}
                {step === 2 && 'Estimate Your Production Budget'}
                {step === 3 && 'Project Vision & Target Timeline'}
                {step === 4 && 'Your Contact Details'}
              </h2>
              <p className="text-xs sm:text-sm text-gray-400 mt-1">
                {step === 1 && 'Choose the core discipline you want our directing crew to handle.'}
                {step === 2 && 'Transparent scale adapted to your brand reach and distribution tier.'}
                {step === 3 && 'Share any specifics, references, or timeline deadlines.'}
                {step === 4 && 'Where can our production team send your custom moodboard & call invite?'}
              </p>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {errorMsg}
              </div>
            )}

            {/* STEP 1: Services */}
            {step === 1 && (
              <div className="space-y-3">
                {serviceOptions.map((opt) => (
                  <button
                    key={opt.title}
                    onClick={() => handleServiceSelect(opt.title)}
                    className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between group cursor-pointer ${
                      formData.serviceCategory === opt.title
                        ? 'bg-pink-500/15 border-pink-500 text-white'
                        : 'bg-[#180722] hover:bg-[#200b2e] border-white/10 text-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <span className="text-2xl">{opt.icon}</span>
                      <div>
                        <div className="font-bold text-sm text-white group-hover:text-pink-300 transition-colors">
                          {opt.title}
                        </div>
                        <div className="text-xs text-gray-400 mt-0.5">
                          {opt.desc}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-pink-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                ))}
              </div>
            )}

            {/* STEP 2: Budget */}
            {step === 2 && (
              <div className="space-y-3">
                {budgetOptions.map((budget) => (
                  <button
                    key={budget}
                    onClick={() => handleBudgetSelect(budget)}
                    className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between group cursor-pointer ${
                      formData.budgetRange === budget
                        ? 'bg-pink-500/15 border-pink-500 text-white'
                        : 'bg-[#180722] hover:bg-[#200b2e] border-white/10 text-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-5 h-5 text-pink-400" />
                      <span className="font-bold text-sm text-white">{budget}</span>
                    </div>
                    <ArrowRight className="w-4 h-4 text-pink-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                ))}

                <div className="pt-3 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white px-3 py-2 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Timeline & Project Details */}
            {step === 3 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">
                    Target Shoot Date / Window
                  </label>
                  <input
                    type="date"
                    value={formData.targetDate}
                    onChange={(e) => setFormData({ ...formData, targetDate: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0d0313] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">
                    Instagram or Brand Website Handle
                  </label>
                  <div className="relative">
                    <Instagram className="w-4 h-4 text-gray-500 absolute left-3.5 top-3.5" />
                    <input
                      type="text"
                      placeholder="@yourbrand / @yourname"
                      value={formData.instagramHandle}
                      onChange={(e) => setFormData({ ...formData, instagramHandle: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0d0313] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">
                    Brief Vision / Deliverable Goals
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Tell us about the space, product, or personal branding concept..."
                    value={formData.projectDetails}
                    onChange={(e) => setFormData({ ...formData, projectDetails: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0d0313] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                  />
                </div>

                <div className="pt-2 flex justify-between items-center">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white px-3 py-2 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back
                  </button>

                  <button
                    type="button"
                    onClick={() => setStep(4)}
                    className="btn-primary-gradient px-6 py-2.5 rounded-full text-xs font-bold uppercase text-white cursor-pointer"
                  >
                    Continue to Details
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: Final Contact Form */}
            {step === 4 && (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">
                      Full Name *
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-gray-500 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        required
                        placeholder="John Doe"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0d0313] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">
                      Business / Brand Name
                    </label>
                    <div className="relative">
                      <Building className="w-4 h-4 text-gray-500 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        placeholder="e.g. Acme Studio"
                        value={formData.companyName}
                        onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0d0313] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">
                      Email Address *
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-gray-500 absolute left-3.5 top-3.5" />
                      <input
                        type="email"
                        required
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0d0313] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1">
                      Phone Number *
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-gray-500 absolute left-3.5 top-3.5" />
                      <input
                        type="tel"
                        required
                        placeholder="+91 98765 43210"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0d0313] border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-3 flex justify-between items-center">
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white px-3 py-2 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back
                  </button>

                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary-gradient px-8 py-3 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-xl shadow-pink-600/30 cursor-pointer disabled:opacity-50"
                  >
                    {loading ? 'Securing Slot...' : 'CONFIRM & BOOK CALL'}
                  </button>
                </div>
              </form>
            )}

          </div>
        )}

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

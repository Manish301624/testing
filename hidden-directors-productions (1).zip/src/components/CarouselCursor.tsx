import React, { useEffect, useState, useRef } from 'react';
import { motion, useMotionValue, useSpring, AnimatePresence } from 'motion/react';

export interface CarouselCursorProps {
  /** Target section container ref to scope cursor visibility to this section only */
  targetRef: React.RefObject<HTMLElement | null>;
}

/**
 * Scoped Custom Cursor for the Carousel Section
 * =========================================================================
 * - Replaces default cursor with a small white circle using mix-blend-mode: difference
 * - Expands to an 80px interactive circle showing "View" when hovering video cards
 * - Follows mouse coordinates with smooth spring physics / slight trailing lag
 * - Hides completely on mobile/touch screens (only displays on desktop with fine pointer)
 * - Strictly scoped to targetRef (disappears when cursor leaves the carousel section)
 * =========================================================================
 */
export const CarouselCursor: React.FC<CarouselCursorProps> = ({ targetRef }) => {
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [isCardHovered, setIsCardHovered] = useState<boolean>(false);
  const [isFinePointer, setIsFinePointer] = useState<boolean>(false);

  // Mouse coordinate motion values
  const mouseX = useMotionValue(-200);
  const mouseY = useMotionValue(-200);

  // Smooth physics-based spring follower for subtle non-linear lag
  const springConfig = { damping: 28, stiffness: 320, mass: 0.5 };
  const smoothX = useSpring(mouseX, springConfig);
  const smoothY = useSpring(mouseY, springConfig);

  const lastCoordsRef = useRef<{ x: number; y: number }>({ x: -200, y: -200 });

  // 1. Check for desktop fine pointer device (exclude touch/mobile devices)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const mediaQuery = window.matchMedia('(pointer: fine)');
    setIsFinePointer(mediaQuery.matches);

    const handleMediaChange = (e: MediaQueryListEvent) => {
      setIsFinePointer(e.matches);
    };

    mediaQuery.addEventListener('change', handleMediaChange);
    return () => mediaQuery.removeEventListener('change', handleMediaChange);
  }, []);

  // 2. Track mouse movement, bounds checking & card hover detection
  useEffect(() => {
    if (!isFinePointer || typeof window === 'undefined') return;

    const checkBoundsAndHover = (clientX: number, clientY: number) => {
      const container = targetRef.current;
      if (!container) {
        setIsVisible(false);
        return;
      }

      const rect = container.getBoundingClientRect();
      const insideSection =
        clientX >= rect.left &&
        clientX <= rect.right &&
        clientY >= rect.top &&
        clientY <= rect.bottom;

      if (!insideSection) {
        setIsVisible(false);
        setIsCardHovered(false);
        return;
      }

      // Inside carousel section
      setIsVisible(true);

      // Check if currently hovering over a video card
      const targetElement = document.elementFromPoint(clientX, clientY) as HTMLElement | null;
      const isOverCard = !!targetElement?.closest('[data-carousel-card="true"]');
      setIsCardHovered(isOverCard);
    };

    const handleMouseMove = (e: MouseEvent) => {
      lastCoordsRef.current = { x: e.clientX, y: e.clientY };
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
      checkBoundsAndHover(e.clientX, e.clientY);
    };

    const handleScroll = () => {
      // Recheck visibility when page scrolls while mouse is stationary
      const { x, y } = lastCoordsRef.current;
      if (x >= 0 && y >= 0) {
        checkBoundsAndHover(x, y);
      }
    };

    const handleMouseLeaveWindow = () => {
      setIsVisible(false);
      setIsCardHovered(false);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });
    document.addEventListener('mouseleave', handleMouseLeaveWindow);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mouseleave', handleMouseLeaveWindow);
    };
  }, [isFinePointer, targetRef, mouseX, mouseY]);

  // Hide completely on mobile/touch devices
  if (!isFinePointer) return null;

  return (
    <>
      {/* When mouse is inside the carousel section, hide the default system cursor */}
      {isVisible && (
        <style>{`
          #featured-work-carousel,
          #featured-work-carousel * {
            cursor: none !important;
          }
        `}</style>
      )}

      {/* Custom Spring Follower Circle */}
      <motion.div
        style={{
          x: smoothX,
          y: smoothY,
          translateX: '-50%',
          translateY: '-50%',
          mixBlendMode: 'difference',
          willChange: 'transform, width, height, opacity',
          transform: 'translate3d(0,0,0)',
        }}
        animate={{
          width: isCardHovered ? 78 : 14,
          height: isCardHovered ? 78 : 14,
          opacity: isVisible ? 1 : 0,
          scale: isVisible ? 1 : 0.3,
        }}
        transition={{
          type: 'spring',
          damping: 24,
          stiffness: 320,
          mass: 0.35,
        }}
        className="fixed top-0 left-0 rounded-full bg-white flex items-center justify-center pointer-events-none z-[9999] select-none"
        aria-hidden="true"
      >
        <AnimatePresence>
          {isCardHovered && (
            <motion.span
              key="view-label"
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.6 }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
              className="text-black text-[12px] font-black tracking-widest uppercase select-none pointer-events-none"
            >
              View
            </motion.span>
          )}
        </AnimatePresence>
      </motion.div>
    </>
  );
};

export default CarouselCursor;

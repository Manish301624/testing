import React from 'react';
import { motion } from 'motion/react';
import { Play, Star, ArrowUpRight } from 'lucide-react';
import { InfiniteLogoCarousel } from './InfiniteLogoCarousel';

interface StatsClientsProps {
  onLearnMoreRatings: () => void;
  onOpenBooking: () => void;
}

export const StatsClientsSection: React.FC<StatsClientsProps> = ({
  onLearnMoreRatings,
  onOpenBooking
}) => {
  return (
    <section id="about" className="py-14 relative overflow-hidden scroll-mt-24">
      {/* Background radial glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#14061a]/40 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* 3 Metric Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-6">
          
          {/* Card 1: 500+ COMPLETED PROJECT */}
          <motion.div
            id="stats-card-completed-projects"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.55, ease: [0.21, 0.45, 0.27, 0.9] }}
            className="relative rounded-2xl bg-[#0f0417]/90 border border-white/10 p-7 sm:p-8 bg-grid-pattern shadow-xl shadow-black/40 overflow-hidden flex flex-col justify-between group hover:border-pink-500/40 transition-all duration-300"
          >
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-pink-600/10 rounded-full blur-2xl pointer-events-none" />

            <div>
              <div className="text-4xl sm:text-5xl font-black text-white font-display tracking-tight group-hover:text-pink-100 transition-colors">
                500+
              </div>
              <div className="text-xs sm:text-sm font-bold tracking-widest text-gray-200 uppercase mt-2 font-display">
                COMPLETED PROJECT
              </div>
            </div>

            <p className="mt-8 text-xs sm:text-sm text-gray-400 font-normal leading-relaxed">
              Successfully delivered visual projects across interiors, cafés, products and brands.
            </p>
          </motion.div>

          {/* Card 2: Achievement with Play Icon & 5 Stars */}
          <motion.div
            id="stats-card-achievements"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.55, delay: 0.12, ease: [0.21, 0.45, 0.27, 0.9] }}
            className="relative rounded-2xl bg-[#0f0417]/90 border border-white/10 p-7 sm:p-8 bg-grid-pattern shadow-xl shadow-black/40 overflow-hidden flex flex-col justify-between group hover:border-pink-500/40 transition-all duration-300"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base sm:text-lg font-bold text-white font-display">
                Achievement
              </h3>
            </div>

            {/* Sub-stats 3 Column */}
            <div className="grid grid-cols-3 gap-2 mt-4 text-center border-y border-white/5 py-3">
              <div>
                <div className="text-sm sm:text-base font-bold text-white">500+</div>
                <div className="text-[10px] font-semibold tracking-wider text-gray-400 uppercase">PROJECT</div>
              </div>
              <div className="border-x border-white/5">
                <div className="text-sm sm:text-base font-bold text-white">4.5K</div>
                <div className="text-[10px] font-semibold tracking-wider text-gray-400 uppercase">RATE</div>
              </div>
              <div>
                <div className="text-sm sm:text-base font-bold text-white">1.5K</div>
                <div className="text-[10px] font-semibold tracking-wider text-gray-400 uppercase">USERS</div>
              </div>
            </div>

            {/* Center Play Button & Stars */}
            <div className="mt-5 flex items-center justify-between">
              {/* Glowing Magenta Circular Play Button */}
              <button
                onClick={onOpenBooking}
                className="w-12 h-12 rounded-full border-2 border-[#FF007A] flex items-center justify-center bg-pink-500/20 hover:bg-[#FF007A] text-[#FF007A] hover:text-white transition-all shadow-[0_0_15px_rgba(255,0,122,0.4)] cursor-pointer"
                title="Watch Agency Showreel"
              >
                <Play className="w-5 h-5 fill-current ml-0.5" />
              </button>

              <div className="flex flex-col items-end">
                <div className="flex items-center gap-0.5 text-[#FF007A]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#FF007A] text-[#FF007A]" />
                  ))}
                </div>
                <span className="text-xs font-semibold text-gray-300 mt-1">
                  Positive Reviews
                </span>
              </div>
            </div>
          </motion.div>

          {/* Card 3: 4.9 CLIENT RATINGS */}
          <motion.div
            id="stats-card-client-ratings"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.55, delay: 0.24, ease: [0.21, 0.45, 0.27, 0.9] }}
            className="relative rounded-2xl bg-[#0f0417]/90 border border-white/10 p-7 sm:p-8 bg-grid-pattern shadow-xl shadow-black/40 overflow-hidden flex flex-col justify-between group hover:border-pink-500/40 transition-all duration-300"
          >
            <div>
              <div className="text-4xl sm:text-5xl font-black text-white font-display tracking-tight">
                4.9
              </div>
              <div className="text-xs sm:text-sm font-bold tracking-widest text-gray-200 uppercase mt-2 font-display">
                CLIENT RATINGS
              </div>
            </div>

            <div className="mt-8">
              <motion.button
                id="stats-learn-more-btn"
                whileHover={{ scale: 1.03, borderColor: '#FF007A' }}
                whileTap={{ scale: 0.97 }}
                onClick={onLearnMoreRatings}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-full border border-pink-500/40 bg-pink-500/10 hover:bg-pink-500/20 text-xs sm:text-sm font-bold tracking-wider text-white uppercase transition-all cursor-pointer"
              >
                <ArrowUpRight className="w-4 h-4 text-pink-400" />
                <span>LEARN MORE</span>
              </motion.button>
            </div>
          </motion.div>

        </div>

        {/* Auto-Scrolling Infinite Client Brand Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mt-14"
        >
          <InfiniteLogoCarousel
            variant="stats"
            direction="left"
            speedSeconds={36}
            title="FEATURED CLIENT BRANDS & PRODUCTION COLLABORATIONS"
            subtitle="Explore visionary hospitality venues, luxury architecture studios, aesthetic spas, and lifestyle leaders powered by our cinema direction."
            onOpenBooking={onOpenBooking}
          />
        </motion.div>

      </div>
    </section>
  );
};

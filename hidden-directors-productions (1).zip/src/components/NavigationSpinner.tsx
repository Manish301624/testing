import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';

export const NavigationSpinner: React.FC = () => {
  return <LoadingSpinner fullScreen />;
};


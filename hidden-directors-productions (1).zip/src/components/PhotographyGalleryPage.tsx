import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence, useScroll, useTransform, useSpring, useReducedMotion, MotionValue } from 'motion/react';
import { 
  Camera, 
  ChevronRight, 
  Home, 
  Sparkles, 
  CalendarCheck, 
  ArrowRight, 
  RefreshCw, 
  Maximize2, 
  AlertCircle,
  PhoneCall,
  SlidersHorizontal
} from 'lucide-react';
import { WorkPhotoItem, WorkCategoryMeta } from '../types';
import { CinematicImage } from './CinematicImage';
import { getPhotographyByCategory, getCategoryMeta } from '../data/workData';
import { PhotographyLightbox } from './PhotographyLightbox';
import { SectionDivider } from './SectionDivider';
import { useLanguage } from '../context/LanguageContext';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { ScrollProgressBar } from './ScrollProgressBar';
import { LoadingSpinner } from './LoadingSpinner';
import { containerStagger, staggerFadeIn, slideUp, fadeIn, scaleIn } from '../utils/motionVariants';

interface PhotographyGalleryPageProps {
  onOpenBooking: () => void;
  onOpenCallback?: () => void;
}

export const PhotographyGalleryPage: React.FC<PhotographyGalleryPageProps> = ({
  onOpenBooking,
  onOpenCallback
}) => {
  const { category = 'interior-architecture' } = useParams<{ category: string }>();
  const navigate = useNavigate();
  const { language } = useLanguage();

  const [photos, setPhotos] = useState<WorkPhotoItem[]>([]);
  const [categoryMeta, setCategoryMeta] = useState<WorkCategoryMeta>(() => getCategoryMeta(category));
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Lightbox state
  const [lightboxIndex, setLightboxIndex] = useState<number>(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState<boolean>(false);

  // Scroll Container Ref for Parallax Target
  const gridContainerRef = useRef<HTMLDivElement>(null);
  
  // Parallax Core: useScroll on the grid container 
  const { scrollYProgress } = useScroll({
    target: gridContainerRef,
    offset: ["start end", "end start"]
  });

  // Fetch photos
  const fetchPhotos = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/work/${category}/photography`);
      if (!res.ok) {
        throw new Error(`Failed to load gallery items (${res.status})`);
      }
      const data = await res.json();
      setPhotos(data.items || []);
      if (data.category) {
        setCategoryMeta(data.category);
      }
    } catch (err: any) {
      console.warn('Backend API fetch error, using local fallback:', err);
      const fallbackItems = getPhotographyByCategory(category);
      const fallbackMeta = getCategoryMeta(category);
      setPhotos(fallbackItems);
      setCategoryMeta(fallbackMeta);
      if (!fallbackItems || fallbackItems.length === 0) {
        setError(err.message || 'Failed to load photography gallery');
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPhotos();
    setActiveFilter('all');
  }, [category]);

  // Filter items
  const filteredPhotos = activeFilter === 'all' 
    ? photos 
    : photos.filter(p => p.type.toLowerCase() === activeFilter.toLowerCase());

  // Infinite Scroll / Preloading State
  const [visibleCount, setVisibleCount] = useState<number>(9);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  const loadMoreEntry = useIntersectionObserver(loadMoreRef, { rootMargin: '600px' });

  // Reset visible count when filter or category changes
  useEffect(() => {
    setVisibleCount(9);
  }, [activeFilter, category]);

  // Handle intersection for preloading
  useEffect(() => {
    if (loadMoreEntry?.isIntersecting && visibleCount < filteredPhotos.length) {
      const nextCount = Math.min(visibleCount + 9, filteredPhotos.length);
      
      // Preload the next batch of images immediately in the background
      const nextBatch = filteredPhotos.slice(visibleCount, nextCount);
      nextBatch.forEach(photo => {
        const img = new Image();
        img.src = photo.imageUrl;
      });

      setVisibleCount(nextCount);
    }
  }, [loadMoreEntry?.isIntersecting, filteredPhotos, visibleCount]);

  // Scroll to top on mount and category change
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [category]);

  const filterCounts = {
    all: photos.length,
    residential: photos.filter(p => p.type.toLowerCase() === 'residential').length,
    commercial: photos.filter(p => p.type.toLowerCase() === 'commercial').length,
    hospitality: photos.filter(p => p.type.toLowerCase() === 'hospitality').length,
  };

  const filterTabs = [
    { id: 'all', label: language === 'es' ? 'Todos' : 'All', count: filterCounts.all },
    { id: 'residential', label: language === 'es' ? 'Residencial' : 'Residential', count: filterCounts.residential },
    { id: 'commercial', label: language === 'es' ? 'Comercial' : 'Commercial', count: filterCounts.commercial },
    { id: 'hospitality', label: language === 'es' ? 'Hospitalidad' : 'Hospitality', count: filterCounts.hospitality },
  ];

  // Mobile Swipe (Pan) Gesture to change filters
  const handleDragEnd = (event: any, info: any) => {
    const swipeConfidenceThreshold = 10000;
    const swipePower = Math.abs(info.offset.x) * info.velocity.x;

    const currentIndex = filterTabs.findIndex(tab => tab.id === activeFilter);
    
    if (swipePower < -swipeConfidenceThreshold) {
      // Swiped left -> Next category
      if (currentIndex < filterTabs.length - 1) {
        setActiveFilter(filterTabs[currentIndex + 1].id);
      }
    } else if (swipePower > swipeConfidenceThreshold) {
      // Swiped right -> Previous category
      if (currentIndex > 0) {
        setActiveFilter(filterTabs[currentIndex - 1].id);
      }
    }
  };

  const heroHeading = language === 'es' ? categoryMeta.photoHeroTitleEs : categoryMeta.photoHeroTitleEn;
  const heroDescription = language === 'es' ? categoryMeta.shortDescEs : categoryMeta.shortDescEn;

  // Distinct Category-Specific SEO Titles & Descriptions for Photography
  const categoryName = language === 'es' && categoryMeta.nameEs ? categoryMeta.nameEs : categoryMeta.name;
  
  const seoTitle = language === 'es'
    ? `${categoryName} — Fotografía Editorial y Arquitectónica | Hidden Directors`
    : `${categoryMeta.name} Photography & Editorial Stills | Hidden Directors Productions`;

  const getPhotographySeoDescription = (catSlug: string, isEs: boolean) => {
    switch (catSlug) {
      case 'interior-architecture':
        return isEs
          ? 'Portafolio fotográfico de arquitectura e interiorismo de alta resolución. Captura de luz natural, textura de materiales y composición de lujo espacial.'
          : 'High-resolution architectural and interior photography capturing natural light geometry, material texture, and spatial luxury by Hidden Directors.';
      case 'hospitality-food':
        return isEs
          ? 'Fotografía gastronómica editorial, coctelería y ambientes de restaurantes de alta cocina con iluminación sensorial y detalles de autor.'
          : 'Editorial culinary, cocktail, and restaurant hospitality photography featuring sensory lighting, artisan details, and Michelin-tier staging.';
      case 'ecommerce-product':
        return isEs
          ? 'Fotografía de producto comercial y lookbooks editoriales de alta resolución diseñados para campañas de comercio electrónico y catálogos de lujo.'
          : 'Commercial product photography and editorial lookbooks engineered for luxury brand campaigns, crisp resolution, and high-converting catalogs.';
      case 'personal-branding':
        return isEs
          ? 'Retratos editoriales y fotografía de marca personal para fundadores, directores y creadores que buscan proyectar liderazgo y autoridad.'
          : 'Executive editorial portraits and personal branding stills capturing authentic presence, leadership, and vision for founders and creators.';
      default:
        return isEs
          ? `Explora el portafolio fotográfico editorial y publicitario de alta resolución en ${categoryName} por Hidden Directors Productions.`
          : `Explore the high-resolution editorial and commercial photography portfolio in ${categoryMeta.name} by Hidden Directors Productions.`;
    }
  };

  const seoDescription = getPhotographySeoDescription(category, language === 'es');
  const canonicalUrl = `https://hiddendirectors.com/work/${category}/photography`;
  const ogImageUrl = photos.length > 0 && photos[0].imageUrl
    ? photos[0].imageUrl
    : 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80';

  const photographySchemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ImageGallery',
    'name': seoTitle,
    'description': seoDescription,
    'url': canonicalUrl,
    'creator': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'url': 'https://hiddendirectors.com'
    },
    'about': categoryMeta.name,
    'genre': 'Editorial Photography',
    'keywords': `${categoryMeta.name} photography, architectural stills, commercial photography, editorial portfolio, interior photography`
  };

  return (
    <div id="photography-gallery" className="min-h-screen bg-[#09030e] text-[#F3F4F6] pt-24 pb-20 selection:bg-pink-600 selection:text-white">
      <ScrollProgressBar />
      <Helmet>
        <title>{seoTitle}</title>
        <meta name="description" content={seoDescription} />
        <meta name="keywords" content={`${categoryMeta.name} photography, editorial stills, architectural photos, commercial photography, luxury interiors, medium format, Hidden Directors`} />

        {/* Open Graph / Facebook */}
        <meta property="og:type" content="article" />
        <meta property="og:title" content={seoTitle} />
        <meta property="og:description" content={seoDescription} />
        <meta property="og:image" content={ogImageUrl} />
        <meta property="og:image:alt" content={`${categoryMeta.name} Photography by Hidden Directors`} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={seoTitle} />
        <meta name="twitter:description" content={seoDescription} />
        <meta name="twitter:image" content={ogImageUrl} />
        <meta name="twitter:image:alt" content={`${categoryMeta.name} Photography Portfolio`} />

        {/* Canonical Link */}
        <link rel="canonical" href={canonicalUrl} />

        {/* Schema.org Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(photographySchemaJsonLd)}
        </script>
      </Helmet>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumbs */}
        <nav aria-label="Breadcrumbs" className="flex items-center gap-2 text-xs text-gray-400 py-3 mb-4 overflow-x-auto whitespace-nowrap">
          <Link to="/" className="hover:text-white transition-colors flex items-center gap-1">
            <Home className="w-3.5 h-3.5 text-pink-400" />
            <span>Home</span>
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <Link to="/#portfolio" className="hover:text-white transition-colors">Our Work</Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <span className="text-gray-300 font-medium">{categoryMeta.name}</span>
          <ChevronRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          <span className="text-pink-400 font-semibold">{language === 'es' ? 'Fotografía' : 'Photography'}</span>
        </nav>

        {/* Hero Header */}
        <motion.header 
          variants={slideUp}
          initial="hidden"
          animate="visible"
          className="relative pt-4 pb-12 border-b border-white/10 mb-10"
        >
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/20 text-pink-300 text-xs font-mono font-bold tracking-wider uppercase">
                <Camera className="w-3.5 h-3.5 text-[#FF007A]" />
                <span>Editorial Photography Gallery</span>
              </div>
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-[1.15]">
                {heroHeading}
              </h1>
              <p className="text-base sm:text-lg text-gray-300 font-light leading-relaxed">
                {heroDescription}
              </p>
            </div>
            <div className="shrink-0 flex items-center gap-3">
              <Link
                to={`/work/${category}/films`}
                className="group flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/5 hover:bg-[#FF007A]/15 border border-white/10 hover:border-[#FF007A]/40 text-xs sm:text-sm font-semibold text-gray-300 hover:text-white transition-all cursor-pointer shadow-sm"
              >
                <span>Switch to {categoryMeta.name} Films</span>
                <ArrowRight className="w-3.5 h-3.5 text-pink-400 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>

          {/* Filters */}
          <div className="mt-8 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-1.5 flex-wrap">
              <SlidersHorizontal className="w-3.5 h-3.5 text-gray-500 mr-1 hidden sm:inline" />
              {filterTabs.map((tab) => {
                const isActive = activeFilter === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveFilter(tab.id)}
                    className={`relative px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      isActive ? 'text-white bg-[#FF007A] shadow-lg shadow-pink-600/30' : 'text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/5'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${isActive ? 'bg-black/30 text-white' : 'bg-white/10 text-gray-400'}`}>
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="text-xs text-gray-400 font-mono flex items-center gap-3">
              <span>Showing {filteredPhotos.length} {filteredPhotos.length === 1 ? 'Capture' : 'Captures'}</span>
              <span className="hidden md:inline text-gray-600">•</span>
              <span className="hidden md:inline">Click any image for full-screen viewer</span>
            </div>
          </div>
        </motion.header>

        <SectionDivider />

        {/* Loading State: Centered Minimalist Loading Spinner */}
        {isLoading && (
          <LoadingSpinner 
            fullScreen={false} 
            size="md" 
            message="DEVELOPING GALLERY EXHIBIT" 
          />
        )}

        {/* Error / Empty States */}
        {!isLoading && error && photos.length === 0 && (
          <div className="py-20 text-center max-w-md mx-auto space-y-4">
            <div className="w-14 h-14 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mx-auto text-rose-400">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold text-white">Unable to Load Gallery</h3>
            <button onClick={fetchPhotos} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/40 text-pink-300 font-semibold text-xs transition-all cursor-pointer">
              <RefreshCw className="w-4 h-4" />
              <span>Retry Loading Gallery</span>
            </button>
          </div>
        )}

        {!isLoading && !error && filteredPhotos.length === 0 && (
          <div className="py-24 text-center max-w-lg mx-auto space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-pink-400">
              <Camera className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-white">{language === 'es' ? 'Próximamente' : 'Curated Gallery Coming Soon'}</h3>
            </div>
          </div>
        )}

        {/* PREMIUM PARALLAX GRID */}
        <div ref={gridContainerRef} className="pb-24 pt-8 min-h-[50vh]">
          {!isLoading && filteredPhotos.length > 0 && (
            <>
              <motion.div 
                layout 
                variants={containerStagger}
                initial="hidden"
                animate="visible"
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.05}
                onDragEnd={handleDragEnd}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 touch-pan-y"
              >
                <AnimatePresence mode="popLayout">
                  {filteredPhotos.slice(0, visibleCount).map((photo, index) => (
                    <ParallaxPhotoCard
                      key={photo.id}
                      photo={photo}
                      index={index}
                      scrollYProgress={scrollYProgress}
                      onClick={() => {
                        setLightboxIndex(index);
                        setIsLightboxOpen(true);
                      }}
                    />
                  ))}
                </AnimatePresence>
              </motion.div>
              
              {/* Intersection Observer Sentinel for Preloading */}
              {visibleCount < filteredPhotos.length && (
                <div ref={loadMoreRef} className="h-10 w-full mt-10 pointer-events-none" aria-hidden="true" />
              )}
            </>
          )}
        </div>

        {/* Bottom CTA Section */}
        <motion.section 
          variants={slideUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="mt-12 rounded-3xl bg-gradient-to-br from-[#180820] via-[#100316] to-[#07010b] border border-pink-500/20 p-8 sm:p-12 relative overflow-hidden shadow-2xl shadow-pink-950/40"
        >
          <div className="absolute top-0 right-0 w-80 h-80 bg-pink-500/10 rounded-full blur-[90px] pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-500/10 rounded-full blur-[90px] pointer-events-none" />
          <div className="relative z-10 max-w-2xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/15 border border-pink-500/30 text-pink-300 text-xs font-mono font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-[#FF007A]" />
              <span>Commission Architectural Photography</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
              Love what you see? <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-pink-400 via-rose-300 to-white bg-clip-text text-transparent">Let's create yours.</span>
            </h2>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2">
              <button onClick={onOpenBooking} className="w-full sm:w-auto px-7 py-3.5 rounded-full text-xs sm:text-sm font-bold tracking-wider text-white uppercase bg-gradient-to-r from-[#FF007A] to-[#D60065] shadow-xl shadow-pink-600/30 transition-all cursor-pointer flex items-center justify-center gap-2">
                <CalendarCheck className="w-4 h-4" />
                <span>Book A Production Call</span>
              </button>
              {onOpenCallback && (
                <button onClick={onOpenCallback} className="w-full sm:w-auto px-6 py-3.5 rounded-full text-xs sm:text-sm font-bold tracking-wider text-gray-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/15 transition-all cursor-pointer flex items-center justify-center gap-2">
                  <PhoneCall className="w-4 h-4 text-pink-400" />
                  <span>15-Min Quick Consultation</span>
                </button>
              )}
            </div>
          </div>
        </motion.section>
      </div>

      <PhotographyLightbox
        photos={filteredPhotos}
        currentIndex={lightboxIndex}
        isOpen={isLightboxOpen}
        onClose={() => setIsLightboxOpen(false)}
        onNavigate={(newIdx) => setLightboxIndex(newIdx)}
        onOpenBooking={onOpenBooking}
        categoryName={categoryMeta.name}
      />
    </div>
  );
};

// ==========================================
// PARALLAX PHOTO CARD SUB-COMPONENT
// ==========================================

interface ParallaxPhotoCardProps {
  photo: WorkPhotoItem;
  index: number;
  scrollYProgress: MotionValue<number>;
  onClick: () => void;
}

const ParallaxPhotoCard: React.FC<ParallaxPhotoCardProps> = ({ 
  photo, 
  index, 
  scrollYProgress,
  onClick 
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const isReducedMotion = useReducedMotion();

  // Handle responsive detection to disable parallax on mobile
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 1024);
    checkMobile(); // initial check
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  /* 
    PARALLAX LOGIC:
    - Col 0 (Left) and Col 2 (Right) translateY upwards (e.g., 60px to -80px)
    - Col 1 (Middle) stays more static / slightly downward (e.g., -20px to 30px)
    - To adjust intensity, modify the yRange arrays.
  */
  const colIndex = index % 3; // 0, 1, or 2 for desktop layout
  
  // Custom transform ranges per column
  const yRange = colIndex === 1 
    ? [-20, 30] // Middle column offsets downward
    : [60, -80]; // Outer columns translate upward faster for staggered depth

  // Raw transform calculations
  const rawY = useTransform(scrollYProgress, [0, 1], yRange);
  // Scale from 0.96 to 1.05 and back to 0.96 as the grid passes through viewport center
  const rawScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.96, 1.05, 0.96]);

  // Spring physics for buttery smooth awwwards-style easing
  const springConfig = { damping: 30, stiffness: 100, mass: 1 };
  const smoothY = useSpring(rawY, springConfig);
  const smoothScale = useSpring(rawScale, springConfig);

  // Disable transforms on mobile or if user prefers reduced motion
  const parallaxY = isMobile || isReducedMotion ? 0 : smoothY;
  const parallaxScale = isMobile || isReducedMotion ? 1 : smoothScale;

  return (
    <motion.div
      layout
      variants={staggerFadeIn}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-50px' }}
      className="w-full"
    >
      {/* Inner motion div specifically for handling the Parallax offsets cleanly */}
      <motion.div 
        style={{ y: parallaxY, scale: parallaxScale }}
        className="w-full h-full"
      >
        <motion.div
          layoutId={`card-${photo.id}`}
          onClick={onClick}
          data-cursor="view" // Hooks into CustomCursor
          className="relative group w-full aspect-[4/5] rounded-2xl overflow-hidden border border-white/5 bg-[#12071a] cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-pink-900/30 transition-shadow duration-500"
        >
          <CinematicImage
            layoutId={`img-${photo.id}`}
            src={photo.imageUrl}
            alt={photo.title}
            loading="lazy"
            containerClassName="absolute inset-0 w-full h-full"
            className="w-full h-full object-cover transition-transform duration-700 ease-[0.33,1,0.68,1] group-hover:scale-110"
          />

          {/* High-end Hover Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

          {/* Hover Details Info (Slides up smoothly) */}
          <div className="absolute inset-x-0 bottom-0 p-6 flex flex-col justify-end translate-y-8 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 ease-[0.22,1,0.36,1] pointer-events-none">
            <div className="flex items-center justify-between mb-3">
              <span className="px-2.5 py-1 rounded text-[10px] font-mono uppercase font-bold tracking-widest bg-pink-500/90 text-white backdrop-blur-md shadow-sm">
                {photo.type}
              </span>
              <div className="p-2 rounded-full bg-black/40 text-white border border-white/20 backdrop-blur-md shadow-lg transform scale-90 group-hover:scale-100 transition-transform duration-500 delay-100">
                <Maximize2 className="w-4 h-4" />
              </div>
            </div>

            <div className="space-y-1.5">
              <h3 className="text-lg font-bold text-white leading-tight">
                {photo.title}
              </h3>
              <p className="text-sm text-pink-300 font-medium">
                {photo.client}
              </p>
              {photo.location && (
                <p className="text-xs text-gray-400 font-mono mt-1">
                  {photo.location}
                </p>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

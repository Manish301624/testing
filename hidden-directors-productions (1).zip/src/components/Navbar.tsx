import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  ChevronDown, 
  ChevronRight, 
  Menu, 
  X, 
  PhoneCall, 
  Sun, 
  Moon, 
  Globe, 
  Camera, 
  Film, 
  ArrowRight,
  ArrowLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Logo } from './Logo';
import { ThemeToggleIcon } from './ThemeToggleIcon';
import { useLanguage } from '../context/LanguageContext';

export interface WorkSubmenuItem {
  label: string;
  subCategory?: string;
  desc?: string;
}

export interface WorkCategoryItem {
  label: string;
  category: string;
  desc: string;
  badge?: string;
  submenu: (string | WorkSubmenuItem)[];
}

interface NavbarProps {
  onOpenBooking: () => void;
  onOpenAdmin?: () => void;
  onOpenCallback?: () => void;
  bookingCount?: number;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}

/**
 * Nested Work Category Configuration Data Structure.
 */
export const WORK_NAV_CATEGORIES: WorkCategoryItem[] = [
  {
    label: 'Interior & Architecture',
    category: 'interior-architecture',
    desc: 'Luxury spaces, modern villas, spatial design & furniture',
    badge: 'Popular',
    submenu: [
      { label: 'Photography', subCategory: 'interior-photo', desc: 'High-res editorial & ambient interior stills' },
      { label: "Film's", subCategory: 'interior-films', desc: 'Cinematic 4K spatial walkthroughs & drone tours' },
      { label: 'Spatial Walkthroughs', subCategory: 'interior-3d', desc: 'Immersive pacing for architects & developers' },
    ]
  },
  {
    label: 'Hospitality & Food',
    category: 'hospitality-food',
    desc: 'Fine dining, upscale cafés, cocktail bars & hotels',
    submenu: [
      { label: 'Photography', subCategory: 'food-photo', desc: 'Editorial lighting, macro textures & beverage' },
      { label: "Film's", subCategory: 'food-films', desc: 'Sensory kitchen action & dining ambience' },
      { label: 'Chef & Brand Stories', subCategory: 'food-story', desc: 'Narrative spotlights for founders & culinary icons' },
    ]
  },
  {
    label: 'E-commerce & Product',
    category: 'ecommerce-product',
    desc: 'Commercial high-speed ads, hero reels & catalog assets',
    submenu: [
      { label: 'Photography', subCategory: 'product-photo', desc: 'Clean studio setups and conversion lookbooks' },
      { label: "Film's", subCategory: 'product-macro', desc: 'Phantom slow-mo & precision lighting' },
      { label: 'E-commerce Hero Videos', subCategory: 'product-hero', desc: 'Direct-to-consumer lifestyle & social convertors' },
    ]
  },
  {
    label: 'Personal Branding',
    category: 'personal-branding',
    desc: 'Founder stories, keynote reels & social authority',
    submenu: [
      { label: 'Photography', subCategory: 'brand-photo', desc: 'Executive visual identity & editorial portraits' },
      { label: "Film's", subCategory: 'brand-doc', desc: 'High-impact visionary storytelling' },
      { label: 'Podcast & Keynote Reels', subCategory: 'brand-reels', desc: 'Viral bite-sized thought leadership clips' },
    ]
  }
];

export const Navbar: React.FC<NavbarProps> = ({ 
  onOpenBooking, 
  onOpenAdmin, 
  onOpenCallback,
  bookingCount = 0,
  theme = 'dark',
  onToggleTheme
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  
  // Desktop Dropdown State
  const [isWorkDropdownOpen, setIsWorkDropdownOpen] = useState<boolean>(false);
  const [activeCategoryIndex, setActiveCategoryIndex] = useState<number | null>(null);

  // Mobile Accordion States
  const [isMobileWorkExpanded, setIsMobileWorkExpanded] = useState<boolean>(false);
  const [mobileExpandedCategory, setMobileExpandedCategory] = useState<string | null>(null);

  // ---------------------------------------------------------------------------
  // TABLET & TOUCH DEVICE DETECTION VIA matchMedia
  // ---------------------------------------------------------------------------
  // We use window.matchMedia('(hover: hover) and (pointer: fine)') to determine 
  // whether the user's primary input device supports true precision mouse hover.
  // - true: Mouse/trackpad (desktop/laptop) -> enables hover-to-open flyouts.
  // - false: Touch device (iPads, Android tablets, touch laptops) -> switches to 
  //          robust click/tap-to-open dropdown behavior.
  const [isTrueHover, setIsTrueHover] = useState<boolean>(true);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mediaQuery = window.matchMedia('(hover: hover) and (pointer: fine)');
    setIsTrueHover(mediaQuery.matches);

    const handler = (e: MediaQueryListEvent) => {
      setIsTrueHover(e.matches);
    };
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  // Close dropdown when tapping outside on touch devices / tablets
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('#nav-work-dropdown-container')) {
        setIsWorkDropdownOpen(false);
        setActiveCategoryIndex(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, []);

  const { language, toggleLanguage } = useLanguage();

  // Timeouts for mouse hover
  const openTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const closeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const dropdownCloseTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (openTimeoutRef.current) clearTimeout(openTimeoutRef.current);
      if (closeTimeoutRef.current) clearTimeout(closeTimeoutRef.current);
      if (dropdownCloseTimeoutRef.current) clearTimeout(dropdownCloseTimeoutRef.current);
    };
  }, []);

  // Desktop hover handlers (only active when isTrueHover is true)
  const handleWorkMenuEnter = () => {
    if (!isTrueHover) return; // Ignore on touch devices
    if (dropdownCloseTimeoutRef.current) {
      clearTimeout(dropdownCloseTimeoutRef.current);
      dropdownCloseTimeoutRef.current = null;
    }
    setIsWorkDropdownOpen(true);
  };

  const handleWorkMenuLeave = () => {
    if (!isTrueHover) return; // Ignore on touch devices
    dropdownCloseTimeoutRef.current = setTimeout(() => {
      setIsWorkDropdownOpen(false);
      setActiveCategoryIndex(null);
    }, 220);
  };

  const handleCategoryMouseEnter = (index: number) => {
    if (!isTrueHover) return; // Ignore on touch devices
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
    if (openTimeoutRef.current) clearTimeout(openTimeoutRef.current);
    openTimeoutRef.current = setTimeout(() => {
      setActiveCategoryIndex(index);
    }, 160);
  };

  const handleCategoryMouseLeave = () => {
    if (!isTrueHover) return; // Ignore on touch devices
    if (openTimeoutRef.current) {
      clearTimeout(openTimeoutRef.current);
      openTimeoutRef.current = null;
    }
    closeTimeoutRef.current = setTimeout(() => {
      setActiveCategoryIndex(null);
    }, 200);
  };

  const handleFlyoutMouseEnter = () => {
    if (!isTrueHover) return;
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
    if (dropdownCloseTimeoutRef.current) {
      clearTimeout(dropdownCloseTimeoutRef.current);
      dropdownCloseTimeoutRef.current = null;
    }
  };

  const handleFlyoutMouseLeave = () => {
    if (!isTrueHover) return;
    closeTimeoutRef.current = setTimeout(() => {
      setActiveCategoryIndex(null);
    }, 180);
  };

  // Click/Tap toggle handler for touch devices and tablets
  const handleWorkClickToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isTrueHover) {
      // Toggle dropdown on touch/tablet
      setIsWorkDropdownOpen((prev) => !prev);
      setActiveCategoryIndex(null);
    } else {
      // On desktop, click navigates to portfolio or toggles
      setIsWorkDropdownOpen((prev) => !prev);
    }
  };

  // Click handler for categories on touch devices (expands inline submenu)
  const handleCategoryTouchToggle = (e: React.MouseEvent, index: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isTrueHover) {
      setActiveCategoryIndex(activeCategoryIndex === index ? null : index);
    }
  };

  // ---------------------------------------------------------------------------
  // NAVIGATION & CATEGORY FILTERING DISPATCH
  // ---------------------------------------------------------------------------
  const location = useLocation();
  const navigate = useNavigate();

  const isAboutRoute = location.pathname === '/about';
  const isBlogRoute = location.pathname.startsWith('/blog') || (location.pathname === '/' && location.hash === '#blog');
  const isPersonalBrandingRoute = location.pathname === '/personal-branding';
  const isHomeRoute = location.pathname === '/' && (!location.hash || location.hash === '#home');

  const navigateTo = useCallback((path: string, hash?: string) => {
    setIsMenuOpen(false);
    setIsWorkDropdownOpen(false);
    setActiveCategoryIndex(null);

    if (path === '/about') {
      if (location.pathname !== '/about') {
        navigate('/about');
      }
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      return;
    }

    if (path === '/personal-branding') {
      if (location.pathname !== '/personal-branding') {
        navigate('/personal-branding');
      }
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      return;
    }

    if (path === '/blog') {
      if (location.pathname !== '/blog') {
        navigate('/blog');
      }
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      return;
    }

    // Path is '/'
    if (location.pathname !== '/') {
      navigate('/');
      if (hash) {
        setTimeout(() => {
          const element = document.querySelector(hash);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
          }
        }, 180);
      } else {
        window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      }
    } else {
      if (hash) {
        const element = document.querySelector(hash);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
      }
    }
  }, [location.pathname, navigate]);

  const scrollToSection = useCallback((id: string) => {
    navigateTo('/', id);
  }, [navigateTo]);

  const handleSubmenuClick = (category: string, subItemLabel: string) => {
    setIsWorkDropdownOpen(false);
    setActiveCategoryIndex(null);
    setIsMenuOpen(false);

    const lower = subItemLabel.toLowerCase();
    if (lower.includes('photo')) {
      navigate(`/work/${category}/photography`);
      window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
      return;
    }
    if (lower.includes('film') || lower.includes('video') || lower.includes('walkthrough') || lower.includes('macro') || lower.includes('doc')) {
      navigate(`/work/${category}/films`);
      window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
      return;
    }

    if (category) {
      navigate(`/work/${category}/photography`);
      window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
      return;
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('hd:select-portfolio-category', {
          detail: { category, subCategory: subItemLabel }
        })
      );
    }
    navigateTo('/', '#portfolio');
  };

  const navLinks = [
    { name: language === 'es' ? 'Inicio' : 'Home', path: '/', hash: '#home', active: isHomeRoute },
    { name: language === 'es' ? 'Sobre Nosotros' : 'About Us', path: '/about', active: isAboutRoute },
    { name: language === 'es' ? 'Portafolio' : 'Our Work', path: '/', hash: '#portfolio', hasDropdown: true, active: (location.pathname === '/' && location.hash === '#portfolio') || location.pathname.startsWith('/project') || location.pathname.startsWith('/work/') },
    { name: language === 'es' ? 'Marca Personal' : 'Personal Branding', path: '/personal-branding', active: isPersonalBrandingRoute },
    { name: language === 'es' ? 'Insights' : 'Insights', path: '/blog', active: isBlogRoute },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 w-full z-50 bg-[#09030e]/85 backdrop-blur-md border-b border-white/5 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
        
        {/* Brand Logo - Official Hidden Directors Identity */}
        <button 
          onClick={() => navigateTo('/', '#home')}
          id="nav-logo"
          aria-label="Hidden Directors Productions Home"
          className="flex items-center group focus:outline-none transition-transform duration-200 hover:scale-[1.02] cursor-pointer bg-transparent border-0 p-2 min-h-[44px] min-w-[44px]"
        >
          <Logo className="h-9 sm:h-10 w-auto text-white" />
        </button>

        {/* Desktop & Tablet-Hover Navigation Links (hidden on screens < 1024px so mobile hamburger handles tablets/mobile correctly up to 1024px) */}
        <nav className="hidden lg:flex items-center gap-7 lg:gap-8">
          {navLinks.map((link) => (
            <div key={link.name} className="relative" id={link.hasDropdown ? "nav-work-dropdown-container" : undefined}>
              {link.hasDropdown ? (
                <div 
                  className="relative"
                  onMouseEnter={handleWorkMenuEnter}
                  onMouseLeave={handleWorkMenuLeave}
                >
                  <button
                    id="nav-our-work-dropdown"
                    onClick={handleWorkClickToggle}
                    className="flex items-center gap-1.5 text-sm font-semibold text-gray-200 hover:text-white transition-colors py-2 px-1 cursor-pointer group min-h-[44px]"
                    aria-expanded={isWorkDropdownOpen}
                    aria-haspopup="true"
                  >
                    <span className="group-hover:text-[#FF007A] transition-colors">{link.name}</span>
                    <ChevronDown className={`w-4 h-4 transition-transform duration-200 text-gray-400 group-hover:text-[#FF007A] ${isWorkDropdownOpen ? 'rotate-180 text-[#FF007A]' : ''}`} />
                  </button>

                  {/* Level 1 Dropdown Menu */}
                  <AnimatePresence>
                    {isWorkDropdownOpen && (
                      <motion.div
                        id="work-level1-dropdown"
                        initial={{ opacity: 0, y: 10, scale: 0.97 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.97 }}
                        transition={{ duration: 0.18, ease: 'easeOut' }}
                        className="absolute top-full left-0 w-80 mt-1 bg-[#0f0a14] border border-white/10 rounded-2xl p-2.5 shadow-2xl shadow-purple-950/60 backdrop-blur-xl z-50"
                      >
                        {/* Header Tag inside dropdown */}
                        <div className="px-3 py-1.5 mb-1.5 border-b border-white/5 flex items-center justify-between">
                          <span className="text-[10px] font-bold tracking-wider text-pink-400 uppercase font-mono">
                            {language === 'es' ? 'CATEGORÍAS DE TRABAJO' : 'WORK DISCIPLINES'}
                          </span>
                          <span className="text-[10px] text-gray-500 font-mono">
                            {isTrueHover ? 'Hover for Submenu' : 'Tap to Expand'}
                          </span>
                        </div>

                        {/* Top-Level Categories List */}
                        <div className="space-y-1">
                          {WORK_NAV_CATEGORIES.map((item, idx) => {
                            const isHovered = activeCategoryIndex === idx;
                            const hasSubmenu = item.submenu && item.submenu.length > 0;

                            return (
                              <div
                                key={item.category}
                                className="relative"
                                onMouseEnter={() => handleCategoryMouseEnter(idx)}
                                onMouseLeave={handleCategoryMouseLeave}
                              >
                                <button
                                  onClick={(e) => {
                                    if (!isTrueHover && hasSubmenu) {
                                      // On touch devices, tapping toggles the inline/sub-panel state
                                      handleCategoryTouchToggle(e, idx);
                                    } else {
                                      e.preventDefault();
                                      handleSubmenuClick(item.category, item.label);
                                    }
                                  }}
                                  className={`w-full text-left p-3 rounded-xl transition-all duration-150 flex items-center justify-between group/cat cursor-pointer min-h-[44px] ${
                                    isHovered 
                                      ? 'bg-gradient-to-r from-pink-500/15 to-purple-500/10 border border-[#FF007A]/40 text-white shadow-md' 
                                      : 'hover:bg-white/5 text-gray-300 border border-transparent'
                                  }`}
                                >
                                  <div className="flex-1 pr-2">
                                    <div className="flex items-center gap-2">
                                      <span className={`text-xs font-bold transition-colors ${isHovered ? 'text-[#FF007A]' : 'text-gray-100 group-hover/cat:text-white'}`}>
                                        {item.label}
                                      </span>
                                      {item.badge && (
                                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-[#FF007A]/20 text-pink-300 border border-pink-500/30">
                                          {item.badge}
                                        </span>
                                      )}
                                    </div>
                                    <p className="text-[10.5px] text-gray-400 mt-0.5 line-clamp-1 leading-tight">
                                      {item.desc}
                                    </p>
                                  </div>

                                  {hasSubmenu && (
                                    <ChevronRight className={`w-4 h-4 transition-transform duration-200 shrink-0 ${isHovered || isHovered ? 'text-[#FF007A] translate-x-0.5' : 'text-gray-500 group-hover/cat:text-gray-300'}`} />
                                  )}
                                </button>

                                {/* LEVEL 2 SUBMENU: Flyout for desktop (hover), or expandable sub-panel for touch/tablet */}
                                <AnimatePresence>
                                  {isHovered && hasSubmenu && (
                                    <motion.div
                                      id={`work-flyout-submenu-${item.category}`}
                                      onMouseEnter={handleFlyoutMouseEnter}
                                      onMouseLeave={handleFlyoutMouseLeave}
                                      initial={{ opacity: 0, x: isTrueHover ? -8 : 0, y: isTrueHover ? 0 : 4, scale: 0.98 }}
                                      animate={{ opacity: 1, x: 0, y: 0, scale: 1 }}
                                      exit={{ opacity: 0, x: isTrueHover ? -6 : 0, y: 4, scale: 0.98 }}
                                      transition={{ duration: 0.16, ease: 'easeOut' }}
                                      className={
                                        isTrueHover 
                                          ? "absolute top-0 left-full ml-2 w-72 bg-[#12071a] border border-[#FF007A]/30 rounded-2xl p-2 shadow-2xl shadow-pink-950/40 backdrop-blur-2xl z-50 pointer-events-auto"
                                          : "mt-1 mb-2 ml-2 mr-2 p-2 bg-[#15091f] border border-[#FF007A]/40 rounded-xl space-y-1"
                                      }
                                    >
                                      {/* If touch device, show a Back button to return to 1st level */}
                                      {!isTrueHover && (
                                        <div className="mb-1 pb-1 border-b border-white/10 flex items-center justify-between">
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setActiveCategoryIndex(null);
                                            }}
                                            className="text-[11px] font-bold text-pink-400 flex items-center gap-1 p-1 min-h-[36px]"
                                          >
                                            <ArrowLeft className="w-3.5 h-3.5" />
                                            <span>Back to Categories</span>
                                          </button>
                                        </div>
                                      )}

                                      <div className="px-3 py-1.5 mb-1 border-b border-white/5 flex items-center justify-between">
                                        <span className="text-[10px] font-bold tracking-wider text-pink-400 uppercase font-mono">
                                          {item.label}
                                        </span>
                                        <span className="text-[10px] text-emerald-400 font-mono font-bold">
                                          {item.submenu.length} Formats
                                        </span>
                                      </div>

                                      <div className="space-y-1">
                                        {item.submenu.map((sub, sIdx) => {
                                          const isObj = typeof sub === 'object';
                                          const subLabel = isObj ? sub.label : sub;
                                          const subDesc = isObj ? sub.desc : undefined;
                                          const isFilm = subLabel.toLowerCase().includes('film') || subLabel.toLowerCase().includes('video') || subLabel.toLowerCase().includes('reel');

                                          return (
                                            <button
                                              key={sIdx}
                                              onClick={(e) => {
                                                e.preventDefault();
                                                handleSubmenuClick(item.category, subLabel);
                                              }}
                                              className="w-full text-left p-2.5 rounded-xl hover:bg-gradient-to-r hover:from-[#FF007A]/20 hover:to-transparent border border-transparent hover:border-[#FF007A]/40 transition-all group/subitem cursor-pointer flex items-start gap-2.5 min-h-[44px]"
                                            >
                                              <div className="mt-0.5 p-1.5 rounded-lg bg-white/5 group-hover/subitem:bg-[#FF007A]/20 transition-colors">
                                                {isFilm ? (
                                                  <Film className="w-3.5 h-3.5 text-pink-400 group-hover/subitem:text-pink-300" />
                                                ) : (
                                                  <Camera className="w-3.5 h-3.5 text-pink-400 group-hover/subitem:text-pink-300" />
                                                )}
                                              </div>
                                              <div className="flex-1">
                                                <div className="flex items-center justify-between">
                                                  <span className="text-xs font-bold text-gray-200 group-hover/subitem:text-white">
                                                    {subLabel}
                                                  </span>
                                                  <ArrowRight className="w-3 h-3 text-gray-500 opacity-0 group-hover/subitem:opacity-100 group-hover/subitem:translate-x-0.5 group-hover/subitem:text-[#FF007A] transition-all" />
                                                </div>
                                                {subDesc && (
                                                  <p className="text-[10px] text-gray-400 group-hover/subitem:text-gray-300 mt-0.5 leading-tight">
                                                    {subDesc}
                                                  </p>
                                                )}
                                              </div>
                                            </button>
                                          );
                                        })}
                                      </div>

                                      {/* Quick View All in Category Footer */}
                                      <div className="mt-2 pt-2 border-t border-white/5">
                                        <button
                                          onClick={(e) => {
                                            e.preventDefault();
                                            handleSubmenuClick(item.category, item.label);
                                          }}
                                          className="w-full py-2 px-2 rounded-lg bg-white/5 hover:bg-white/10 text-[10.5px] font-bold text-pink-300 hover:text-white text-center flex items-center justify-center gap-1.5 transition-colors cursor-pointer min-h-[40px]"
                                        >
                                          <span>View All {item.label}</span>
                                          <ArrowRight className="w-3 h-3" />
                                        </button>
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            );
                          })}
                        </div>

                        {/* Dropdown Footer */}
                        <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between px-2">
                          <button
                            onClick={() => scrollToSection('#portfolio')}
                            className="text-[11px] font-bold text-gray-400 hover:text-white transition-colors flex items-center gap-1 py-1.5 min-h-[36px]"
                          >
                            <span>Browse Complete Portfolio</span>
                            <ArrowRight className="w-3 h-3 text-[#FF007A]" />
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <button
                  onClick={() => navigateTo(link.path, link.hash)}
                  className={`text-sm font-semibold transition-colors py-2 px-1 relative cursor-pointer bg-transparent border-0 min-h-[44px] ${
                    link.active 
                      ? 'text-[#FF007A] font-bold' 
                      : 'text-gray-200 hover:text-white'
                  }`}
                >
                  {link.name}
                  {link.active && (
                    <motion.div 
                      layoutId="activeNavIndicator"
                      className="absolute -bottom-1 left-0 right-0 h-[2px] bg-[#FF007A] rounded-full shadow-[0_0_8px_#FF007A]" 
                    />
                  )}
                </button>
              )}
            </div>
          ))}
        </nav>

        {/* Right CTA, Language Switcher, Theme Toggle and Admin shortcut */}
        <div className="hidden lg:flex items-center gap-2.5 lg:gap-3.5">
          
          {/* Language Switcher Segmented Button */}
          <div className="relative">
            <button
              id="language-switcher-btn"
              onClick={toggleLanguage}
              title={language === 'en' ? 'Cambiar a Español' : 'Switch to English'}
              aria-label="Toggle language between English and Spanish"
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white transition-all cursor-pointer group min-h-[44px]"
            >
              <Globe className="w-3.5 h-3.5 text-pink-400 group-hover:rotate-12 transition-transform duration-300" />
              <div className="flex items-center text-[11px] font-extrabold tracking-wider font-mono">
                <span className={language === 'en' ? 'text-white' : 'text-gray-500'}>EN</span>
                <span className="text-gray-600 mx-0.5">/</span>
                <span className={language === 'es' ? 'text-pink-400' : 'text-gray-500'}>ES</span>
              </div>
            </button>
          </div>

          {/* Theme Toggle Button */}
          {onToggleTheme && (
            <motion.button
              id="theme-mode-toggle-btn"
              whileHover={{ scale: 1.1, backgroundColor: 'rgba(255, 255, 255, 0.12)' }}
              whileTap={{ scale: 0.9 }}
              onClick={onToggleTheme}
              aria-label={theme === 'dark' ? 'Switch to high-contrast light mode' : 'Switch to dark mode'}
              title={theme === 'dark' ? 'Switch to high-contrast light mode' : 'Switch to dark mode'}
              className="p-3 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 transition-colors cursor-pointer flex items-center justify-center relative overflow-hidden group shadow-inner min-h-[44px] min-w-[44px]"
            >
              <ThemeToggleIcon theme={theme} size={18} />
            </motion.button>
          )}

          {/* Instant Callback Quick Action */}
          {onOpenCallback && (
            <motion.button
              id="nav-instant-callback-btn"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={onOpenCallback}
              title="Request a 15-Minute Instant Callback"
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-bold tracking-wider text-pink-300 hover:text-white bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 transition-all cursor-pointer shadow-sm group min-h-[44px]"
            >
              <PhoneCall className="w-3.5 h-3.5 text-[#FF007A] group-hover:rotate-12 transition-transform" />
              <span className="hidden xl:inline">{language === 'es' ? 'LLAMADA RÁPIDA' : 'INSTANT CALLBACK'}</span>
              <span className="xl:hidden">{language === 'es' ? 'LLAMAR' : 'CALLBACK'}</span>
            </motion.button>
          )}

          {/* Glowing "BOOK A CALL" gradient pill button */}
          <motion.button
            id="nav-book-a-call-btn"
            data-cursor="magnetic"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            onClick={onOpenBooking}
            className="btn-primary-gradient px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold tracking-wider text-white uppercase shadow-lg shadow-pink-600/30 transition-all cursor-pointer min-h-[44px]"
          >
            {language === 'es' ? 'RESERVAR LLAMADA' : 'BOOK A CALL'}
          </motion.button>
        </div>

        {/* Mobile & Tablet Hamburger Menu Trigger (Shown on screens < 1024px to cover tablets up to 1024px landscape) */}
        <div className="flex lg:hidden items-center gap-2">
          {/* Mobile Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="px-3 py-2 rounded-xl bg-white/5 text-gray-300 hover:text-white border border-white/10 text-xs font-bold font-mono flex items-center gap-1 min-h-[44px] min-w-[44px] justify-center"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-pink-400" />
            <span className="text-[11px]">{language.toUpperCase()}</span>
          </button>

          {onToggleTheme && (
            <motion.button
              whileTap={{ scale: 0.88 }}
              onClick={onToggleTheme}
              className="p-3 rounded-xl bg-white/5 text-gray-300 hover:text-white border border-white/10 flex items-center justify-center min-h-[44px] min-w-[44px]"
              aria-label="Toggle theme mode"
              title="Toggle theme mode"
            >
              <ThemeToggleIcon theme={theme} size={16} />
            </motion.button>
          )}

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onOpenBooking}
            className="btn-primary-gradient px-4 py-2 rounded-full text-xs font-bold tracking-wider text-white uppercase shadow-md shadow-pink-600/20 min-h-[44px] flex items-center"
          >
            {language === 'es' ? 'RESERVAR' : 'BOOK'}
          </motion.button>

          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-3 rounded-xl bg-white/5 text-gray-300 hover:text-white border border-white/10 focus:outline-none min-h-[44px] min-w-[44px] flex items-center justify-center"
            aria-label="Toggle navigation menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

      </div>

      {/* Mobile & Tablet Drawer Menu (Accordion for Our Work & Touch navigation up to 1024px) */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#0e0514] border-b border-white/10 px-4 pt-4 pb-8 space-y-3 max-h-[88vh] overflow-y-auto"
          >
            {navLinks.map((link) => {
              if (link.hasDropdown) {
                return (
                  <div key={link.name} className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
                    {/* Mobile Level 1 Tap Header */}
                    <button
                      onClick={() => setIsMobileWorkExpanded(!isMobileWorkExpanded)}
                      className="w-full flex items-center justify-between px-4 py-3.5 text-sm font-bold text-gray-200 hover:text-white transition-colors min-h-[44px]"
                    >
                      <span className="flex items-center gap-2">
                        <span className={isMobileWorkExpanded ? 'text-[#FF007A]' : ''}>{link.name}</span>
                        <span className="text-[10px] font-mono font-bold text-pink-400 bg-pink-500/10 px-2 py-0.5 rounded border border-pink-500/20">
                          {WORK_NAV_CATEGORIES.length} Categories
                        </span>
                      </span>
                      <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${isMobileWorkExpanded ? 'rotate-180 text-[#FF007A]' : ''}`} />
                    </button>

                    {/* Mobile Level 1 Dropdown Content */}
                    <AnimatePresence>
                      {isMobileWorkExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="px-3 pb-3 space-y-2 border-t border-white/5 bg-black/20"
                        >
                          <div className="pt-2 text-[10px] font-mono uppercase tracking-wider text-pink-400 px-2">
                            Select Category
                          </div>
                          {WORK_NAV_CATEGORIES.map((cat) => {
                            const isCategoryOpen = mobileExpandedCategory === cat.category;
                            return (
                              <div key={cat.category} className="rounded-xl border border-white/5 bg-white/[0.01] overflow-hidden">
                                <button
                                  onClick={() => setMobileExpandedCategory(isCategoryOpen ? null : cat.category)}
                                  className="w-full flex items-center justify-between p-3 text-left min-h-[44px]"
                                >
                                  <div>
                                    <div className="text-xs font-bold text-white">{cat.label}</div>
                                    <div className="text-[10px] text-gray-400 line-clamp-1">{cat.desc}</div>
                                  </div>
                                  <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform ${isCategoryOpen ? 'rotate-180 text-[#FF007A]' : ''}`} />
                                </button>

                                <AnimatePresence>
                                  {isCategoryOpen && (
                                    <motion.div
                                      initial={{ opacity: 0, height: 0 }}
                                      animate={{ opacity: 1, height: 'auto' }}
                                      exit={{ opacity: 0, height: 0 }}
                                      className="px-3 pb-3 space-y-1.5 border-t border-white/5 bg-white/[0.02]"
                                    >
                                      {cat.submenu.map((sub, sIdx) => {
                                        const subLabel = typeof sub === 'object' ? sub.label : sub;
                                        return (
                                          <button
                                            key={sIdx}
                                            onClick={() => handleSubmenuClick(cat.category, subLabel)}
                                            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-pink-500/10 text-xs font-semibold text-gray-300 hover:text-white flex items-center justify-between min-h-[44px]"
                                          >
                                            <span>{subLabel}</span>
                                            <ArrowRight className="w-3 h-3 text-[#FF007A]" />
                                          </button>
                                        );
                                      })}
                                      <button
                                        onClick={() => handleSubmenuClick(cat.category, cat.label)}
                                        className="w-full mt-1 py-2 px-3 rounded-lg bg-pink-500/20 text-[11px] font-bold text-pink-300 text-center min-h-[40px]"
                                      >
                                        View All {cat.label}
                                      </button>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            );
                          })}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              }

              return (
                <button
                  key={link.name}
                  onClick={() => navigateTo(link.path, link.hash)}
                  className={`w-full text-left px-4 py-3.5 rounded-xl text-sm font-semibold transition-colors flex items-center justify-between min-h-[44px] ${
                    link.active 
                      ? 'bg-pink-500/10 text-[#FF007A] font-bold border border-pink-500/30' 
                      : 'text-gray-200 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <span>{link.name}</span>
                  <ArrowRight className="w-4 h-4 text-gray-500" />
                </button>
              );
            })}

            {/* Mobile Footer Actions */}
            <div className="pt-4 border-t border-white/10 flex flex-col gap-2.5">
              {onOpenCallback && (
                <button
                  onClick={() => {
                    setIsMenuOpen(false);
                    onOpenCallback();
                  }}
                  className="w-full py-3 px-4 rounded-xl bg-pink-500/10 border border-pink-500/30 text-pink-300 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 min-h-[44px]"
                >
                  <PhoneCall className="w-4 h-4 text-[#FF007A]" />
                  <span>{language === 'es' ? 'Solicitar Llamada Rápida' : 'Request Instant Callback'}</span>
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

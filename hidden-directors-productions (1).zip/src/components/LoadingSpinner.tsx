import React from 'react';
import { motion } from 'motion/react';

export interface LoadingSpinnerProps {
  fullScreen?: boolean;
  message?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  fullScreen = true,
  message,
  size = 'md',
  className = '',
}) => {
  const sizeMap = {
    sm: { container: 'w-8 h-8', svg: 'w-8 h-8', dot: 'w-1 h-1', stroke: '1.5' },
    md: { container: 'w-12 h-12', svg: 'w-12 h-12', dot: 'w-1.5 h-1.5', stroke: '1.5' },
    lg: { container: 'w-16 h-16', svg: 'w-16 h-16', dot: 'w-2 h-2', stroke: '2' },
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  const content = (
    <motion.div
      className="flex flex-col items-center justify-center gap-4"
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      role="status"
      aria-label={message || "Loading content"}
      aria-live="polite"
    >
      <div className={`relative flex items-center justify-center ${currentSize.container}`}>
        {/* Subtle glowing ambient aura */}
        <div 
          className="absolute inset-0 rounded-full bg-[#FF007A]/10 blur-xl pointer-events-none"
          aria-hidden="true"
        />

        {/* Outer track and spinning high-end minimal arc */}
        <motion.svg
          className={`${currentSize.svg} text-[#FF007A]`}
          viewBox="0 0 50 50"
          animate={{ rotate: 360 }}
          transition={{
            duration: 1.1,
            repeat: Infinity,
            ease: "linear",
          }}
          aria-hidden="true"
        >
          {/* Subtle background track */}
          <circle
            cx="25"
            cy="25"
            r="20"
            fill="none"
            stroke="currentColor"
            strokeWidth={currentSize.stroke}
            className="opacity-15"
          />
          {/* Active spinning arc with rounded ends */}
          <circle
            cx="25"
            cy="25"
            r="20"
            fill="none"
            stroke="currentColor"
            strokeWidth={currentSize.stroke}
            strokeLinecap="round"
            strokeDasharray="85 150"
            className="opacity-95 drop-shadow-[0_0_12px_rgba(255,0,122,0.85)]"
          />
        </motion.svg>

        {/* Center luminous pulsating micro-aperture */}
        <motion.div
          className={`absolute ${currentSize.dot} bg-[#FF007A] rounded-full shadow-[0_0_10px_rgba(255,0,122,1)]`}
          animate={{ 
            opacity: [0.35, 1, 0.35], 
            scale: [0.8, 1.25, 0.8] 
          }}
          transition={{ 
            duration: 1.4, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
          aria-hidden="true"
        />
      </div>

      {message && (
        <motion.p
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.3 }}
          className="text-xs font-mono tracking-widest text-gray-400 uppercase select-none"
        >
          {message}
        </motion.p>
      )}
    </motion.div>
  );

  if (!fullScreen) {
    return (
      <div 
        id="loading-spinner-container"
        className={`w-full min-h-[320px] py-16 flex items-center justify-center ${className}`}
      >
        {content}
      </div>
    );
  }

  return (
    <div
      id="loading-spinner-overlay"
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-[#09030e]/85 backdrop-blur-md ${className}`}
    >
      {content}
    </div>
  );
};

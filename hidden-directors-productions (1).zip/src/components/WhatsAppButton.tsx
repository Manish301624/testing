import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  buildWhatsAppUrl,
  fetchConfiguredWhatsAppNumber,
  getInitialWhatsAppNumber,
  getContextualWhatsAppMessage,
  logWhatsAppInquiry,
  WhatsAppContextType
} from '../utils/whatsapp';

interface WhatsAppButtonProps {
  customMessage?: string;
  forcedContext?: WhatsAppContextType;
}

export const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({ 
  customMessage,
  forcedContext 
}) => {
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [activeSection, setActiveSection] = useState<WhatsAppContextType>('general');
  const [activeSectionName, setActiveSectionName] = useState<string>('Hidden Directors');

  // Sync WhatsApp number from server configuration
  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) {
        setWhatsappNumber(num);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Section observer to detect context dynamically based on user scroll position
  useEffect(() => {
    if (forcedContext) {
      setActiveSection(forcedContext);
      return;
    }

    const sectionIds: { id: string; context: WhatsAppContextType; name: string }[] = [
      { id: 'hero', context: 'hero', name: 'Commercials & Reels' },
      { id: 'portfolio', context: 'portfolio', name: 'Portfolio & Work' },
      { id: 'services', context: 'services', name: 'Services & Packages' },
      { id: 'process', context: 'process', name: '5-Stage Process' },
      { id: 'reviews', context: 'reviews', name: 'Client Reviews' },
      { id: 'faq', context: 'faq', name: 'FAQ & Deliverables' },
    ];

    const observerCallback: IntersectionObserverCallback = (entries) => {
      // Find the entry with the highest intersection ratio
      const visible = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio);

      if (visible.length > 0) {
        const topEntry = visible[0];
        const match = sectionIds.find((s) => s.id === topEntry.target.id);
        if (match) {
          setActiveSection(match.context);
          setActiveSectionName(match.name);
        }
      }
    };

    const observer = new IntersectionObserver(observerCallback, {
      threshold: [0.2, 0.5, 0.8],
      rootMargin: '-10% 0px -10% 0px'
    });

    sectionIds.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => {
      observer.disconnect();
    };
  }, [forcedContext]);

  // Derive the context-aware message
  const message = useMemo(() => {
    if (customMessage) return customMessage;
    return getContextualWhatsAppMessage(activeSection);
  }, [customMessage, activeSection]);

  const whatsappUrl = useMemo(() => {
    return buildWhatsAppUrl(whatsappNumber, message);
  }, [whatsappNumber, message]);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    logWhatsAppInquiry(activeSection, { sourceSection: activeSectionName }, message);
    if (typeof window !== 'undefined') {
      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    }
  };

  // Human-readable contextual label for the pill
  const contextualPillText = useMemo(() => {
    switch (activeSection) {
      case 'portfolio':
        return 'Inquire about Portfolio';
      case 'services':
        return 'Inquire about Services';
      case 'process':
        return 'Ask about Production';
      case 'reviews':
        return 'Chat with Directors';
      case 'faq':
        return 'Quick WhatsApp Inquiry';
      default:
        return 'Chat on WhatsApp';
    }
  }, [activeSection]);

  return (
    <div
      id="floating-whatsapp-container"
      className="fixed bottom-6 left-6 z-50 flex flex-col items-start select-none group/container"
    >
      <div className="flex items-center gap-2.5">
        {/* Glowing Circular WhatsApp Button with subtle pulse animation that pauses on hover */}
        <motion.a
          id="floating-whatsapp-btn"
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={handleClick}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          // Subtle pulse animation on unhover; pauses completely when hovered
          animate={
            isHovered
              ? {
                  scale: 1.1,
                  boxShadow: '0 10px 30px rgba(37, 211, 102, 0.7)',
                }
              : {
                  scale: [1, 1.05, 1],
                  boxShadow: [
                    '0 0 0 0 rgba(37, 211, 102, 0.45)',
                    '0 0 0 14px rgba(37, 211, 102, 0)',
                    '0 0 0 0 rgba(37, 211, 102, 0)'
                  ],
                }
          }
          transition={
            isHovered
              ? {
                  type: 'spring',
                  stiffness: 350,
                  damping: 22
                }
              : {
                  duration: 2.4,
                  repeat: Infinity,
                  repeatType: 'loop',
                  ease: 'easeInOut'
                }
          }
          whileTap={{ scale: 0.94 }}
          className="relative w-13 h-13 rounded-full bg-gradient-to-tr from-[#1EBE5D] via-[#25D366] to-[#40E57E] text-white flex items-center justify-center cursor-pointer transition-colors border border-white/30 group"
          title={`Chat on WhatsApp with Hidden Directors (${activeSectionName})`}
          aria-label="Chat with Hidden Directors Productions on WhatsApp"
        >
          {/* Concentric expanding radar wave (pauses on hover) */}
          <AnimatePresence>
            {!isHovered && (
              <motion.span
                initial={{ opacity: 0.5, scale: 1 }}
                animate={{ opacity: 0, scale: 1.6 }}
                exit={{ opacity: 0 }}
                transition={{
                  duration: 2.4,
                  repeat: Infinity,
                  repeatType: 'loop',
                  ease: 'easeOut',
                }}
                className="absolute inset-0 rounded-full bg-[#25D366] pointer-events-none -z-10"
              />
            )}
          </AnimatePresence>

          {/* Authentic WhatsApp Icon SVG */}
          <svg
            className="w-7 h-7 text-white fill-current filter drop-shadow-sm transition-transform duration-200 group-hover:scale-105"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            <path
              d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.711 1.457h.005c6.554 0 11.89-5.335 11.893-11.893a11.82 11.82 0 00-3.488-8.414z"
              fill="currentColor"
            />
          </svg>

          {/* Online green indicator badge */}
          <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-[#100517] border-2 border-[#12051a] flex items-center justify-center">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </span>
        </motion.a>

        {/* Dynamic Context-Aware Floating Pill Badge */}
        <motion.a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={handleClick}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          whileHover={{ scale: 1.02 }}
          className="hidden sm:flex items-center gap-2 bg-[#14061a]/95 hover:bg-[#1f0828] text-white border border-[#25D366]/40 px-3.5 py-2 rounded-full shadow-2xl shadow-black/80 backdrop-blur-md cursor-pointer transition-all group/pill"
        >
          <span className="w-2 h-2 rounded-full bg-[#25D366] shadow-[0_0_8px_#25D366]" />
          <span className="text-xs font-bold text-gray-200 group-hover/pill:text-white tracking-wide">
            {contextualPillText}
          </span>
          <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 uppercase">
            {activeSection !== 'general' ? activeSection : 'Direct'}
          </span>
        </motion.a>
      </div>
    </div>
  );
};

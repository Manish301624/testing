import React from 'react';
import { motion } from 'motion/react';

interface SectionDividerProps {
  className?: string;
}

export const SectionDivider: React.FC<SectionDividerProps> = ({ className = 'my-12' }) => {
  return (
    <div className={`w-full relative flex items-center justify-center ${className}`}>
      {/* Subtle gradient line */}
      <div className="absolute inset-0 h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent w-full top-1/2 -translate-y-1/2" />
      
      {/* Glowing animated dot */}
      <div className="relative w-full max-w-2xl h-[1px]">
        <motion.div
          className="absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-[#FF007A]"
          style={{
            boxShadow: '0 0 12px 2px rgba(255, 0, 122, 0.8)',
          }}
          animate={{
            left: ['0%', '100%', '0%'],
            opacity: [0, 1, 1, 0, 0, 1, 0]
          }}
          transition={{
            duration: 6,
            ease: "easeInOut",
            repeat: Infinity,
          }}
        />
      </div>
    </div>
  );
};

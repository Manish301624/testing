import { CinematicImage } from "./CinematicImage";
import React, { useRef, useState, useEffect, useCallback, useMemo } from 'react';
import { motion, useScroll, useTransform, useReducedMotion, useMotionValue, useSpring } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { CarouselCursor } from './CarouselCursor';

/**
 * Single Video Card Data Structure
 */
export interface VideoCardItem {
  id?: string;
  videoUrl: string;
  imageUrl: string;
  posterUrl?: string;
  category: string;
  title: string;
  // Technical production metadata
  resolution?: string;
  duration?: string;
  clientType?: string;
}

export type VideoCardData = VideoCardItem;

/**
 * Column Data Structure
 */
export interface VideoColumn {
  id?: string | number;
  /** Array of video cards for this column */
  cards: VideoCardItem[];
  /** Direction of scroll: 'up' or 'down' (auto-assigned if omitted based on column index) */
  direction?: 'up' | 'down';
  /** Duration in seconds for one full loop cycle (default: ~24-30s) */
  speed?: number;
}

export type VideoColumnData = VideoColumn;

export interface VerticalVideoCarouselProps {
  /** Array of column objects (typically 6 columns for desktop layout) */
  columns?: VideoColumn[];
  /** Outer container styling override */
  className?: string;
  /** Carousel track viewport height class (defaults to 'h-[540px] sm:h-[620px] lg:h-[700px]') */
  trackHeightClassName?: string;
  /** Large bold editorial-style heading (defaults to "FEATURED WORK") */
  heading?: string;
  /** Editorial subline / kicker label */
  subheading?: string;
  /** Custom ticker text items (defaults to standard luxury ticker) */
  tickerItems?: string[];
  /** Show the full editorial header & marquee ticker */
  showEditorialHeader?: boolean;
  /** Optional CTA label */
  ctaLabel?: string;
  /** Callback when the CTA button is clicked */
  onCtaClick?: () => void;
  /** Optional header right custom elements (e.g. view switchers, badges) */
  headerRight?: React.ReactNode;
  /** Optional callback when a video card is clicked */
  onCardClick?: (card: VideoCardItem) => void;
}

/**
 * Individual Video Card Component
 * =========================================================================
 * - 3:4 aspect ratio tall rectangle
 * - 16px rounded corners (`rounded-[16px]`)
 * - Subtle shadow & dark border (`shadow-2xl shadow-black/80 border-white/10`)
 * - Background image layer: Renders immediately to prevent black/blank flashes
 * - HTML5 <video>: autoPlay, loop, muted, playsInline, object-fit: cover, no controls
 * - Lazy loads video playback with IntersectionObserver (plays only when visible)
 * - Graceful fallback to image if video fails or encounters network issues
 * - Dark gradient overlay at bottom
 * - Accent color: Electric Pink (#FF2D78) strictly on the category tag with `tracking-wide`
 * - White title text truncated with ellipsis
 * =========================================================================
 */
/**
 * Individual Video Card Component
 * =========================================================================
 * HOVER & 3D TILT SPECIFICATIONS (Apple-Style Product Card):
 * =========================================================================
 * 1. 3D Perspective Tilt:
 *    - Uses `useMotionValue` and `useSpring` to track cursor position relative to card center.
 *    - Calculates rotational angles on X and Y axes with a perspective plane of 1000px.
 *    - Rebounds smoothly to level plane on mouse leave with natural spring recoil (non-linear).
 * 2. Media Scale Up:
 *    - On hover, the underlying video/poster smoothly scales up by 1.05 using spring physics.
 * 3. Gradient Scrim Overlay:
 *    - Darkens and becomes significantly deeper/more visible on hover for maximum cinematic contrast.
 * 4. Title Underline Animation:
 *    - Draws in smoothly from left to right on hover using an electric pink (#FF2D78) accent line.
 * 5. Accessibility:
 *    - Respects `useReducedMotion()`. When active, tilts and scales remain disabled.
 * =========================================================================
 */
const VideoCard: React.FC<{
  card: VideoCardItem;
  onClick?: () => void;
}> = ({ card, onClick }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const shouldReduceMotion = useReducedMotion();

  const [hasVideoError, setHasVideoError] = useState<boolean>(false);
  const [isVideoLoading, setIsVideoLoading] = useState<boolean>(true);
  const [isVideoPlaying, setIsVideoPlaying] = useState<boolean>(false);
  const [isHovered, setIsHovered] = useState<boolean>(false);

  // Motion values for cursor position relative to card center:
  // x: -0.5 (left edge) to +0.5 (right edge)
  // y: -0.5 (top edge) to +0.5 (bottom edge)
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  // Smooth physics-based spring configuration for Apple-style subtle 3D tilt
  // Ensures spring animation (not linear) with natural dampening and elasticity
  const tiltSpringConfig = { stiffness: 320, damping: 22, mass: 0.1 };
  const smoothMouseX = useSpring(mouseX, tiltSpringConfig);
  const smoothMouseY = useSpring(mouseY, tiltSpringConfig);

  // Subtle 3D perspective rotation (max ~7.5 degrees)
  // When cursor is near the top (negative Y), top tilts back (positive rotateX)
  // When cursor is near the right (positive X), right tilts in (positive rotateY)
  const rotateX = useTransform(smoothMouseY, [-0.5, 0.5], shouldReduceMotion ? [0, 0] : [7.5, -7.5]);
  const rotateY = useTransform(smoothMouseX, [-0.5, 0.5], shouldReduceMotion ? [0, 0] : [-7.5, 7.5]);

  // Handle cursor movement inside card bounding box
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (shouldReduceMotion || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const xPct = (e.clientX - rect.left) / rect.width - 0.5;
    const yPct = (e.clientY - rect.top) / rect.height - 0.5;
    mouseX.set(xPct);
    mouseY.set(yPct);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    // Smoothly spring back to rest position (0, 0)
    mouseX.set(0);
    mouseY.set(0);
  };

  // Intersection Observer: lazy-play video only when inside the carousel viewport,
  // and pause immediately when card scrolls out of view to save battery and GPU performance.
  useEffect(() => {
    const el = containerRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          if (videoRef.current && !hasVideoError) {
            videoRef.current.play().catch(() => {
              // Gracefully handle browser auto-play restrictions
            });
          }
        } else {
          // Strictly pause immediately when scrolled out of viewport
          if (videoRef.current) {
            videoRef.current.pause();
          }
        }
      },
      {
        threshold: 0,
        rootMargin: '0px' // Exact viewport bounds to preserve battery & avoid unnecessary decoding
      }
    );

    observer.observe(el);

    // Also automatically pause playback when document tab is minimized or switched
    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (videoRef.current) {
          videoRef.current.pause();
        }
      } else if (!hasVideoError && videoRef.current && el) {
        const rect = el.getBoundingClientRect();
        const inViewport = rect.top < window.innerHeight && rect.bottom > 0;
        if (inViewport) {
          videoRef.current.play().catch(() => {});
        }
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      observer.disconnect();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [hasVideoError]);

  const handleVideoError = useCallback(() => {
    setHasVideoError(true);
    setIsVideoLoading(false);
    setIsVideoPlaying(false);
  }, []);

  /**
   * Scroll-driven card entrance animation:
   * Scales from 0.85 to 1 and fades from opacity 0 to 1 as it scrolls into view.
   * If user has prefers-reduced-motion active, scale starts directly at 1.
   */
  return (
    <div style={{ perspective: 1000 }} className="w-full">
      <motion.div
        ref={containerRef}
        onClick={onClick}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        initial={shouldReduceMotion ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.85 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{
          duration: shouldReduceMotion ? 0.15 : 0.6,
          ease: [0.16, 1, 0.3, 1]
        }}
        style={{
          rotateX,
          rotateY,
          transformStyle: 'preserve-3d',
          transform: 'translate3d(0,0,0)',
          willChange: 'transform',
        }}
        data-carousel-card="true"
        className="group relative w-full aspect-[3/4] rounded-[16px] overflow-hidden bg-[#111111] border border-white/10 hover:border-white/30 shadow-2xl shadow-black/80 cursor-pointer select-none will-change-transform"
      >
        {/* 0. Skeleton Shimmer Loading State: Shown while video is loading before autoplay starts */}
        {isVideoLoading && !hasVideoError && (
          <div
            className="absolute inset-0 z-15 bg-[#121212] overflow-hidden pointer-events-none transition-opacity duration-500"
            style={{ willChange: 'opacity, transform', transform: 'translate3d(0,0,0)' }}
            aria-hidden="true"
          >
            {/* Underlying blurred thumbnail for contextual perceived speed */}
            {card.imageUrl && (
              <CinematicImage
                src={card.imageUrl}
                alt=""
                aria-hidden="true"
                loading="lazy"
                decoding="async"
                containerClassName="absolute inset-0 w-full h-full object-cover opacity-20 filter blur-sm scale-105 pointer-events-none"
              />
            )}

            {/* High-speed GPU Shimmer Ray */}
            <div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.09] to-transparent animate-shimmer"
              style={{ willChange: 'transform', transform: 'translate3d(0,0,0)' }}
            />

            {/* Central pulsing video loader ring */}
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
              <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center animate-pulse">
                <div className="w-2.5 h-2.5 rounded-full bg-[#FF2D78]/70 animate-ping" />
              </div>
              <span className="text-[8px] font-mono uppercase tracking-widest text-gray-400/80 animate-pulse">
                Loading Stream
              </span>
            </div>

            {/* Bottom skeleton bars mimicking metadata */}
            <div className="absolute inset-x-0 bottom-0 p-3.5 space-y-2">
              <div className="h-2 w-14 bg-white/10 rounded-full animate-pulse" />
              <div className="h-3 w-3/4 bg-white/10 rounded-full animate-pulse" />
            </div>
          </div>
        )}

        {/* 1 & 2. Video & Poster Layer: scales up smoothly by 1.05 on hover using spring physics */}
        <motion.div
          className="absolute inset-0 w-full h-full pointer-events-none"
          animate={{
            scale: isHovered && !shouldReduceMotion ? 1.05 : 1
          }}
          transition={{
            type: 'spring',
            stiffness: 260,
            damping: 20,
            mass: 0.8
          }}
          style={{
            willChange: 'transform',
            transform: 'translate3d(0,0,0)',
          }}
        >
          {/* Fallback image */}
          <CinematicImage
            src={card.imageUrl}
            alt={card.title}
            loading="lazy"
            decoding="async"
            containerClassName="absolute inset-0 w-full h-full pointer-events-none"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />

          {/* Primary HTML5 AutoPlay Video */}
          {!hasVideoError && card.videoUrl && (
            <video
              ref={videoRef}
              src={card.videoUrl}
              autoPlay
              loop
              muted
              playsInline
              preload="metadata"
              poster={card.imageUrl}
              onPlaying={() => {
                setIsVideoPlaying(true);
                setIsVideoLoading(false);
              }}
              onError={handleVideoError}
              className={`absolute inset-0 w-full h-full object-cover pointer-events-none transition-opacity duration-500 ${
                isVideoPlaying ? 'opacity-100' : 'opacity-0'
              }`}
              {...({ loading: 'lazy' } as React.VideoHTMLAttributes<HTMLVideoElement>)}
            />
          )}
        </motion.div>

        {/* 3. Dark Gradient Scrim Overlay at Bottom: becomes darker and more visible on hover */}
        <motion.div
          className="absolute inset-x-0 bottom-0 pt-20 pb-4 px-3.5 pointer-events-none z-10 flex flex-col justify-end"
          animate={{
            opacity: isHovered ? 1 : 0.85
          }}
          transition={{ type: 'spring', stiffness: 280, damping: 24 }}
          style={{
            willChange: 'opacity, transform',
            transform: 'translate3d(0,0,0)',
            background: isHovered
              ? 'linear-gradient(to top, rgba(0,0,0,0.98) 0%, rgba(0,0,0,0.85) 55%, rgba(0,0,0,0.4) 85%, transparent 100%)'
              : 'linear-gradient(to top, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.7) 50%, transparent 100%)'
          }}
        >
          {/* Accent Electric Pink (#FF2D78) Uppercase Category Label with tracking-wide */}
          <span className="text-[10px] sm:text-[11px] font-extrabold uppercase tracking-wide text-[#FF2D78] leading-tight drop-shadow-sm truncate">
            {card.category}
          </span>

          {/* Truncated White Title with animated underline drawing in from left to right */}
          <h4 className="relative inline-block text-xs sm:text-[13px] font-semibold text-white leading-tight mt-1 truncate drop-shadow-md">
            <span className="relative inline-block max-w-full truncate">
              <span className="truncate">{card.title}</span>
              {/* Underline indicator: draws in from left to right with spring physics */}
              <motion.span
                className="absolute left-0 -bottom-0.5 h-[1.5px] bg-[#FF2D78] rounded-full origin-left pointer-events-none"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: isHovered ? 1 : 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 300,
                  damping: 24
                }}
                style={{
                  width: '100%',
                  willChange: 'transform',
                  transform: 'translate3d(0,0,0)',
                }}
              />
            </span>
          </h4>
        </motion.div>

        {/* 4. Cinematic Viewfinder Corner Brackets on Hover */}
        <div className="absolute inset-2 border border-white/0 group-hover:border-white/10 rounded-[12px] pointer-events-none z-20 transition-all duration-300">
          <div className="absolute top-1 left-1 w-2.5 h-2.5 border-t border-l border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute top-1 right-1 w-2.5 h-2.5 border-t border-r border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute bottom-1 left-1 w-2.5 h-2.5 border-b border-l border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute bottom-1 right-1 w-2.5 h-2.5 border-b border-r border-[#FF2D78] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>

        {/* 5. Production Agency Technical Metadata Tooltip / HUD Overlay on Hover */}
        <div className="absolute top-2.5 inset-x-2.5 z-30 opacity-0 group-hover:opacity-100 translate-y-[-4px] group-hover:translate-y-0 transition-all duration-300 pointer-events-none">
          <div className="bg-black/92 backdrop-blur-md border border-white/20 rounded-xl p-2.5 shadow-2xl shadow-black/90">
            {/* Header Row: Spec Badge & 4K Resolution */}
            <div className="flex items-center justify-between border-b border-white/10 pb-1.5 mb-1.5">
              <div className="flex items-center gap-1.5">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF2D78] opacity-75" />
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#FF2D78]" />
                </span>
                <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-gray-300">
                  PROD SPECS
                </span>
              </div>
              <span className="text-[9px] font-mono font-extrabold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-500/30 tracking-tight">
                {card.resolution || '4K UHD'}
              </span>
            </div>

            {/* Technical Specs: Duration & Client Type */}
            <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px]">
              <div>
                <div className="text-[8px] font-mono uppercase text-gray-400 tracking-wider">Duration</div>
                <div className="font-mono font-bold text-white flex items-center gap-1">
                  <span>{card.duration || '0:20'}</span>
                </div>
              </div>
              <div>
                <div className="text-[8px] font-mono uppercase text-gray-400 tracking-wider">Client Type</div>
                <div className="font-semibold text-gray-200 truncate" title={card.clientType || card.category}>
                  {card.clientType || card.category}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 6. Subtle Border Highlight on Hover */}
        <div className="absolute inset-0 rounded-[16px] border border-transparent group-hover:border-white/20 transition-colors duration-300 pointer-events-none z-20" />
      </motion.div>
    </div>
  );
};

/**
 * Individual Auto-Scrolling Column Component
 * =========================================================================
 * INFINITE SEAMLESS VERTICAL LOOP LOGIC:
 * =========================================================================
 * 1. Array Duplication:
 *    `duplicatedCards = [...cards, ...cards]`.
 *    The cards array is duplicated once in memory. If a column has 3 cards,
 *    6 cards are rendered sequentially in the DOM track.
 *
 * 2. Translation Coordinates:
 *    - For UPWARD columns (odd index: 0, 2, 4):
 *      y animates from `0%` to `-50%`.
 *      At `-50%`, the first half of the cards has moved fully above the viewport,
 *      and the second duplicate half sits at the EXACT initial pixel position
 *      where card #1 began.
 *
 *    - For DOWNWARD columns (even index: 1, 3, 5):
 *      y animates from `-50%` to `0%`.
 *      The track smoothly translates downwards.
 *
 * 3. Seamless Reset:
 *    Using Framer Motion with `repeat: Infinity` and `ease: "linear"`, the loop
 *    resets back to the start. Because `-50%` and `0%` are visually identical in
 *    content and layout, the reset is completely seamless with zero hitching.
 *
 * 4. Hover Pause:
 *    When `isHovered` is true, the animation freezes in place so users can
 *    scrutinize or click cards without chasing motion.
 * =========================================================================
 */
interface CarouselColumnProps {
  column: VideoColumn;
  columnIndex: number;
  onCardClick?: (card: VideoCardItem) => void;
}

const CarouselColumn: React.FC<CarouselColumnProps> = ({ column, columnIndex, onCardClick }) => {
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const shouldReduceMotion = useReducedMotion();

  const cards = column.cards && column.cards.length > 0 ? column.cards : [];
  const duplicatedCards = [...cards, ...cards];

  // Alternating directions: odd columns up (0, 2, 4), even columns down (1, 3, 5)
  const isUpward = column.direction ? column.direction === 'up' : columnIndex % 2 === 0;

  const initialY = isUpward ? '0%' : '-50%';
  const targetY = isUpward ? '-50%' : '0%';
  const duration = column.speed || 24 + (columnIndex % 3) * 3;

  return (
    <div
      className="relative flex-1 h-full overflow-hidden select-none"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <motion.div
        className="flex flex-col gap-3.5 sm:gap-4 w-full"
        // Continuous scroll pauses on hover or if user requested reduced motion
        animate={
          shouldReduceMotion || isHovered
            ? undefined
            : {
                y: [initialY, targetY]
              }
        }
        transition={{
          y: {
            repeat: Infinity,
            repeatType: 'loop',
            duration: duration,
            ease: 'linear'
          }
        }}
        style={{
          willChange: 'transform',
          transform: 'translate3d(0,0,0)'
        }}
      >
        {duplicatedCards.map((card, idx) => (
          <VideoCard
            key={`${card.id || card.title}-${idx}`}
            card={card}
            onClick={() => onCardClick?.(card)}
          />
        ))}
      </motion.div>
    </div>
  );
};

/**
 * Scrolling Marquee / Ticker Text Strip
 * Loops infinitely from left to right across the top of the carousel.
 * Respects prefers-reduced-motion.
 */
interface MarqueeTickerProps {
  items: string[];
}

const MarqueeTicker: React.FC<MarqueeTickerProps> = ({ items }) => {
  const shouldReduceMotion = useReducedMotion();
  // Concatenate multiple repeats so the string comfortably spans wide screens
  const fullText = items.join('   •   ') + '   •   ';
  const repeatedText = `${fullText}${fullText}${fullText}${fullText}`;

  return (
    <div className="relative w-full overflow-hidden py-3.5 border-y border-white/10 bg-[#0a0a0a] select-none">
      <motion.div
        className="flex whitespace-nowrap text-xs sm:text-sm font-bold uppercase tracking-wide text-gray-400"
        // Left-to-right infinite scroll: translates from -50% to 0%
        animate={shouldReduceMotion ? undefined : { x: ['-50%', '0%'] }}
        transition={{
          x: {
            repeat: Infinity,
            repeatType: 'loop',
            duration: 30,
            ease: 'linear'
          }
        }}
        style={{
          willChange: 'transform',
          transform: 'translate3d(0,0,0)'
        }}
      >
        <span className="inline-block px-4">{repeatedText}</span>
        <span className="inline-block px-4">{repeatedText}</span>
      </motion.div>
    </div>
  );
};

/**
 * Default 6-Column Video Dataset
 */
export const DEFAULT_CAROUSEL_COLUMNS: VideoColumn[] = [
  {
    id: 'col-1',
    direction: 'up',
    speed: 24,
    cards: [
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-interior-of-a-living-room-41527-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=600&auto=format&fit=crop&q=80',
        category: 'VILASITA DESIGNS',
        title: 'Minimalist Architecture & Wooden Craft',
        resolution: '4K UHD (2160p)',
        duration: '0:18',
        clientType: 'Luxury Architecture'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-potter-shaping-clay-on-a-wheel-41484-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=600&auto=format&fit=crop&q=80',
        category: 'ARTISAN STUDIO',
        title: 'Master Ceramicist Craft Film',
        resolution: '4K DCI Cinema',
        duration: '0:22',
        clientType: 'Artisan & Craft'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-architect-working-on-a-blueprint-41526-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&auto=format&fit=crop&q=80',
        category: 'STUDIO SPACES',
        title: 'Luxury Villa Design Blueprint',
        resolution: '4K ProRes HDR',
        duration: '0:26',
        clientType: 'Bespoke Villa Studio'
      }
    ]
  },
  {
    id: 'col-2',
    direction: 'down',
    speed: 28,
    cards: [
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-bottle-of-lotion-41505-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&auto=format&fit=crop&q=80',
        category: 'DIVA LUXURY LOUNGE',
        title: 'Sanctuary Amber Spa Essence',
        resolution: '4K Ultra HD',
        duration: '0:24',
        clientType: 'Wellness Lounge'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-41499-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=600&auto=format&fit=crop&q=80',
        category: 'ORGANIC BOTANICALS',
        title: 'Rosewater Glow Morning Routine',
        resolution: '4K HDR Macro',
        duration: '0:16',
        clientType: 'Clean Cosmetics'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-perfume-bottle-placed-on-a-mirror-41503-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=600&auto=format&fit=crop&q=80',
        category: 'NOIR COLOGNE',
        title: 'Velvet Midnight Fragrance Ad',
        resolution: '4K 60fps Cinema',
        duration: '0:20',
        clientType: 'Luxury Fragrance'
      }
    ]
  },
  {
    id: 'col-3',
    direction: 'up',
    speed: 22,
    cards: [
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-stylish-living-room-with-a-gray-sofa-41529-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=600&auto=format&fit=crop&q=80',
        category: 'KARMA INTERIORS',
        title: 'Bespoke Scandinavian Living',
        resolution: '4K ProRes HDR',
        duration: '0:22',
        clientType: 'High-End Residential'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-pouring-coffee-into-a-cup-with-foam-41508-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=600&auto=format&fit=crop&q=80',
        category: 'CAFE HAWKERS',
        title: 'Artisan Espresso Roast Commercial',
        resolution: '4K 60fps High-Speed',
        duration: '0:15',
        clientType: 'Artisan Coffee Roaster'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-chef-plating-a-delicious-dish-41512-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&auto=format&fit=crop&q=80',
        category: 'HAUTE DINING',
        title: 'Michelin Star Plating Experience',
        resolution: '4K Macro Plating',
        duration: '0:19',
        clientType: 'Haute Cuisine'
      }
    ]
  },
  {
    id: 'col-4',
    direction: 'down',
    speed: 26,
    cards: [
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-cosmetic-products-arranged-on-a-table-41506-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1608248597359-2d1297e68fa7?w=600&auto=format&fit=crop&q=80',
        category: 'ATE SKINCARE',
        title: 'Hydra-Boost Dropper Commercial',
        resolution: '4K 120fps Macro',
        duration: '0:15',
        clientType: 'Cosmetics & Skincare'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-serum-dropper-over-a-bottle-41501-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=600&auto=format&fit=crop&q=80',
        category: 'LUMEN DERMA',
        title: 'Clinical Formula Launch Reel',
        resolution: '4K DCI Lab Master',
        duration: '0:18',
        clientType: 'Clinical Skincare'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-face-oil-dripping-from-a-pipette-41504-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=600&auto=format&fit=crop&q=80',
        category: 'AURA BEAUTY',
        title: 'Pure Golden Elixir Drop Shot',
        resolution: '4K Fluid Macro',
        duration: '0:14',
        clientType: 'Luxury Skincare'
      }
    ]
  },
  {
    id: 'col-5',
    direction: 'up',
    speed: 25,
    cards: [
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-posing-in-a-yellow-sweatshirt-41517-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=80',
        category: 'NEWME APPAREL',
        title: 'Oversized Streetwear Autumn Drop',
        resolution: '4K 60fps Studio',
        duration: '0:20',
        clientType: 'Streetwear & Apparel'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-model-walking-down-a-runway-41519-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=600&auto=format&fit=crop&q=80',
        category: 'VOGUE EDITORIAL',
        title: 'High-Fashion Paris Runway Cut',
        resolution: '4K Cinema Runway',
        duration: '0:25',
        clientType: 'Fashion Editorial'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-close-up-of-a-model-with-colorful-makeup-41520-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=600&auto=format&fit=crop&q=80',
        category: 'COUTURE CAPSULE',
        title: 'Avant-Garde Studio Portrait',
        resolution: '4K Studio Portrait',
        duration: '0:17',
        clientType: 'Avant-Garde Couture'
      }
    ]
  },
  {
    id: 'col-6',
    direction: 'down',
    speed: 30,
    cards: [
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-wooden-furniture-in-a-room-41528-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?w=600&auto=format&fit=crop&q=80',
        category: 'FND FURNITURE NEXT DOOR',
        title: 'Bespoke Wardrobe & Joinery Film',
        resolution: '4K Ultra HD',
        duration: '0:28',
        clientType: 'Bespoke Joinery'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-wooden-table-and-chairs-in-a-bright-room-41530-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&auto=format&fit=crop&q=80',
        category: 'NORDIC LIVING',
        title: 'Solid Oak Craftsmanship Showcase',
        resolution: '4K Pro Master',
        duration: '0:21',
        clientType: 'Designer Woodcraft'
      },
      {
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-minimalist-kitchen-interior-41531-large.mp4',
        imageUrl: 'https://images.unsplash.com/photo-16005851554526-990dced4db0d?w=600&auto=format&fit=crop&q=80',
        category: 'ARCHITECTURAL SPACES',
        title: 'Monochrome Loft Kitchen Tour',
        resolution: '4K Motion Dolly',
        duration: '0:24',
        clientType: 'Modern Loft Architect'
      }
    ]
  }
];

export const DEFAULT_COLUMNS_DATA = DEFAULT_CAROUSEL_COLUMNS;

const DEFAULT_TICKER_ITEMS = [
  'NEW WORK',
  'FEATURED PROJECTS',
  '2026',
  'VISUAL NARRATIVES',
  'DIRECTED REELS',
  'GLOBAL CAMPAIGNS'
];

/**
 * Magnetic Button Component
 * =========================================================================
 * MAGNETIC HOVER SPECIFICATION:
 * =========================================================================
 * - Calculates cursor coordinates relative to button geometric center.
 * - Applies a smooth physics-based magnetic pull (spring animation) that
 *   slightly draws the button toward the cursor when hovering or moving near it.
 * - On mouse leave, smoothly snaps back to (0, 0) with zero jarring.
 * - Respects accessibility (`useReducedMotion`).
 * =========================================================================
 */
export interface MagneticButtonProps {
  children: React.ReactNode;
  className?: string;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  strength?: number;
  maxOffset?: number;
}

export const MagneticButton: React.FC<MagneticButtonProps> = ({
  children,
  className = '',
  onClick,
  strength = 0.35,
  maxOffset = 18
}) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const shouldReduceMotion = useReducedMotion();

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  // Elastic physics spring for smooth, non-linear attraction and recoil
  const springConfig = { stiffness: 280, damping: 18, mass: 0.1 };
  const springX = useSpring(mouseX, springConfig);
  const springY = useSpring(mouseY, springConfig);

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (shouldReduceMotion || !buttonRef.current) return;
    const { left, top, width, height } = buttonRef.current.getBoundingClientRect();
    const centerX = left + width / 2;
    const centerY = top + height / 2;

    const deltaX = (e.clientX - centerX) * strength;
    const deltaY = (e.clientY - centerY) * strength;

    // Clamped distance to keep displacement subtle and elegant
    const clampedX = Math.max(-maxOffset, Math.min(maxOffset, deltaX));
    const clampedY = Math.max(-maxOffset, Math.min(maxOffset, deltaY));

    mouseX.set(clampedX);
    mouseY.set(clampedY);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  return (
    <motion.button
      ref={buttonRef}
      style={{
        x: shouldReduceMotion ? 0 : springX,
        y: shouldReduceMotion ? 0 : springY,
        willChange: 'transform',
        transform: 'translate3d(0,0,0)'
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 400, damping: 25 }}
      onClick={onClick}
      className={className}
    >
      {children}
    </motion.button>
  );
};

/**
 * Premium Cinematic Vertical Video Carousel Section
 * =========================================================================
 * - Near-black background: #0a0a0a
 * - Large bold editorial-style heading: e.g. "FEATURED WORK" (text-6xl to text-8xl)
 * - Scrolling marquee / ticker text strip looping infinitely left-to-right
 * - Single accent color: Electric pink (#FF2D78) strictly for category tags & CTA buttons
 * - Everything else: White, off-white, and neutral grays
 * - Letter-spacing (tracking-wide) on all uppercase labels
 * - Generous, airy padding and rhythm (py-24 sm:py-32)
 * =========================================================================
 */
export const VerticalVideoCarousel: React.FC<VerticalVideoCarouselProps> = ({
  columns = DEFAULT_CAROUSEL_COLUMNS,
  className = '',
  trackHeightClassName = 'h-[520px] sm:h-[600px] lg:h-[680px]',
  heading = 'FEATURED WORK',
  subheading = 'SELECTED COMMISSIONS // ARCHIVE 2026',
  tickerItems = DEFAULT_TICKER_ITEMS,
  showEditorialHeader = true,
  ctaLabel = 'START A PROJECT',
  onCtaClick,
  headerRight,
  onCardClick
}) => {
  const sectionRef = useRef<HTMLElement>(null);
  const shouldReduceMotion = useReducedMotion();

  /**
   * =========================================================================
   * FRAMER MOTION SCROLL-DRIVEN ARCHITECTURE (useScroll & useTransform):
   * =========================================================================
   * 1. Target:
   *    `target: sectionRef` tracks viewport scroll coordinates relative only to
   *    this section, avoiding global window scroll interference.
   *
   * 2. Intersection Range (Offset):
   *    `offset: ['start end', 'end start']`
   *    - 0.0 (start end): The top edge of this carousel section enters the bottom
   *      of the browser window.
   *    - 1.0 (end start): The bottom edge of this carousel section scrolls out
   *      past the top of the browser window.
   *
   * 3. Multi-Plane Parallax Depth Math:
   *    - Heading (headingParallaxY):
   *      Moves slightly slower than the browser scroll velocity (lagging).
   *      Translates from -35px to +35px across the section scroll cycle.
   *      This establishes a grounded typographic mid-plane.
   *
   *    - Ambient Background (bgParallaxY):
   *      Moves from -60px to +60px, simulating far-field atmosphere.
   *
   *    - Video Carousel Track (trackParallaxY):
   *      Moves from +20px to -20px relative to the viewport, creating optical
   *      depth where the foreground cards float forward from the typography.
   *
   * 4. Accessibility & prefers-reduced-motion:
   *    - When shouldReduceMotion is true, useTransform yields static [0, 0],
   *      and word reveals skip rotation/translation.
   * =========================================================================
   */
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start']
  });

  // Parallax: heading moves slightly slower than the normal scroll speed
  const headingParallaxY = useTransform(
    scrollYProgress,
    [0, 1],
    shouldReduceMotion ? [0, 0] : [-35, 35]
  );

  // Parallax: ambient background lighting layer moves with deeper travel
  const bgParallaxY = useTransform(
    scrollYProgress,
    [0, 1],
    shouldReduceMotion ? [0, 0] : [-60, 60]
  );

  // Parallax: video cards track moves with responsive foreground depth
  const trackParallaxY = useTransform(
    scrollYProgress,
    [0, 1],
    shouldReduceMotion ? [0, 0] : [20, -20]
  );

  /**
   * Word-by-Word Staggered Reveal Setup:
   * Splits heading into discrete words for kinetic stagger upon entering view.
   */
  const words = useMemo(() => {
    return heading.split(/\s+/).filter(Boolean);
  }, [heading]);

  const headingContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: shouldReduceMotion ? 0 : 0.08,
        delayChildren: 0.06
      }
    }
  };

  const headingWordVariants = {
    hidden: {
      opacity: 0,
      y: shouldReduceMotion ? 0 : 35,
      rotateX: shouldReduceMotion ? 0 : 45
    },
    visible: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: {
        duration: shouldReduceMotion ? 0.2 : 0.65,
        ease: [0.215, 0.61, 0.355, 1] as const
      }
    }
  };

  // Pre-load images in memory to guarantee immediate visual readiness
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const allCards = columns.flatMap((c) => c.cards);
    const uniqueImages = Array.from(new Set(allCards.map((c) => c.imageUrl).filter(Boolean)));
    uniqueImages.slice(0, 12).forEach((src) => {
      const img = new Image();
      img.src = src;
    });
  }, [columns]);

  return (
    <section
      ref={sectionRef}
      id="featured-work-carousel"
      className={`relative w-full bg-[#0a0a0a] text-[#F3F4F6] py-20 sm:py-28 lg:py-36 overflow-hidden select-none ${className}`}
    >
      {/* Custom Cursor with Difference Blending and Spring Lag (Scoped to Carousel Section Only) */}
      <CarouselCursor targetRef={sectionRef} />

      {/* Background Ambient Glow Layer with Parallax Depth */}
      <motion.div
        style={{
          y: bgParallaxY,
          willChange: 'transform',
          transform: 'translate3d(0,0,0)'
        }}
        className="absolute inset-0 pointer-events-none overflow-hidden z-0"
        aria-hidden="true"
      >
        <div className="absolute top-1/4 -left-48 w-96 h-96 bg-[#FF2D78]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-48 w-96 h-96 bg-purple-900/10 rounded-full blur-3xl" />
      </motion.div>

      {/* 1. Scrolling Marquee / Ticker Text Strip */}
      {showEditorialHeader && (
        <div className="relative z-10 w-full mb-12 sm:mb-16">
          <MarqueeTicker items={tickerItems} />
        </div>
      )}

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 2. Large Bold Editorial-Style Heading & Header Block with Parallax & Word-by-Word Reveal */}
        {showEditorialHeader && (
          <motion.div
            style={{
              y: headingParallaxY,
              willChange: 'transform',
              transform: 'translate3d(0,0,0)'
            }}
            className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-16"
          >
            <div>
              {/* Kicker Label with Tracking-wide */}
              <motion.div
                initial={{ opacity: 0, y: shouldReduceMotion ? 0 : 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: shouldReduceMotion ? 0.2 : 0.5 }}
                className="flex items-center gap-2.5 mb-3"
              >
                <span className="w-2 h-2 rounded-full bg-[#FF2D78] shadow-[0_0_8px_#FF2D78]" />
                <span className="text-xs sm:text-sm font-bold uppercase tracking-wide text-gray-400">
                  {subheading}
                </span>
              </motion.div>

              {/* Huge Bold Editorial Heading with Word-by-Word Staggered Entrance */}
              <motion.h2
                variants={headingContainerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.3 }}
                className="text-5xl sm:text-7xl lg:text-8xl font-black uppercase tracking-tight text-white leading-[0.9] font-['Bebas_Neue',sans-serif] flex flex-wrap gap-x-3 sm:gap-x-4 gap-y-1"
              >
                {words.map((word, idx) => (
                  <motion.span
                    key={`${word}-${idx}`}
                    variants={headingWordVariants}
                    className="inline-block origin-bottom will-change-transform"
                  >
                    {word}
                  </motion.span>
                ))}
              </motion.h2>
            </div>

            <div className="self-start md:self-end flex flex-wrap items-center gap-3">
              {headerRight}

              {/* Electric Pink Magnetic CTA Button with Cursor Tracking */}
              {onCtaClick && (
                <MagneticButton
                  onClick={onCtaClick}
                  className="inline-flex items-center gap-2.5 px-8 py-4 rounded-full bg-[#FF2D78] hover:bg-[#e6206a] text-white text-xs sm:text-sm font-bold uppercase tracking-wide shadow-xl shadow-[#FF2D78]/25 hover:shadow-[#FF2D78]/40 transition-shadow cursor-pointer select-none"
                >
                  <span>{ctaLabel}</span>
                  <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                </MagneticButton>
              )}
            </div>
          </motion.div>
        )}

        {/* 3. Infinite 6-Column Vertical Video Carousel Track with Optical Parallax */}
        <motion.div
          style={{
            y: trackParallaxY,
            willChange: 'transform',
            transform: 'translate3d(0,0,0)'
          }}
          className={`relative w-full ${trackHeightClassName} overflow-hidden rounded-2xl`}
        >
          {/* Top & Bottom Vignette Fade Gradients */}
          <div className="absolute inset-x-0 top-0 h-20 sm:h-24 bg-gradient-to-b from-[#0a0a0a] via-[#0a0a0a]/90 to-transparent z-20 pointer-events-none" />
          <div className="absolute inset-x-0 bottom-0 h-20 sm:h-24 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/90 to-transparent z-20 pointer-events-none" />

          {/* Responsive Columns Track:
              - Mobile: 2 columns
              - Tablet: 3-4 columns
              - Desktop: 6 columns
          */}
          <div className="w-full h-full flex gap-3 sm:gap-3.5 lg:gap-4 px-1 sm:px-2">
            {columns.map((col, idx) => (
              <div
                key={col.id || `col-${idx}`}
                className={`flex-1 h-full ${
                  idx >= 2 ? 'hidden sm:block' : ''
                } ${idx >= 3 ? 'hidden md:block' : ''} ${idx >= 4 ? 'hidden lg:block' : ''}`}
              >
                <CarouselColumn
                  column={col}
                  columnIndex={idx}
                  onCardClick={onCardClick}
                />
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default VerticalVideoCarousel;

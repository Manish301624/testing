import React from 'react';
import { Helmet } from 'react-helmet-async';
import { HeroSection } from './HeroSection';
import { StatsClientsSection } from './StatsClientsSection';
import { WhatWeOfferSection } from './WhatWeOfferSection';
import { PortfolioSection } from './PortfolioSection';
import { ProcessSection } from './ProcessSection';
import { ReviewsSection } from './ReviewsSection';
import { BlogSection } from './BlogSection';
import { FaqSection } from './FaqSection';
import { ReelItem, ProjectItem, ReviewItem, BlogPost } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface HomePageProps {
  reels: ReelItem[];
  projects: ProjectItem[];
  reviews: ReviewItem[];
  blogPosts: BlogPost[];
  isLoading: boolean;
  onSelectReel: (reel: ReelItem) => void;
  onSelectProject: (proj: ProjectItem) => void;
  onOpenBooking: () => void;
  onOpenCallback: () => void;
  onAddReview: (review: { name: string; role: string; company: string; rating: number; comment: string; videoUrl?: string }) => Promise<void>;
  scrollToPortfolio: () => void;
  scrollToReviews: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  reels,
  projects,
  reviews,
  blogPosts,
  isLoading,
  onSelectReel,
  onSelectProject,
  onOpenBooking,
  onOpenCallback,
  onAddReview,
  scrollToPortfolio,
  scrollToReviews
}) => {
  const { language } = useLanguage();

  const homeTitle = language === 'es'
    ? 'Hidden Directors Productions | Estudio Cinematográfico y Producción Audiovisual'
    : 'Hidden Directors Productions | Cinematic Video Production Studio';

  const homeDescription = language === 'es'
    ? 'Agencia de producción visual de alta gama que crea películas de marca, comerciales, videos de arquitectura y contenido de marca personal con impacto cinematográfico.'
    : 'High-end visual production agency creating brand films, commercials, interiors, fashion, and personal branding visuals that define your story.';

  const canonicalUrl = 'https://hiddendirectors.com/';
  const ogImageUrl = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80';

  const homeSchemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    'name': 'Hidden Directors Productions',
    'url': 'https://hiddendirectors.com',
    'logo': 'https://hiddendirectors.com/logo.svg',
    'description': homeDescription,
    'sameAs': [
      'https://www.instagram.com',
      'https://www.linkedin.com',
      'https://www.youtube.com'
    ],
    'contactPoint': {
      '@type': 'ContactPoint',
      'contactType': 'Production Inquiries',
      'availableLanguage': ['English', 'Spanish']
    }
  };

  return (
    <main id="home-page" className="w-full relative min-h-screen">
      <Helmet>
        <title>{homeTitle}</title>
        <meta name="description" content={homeDescription} />
        
        {/* OpenGraph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content={homeTitle} />
        <meta property="og:description" content={homeDescription} />
        <meta property="og:image" content={ogImageUrl} />
        <meta property="og:image:alt" content="Hidden Directors Productions Showreel" />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />

        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={homeTitle} />
        <meta name="twitter:description" content={homeDescription} />
        <meta name="twitter:image" content={ogImageUrl} />
        <meta name="twitter:image:alt" content="Hidden Directors Productions Showreel" />

        {/* Canonical */}
        <link rel="canonical" href={canonicalUrl} />

        {/* Schema.org Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(homeSchemaJsonLd)}
        </script>
      </Helmet>

      {/* Hero Section with Headline & 6 Vertical Reels */}
      <HeroSection
        reels={reels}
        onSelectReel={onSelectReel}
        onOpenBooking={onOpenBooking}
        onOpenCallback={onOpenCallback}
        onExploreWork={scrollToPortfolio}
      />

      {/* 3 Metric Cards & Client Brand Logos Row */}
      <StatsClientsSection
        onLearnMoreRatings={scrollToReviews}
        onOpenBooking={onOpenBooking}
      />

      {/* What We Offer / Personal Branding Section */}
      <WhatWeOfferSection
        onOpenBooking={onOpenBooking}
      />

      {/* Selected Work Portfolio Grid */}
      <PortfolioSection
        projects={projects}
        onSelectProject={onSelectProject}
        onOpenBooking={onOpenBooking}
      />

      {/* How We Operate Process */}
      <ProcessSection
        onOpenBooking={onOpenBooking}
      />

      {/* Client Reviews & Testimonials */}
      <ReviewsSection
        reviews={reviews}
        onAddReview={onAddReview}
        isLoading={isLoading}
        onBookShoot={onOpenBooking}
      />

      {/* Industry Insights & Blog Section (SEO Grid) */}
      <BlogSection
        posts={blogPosts}
        onOpenBooking={onOpenBooking}
      />

      {/* Frequently Asked Questions (FAQ) Accordion */}
      <FaqSection
        onOpenBooking={onOpenBooking}
        isLoading={isLoading}
      />
    </main>
  );
};

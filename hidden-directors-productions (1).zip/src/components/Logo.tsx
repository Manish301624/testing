import React from 'react';

interface LogoProps {
  className?: string;
  height?: number | string;
  variant?: 'light' | 'dark' | 'auto';
  showText?: boolean;
}

/**
 * Official Hidden Directors Productions Logo
 * Accurately vectorized from brand identity specifications
 */
export const Logo: React.FC<LogoProps> = ({
  className = 'h-9 w-auto',
  variant = 'auto',
  showText = true,
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 text-white ${className}`}>
      <svg
        viewBox="0 0 450 140"
        fill="currentColor"
        className="h-full w-auto max-h-full object-contain"
        aria-label="Hidden Directors Productions"
      >
        {/* Monogram HD */}
        <g>
          {/* Dot at bottom left */}
          <rect x="20" y="94" width="20" height="24" rx="2" />
          
          {/* H Left Stem with cutout */}
          <rect x="48" y="22" width="20" height="42" rx="1" />
          <rect x="48" y="76" width="20" height="42" rx="1" />
          
          {/* H Center Crossbar connecting into D */}
          <rect x="68" y="56" width="46" height="26" />
          
          {/* D Vertical Stem */}
          <rect x="94" y="22" width="20" height="96" rx="1" />
          
          {/* D Outer Curve & Inner Counter */}
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M114 22H150C178 22 196 42 196 70C196 98 178 118 150 118H114V22ZM134 46V94H148C162 94 172 84 172 70C172 56 162 46 148 46H134Z"
          />
        </g>

        {showText && (
          <g>
            {/* HIDDEN */}
            <text
              x="218"
              y="52"
              fill="currentColor"
              fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
              fontWeight="900"
              fontSize="34"
              letterSpacing="2.5"
            >
              HIDDEN
            </text>
            
            {/* DIRECTORS */}
            <text
              x="218"
              y="88"
              fill="currentColor"
              fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
              fontWeight="900"
              fontSize="34"
              letterSpacing="2.5"
            >
              DIRECTORS
            </text>
            
            {/* PRODUCTIONS */}
            <text
              x="220"
              y="112"
              fill="currentColor"
              fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
              fontWeight="700"
              fontSize="12"
              letterSpacing="7"
            >
              PRODUCTIONS
            </text>
          </g>
        )}
      </svg>
    </div>
  );
};

export default Logo;

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Lock, Mail, Eye, EyeOff, Loader2, AlertCircle, Sparkles, KeyRound, Film, X } from 'lucide-react';
import { AdminLoginResponse } from '../types';

interface AdminLoginProps {
  onLoginSuccess: (token: string, user: { email: string; role: string }, expiresAt: number) => void;
  onClose: () => void;
  initialError?: string | null;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess, onClose, initialError }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(initialError || null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError('Please provide both your administrator email and password.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password })
      });

      const data: AdminLoginResponse = await response.json();

      if (!response.ok || !data.success || !data.token) {
        throw new Error(data.error || 'Authentication failed. Please check your credentials.');
      }

      const expiresAt = data.expiresAt || Date.now() + (data.expiresIn || 900) * 1000;
      onLoginSuccess(data.token, data.user || { email: email.trim(), role: 'admin' }, expiresAt);
    } catch (err: any) {
      setError(err.message || 'Unable to connect to production authentication server.');
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemoCredentials = () => {
    setEmail('director@hiddendirectors.com');
    setPassword('director123');
    setError(null);
  };

  return (
    <div className="w-full h-full flex flex-col justify-between p-6 sm:p-8 bg-[#0d0212] text-white">
      {/* Top Bar with Close */}
      <div className="flex items-center justify-between pb-4 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-500/30">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-wide uppercase font-display">
              Restricted Access
            </h3>
            <p className="text-[11px] text-gray-400">
              Hidden Directors Admin Authentication
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Login Form */}
      <div className="my-auto py-6 max-w-md w-full mx-auto space-y-6">
        {/* Brand visual header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#FF007A]/20 via-purple-500/20 to-pink-500/30 border border-pink-500/40 text-pink-400 shadow-xl shadow-pink-500/10 mb-2">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-bold font-display tracking-tight text-white">
            Production Leads Desk
          </h2>
          <p className="text-xs text-gray-400 leading-relaxed max-w-xs mx-auto">
            Secure portal for directors to manage consultation bookings, client inquiries & callbacks.
          </p>
        </div>

        {/* Error Notification */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5 shadow-sm"
            >
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">
                <span>{error}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Form Elements */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email Field */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-gray-300 uppercase tracking-wider">
              Admin Email
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                <Mail className="w-4 h-4" />
              </div>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="director@hiddendirectors.com"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-pink-500 focus:ring-1 focus:ring-pink-500/50 transition-all font-mono"
              />
            </div>
          </div>

          {/* Password Field */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Password
              </label>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                <KeyRound className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-11 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-pink-500 focus:ring-1 focus:ring-pink-500/50 transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-white transition-colors cursor-pointer"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#FF007A] via-[#FF5E62] to-[#FF007A] bg-[length:200%_auto] hover:bg-right text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-pink-500/25 transition-all duration-300 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.01] active:scale-[0.99]"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Verifying Credentials...</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>Authorize & Unlock Desk</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Autofill Helper for Convenience */}
        <div className="pt-3 border-t border-white/10 flex flex-col items-center gap-2">
          <button
            type="button"
            onClick={handleFillDemoCredentials}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] text-gray-400 hover:text-pink-300 transition-all cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-pink-400" />
            <span>Use configured demo credentials</span>
          </button>
          <p className="text-[10px] text-gray-500">
            Session tokens expire automatically after 15 minutes of inactivity.
          </p>
        </div>
      </div>

      {/* Security Footer Notice */}
      <div className="pt-4 border-t border-white/10 text-center flex items-center justify-center gap-2 text-[11px] text-gray-500">
        <Film className="w-3.5 h-3.5 text-pink-500/60" />
        <span>Hidden Directors Visual Productions • End-to-End JWT Auth Protection</span>
      </div>
    </div>
  );
};

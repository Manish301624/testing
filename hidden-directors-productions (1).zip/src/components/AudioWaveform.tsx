import React, { useEffect, useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Volume2, Volume1, VolumeX, Activity } from 'lucide-react';

export interface AudioWaveformProps {
  /** Reference to the video element to read or sync audio */
  videoRef: React.RefObject<HTMLVideoElement | null>;
  /** Playback status */
  isPlaying: boolean;
  /** Muted status */
  isMuted: boolean;
  /** Volume level 0 to 1 */
  volume: number;
  /** Callback when volume slider changes */
  onVolumeChange: (volume: number) => void;
  /** Callback to toggle mute */
  onToggleMute: () => void;
  /** Optional playback speed to scale frequency oscillations */
  playbackSpeed?: number;
  /** Optional CSS class name */
  className?: string;
  /** Optional bar count (default: 32) */
  barCount?: number;
}

/**
 * Dynamic CSS-Based Audio Waveform Visualization
 * ============================================================================
 * - Renders high-density vertical equalizer bars styled with dynamic CSS
 * - Directly reacts in real time to the video audio volume level, muted state & playback
 * - Uses Web Audio API AnalyserNode when accessible with graceful procedural harmonic synthesis fallback
 * - Features interactive volume slider and VU peak meter
 * ============================================================================
 */
export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  videoRef,
  isPlaying,
  isMuted,
  volume,
  onVolumeChange,
  onToggleMute,
  playbackSpeed = 1,
  className = '',
  barCount = 32,
}) => {
  // Array of bar heights in pixels (defaulting to baseline 3px)
  const [barHeights, setBarHeights] = useState<number[]>(() =>
    Array.from({ length: barCount }, () => 3)
  );

  // Peak amplitude (0 to 1) for VU meter
  const [peakLevel, setPeakLevel] = useState<number>(0);

  // Web Audio refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const isConnectedRef = useRef<boolean>(false);
  const animationFrameRef = useRef<number | null>(null);

  // Attempt Web Audio API connection safely (with CORS isolation protection)
  useEffect(() => {
    if (!videoRef.current || isConnectedRef.current) return;

    const setupWebAudio = () => {
      try {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AudioContextClass) return;

        if (!audioCtxRef.current) {
          audioCtxRef.current = new AudioContextClass();
        }

        const ctx = audioCtxRef.current;
        if (ctx.state === 'suspended' && isPlaying && !isMuted) {
          ctx.resume().catch(() => {});
        }

        if (!analyserRef.current) {
          const analyser = ctx.createAnalyser();
          analyser.fftSize = 64;
          analyser.smoothingTimeConstant = 0.8;
          analyserRef.current = analyser;
        }

        // Only attach MediaElementSource once
        if (videoRef.current && !sourceRef.current) {
          try {
            const source = ctx.createMediaElementSource(videoRef.current);
            source.connect(analyserRef.current);
            analyserRef.current.connect(ctx.destination);
            sourceRef.current = source;
            isConnectedRef.current = true;
          } catch {
            // If cross-origin or already attached, fail gracefully without disrupting audio
          }
        }
      } catch {
        // Safe fallback to procedural harmonic engine
      }
    };

    if (isPlaying && !isMuted) {
      setupWebAudio();
    }
  }, [isPlaying, isMuted, videoRef]);

  // Main real-time waveform animation loop
  useEffect(() => {
    let startTime = performance.now();

    const updateWaveform = (now: number) => {
      const elapsed = (now - startTime) / 1000 * playbackSpeed;

      // Effective volume factor: strictly 0 when muted, paused, or volume is 0
      const effectiveVolume = isMuted || !isPlaying ? 0 : Math.max(0, Math.min(1, volume));

      // Try reading from Web Audio Analyser if real data is available
      let realAudioDetected = false;
      const realData = new Uint8Array(32);
      if (analyserRef.current && effectiveVolume > 0) {
        try {
          analyserRef.current.getByteFrequencyData(realData);
          // Check if any frequency has actual amplitude
          const sum = realData.reduce((acc, v) => acc + v, 0);
          if (sum > 20) {
            realAudioDetected = true;
          }
        } catch {
          // ignore
        }
      }

      const newHeights: number[] = [];
      let totalEnergy = 0;

      for (let i = 0; i < barCount; i++) {
        let height = 3; // minimal baseline resting height

        if (effectiveVolume > 0) {
          if (realAudioDetected) {
            // Map real FFT frequency bin to bar
            const binIdx = Math.floor((i / barCount) * realData.length);
            const rawVal = (realData[binIdx] || 0) / 255;
            height = Math.max(3, rawVal * 36 * effectiveVolume);
          } else {
            // Procedural harmonic acoustic synthesizer mapped to audio clock
            // Symmetrical frequency curve (higher in mids, structured bass on left)
            const norm = i / (barCount - 1);
            const centerBell = Math.sin(norm * Math.PI);

            // Sub-bass beat (124 BPM rhythm kick)
            const kick = Math.pow(Math.max(0, Math.sin(elapsed * 4.1)), 5);
            // Snare / clap offbeat
            const snare = Math.pow(Math.max(0, Math.sin(elapsed * 4.1 + 1.6)), 7);

            // Fluid acoustic wave frequencies
            const waveA = Math.sin(elapsed * 5.4 + i * 0.38);
            const waveB = Math.cos(elapsed * 3.2 - i * 0.22);
            const waveC = Math.sin(elapsed * 8.7 + i * 0.55);
            const jitter = Math.sin(elapsed * 17.5 + i * 1.9) * 0.12;

            // Frequency envelope: bass has high kick weight, treble has high jitter
            const isBass = i < barCount * 0.25;
            const isMid = i >= barCount * 0.25 && i < barCount * 0.75;

            let barEnergy = 0.25 + 0.35 * centerBell;
            if (isBass) {
              barEnergy += 0.5 * kick + 0.2 * waveA;
            } else if (isMid) {
              barEnergy += 0.35 * snare + 0.25 * waveA + 0.25 * waveB;
            } else {
              barEnergy += 0.3 * waveC + jitter + 0.2 * snare;
            }

            // Scale dynamically by effectiveVolume:
            // At volume 1: bars can reach up to 34-38px
            // At volume 0.3: bars reach max 12px
            // At volume 0 / muted: falls strictly to 3px
            const maxBarPx = 36;
            const targetHeight = Math.max(3, Math.min(maxBarPx, (barEnergy * maxBarPx) * effectiveVolume));
            height = Math.round(targetHeight * 10) / 10;
          }
        }

        totalEnergy += height;
        newHeights.push(height);
      }

      setBarHeights(newHeights);

      // Compute peak VU meter level (0 to 1)
      const avgHeight = totalEnergy / barCount;
      const currentPeak = effectiveVolume > 0 ? Math.min(1, (avgHeight / 32) * (0.8 + effectiveVolume * 0.2)) : 0;
      setPeakLevel(currentPeak);

      animationFrameRef.current = requestAnimationFrame(updateWaveform);
    };

    animationFrameRef.current = requestAnimationFrame(updateWaveform);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, isMuted, volume, playbackSpeed, barCount]);

  // Clean up Web Audio Context on unmount
  useEffect(() => {
    return () => {
      if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  const effectiveVolPercent = isMuted || !isPlaying ? 0 : Math.round(volume * 100);

  // Volume icon logic
  const getVolumeIcon = () => {
    if (isMuted || volume === 0 || !isPlaying) {
      return <VolumeX className="w-3.5 h-3.5 text-[#FF007A]" />;
    }
    if (volume < 0.5) {
      return <Volume1 className="w-3.5 h-3.5 text-pink-400" />;
    }
    return <Volume2 className="w-3.5 h-3.5 text-emerald-400" />;
  };

  return (
    <div
      id="reel-audio-waveform-container"
      onClick={(e) => e.stopPropagation()}
      className={`px-3 py-2 rounded-2xl bg-black/85 backdrop-blur-xl border border-pink-500/30 shadow-2xl space-y-2 select-none ${className}`}
    >
      {/* Top Status & Interactive Volume Slider Row */}
      <div className="flex items-center justify-between gap-2 text-xs">
        {/* Waveform Title & Live Status Indicator */}
        <div className="flex items-center gap-1.5 min-w-0">
          <div className="relative flex items-center justify-center">
            <Activity className={`w-3.5 h-3.5 transition-colors ${effectiveVolPercent > 0 ? 'text-[#FF007A] animate-pulse' : 'text-gray-500'}`} />
          </div>
          <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-gray-300 truncate">
            {effectiveVolPercent > 0 ? 'Audio Waveform' : 'Audio Inactive'}
          </span>
          {effectiveVolPercent > 0 && (
            <span className="text-[8px] font-mono font-extrabold uppercase px-1.5 py-0.2 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300">
              Live
            </span>
          )}
        </div>

        {/* Volume Controls & Level Percentage */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Quick Mute/Unmute Icon Button */}
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? 'Unmute' : 'Mute'}
            title={isMuted ? 'Unmute audio' : 'Mute audio'}
            className="p-1 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer"
          >
            {getVolumeIcon()}
          </button>

          {/* Inline Volume Slider with dynamic CSS fill */}
          <div className="relative w-16 sm:w-20 h-4 flex items-center">
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-75 ${
                  isMuted || !isPlaying
                    ? 'bg-gray-600'
                    : 'bg-gradient-to-r from-[#FF007A] to-purple-500'
                }`}
                style={{ width: `${isMuted || !isPlaying ? 0 : volume * 100}%` }}
              />
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                const newVol = parseFloat(e.target.value);
                onVolumeChange(newVol);
              }}
              aria-label="Audio Volume Level"
              className="absolute inset-0 w-full opacity-0 cursor-pointer"
            />
          </div>

          {/* Exact Volume Percentage Badge */}
          <span
            className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-full border min-w-[42px] text-center ${
              effectiveVolPercent > 0
                ? 'bg-[#1c0827] text-pink-300 border-pink-500/40'
                : 'bg-white/5 text-gray-400 border-white/10'
            }`}
          >
            {isMuted ? 'MUTED' : `${effectiveVolPercent}%`}
          </span>
        </div>
      </div>

      {/* Dynamic CSS Waveform Visualizer Bars */}
      <div
        className="relative w-full h-10 flex items-center justify-between gap-[2px] px-1 py-1 rounded-xl bg-black/40 border border-white/5 overflow-hidden"
        title={`Audio Waveform reacting to ${effectiveVolPercent}% volume`}
      >
        {/* Subtle Horizontal Midline Guide */}
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-[1px] bg-white/5 pointer-events-none" />

        {/* Individual CSS-animated Bars */}
        {barHeights.map((h, index) => {
          const isHighVolume = volume >= 0.7 && !isMuted && isPlaying;
          const isMidVolume = volume >= 0.3 && !isMuted && isPlaying;
          const isActive = !isMuted && isPlaying && volume > 0;

          // Compute dynamic CSS styling
          let barBg = 'bg-white/20';
          if (isActive) {
            if (isHighVolume) {
              barBg = 'bg-gradient-to-t from-[#FF007A] via-pink-400 to-purple-300';
            } else if (isMidVolume) {
              barBg = 'bg-gradient-to-t from-pink-600 via-pink-400 to-pink-300';
            } else {
              barBg = 'bg-gradient-to-t from-pink-800 to-pink-500';
            }
          }

          // Subtle shadow glow when high volume
          const shadowGlow = isActive && h > 18
            ? '0 0 8px rgba(255, 0, 122, 0.65)'
            : 'none';

          return (
            <div
              key={index}
              className="flex-1 flex items-center justify-center h-full min-w-[2px] max-w-[8px]"
            >
              <div
                style={{
                  height: `${h}px`,
                  boxShadow: shadowGlow,
                  transition: 'height 65ms cubic-bezier(0.2, 0, 0, 1)',
                }}
                className={`w-full rounded-full transition-colors duration-150 ${barBg}`}
              />
            </div>
          );
        })}
      </div>

      {/* Frequency & VU Peak Meter Footer */}
      <div className="flex items-center justify-between text-[8px] font-mono uppercase tracking-wider text-gray-500 px-0.5">
        <span className={effectiveVolPercent > 0 ? 'text-pink-400 font-bold' : ''}>Sub 30Hz</span>
        <span>Low-Mid</span>
        <div className="flex items-center gap-1">
          <span className="text-[7px] text-gray-400">VU PEAK:</span>
          <div className="flex items-center gap-0.5">
            {[0.2, 0.4, 0.6, 0.8, 0.95].map((threshold, i) => {
              const isLit = peakLevel >= threshold;
              const color =
                i >= 4 ? (isLit ? 'bg-red-500 shadow-[0_0_6px_red]' : 'bg-white/10')
                : i >= 3 ? (isLit ? 'bg-[#FF007A] shadow-[0_0_6px_#FF007A]' : 'bg-white/10')
                : (isLit ? 'bg-emerald-400 shadow-[0_0_6px_#34d399]' : 'bg-white/10');

              return (
                <span
                  key={i}
                  className={`w-1.5 h-1.5 rounded-full transition-all duration-75 ${color}`}
                />
              );
            })}
          </div>
        </div>
        <span>High-Mid</span>
        <span className={effectiveVolPercent > 0 ? 'text-purple-400 font-bold' : ''}>Air 16kHz</span>
      </div>
    </div>
  );
};

export default AudioWaveform;

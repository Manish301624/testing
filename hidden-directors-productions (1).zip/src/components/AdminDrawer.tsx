import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, ShieldCheck, Mail, Phone, Calendar, DollarSign, Clock, RefreshCw, 
  CheckCircle, UserCheck, PhoneCall, MessageCircle, ArrowUpRight, 
  ExternalLink, Globe, LogOut, Lock, AlertTriangle, Sparkles, Timer
} from 'lucide-react';
import { BookingSubmission, ContactMessage, CallbackRequest, WhatsAppInquiry } from '../types';
import { buildWhatsAppUrl, getInitialWhatsAppNumber } from '../utils/whatsapp';
import { AdminLogin } from './AdminLogin';
import { backdropBlurIn } from '../utils/motionVariants';

interface AdminDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const TOKEN_STORAGE_KEY = 'hd_admin_jwt_token';
const USER_STORAGE_KEY = 'hd_admin_user';
const EXPIRES_AT_STORAGE_KEY = 'hd_admin_expires_at';

export const AdminDrawer: React.FC<AdminDrawerProps> = ({ isOpen, onClose }) => {
  // Authentication State
  const [token, setToken] = useState<string | null>(() => {
    return typeof window !== 'undefined' ? localStorage.getItem(TOKEN_STORAGE_KEY) : null;
  });
  const [adminUser, setAdminUser] = useState<{ email: string; role: string } | null>(() => {
    if (typeof window === 'undefined') return null;
    const raw = localStorage.getItem(USER_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  });
  const [expiresAt, setExpiresAt] = useState<number | null>(() => {
    if (typeof window === 'undefined') return null;
    const raw = localStorage.getItem(EXPIRES_AT_STORAGE_KEY);
    return raw ? parseInt(raw, 10) : null;
  });

  const [authError, setAuthError] = useState<string | null>(null);
  const [isRefreshingSession, setIsRefreshingSession] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number | null>(null);

  // Leads Desk Tab Data
  const [activeTab, setActiveTab] = useState<'bookings' | 'whatsapp' | 'callbacks' | 'messages'>('bookings');
  const [bookings, setBookings] = useState<BookingSubmission[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [callbacks, setCallbacks] = useState<CallbackRequest[]>([]);
  const [whatsappInquiries, setWhatsappInquiries] = useState<WhatsAppInquiry[]>([]);
  const [loading, setLoading] = useState(false);

  // Clear Session & Logout
  const handleLogout = useCallback((reason?: string) => {
    setToken(null);
    setAdminUser(null);
    setExpiresAt(null);
    setSecondsRemaining(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
      localStorage.removeItem(USER_STORAGE_KEY);
      localStorage.removeItem(EXPIRES_AT_STORAGE_KEY);
    }
    if (reason) {
      setAuthError(reason);
    }
  }, []);

  // Handle Successful Login
  const handleLoginSuccess = (newToken: string, user: { email: string; role: string }, expirationTimestamp: number) => {
    setToken(newToken);
    setAdminUser(user);
    setExpiresAt(expirationTimestamp);
    setAuthError(null);
    if (typeof window !== 'undefined') {
      localStorage.setItem(TOKEN_STORAGE_KEY, newToken);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      localStorage.setItem(EXPIRES_AT_STORAGE_KEY, expirationTimestamp.toString());
    }
  };

  // Extend / Refresh Session
  const handleExtendSession = async () => {
    if (!token) return;
    setIsRefreshingSession(true);
    try {
      const res = await fetch('/api/admin/refresh', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (res.ok && data.success && data.token) {
        handleLoginSuccess(data.token, data.user || adminUser, data.expiresAt);
      } else {
        handleLogout('Session expired. Please log in again.');
      }
    } catch (err) {
      console.error('Failed to extend session:', err);
    } finally {
      setIsRefreshingSession(false);
    }
  };

  // Fetch Protected Leads Data with JWT Authentication
  const fetchData = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const authHeaders = {
        'Authorization': `Bearer ${token}`
      };

      const [bRes, mRes, cbRes, waRes] = await Promise.all([
        fetch('/api/bookings', { headers: authHeaders }),
        fetch('/api/contact', { headers: authHeaders }),
        fetch('/api/callback-request', { headers: authHeaders }),
        fetch('/api/whatsapp-inquiry', { headers: authHeaders })
      ]);

      // Detect Unauthorized (401) responses and redirect to login
      if (bRes.status === 401 || mRes.status === 401 || cbRes.status === 401 || waRes.status === 401) {
        handleLogout('Your session has expired (15-minute timeout). Please log in again.');
        return;
      }

      const [bData, mData, cbData, waData] = await Promise.all([
        bRes.json(),
        mRes.json(),
        cbRes.json(),
        waRes.json()
      ]);

      setBookings(Array.isArray(bData) ? bData : []);
      setMessages(Array.isArray(mData) ? mData : []);
      setCallbacks(Array.isArray(cbData) ? cbData : []);
      setWhatsappInquiries(Array.isArray(waData) ? waData : []);
    } catch (err) {
      console.error('Failed to fetch leads data:', err);
    } finally {
      setLoading(false);
    }
  }, [token, handleLogout]);

  // Session Timeout Timer & Countdown Hook
  useEffect(() => {
    if (!token || !expiresAt) {
      setSecondsRemaining(null);
      return;
    }

    const checkTime = () => {
      const remainingMs = expiresAt - Date.now();
      const remainingSec = Math.max(0, Math.floor(remainingMs / 1000));
      setSecondsRemaining(remainingSec);

      // Auto-logout when session expires
      if (remainingSec <= 0) {
        handleLogout('Session timed out after 15 minutes of security inactivity.');
      }
    };

    checkTime();
    const interval = setInterval(checkTime, 1000);
    return () => clearInterval(interval);
  }, [token, expiresAt, handleLogout]);

  // Trigger Data Fetch on Modal Open or Auth change
  useEffect(() => {
    if (isOpen && token) {
      fetchData();
    }
  }, [isOpen, token, fetchData]);

  if (!isOpen) return null;

  // Render Login Screen if not authenticated
  if (!token) {
    return (
      <motion.div 
        variants={backdropBlurIn}
        initial="hidden"
        animate="visible"
        exit="exit"
        className="fixed inset-0 z-50 flex justify-end bg-black/80"
      >
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="w-full max-w-xl h-full bg-[#0d0212] border-l border-white/10 flex flex-col justify-between overflow-y-auto"
        >
          <AdminLogin
            onLoginSuccess={handleLoginSuccess}
            onClose={onClose}
            initialError={authError}
          />
        </motion.div>
      </motion.div>
    );
  }

  // Format countdown string mm:ss
  const formatTimer = (totalSeconds: number | null) => {
    if (totalSeconds === null) return '--:--';
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const isWarningTime = secondsRemaining !== null && secondsRemaining <= 120; // 2 minutes warning

  return (
    <motion.div 
      variants={backdropBlurIn}
      initial="hidden"
      animate="visible"
      exit="exit"
      className="fixed inset-0 z-50 flex justify-end bg-black/80"
    >
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="w-full max-w-xl h-full bg-[#110416] border-l border-white/10 p-6 flex flex-col justify-between overflow-y-auto"
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-500/30">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-display flex items-center gap-2">
                  <span>Production Leads Desk</span>
                  <span className="text-[10px] font-mono font-normal text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                    AUTHENTICATED
                  </span>
                </h3>
                <p className="text-[11px] text-gray-400">
                  {adminUser?.email || 'Director Portal'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Session Timer Badge */}
              <div
                title="Session active time remaining before automatic logout"
                className={`flex items-center gap-1.5 text-[11px] font-mono px-2.5 py-1 rounded-lg border ${
                  isWarningTime
                    ? 'bg-rose-500/20 border-rose-500/50 text-rose-300 animate-pulse'
                    : 'bg-white/5 border-white/10 text-gray-300'
                }`}
              >
                <Timer className={`w-3.5 h-3.5 ${isWarningTime ? 'text-rose-400' : 'text-pink-400'}`} />
                <span>{formatTimer(secondsRemaining)}</span>
              </div>

              {/* Refresh Data */}
              <button
                onClick={fetchData}
                disabled={loading}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 transition-colors cursor-pointer"
                title="Refresh leads"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-pink-400' : ''}`} />
              </button>

              {/* Logout Button */}
              <button
                onClick={() => handleLogout()}
                className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-colors cursor-pointer flex items-center gap-1 text-xs font-semibold px-2.5"
                title="Log out and lock desk"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">Logout</span>
              </button>

              {/* Close Drawer */}
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Session Timeout Warning Banner (triggers <= 2 mins) */}
          <AnimatePresence>
            {isWarningTime && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="my-3 p-3 rounded-xl bg-gradient-to-r from-rose-950/80 to-amber-950/80 border border-rose-500/40 text-xs flex items-center justify-between gap-3 shadow-lg"
              >
                <div className="flex items-center gap-2 text-rose-200">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 animate-bounce" />
                  <span>
                    Session expires in <strong>{formatTimer(secondsRemaining)}</strong>.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleExtendSession}
                  disabled={isRefreshingSession}
                  className="px-3 py-1 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold text-[11px] uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all shadow-md shadow-rose-500/30 shrink-0"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>{isRefreshingSession ? 'Extending...' : 'Extend (+15m)'}</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Navigation Tabs */}
          <div className="grid grid-cols-4 gap-1.5 my-4">
            <button
              onClick={() => setActiveTab('bookings')}
              className={`py-2 text-[11px] font-bold rounded-xl transition-all cursor-pointer truncate px-1 ${
                activeTab === 'bookings'
                  ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-md'
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              Bookings ({bookings.length})
            </button>
            <button
              onClick={() => setActiveTab('whatsapp')}
              className={`py-2 text-[11px] font-bold rounded-xl transition-all cursor-pointer truncate px-1 flex items-center justify-center gap-1 ${
                activeTab === 'whatsapp'
                  ? 'bg-[#25D366] text-white shadow-md'
                  : 'bg-white/5 text-gray-400 hover:text-emerald-300'
              }`}
            >
              <span>WhatsApp</span>
              <span className="text-[10px] bg-black/30 px-1 rounded">({whatsappInquiries.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('callbacks')}
              className={`py-2 text-[11px] font-bold rounded-xl transition-all cursor-pointer truncate px-1 ${
                activeTab === 'callbacks'
                  ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-md'
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              Callbacks ({callbacks.length})
            </button>
            <button
              onClick={() => setActiveTab('messages')}
              className={`py-2 text-[11px] font-bold rounded-xl transition-all cursor-pointer truncate px-1 ${
                activeTab === 'messages'
                  ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-md'
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              Messages ({messages.length})
            </button>
          </div>

          {/* List Content */}
          <div className="space-y-3 mt-4">
            {activeTab === 'bookings' ? (
              bookings.length === 0 ? (
                <div className="text-center py-12 text-xs text-gray-500">
                  No consultation bookings received yet.
                </div>
              ) : (
                bookings.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-[#190823] border border-white/10 hover:border-pink-500/30 transition-all space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-pink-400 font-bold bg-pink-500/10 px-2 py-0.5 rounded">
                        {item.id}
                      </span>
                      <span className="text-[10px] text-gray-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(item.createdAt || '').toLocaleDateString()}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        {item.fullName}
                        {item.companyName && (
                          <span className="text-xs font-normal text-gray-400">
                            ({item.companyName})
                          </span>
                        )}
                      </h4>
                      <p className="text-xs font-semibold text-pink-300 mt-0.5">
                        {item.serviceCategory}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-gray-300 bg-black/40 p-2.5 rounded-xl">
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <Mail className="w-3 h-3 text-pink-400 shrink-0" />
                        <span className="truncate">{item.email}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <Phone className="w-3 h-3 text-pink-400 shrink-0" />
                        <span>{item.phone}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <DollarSign className="w-3 h-3 text-pink-400 shrink-0" />
                        <span>{item.budgetRange}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <Calendar className="w-3 h-3 text-pink-400 shrink-0" />
                        <span>{item.targetDate || 'Flexible'}</span>
                      </div>
                    </div>

                    {item.projectDetails && (
                      <p className="text-xs text-gray-400 italic bg-white/5 p-2 rounded-lg">
                        &ldquo;{item.projectDetails}&rdquo;
                      </p>
                    )}
                  </div>
                ))
              )
            ) : activeTab === 'whatsapp' ? (
              whatsappInquiries.length === 0 ? (
                <div className="text-center py-12 text-xs text-gray-500">
                  No WhatsApp click inquiries logged yet.
                </div>
              ) : (
                whatsappInquiries.map((wa) => (
                  <div
                    key={wa.id}
                    className="p-4 rounded-2xl bg-[#0f1d16] border border-emerald-500/20 hover:border-[#25D366]/40 transition-all space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-emerald-400 font-bold bg-[#25D366]/15 px-2 py-0.5 rounded border border-[#25D366]/30">
                          {wa.id}
                        </span>
                        <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-300/80 bg-white/5 px-2 py-0.5 rounded">
                          {wa.context || 'General'}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-emerald-400/80" />
                        {new Date(wa.createdAt || '').toLocaleString()}
                      </span>
                    </div>

                    <div>
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                          <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                          <span>{wa.sourceSection || 'Website WhatsApp Trigger'}</span>
                        </h4>
                        {(wa.projectName || wa.serviceName || wa.reelTitle) && (
                          <span className="text-[11px] font-semibold text-emerald-300">
                            {wa.projectName || wa.serviceName || wa.reelTitle}
                          </span>
                        )}
                      </div>

                      {wa.clientName && (
                        <p className="text-xs text-gray-300 mt-1">
                          Client: <span className="font-bold text-white">{wa.clientName}</span> {wa.clientPhone && `(${wa.clientPhone})`}
                        </p>
                      )}
                    </div>

                    {wa.message && (
                      <div className="text-xs text-emerald-100/90 bg-black/40 p-2.5 rounded-xl border border-white/5 font-sans leading-relaxed">
                        <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-1">Pre-filled Message</p>
                        &ldquo;{wa.message}&rdquo;
                      </div>
                    )}

                    <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-white/5">
                      <span className="truncate max-w-[280px] opacity-70">
                        {wa.userAgent || 'Web Browser'}
                      </span>
                      <a
                        href={buildWhatsAppUrl(getInitialWhatsAppNumber(), wa.message)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 bg-[#25D366]/15 hover:bg-[#25D366]/25 px-2.5 py-1 rounded-full border border-[#25D366]/30 transition-colors"
                      >
                        <span>Open Chat</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ))
              )
            ) : activeTab === 'callbacks' ? (
              callbacks.length === 0 ? (
                <div className="text-center py-12 text-xs text-gray-500">
                  No instant callback requests received yet.
                </div>
              ) : (
                callbacks.map((cb) => (
                  <div
                    key={cb.id}
                    className="p-4 rounded-2xl bg-[#190823] border border-white/10 hover:border-pink-500/30 transition-all space-y-2"
                  >
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="font-mono text-pink-400 font-bold bg-pink-500/10 px-2 py-0.5 rounded">
                        {cb.id}
                      </span>
                      <span className="text-emerald-400 font-semibold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        15-min ETA
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-white">{cb.name}</h4>
                      <span className="text-[11px] font-mono font-bold text-pink-300">{cb.phone}</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-white/5">
                      <span>Submitted: {new Date(cb.createdAt || '').toLocaleTimeString()}</span>
                      <a
                        href={`tel:${cb.phone}`}
                        className="text-pink-400 hover:text-pink-300 font-bold flex items-center gap-1"
                      >
                        <PhoneCall className="w-3 h-3" />
                        <span>Call Now</span>
                      </a>
                    </div>
                  </div>
                ))
              )
            ) : (
              messages.length === 0 ? (
                <div className="text-center py-12 text-xs text-gray-500">
                  No contact messages yet.
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className="p-4 rounded-2xl bg-[#190823] border border-white/10 space-y-2"
                  >
                    <div className="flex justify-between text-[10px] text-gray-400">
                      <span className="font-bold text-white">{msg.name}</span>
                      <span>{new Date(msg.createdAt || '').toLocaleDateString()}</span>
                    </div>
                    <div className="text-xs font-semibold text-pink-300">{msg.subject}</div>
                    <p className="text-xs text-gray-300">{msg.message}</p>
                    <div className="text-[11px] text-gray-400 flex gap-4 pt-1">
                      <span>{msg.email}</span>
                      {msg.phone && <span>{msg.phone}</span>}
                    </div>
                  </div>
                ))
              )
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3">
          <div className="text-[11px] text-gray-500 flex items-center gap-1.5">
            <Lock className="w-3 h-3 text-pink-500/80" />
            <span>Protected Admin Session</span>
          </div>
          <button
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-300 hover:text-white cursor-pointer transition-all"
          >
            Close Leads Panel
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};


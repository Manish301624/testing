import { CinematicImage } from "./CinematicImage";
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Calendar, Clock, BookOpen, Sparkles, Tag } from 'lucide-react';
import { BlogPost } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface BlogSectionProps {
  posts: BlogPost[];
  onOpenBooking?: () => void;
}

export const BlogSection: React.FC<BlogSectionProps> = ({ posts, onOpenBooking }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const { language } = useLanguage();
  const navigate = useNavigate();

  const categories = [
    'All',
    'Production Strategy',
    'Cinematography',
    'Interiors & Architecture',
    'Personal Branding',
    'Audio & Post-Production'
  ];

  const filteredPosts = selectedCategory === 'All'
    ? posts
    : posts.filter(p => p.category?.toLowerCase() === selectedCategory.toLowerCase());

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString(language === 'es' ? 'es-ES' : 'en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <section id="blog" className="py-24 relative bg-[#090210] border-t border-white/5 overflow-hidden">
      {/* Subtle ambient light gradient background */}
      <div className="absolute top-1/3 left-1/4 -translate-x-1/2 w-[550px] h-[350px] bg-pink-600/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-[400px] h-[300px] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.55, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12"
        >
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-[11px] font-bold tracking-wider text-pink-300 uppercase mb-3">
              <Sparkles className="w-3 h-3 text-[#FF007A]" />
              <span>{language === 'es' ? 'PERSPECTIVAS & FILMACIÓN' : 'INDUSTRY INSIGHTS & STRATEGY'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display">
              {language === 'es' ? 'Producción, Estrategia & SEO' : 'Insights & Visual Direction'}
            </h2>
            <p className="mt-2 text-sm sm:text-base text-gray-400 max-w-xl leading-relaxed">
              {language === 'es'
                ? 'Análisis profundo sobre cinemática de alto impacto, psicología de atención en 9:16 y secretos de iluminación de estudio.'
                : 'Deep-dives into short-form commercial cinematography, high-speed lighting engineering, and executive personal branding.'}
            </p>
          </div>

          {onOpenBooking && (
            <button
              onClick={onOpenBooking}
              className="self-start md:self-auto btn-primary-gradient px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/20 cursor-pointer"
            >
              {language === 'es' ? 'RESERVAR SESIÓN' : 'BOOK A PRODUCTION CALL'}
            </button>
          )}
        </motion.div>

        {/* Category Filter Pills */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex items-center gap-2 overflow-x-auto pb-4 no-scrollbar mb-10"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#FF007A] text-white shadow-md shadow-pink-500/30 scale-105'
                  : 'bg-[#15071f] text-gray-300 hover:text-white border border-white/5 hover:border-white/20'
              }`}
            >
              {cat === 'All' && language === 'es' ? 'Todos los Artículos' : cat}
            </button>
          ))}
        </motion.div>

        {/* Blog Post Cards Grid */}
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          <AnimatePresence>
            {filteredPosts.map((post, idx) => (
              <motion.article
                layout
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4, delay: idx * 0.05 }}
                onClick={() => navigate(`/blog/${post.slug}`)}
                className="group flex flex-col bg-[#12061b]/80 hover:bg-[#180924] border border-white/10 hover:border-pink-500/40 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1.5 shadow-xl hover:shadow-2xl hover:shadow-pink-500/10 cursor-pointer"
              >
                {/* Cover Image Container with Aspect Ratio */}
                <div className="relative aspect-[16/10] overflow-hidden bg-black/40">
                  <img
                    src={post.coverImage}
                    alt={post.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#12061b] via-[#12061b]/30 to-transparent" />
                  
                  {/* Category Pill Tag on Image */}
                  {post.category && (
                    <div className="absolute top-3.5 left-3.5">
                      <span className="px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-[#09030e]/85 backdrop-blur-md text-pink-400 border border-pink-500/30 shadow-sm">
                        {post.category}
                      </span>
                    </div>
                  )}

                  {/* Read Time Pill */}
                  {post.readTime && (
                    <div className="absolute top-3.5 right-3.5">
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[10.5px] font-semibold bg-black/60 backdrop-blur-md text-gray-300 border border-white/10">
                        <Clock className="w-3 h-3 text-pink-400" />
                        <span>{post.readTime}</span>
                      </span>
                    </div>
                  )}
                </div>

                {/* Content Section */}
                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Meta: Published Date */}
                    <div className="flex items-center gap-2 text-[11px] text-gray-400 font-mono mb-2.5">
                      <Calendar className="w-3.5 h-3.5 text-pink-400" />
                      <time dateTime={post.publishedDate}>{formatDate(post.publishedDate)}</time>
                      {post.tags && post.tags[0] && (
                        <>
                          <span className="text-gray-600">•</span>
                          <span className="text-gray-400">#{post.tags[0]}</span>
                        </>
                      )}
                    </div>

                    {/* Post Title */}
                    <h3 className="text-lg sm:text-xl font-bold text-white group-hover:text-pink-300 transition-colors leading-snug line-clamp-2 mb-2.5">
                      {post.title}
                    </h3>

                    {/* Excerpt */}
                    <p className="text-xs sm:text-sm text-gray-400 leading-relaxed line-clamp-3 mb-5">
                      {post.excerpt}
                    </p>
                  </div>

                  {/* Card Bottom: Author info and Action Link */}
                  <div className="pt-4 border-t border-white/5 flex items-center justify-between mt-auto">
                    <div className="flex items-center gap-2.5">
                      {post.author.avatarUrl && (
                        <img
                          src={post.author.avatarUrl}
                          alt={post.author.name}
                          referrerPolicy="no-referrer"
                          className="w-7 h-7 rounded-full object-cover border border-pink-500/40"
                        />
                      )}
                      <div>
                        <p className="text-xs font-semibold text-gray-200 line-clamp-1">
                          {post.author.name}
                        </p>
                        <p className="text-[10px] text-gray-400 line-clamp-1">
                          {post.author.role}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-xs font-bold text-[#FF007A] group-hover:translate-x-1 transition-transform">
                      <span>{language === 'es' ? 'Leer' : 'Read'}</span>
                      <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredPosts.length === 0 && (
          <div className="text-center py-16 bg-[#13071c]/50 rounded-2xl border border-white/5">
            <BookOpen className="w-10 h-10 text-gray-500 mx-auto mb-3" />
            <p className="text-gray-300 font-semibold">
              {language === 'es' ? 'No hay artículos en esta categoría aún.' : 'No articles found in this category.'}
            </p>
          </div>
        )}

        {/* View Complete Archive Link */}
        <div className="mt-12 text-center">
          <button
            onClick={() => navigate('/blog')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-pink-500/40 text-xs sm:text-sm font-bold uppercase tracking-wider text-gray-200 hover:text-white transition-all shadow-md group cursor-pointer"
          >
            <span>{language === 'es' ? 'VER ARCHIVO COMPLETO DE ARTÍCULOS' : 'EXPLORE ALL PRODUCTION INSIGHTS'}</span>
            <ArrowRight className="w-4 h-4 text-[#FF007A] group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

      </div>
    </section>
  );
};

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Eye, SlidersHorizontal, Sparkles, Film, Share2, Check } from 'lucide-react';
import { ProjectItem } from '../types';
import { CinematicImage } from './CinematicImage';
import { cardHover, staggerFadeIn } from '../utils/motionVariants';

interface ProjectVideoCardProps {
  project: ProjectItem;
  idx: number;
  currentViewsCount: number;
  formattedViewString: string;
  popularity: { label: string; icon: any; color: string } | null;
  language: 'en' | 'es';
  onCardClick: (project: ProjectItem) => void;
}

export const ProjectVideoCard: React.FC<ProjectVideoCardProps> = ({
  project,
  idx,
  currentViewsCount,
  formattedViewString,
  popularity,
  language,
  onCardClick
}) => {
  const thumbnailRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Drag & scrub state
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [scrubProgress, setScrubProgress] = useState<number>(0); // 0 to 1
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isVideoLoaded, setIsVideoLoaded] = useState<boolean>(false);
  const [hasScrubbed, setHasScrubbed] = useState<boolean>(false);

  // Share state
  const [copied, setCopied] = useState<boolean>(false);
  const [showShareToast, setShowShareToast] = useState<boolean>(false);
  const [shareFeedbackMsg, setShareFeedbackMsg] = useState<string>('');
  const toastTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Gesture tracking refs
  const isPointerDownRef = useRef<boolean>(false);
  const hasDraggedRef = useRef<boolean>(false);
  const startPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Format seconds to mm:ss
  const formatTime = useCallback((seconds: number): string => {
    if (isNaN(seconds) || seconds < 0) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }, []);

  // Update video duration on metadata load
  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const vidDur = videoRef.current.duration;
      if (vidDur && !isNaN(vidDur) && vidDur > 0) {
        setDuration(vidDur);
        setIsVideoLoaded(true);
      }
    }
  };

  // Video timeupdate tracking (only when not actively dragging)
  const handleTimeUpdate = () => {
    if (!isDragging && videoRef.current) {
      const curr = videoRef.current.currentTime;
      const dur = duration > 0 ? duration : (videoRef.current.duration || 15);
      setCurrentTime(curr);
      if (dur > 0) {
        setScrubProgress(curr / dur);
      }
    }
  };

  // Control video play/pause on hover and drag
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !project.videoUrl) return;

    if (isDragging) {
      video.pause();
    } else if (isHovered && !hasScrubbed) {
      video.play().catch(() => {
        // browser autoplay policy guard
      });
    } else if (!isHovered && !hasScrubbed) {
      video.pause();
      video.currentTime = 0;
      setScrubProgress(0);
      setCurrentTime(0);
    }
  }, [isHovered, isDragging, hasScrubbed, project.videoUrl]);

  // Calculate scrub position from clientX
  const updateScrub = useCallback((clientX: number) => {
    if (!thumbnailRef.current) return;
    const rect = thumbnailRef.current.getBoundingClientRect();
    if (rect.width <= 0) return;

    const relativeX = Math.max(0, Math.min(rect.width, clientX - rect.left));
    const progress = relativeX / rect.width;
    setScrubProgress(progress);
    setHasScrubbed(true);

    if (videoRef.current) {
      const vidDuration = duration > 0 ? duration : (videoRef.current.duration || 15);
      const targetTime = progress * vidDuration;
      videoRef.current.currentTime = targetTime;
      setCurrentTime(targetTime);
    }
  }, [duration]);

  // Pointer Down on Thumbnail
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    // Only respond to main click/touch
    if (e.button !== 0) return;
    isPointerDownRef.current = true;
    hasDraggedRef.current = false;
    startPosRef.current = { x: e.clientX, y: e.clientY };

    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // safe ignore
    }
  };

  // Pointer Move on Thumbnail
  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isPointerDownRef.current) return;

    const deltaX = Math.abs(e.clientX - startPosRef.current.x);
    const deltaY = Math.abs(e.clientY - startPosRef.current.y);

    // If movement exceeds small threshold, initiate drag scrub
    if (deltaX > 4 || hasDraggedRef.current) {
      hasDraggedRef.current = true;
      if (!isDragging) {
        setIsDragging(true);
      }
      updateScrub(e.clientX);
    }
  };

  // Pointer Up
  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isPointerDownRef.current) return;
    isPointerDownRef.current = false;

    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {
      // safe ignore
    }

    if (isDragging) {
      // Clear dragging flag shortly after to prevent click propagation
      setTimeout(() => {
        setIsDragging(false);
      }, 80);
    }
  };

  // Pointer Cancel
  const handlePointerCancel = (e: React.PointerEvent<HTMLDivElement>) => {
    isPointerDownRef.current = false;
    setIsDragging(false);
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {
      // safe ignore
    }
  };

  // Clean up toast timer on unmount
  useEffect(() => {
    return () => {
      if (toastTimerRef.current) {
        clearTimeout(toastTimerRef.current);
      }
    };
  }, []);

  // Web Share API handler with Clipboard fallback
  const handleShare = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    let shareUrl = '';
    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.origin + window.location.pathname);
        url.searchParams.set('project', project.id);
        url.hash = 'portfolio';
        shareUrl = url.toString();
      } catch {
        shareUrl = `${window.location.origin}/?project=${project.id}#portfolio`;
      }
    }

    const shareTitle = `${project.title} | ${project.client} - Case Study`;
    const shareText = language === 'es'
      ? `Mira el caso de estudio "${project.title}" para ${project.client} por HIGH DEFINITION.`
      : `Explore the "${project.title}" case study for ${project.client} by HIGH DEFINITION video studio.`;

    const sharePayload = {
      title: shareTitle,
      text: shareText,
      url: shareUrl,
    };

    // Check if native Web Share API is available
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        if (navigator.canShare && !navigator.canShare(sharePayload)) {
          await navigator.share({
            title: shareTitle,
            url: shareUrl,
          });
        } else {
          await navigator.share(sharePayload);
        }
        setCopied(true);
        setShareFeedbackMsg(language === 'es' ? '¡Compartido!' : 'Shared!');
        setShowShareToast(true);
        if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
        toastTimerRef.current = setTimeout(() => {
          setCopied(false);
          setShowShareToast(false);
        }, 2400);
        return;
      } catch (err: any) {
        if (err?.name === 'AbortError') {
          // User dismissed or cancelled native share sheet
          return;
        }
        // Fallback continues below
      }
    }

    // Fallback: Copy link to clipboard
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(shareUrl);
      } else {
        const el = document.createElement('textarea');
        el.value = shareUrl;
        el.style.position = 'fixed';
        el.style.left = '-9999px';
        document.body.appendChild(el);
        el.focus();
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      }
      setCopied(true);
      setShareFeedbackMsg(language === 'es' ? '¡Enlace copiado!' : 'Link copied!');
      setShowShareToast(true);
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
      toastTimerRef.current = setTimeout(() => {
        setCopied(false);
        setShowShareToast(false);
      }, 2400);
    } catch {
      // safe ignore
    }
  };

  // Card Click - only opens modal if user did NOT drag/scrub
  const handleCardClick = (e: React.MouseEvent) => {
    if (hasDraggedRef.current || isDragging) {
      e.preventDefault();
      e.stopPropagation();
      hasDraggedRef.current = false;
      return;
    }
    onCardClick(project);
  };

  return (
    <motion.div
      layout
      variants={staggerFadeIn}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-40px' }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={cardHover}
      onClick={handleCardClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        if (!isPointerDownRef.current) {
          setIsDragging(false);
        }
      }}
      className={`group relative rounded-2xl overflow-hidden bg-[#13061c] border border-white/10 hover:border-pink-500/50 shadow-xl shadow-black/50 transition-all cursor-pointer flex flex-col justify-between select-none ${
        isDragging ? 'ring-2 ring-[#FF007A]/50 border-pink-500' : ''
      }`}
    >
      {/* Project Thumbnail & Video Scrubbing Canvas */}
      <div
        ref={thumbnailRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerCancel}
        className="relative aspect-[16/10] overflow-hidden bg-black touch-pan-y cursor-ew-resize select-none"
      >
        {/* Base Thumbnail Image */}
        <CinematicImage
          src={project.thumbnailUrl}
          alt={project.title}
          containerClassName={`absolute inset-0 w-full h-full pointer-events-none transition-opacity duration-700 ${
            hasScrubbed ? 'opacity-0' : 'opacity-100'
          }`}
          className={`w-full h-full object-cover transition-transform duration-700 pointer-events-none ${isHovered && !isDragging ? 'scale-105' : 'scale-100'}`}
        />

        {/* Video Player for Scrubbing */}
        {project.videoUrl && (
          <video
            ref={videoRef}
            src={project.videoUrl}
            preload="metadata"
            muted
            playsInline
            onLoadedMetadata={handleLoadedMetadata}
            onTimeUpdate={handleTimeUpdate}
            className={`absolute inset-0 w-full h-full object-cover pointer-events-none transition-opacity duration-300 ${
              hasScrubbed || isHovered ? 'opacity-100' : 'opacity-0'
            }`}
          />
        )}

        {/* Cinematic Vignette Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#13061c] via-transparent to-black/30 pointer-events-none" />

        {/* Top Category Badge */}
        <div className="absolute top-3 left-3 pointer-events-none z-10">
          <span className="px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md text-[10px] font-bold text-pink-300 uppercase tracking-wider border border-white/10 shadow-md">
            {project.category}
          </span>
        </div>

        {/* Top Right: Popularity Badge or Scrub Indicator */}
        <div className="absolute top-3 right-3 pointer-events-none z-10 flex items-center gap-1.5">
          {isDragging ? (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#FF007A] text-white text-[10px] font-bold tracking-wider uppercase shadow-lg shadow-pink-500/50 animate-pulse">
              <SlidersHorizontal className="w-3 h-3" />
              <span>{language === 'es' ? 'Deslizando' : 'Scrubbing'}</span>
            </div>
          ) : popularity ? (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md text-[10px] font-bold border border-white/10 shadow-lg">
              <popularity.icon className={`w-3 h-3 ${popularity.color.split(' ')[0]}`} />
              <span className={popularity.color.split(' ')[0]}>{popularity.label}</span>
            </div>
          ) : null}
        </div>

        {/* Center Overlay: Play Button or Scrub HUD */}
        {!isDragging && (
          <div className="absolute inset-0 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/35 backdrop-blur-[1px] pointer-events-none z-10">
            <div className="w-12 h-12 rounded-full bg-[#FF007A] text-white flex items-center justify-center shadow-lg shadow-pink-500/50 transform group-hover:scale-110 transition-transform mb-2">
              <Play className="w-5 h-5 fill-current ml-0.5" />
            </div>
            {/* Interactive scrubbing cue pill */}
            <div className="px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md border border-white/20 text-[10px] font-semibold text-gray-200 flex items-center gap-1.5 shadow-md">
              <SlidersHorizontal className="w-3 h-3 text-[#FF007A]" />
              <span>{language === 'es' ? 'Arrastra para explorar reel' : 'Drag to scrub timeline'}</span>
            </div>
          </div>
        )}

        {/* Active Scrubbing HUD Overlay (Displayed during drag) */}
        {isDragging && (
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-20">
            <div className="px-3.5 py-1.5 rounded-full bg-black/90 backdrop-blur-md border border-pink-500/50 text-white flex items-center gap-2 shadow-2xl">
              <Film className="w-3.5 h-3.5 text-[#FF007A]" />
              <span className="font-mono text-xs font-bold text-pink-300">
                {formatTime(currentTime)}
              </span>
              <span className="text-gray-500 text-xs">/</span>
              <span className="font-mono text-xs text-gray-400">
                {formatTime(duration || 15)}
              </span>
            </div>
          </div>
        )}

        {/* Interactive Scrubbing Timeline Bar at Bottom Edge */}
        <div className="absolute inset-x-0 bottom-0 p-3 pt-6 bg-gradient-to-t from-black/90 via-black/40 to-transparent pointer-events-none z-20">
          <div className="relative w-full h-1.5 group-hover:h-2 transition-all bg-white/20 rounded-full overflow-visible backdrop-blur-sm">
            {/* Filled Progress Track */}
            <div
              className="h-full bg-gradient-to-r from-[#FF007A] to-[#FF5E62] rounded-full shadow-[0_0_10px_#FF007A] relative"
              style={{ width: `${Math.max(0, Math.min(100, scrubProgress * 100))}%` }}
            >
              {/* Scrub Handle / Thumb (visible on hover or drag) */}
              <div
                className={`absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3.5 h-3.5 bg-white border-2 border-[#FF007A] rounded-full shadow-[0_0_8px_rgba(255,0,122,0.8)] transition-transform ${
                  isDragging ? 'scale-125' : isHovered ? 'scale-100' : 'scale-0'
                }`}
              />
            </div>
          </div>

          {/* Time indicator underneath timeline */}
          <div className="flex justify-between items-center text-[10px] font-mono text-gray-400 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <span className="text-pink-300 font-semibold">{formatTime(currentTime)}</span>
            <span>{formatTime(duration || 15)}</span>
          </div>
        </div>
      </div>

      {/* Project Content */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-semibold text-pink-400">{project.client}</span>
            <span>{project.year}</span>
          </div>
          <h3 className="text-lg font-bold text-white mt-1 group-hover:text-pink-200 transition-colors line-clamp-1">
            {project.title}
          </h3>
          <p className="text-xs text-gray-300 mt-2 line-clamp-2 leading-relaxed">
            {project.description}
          </p>
        </div>

        {/* Deliverables Tags, Views Counter & Share Button */}
        <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between gap-2">
          {/* Deliverables chips */}
          <div className="flex flex-wrap gap-1.5 flex-1 overflow-hidden">
            {project.deliverables.slice(0, 1).map((item, i) => (
              <span key={i} className="text-[10px] font-medium bg-white/5 text-gray-300 px-2 py-0.5 rounded truncate max-w-[110px]">
                {item}
              </span>
            ))}
            {project.deliverables.length > 1 && (
              <span className="text-[10px] font-medium text-gray-400 px-1 py-0.5">
                +{project.deliverables.length - 1}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Views Counter */}
            <div
              id={`project-views-${project.id}`}
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full bg-[#1c0827]/90 border border-pink-500/20 text-gray-300 text-[11px] font-medium tracking-tight shadow-sm shrink-0 group-hover:border-pink-500/40 group-hover:text-pink-200 group-hover:bg-[#250b34] transition-all"
              title={`${currentViewsCount.toLocaleString()} ${language === 'es' ? 'vistas verificadas' : 'verified views'}`}
            >
              <Eye className="w-3.5 h-3.5 text-pink-400 shrink-0" />
              <span className="font-bold text-white font-mono text-[11px]">
                {formattedViewString}
              </span>
            </div>

            {/* Share Button (Web Share API) */}
            <button
              id={`share-case-study-${project.id}`}
              type="button"
              onClick={handleShare}
              title={language === 'es' ? 'Compartir caso de estudio' : 'Share case study (Web Share API)'}
              aria-label={`Share ${project.title} case study`}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold border transition-all duration-200 cursor-pointer select-none shadow-sm ${
                copied
                  ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-300 shadow-emerald-500/20'
                  : 'bg-white/5 hover:bg-[#FF007A]/15 border-white/10 hover:border-[#FF007A]/50 text-gray-300 hover:text-white hover:shadow-[#FF007A]/20'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-[10px] font-mono tracking-tight text-emerald-300 uppercase">
                    {language === 'es' ? 'Copiado' : 'Copied'}
                  </span>
                </>
              ) : (
                <>
                  <Share2 className="w-3 h-3 text-[#FF007A]" />
                  <span className="text-[10px] font-mono tracking-tight uppercase">
                    {language === 'es' ? 'Compartir' : 'Share'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Floating Share Feedback Toast */}
        <AnimatePresence>
          {showShareToast && (
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.92 }}
              transition={{ duration: 0.2 }}
              className="absolute bottom-16 right-4 z-40 pointer-events-none"
            >
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/95 border border-emerald-500/60 text-emerald-300 text-xs font-semibold shadow-2xl backdrop-blur-md">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-mono text-[11px] font-bold">
                  {shareFeedbackMsg || (language === 'es' ? '¡Enlace copiado!' : 'Link copied!')}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

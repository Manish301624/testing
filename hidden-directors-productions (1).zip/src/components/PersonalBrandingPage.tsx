import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Helmet } from 'react-helmet-async';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  X, 
  ChevronRight, 
  Sparkles, 
  Award, 
  TrendingUp, 
  Users, 
  ArrowRight, 
  Film, 
  CheckCircle2,
  Clock,
  ExternalLink
} from 'lucide-react';
import { PersonalBrandingItem } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { useLanguage } from '../context/LanguageContext';
import { containerStagger, staggerFadeIn, slideUp, fadeIn, scaleIn } from '../utils/motionVariants';

interface PersonalBrandingPageProps {
  onOpenBooking: () => void;
}

// Reusable Autoplay Preview Video Component with Intersection Observer
const VideoPreviewCard: React.FC<{
  item: PersonalBrandingItem;
  onClick: () => void;
  isFeatured?: boolean;
}> = ({ item, onClick, isFeatured }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isInView, setIsInView] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const element = videoRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.25 }
    );

    observer.observe(element);
    return () => {
      if (element) observer.unobserve(element);
    };
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isInView) {
      video.play().catch(() => {
        // Autoplay policy fallback handled silently
      });
    } else {
      video.pause();
    }
  }, [isInView]);

  return (
    <motion.div
      layout
      variants={scaleIn}
      initial="hidden"
      animate="visible"
      exit="exit"
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      data-cursor="play"
      className={`group relative rounded-3xl overflow-hidden bg-[#12071a] border border-white/10 hover:border-[#FF007A]/50 transition-all duration-500 shadow-2xl cursor-pointer ${
        isFeatured ? 'md:col-span-2 md:row-span-2 min-h-[460px] md:min-h-[520px]' : 'col-span-1 min-h-[360px] sm:min-h-[400px]'
      }`}
    >
      {/* Background Video / Poster Preview */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <video
          ref={videoRef}
          src={item.videoUrl}
          poster={item.posterUrl}
          muted
          loop
          playsInline
          preload="none"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {/* Cinematic Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#09030e] via-[#09030e]/40 to-transparent opacity-85 group-hover:opacity-95 transition-opacity duration-500" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#09030e]/60 via-transparent to-transparent opacity-70" />
        <div className="absolute inset-0 bg-[#FF007A]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      </div>

      {/* Top Badges: Category & Duration Pill */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10 pointer-events-none">
        <span className="px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-widest bg-black/60 backdrop-blur-md text-pink-300 border border-pink-500/30 font-mono shadow-sm">
          {item.category}
        </span>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-black/60 backdrop-blur-md text-gray-200 border border-white/10 font-mono shadow-sm">
          <Clock className="w-3 h-3 text-[#FF007A]" />
          <span>{item.duration}</span>
        </div>
      </div>

      {/* Center Play Button Floating on Hover */}
      <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: isHovered ? 1 : 0.85, opacity: isHovered ? 1 : 0.7 }}
          transition={{ duration: 0.25 }}
          className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#FF007A]/90 backdrop-blur-md text-white flex items-center justify-center shadow-[0_0_30px_rgba(255,0,122,0.6)] border border-pink-400/50"
        >
          <Play className="w-6 h-6 fill-white ml-0.5" />
        </motion.div>
      </div>

      {/* Bottom Content Metadata */}
      <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-7 z-10 flex flex-col justify-end">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-bold text-pink-400 font-mono tracking-wide">
            {item.clientName}
          </span>
          <span className="w-1 h-1 rounded-full bg-pink-500/60" />
          <span className="text-[11px] text-gray-400 font-mono">Verified Production</span>
        </div>

        <h3 className={`font-display font-extrabold text-white tracking-tight group-hover:text-pink-200 transition-colors ${
          isFeatured ? 'text-xl sm:text-2xl md:text-3xl mb-3' : 'text-lg sm:text-xl mb-2'
        }`}>
          {item.title}
        </h3>

        <p className={`text-gray-300 line-clamp-2 font-sans font-light leading-relaxed ${isFeatured ? 'text-sm sm:text-base max-w-2xl mb-4' : 'text-xs sm:text-sm mb-3'}`}>
          {item.description}
        </p>

        {/* Impact Stat Badge if Available */}
        {item.impactStat && (
          <div className="flex items-center gap-2 pt-2 border-t border-white/10 mt-1">
            <div className="p-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-bold text-emerald-300 font-mono">
              {item.impactStat}
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export const PersonalBrandingPage: React.FC<PersonalBrandingPageProps> = ({ onOpenBooking }) => {
  const { language } = useLanguage();
  const [items, setItems] = useState<PersonalBrandingItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<PersonalBrandingItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeModalItem, setActiveModalItem] = useState<PersonalBrandingItem | null>(null);

  const categories = ['All', 'Creators', 'Founders & Entrepreneurs', 'Fashion & Lifestyle', 'Coaches & Experts'];

  useEffect(() => {
    const fetchPersonalBranding = async () => {
      try {
        const res = await fetch('/api/personal-branding');
        if (res.ok) {
          const data = await res.json();
          setItems(data);
          setFilteredItems(data);
        }
      } catch (err) {
        console.error('Failed to fetch personal branding data:', err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchPersonalBranding();
  }, []);

  useEffect(() => {
    if (activeCategory === 'All') {
      setFilteredItems(items);
    } else {
      setFilteredItems(items.filter(i => i.category.toLowerCase() === activeCategory.toLowerCase()));
    }
  }, [activeCategory, items]);

  // Handle modal next video
  const handleNextVideo = () => {
    if (!activeModalItem) return;
    const currentIndex = filteredItems.findIndex(i => i.id === activeModalItem.id);
    if (currentIndex !== -1) {
      const nextIndex = (currentIndex + 1) % filteredItems.length;
      setActiveModalItem(filteredItems[nextIndex]);
    }
  };

  // Distinct SEO Metadata for Personal Branding
  const brandingTitle = language === 'es'
    ? 'Marca Personal y Videos para Fundadores | Hidden Directors Productions'
    : 'Personal Branding Video Production & Founder Films | Hidden Directors';

  const brandingDescription = language === 'es'
    ? 'Dirección cinematográfica para marcas personales de élite: fundadores, CEOs y creadores. Series de video para LinkedIn, podcasts multi-cámara y documentales de autoridad.'
    : 'Executive personal branding video production for founders, creators, and visionary leaders. Multi-camera thought leadership series, podcasts, and viral reels that build authority.';

  const brandingCanonicalUrl = 'https://hiddendirectors.com/personal-branding';
  const brandingOgImage = 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1200&q=80';

  const brandingSchemaJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    'serviceType': 'Personal Branding Video Production',
    'name': brandingTitle,
    'description': brandingDescription,
    'url': brandingCanonicalUrl,
    'provider': {
      '@type': 'Organization',
      'name': 'Hidden Directors Productions',
      'url': 'https://hiddendirectors.com',
      'logo': 'https://hiddendirectors.com/logo.svg'
    },
    'areaServed': 'Worldwide'
  };

  return (
    <>
      <Helmet>
        <title>{brandingTitle}</title>
        <meta name="description" content={brandingDescription} />
        <meta name="keywords" content="personal branding video, founder brand film, executive video production, LinkedIn video series, creator reels, keynote showreel, thought leadership content agency, Hidden Directors" />

        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content={brandingTitle} />
        <meta property="og:description" content={brandingDescription} />
        <meta property="og:image" content={brandingOgImage} />
        <meta property="og:image:alt" content="Personal Branding Films by Hidden Directors" />
        <meta property="og:url" content={brandingCanonicalUrl} />
        <meta property="og:site_name" content="Hidden Directors Productions" />

        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={brandingTitle} />
        <meta name="twitter:description" content={brandingDescription} />
        <meta name="twitter:image" content={brandingOgImage} />
        <meta name="twitter:image:alt" content="Personal Branding Films by Hidden Directors" />

        {/* Canonical Link */}
        <link rel="canonical" href={brandingCanonicalUrl} />

        {/* Schema.org Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(brandingSchemaJsonLd)}
        </script>
      </Helmet>

      <div id="personal-branding-showcase-page" className="min-h-screen bg-[#09030e] text-[#F3F4F6] pt-28 pb-32 relative overflow-hidden">
        
        {/* Background Ambient Glows & Grain Texture Overlay */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-b from-[#FF007A]/15 via-purple-900/10 to-transparent blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/3 right-0 w-[600px] h-[600px] bg-pink-600/10 rounded-full blur-[150px] pointer-events-none" />
        <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          {/* Breadcrumb & Live Counter Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-2 text-xs font-mono text-gray-400">
              <a href="/" className="hover:text-white transition-colors">Home</a>
              <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
              <span className="text-pink-400 font-bold">Personal Branding</span>
            </div>

            <div className="flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34D399]" />
              <span className="text-xs font-mono font-bold text-gray-200">50+ Branding Films Delivered Globally</span>
            </div>
          </div>

          {/* Page Hero Section */}
          <div className="max-w-4xl mb-16">
            <motion.div
              variants={slideUp}
              initial="hidden"
              animate="visible"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/30 text-pink-300 text-xs font-bold tracking-wider uppercase mb-4 font-mono">
                <Sparkles className="w-3.5 h-3.5 text-[#FF007A]" />
                <span>Authority & Presence Architecture</span>
              </div>

              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-display font-extrabold tracking-tight text-white mb-6">
                Personal <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF007A] via-[#FF5E62] to-purple-400">Branding</span>
              </h1>

              <p className="text-lg sm:text-xl text-gray-300 font-light leading-relaxed max-w-3xl">
                Your presence deserves direction. We build personal branding visuals that feel authentic, structured and strongly positioned to command trust, engagement, and industry leadership.
              </p>
            </motion.div>
          </div>

          {/* Filter & Category Bar */}
          <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto pb-4 mb-12 scrollbar-none">
            {categories.map((category) => {
              const isActive = activeCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`relative px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold tracking-wide transition-all duration-300 cursor-pointer whitespace-nowrap ${
                    isActive 
                      ? 'text-white bg-transparent shadow-lg' 
                      : 'text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/5'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeCategoryIndicator"
                      className="absolute inset-0 bg-gradient-to-r from-[#FF007A] to-purple-600 rounded-full shadow-[0_0_20px_rgba(255,0,122,0.5)] -z-10"
                      transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                    />
                  )}
                  <span>{category}</span>
                </button>
              );
            })}
          </div>

          {/* Video Showcase Grid (Mixed-Size Bento & Masonry Layout) */}
          {isLoading ? (
            <LoadingSpinner 
              fullScreen={false} 
              size="md" 
              message="CURATING BRANDING MASTERPIECES" 
            />
          ) : filteredItems.length === 0 ? (
            <div className="py-24 text-center rounded-3xl bg-[#12071a]/80 border border-white/10 p-8">
              <Film className="w-12 h-12 text-pink-500 mx-auto mb-4 opacity-60" />
              <h3 className="text-xl font-display font-bold text-white mb-2">No Branding Films Found</h3>
              <p className="text-sm text-gray-400 mb-6">No videos match the selected category "{activeCategory}". Try selecting another category.</p>
              <button
                onClick={() => setActiveCategory('All')}
                className="px-6 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                View All Categories
              </button>
            </div>
          ) : (
            <motion.div 
              layout
              variants={containerStagger}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
            >
              <AnimatePresence>
                {filteredItems.map((item, index) => {
                  // Make every 1st and 5th item featured (larger 2x grid span) if in All view
                  const isFeaturedItem = item.isFeatured || (activeCategory === 'All' && (index === 0 || index === 3 || index === 7));
                  return (
                    <VideoPreviewCard
                      key={item.id}
                      item={item}
                      isFeatured={isFeaturedItem}
                      onClick={() => setActiveModalItem(item)}
                    />
                  );
                })}
              </AnimatePresence>
            </motion.div>
          )}

          {/* Results & Impact Section */}
          <motion.div 
            variants={slideUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            className="mt-28 py-16 px-6 sm:px-12 rounded-3xl bg-gradient-to-r from-[#140620] via-[#100418] to-[#12061b] border border-[#FF007A]/20 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute -right-20 -top-20 w-80 h-80 bg-pink-500/10 rounded-full blur-[100px] pointer-events-none" />
            
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-xs font-mono font-bold text-pink-400 uppercase tracking-widest bg-pink-500/10 px-3 py-1 rounded-full border border-pink-500/20">
                Verified Impact
              </span>
              <h2 className="text-3xl sm:text-4xl font-display font-extrabold text-white mt-4 mb-3">
                Built for Elite Digital Authority
              </h2>
              <p className="text-sm sm:text-base text-gray-300 font-light">
                Our personal branding productions combine cinematic framing with psychological positioning to drive exponential audience growth.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="p-6 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm">
                <div className="text-4xl sm:text-5xl font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-[#FF007A] to-pink-400 mb-2">
                  35+
                </div>
                <div className="text-sm font-bold text-white mb-1">Creators & Founders</div>
                <p className="text-xs text-gray-400">Positioned as Tier-1 industry authorities</p>
              </div>

              <div className="p-6 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm">
                <div className="text-4xl sm:text-5xl font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-[#FF007A] to-purple-400 mb-2">
                  10M+
                </div>
                <div className="text-sm font-bold text-white mb-1">Combined Reach Generated</div>
                <p className="text-xs text-gray-400">Across YouTube, LinkedIn & Instagram</p>
              </div>

              <div className="p-6 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm">
                <div className="text-4xl sm:text-5xl font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-2">
                  95%
                </div>
                <div className="text-sm font-bold text-white mb-1">Client Retention Rate</div>
                <p className="text-xs text-gray-400">Long-term ongoing production partners</p>
              </div>
            </div>
          </motion.div>

          {/* Bottom CTA Section */}
          <motion.div 
            variants={slideUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            className="mt-28 text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold text-white mb-6">
              Ready to command your market with cinematic authority?
            </h2>
            <p className="text-base sm:text-lg text-gray-300 font-light mb-8">
              Book a strategic consultation with our creative directors to discuss your personal brand vision.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              onClick={onOpenBooking}
              data-cursor="magnetic"
              className="btn-primary-gradient px-8 py-4 rounded-full text-sm sm:text-base font-bold tracking-wider text-white uppercase shadow-xl shadow-pink-600/40 cursor-pointer inline-flex items-center gap-3"
            >
              <span>Book a Strategy Call</span>
              <ArrowRight className="w-5 h-5" />
            </motion.button>
          </motion.div>

        </div>
      </div>

      {/* Immersive Video Modal */}
      <AnimatePresence>
        {activeModalItem && (
          <motion.div
            variants={fadeIn}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl p-4 sm:p-6 md:p-10"
            onClick={() => setActiveModalItem(null)}
          >
            <motion.div
              variants={scaleIn}
              initial="hidden"
              animate="visible"
              exit="exit"
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-5xl bg-[#12071a] border border-[#FF007A]/40 rounded-3xl overflow-hidden shadow-2xl shadow-pink-950/80 flex flex-col max-h-[92vh]"
            >
              {/* Modal Header */}
              <div className="px-6 py-4 bg-black/60 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 rounded-full text-[10px] font-mono font-bold bg-[#FF007A]/20 text-pink-300 border border-pink-500/30">
                    {activeModalItem.category}
                  </span>
                  <span className="text-xs font-mono text-gray-300">Client: <strong className="text-white">{activeModalItem.clientName}</strong></span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleNextVideo}
                    className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-200 border border-white/10 transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Next Film</span>
                    <ChevronRight className="w-3.5 h-3.5 text-[#FF007A]" />
                  </button>

                  <button
                    onClick={() => setActiveModalItem(null)}
                    className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
                    aria-label="Close modal"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Video Player Area */}
              <div className="relative bg-black aspect-video w-full flex items-center justify-center">
                <video
                  src={activeModalItem.videoUrl}
                  poster={activeModalItem.posterUrl}
                  autoPlay
                  controls
                  playsInline
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Modal Footer / Context */}
              <div className="p-6 sm:p-8 bg-gradient-to-b from-[#12071a] to-[#09030e] border-t border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div>
                  <h3 className="text-xl sm:text-2xl font-display font-bold text-white mb-2">
                    {activeModalItem.title}
                  </h3>
                  <p className="text-sm text-gray-300 font-light max-w-2xl leading-relaxed">
                    {activeModalItem.description}
                  </p>
                </div>

                {activeModalItem.impactStat && (
                  <div className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 shrink-0">
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                    <div>
                      <div className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Verified Impact</div>
                      <div className="text-sm font-bold text-emerald-200">{activeModalItem.impactStat}</div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

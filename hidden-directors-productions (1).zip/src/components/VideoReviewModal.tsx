import { CinematicImage } from "./CinematicImage";
import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Play, Pause, Volume2, VolumeX, Star, CheckCircle, Quote, Sparkles, MessageCircle } from 'lucide-react';
import { ReviewItem } from '../types';
import { buildWhatsAppUrl, getInitialWhatsAppNumber, fetchConfiguredWhatsAppNumber, getContextualWhatsAppMessage, logWhatsAppInquiry } from '../utils/whatsapp';
import { backdropBlurIn, modalContentEntrance } from '../utils/motionVariants';

interface VideoReviewModalProps {
  review: ReviewItem | null;
  onClose: () => void;
  onBookShoot?: () => void;
}

export const VideoReviewModal: React.FC<VideoReviewModalProps> = ({
  review,
  onClose,
  onBookShoot
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isBuffering, setIsBuffering] = useState<boolean>(true);
  const [loadProgress, setLoadProgress] = useState<number>(15);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(getInitialWhatsAppNumber);

  useEffect(() => {
    let isMounted = true;
    fetchConfiguredWhatsAppNumber().then((num) => {
      if (isMounted && num) setWhatsappNumber(num);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Reset and play video on open
  useEffect(() => {
    if (review && review.videoUrl) {
      setIsPlaying(true);
      setIsBuffering(true);
      setLoadProgress(20);
      setCurrentTime(0);

      const timer = setInterval(() => {
        setLoadProgress((prev) => {
          if (prev >= 95) {
            clearInterval(timer);
            return prev;
          }
          return prev + Math.floor(Math.random() * 15) + 10;
        });
      }, 120);

      return () => clearInterval(timer);
    }
  }, [review]);

  // Keyboard navigation: Escape to close, Space to toggle play
  useEffect(() => {
    if (!review) {
      document.body.style.overflow = '';
      return;
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'm' || e.key === 'M') {
        setIsMuted((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [review, isPlaying, onClose]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (videoRef.current && duration > 0) {
      const rect = e.currentTarget.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const pct = Math.max(0, Math.min(1, clickX / rect.width));
      videoRef.current.currentTime = pct * duration;
      setCurrentTime(pct * duration);
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPct = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <AnimatePresence>
      {review && review.videoUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          {/* Backdrop with subtle blur-in animation */}
          <motion.div
            variants={backdropBlurIn}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={onClose}
            className="fixed inset-0 bg-black/85"
          />

          {/* Modal Container */}
          <motion.div
            variants={modalContentEntrance}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="relative w-full max-w-4xl rounded-3xl bg-[#13051c] border border-pink-500/30 overflow-hidden shadow-[0_20px_60px_rgba(255,0,122,0.2)] z-10 my-auto"
          >
          {/* Close button */}
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="absolute top-4 right-4 z-30 p-2.5 rounded-full bg-black/70 hover:bg-black text-white backdrop-blur-md border border-white/15 transition-all cursor-pointer hover:scale-105"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left / Video Player Column */}
            <div className="lg:col-span-7 relative bg-black flex items-center justify-center aspect-video lg:aspect-auto lg:min-h-[480px]">
              <video
                ref={videoRef}
                src={review.videoUrl}
                poster={review.videoPosterUrl || review.avatarUrl}
                playsInline
                autoPlay
                loop
                muted={isMuted}
                onClick={togglePlay}
                onCanPlay={() => {
                  setIsBuffering(false);
                  setLoadProgress(100);
                }}
                onWaiting={() => setIsBuffering(true)}
                onPlaying={() => setIsBuffering(false)}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                className="w-full h-full object-cover cursor-pointer"
              />

              {/* Video Play Overlay */}
              <AnimatePresence>
                {(!isPlaying || isBuffering) && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={togglePlay}
                    className="absolute inset-0 bg-black/45 flex flex-col items-center justify-center cursor-pointer select-none"
                  >
                    <div className="relative flex items-center justify-center">
                      {/* Circular Progress Ring */}
                      <svg className="w-20 h-20 -rotate-90 transform pointer-events-none" viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="44" className="stroke-white/20" strokeWidth="3" fill="none" />
                        <circle
                          cx="50"
                          cy="50"
                          r="44"
                          className="stroke-[#FF007A] transition-all duration-150"
                          strokeWidth="3.5"
                          strokeLinecap="round"
                          fill="none"
                          strokeDasharray={276.46}
                          strokeDashoffset={276.46 - (276.46 * Math.min(100, Math.max(10, isBuffering ? loadProgress : 100))) / 100}
                        />
                      </svg>
                      <button
                        aria-label="Play video testimonial"
                        className="absolute w-14 h-14 rounded-full bg-gradient-to-tr from-[#FF007A] to-[#FF5E62] text-white flex items-center justify-center shadow-[0_0_20px_rgba(255,0,122,0.6)]"
                      >
                        <Play className="w-6 h-6 fill-current ml-0.5" />
                      </button>
                    </div>
                    {isBuffering && (
                      <span className="mt-3 font-mono text-[11px] font-bold text-pink-200 uppercase tracking-widest bg-black/75 px-3 py-1 rounded-full border border-pink-500/30">
                        Buffering Testimonial...
                      </span>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Bottom Video Controls Bar */}
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-4 flex flex-col gap-2">
                {/* Progress bar */}
                <div
                  onClick={handleSeek}
                  className="w-full h-1.5 bg-white/20 rounded-full cursor-pointer relative overflow-hidden group/bar"
                >
                  <div
                    className="h-full bg-gradient-to-r from-[#FF007A] to-[#FFA07A] rounded-full relative transition-all"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-white text-xs">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={togglePlay}
                      className="p-1 rounded-full hover:bg-white/10 text-white transition-colors"
                      title={isPlaying ? 'Pause' : 'Play'}
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                    </button>

                    <button
                      onClick={() => setIsMuted((prev) => !prev)}
                      className="p-1 rounded-full hover:bg-white/10 text-white transition-colors"
                      title={isMuted ? 'Unmute' : 'Mute'}
                    >
                      {isMuted ? <VolumeX className="w-4 h-4 text-pink-400" /> : <Volume2 className="w-4 h-4" />}
                    </button>

                    <span className="font-mono text-[11px] text-gray-300">
                      {formatTime(currentTime)} / {formatTime(duration || 30)}
                    </span>
                  </div>

                  <span className="px-2 py-0.5 rounded bg-pink-500/20 border border-pink-500/40 text-[10px] font-bold uppercase tracking-wider text-pink-300">
                    4K Video Testimonial
                  </span>
                </div>
              </div>
            </div>

            {/* Right / Testimonial Details Column */}
            <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-6 bg-[#13051c]">
              <div>
                {/* Header Tag */}
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/30 text-[10px] font-bold text-pink-300 uppercase tracking-wider mb-4">
                  <Quote className="w-3 h-3 text-pink-400" />
                  <span>Verified Client Story</span>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-1.5 mb-3">
                  <div className="flex items-center text-[#FF007A]">
                    {[...Array(review.rating || 5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#FF007A]" />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-gray-200">
                    5.0 • {review.date}
                  </span>
                </div>

                {/* Quote Body */}
                <div className="relative">
                  <p className="text-sm sm:text-base text-gray-200 leading-relaxed font-normal italic">
                    &ldquo;{review.comment}&rdquo;
                  </p>
                </div>

                {/* Author Card */}
                <div className="mt-6 pt-5 border-t border-white/10 flex items-center gap-3.5">
                  <img
                    src={review.avatarUrl}
                    alt={review.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover border-2 border-pink-500/40 shadow-md"
                  />
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span>{review.name}</span>
                      {review.verified && (
                        <CheckCircle className="w-3.5 h-3.5 text-pink-400 shrink-0" />
                      )}
                    </div>
                    <div className="text-xs text-gray-400 mt-0.5">
                      {review.role} • <span className="text-pink-300 font-semibold">{review.company}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center gap-3">
                <a
                  href={buildWhatsAppUrl(
                    whatsappNumber,
                    getContextualWhatsAppMessage('reviews', { sourceSection: `Testimonial from ${review.name}` })
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    logWhatsAppInquiry(
                      'reviews',
                      { sourceSection: `Video Testimonial - ${review.name} (${review.company})` },
                      getContextualWhatsAppMessage('reviews', { sourceSection: `Testimonial from ${review.name}` })
                    );
                  }}
                  className="w-full sm:flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-full border border-[#25D366]/40 bg-[#0e2418]/90 hover:bg-[#133623] text-emerald-300 hover:text-white text-xs font-bold transition-all shadow-md group"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-[#25D366] group-hover:scale-110 transition-transform" />
                  <span>Discuss Similar Project</span>
                </a>

                {onBookShoot && (
                  <button
                    onClick={() => {
                      onClose();
                      onBookShoot();
                    }}
                    className="w-full sm:flex-1 btn-primary-gradient py-2.5 px-4 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-pink-600/30 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Book Discovery Call</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      )}
    </AnimatePresence>
  );
};

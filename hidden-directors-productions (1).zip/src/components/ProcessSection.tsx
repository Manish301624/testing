import React from 'react';
import { motion } from 'motion/react';
import { Compass, Lightbulb, Video, Sliders, CheckCircle2, ArrowRight } from 'lucide-react';

interface ProcessSectionProps {
  onOpenBooking: () => void;
}

export const ProcessSection: React.FC<ProcessSectionProps> = ({ onOpenBooking }) => {
  const steps = [
    {
      num: '01',
      title: 'Discovery & Creative Brief',
      desc: 'We analyze your brand DNA, target audience, aesthetic benchmarks, and exact content goals to build a razor-sharp shoot plan.',
      icon: Compass,
      tags: ['Brand Alignment', 'Audience Research', 'Goal Mapping']
    },
    {
      num: '02',
      title: 'Scripting & Moodboarding',
      desc: 'From hook writing and shot lists to lighting choreography and talent styling, every detail is engineered before rolling camera.',
      icon: Lightbulb,
      tags: ['Hook Engineering', 'Lighting Plot', 'Location Scouting']
    },
    {
      num: '03',
      title: 'Cinematic Production Shoot',
      desc: 'Our directors and DP arrive with cinema cameras (Sony FX/RED), Godox lighting, motion sliders, and pro sound gear.',
      icon: Video,
      tags: ['4K/6K Raw Capture', 'Studio Softboxes', 'Live Direction']
    },
    {
      num: '04',
      title: 'Post-Production & Polish',
      desc: 'Precision pacing, DaVinci Resolve color grading, custom sound effects (SFX), animated typography captions, and master delivery.',
      icon: Sliders,
      tags: ['DaVinci Color Grade', 'Dynamic Subtitles', 'Sound Design']
    }
  ];

  return (
    <section id="process" className="py-20 relative bg-[#09030e] border-t border-white/5 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.55, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center px-3.5 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-[11px] font-bold tracking-wider text-pink-300 uppercase mb-3">
            HOW WE OPERATE
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display">
            The Hidden Directors Standard
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-300">
            A frictionless, meticulously planned production workflow from raw concept to viral execution.
          </p>
        </motion.div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, idx) => {
            const IconComponent = step.icon;
            return (
              <motion.div
                key={step.num}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.5, delay: idx * 0.12, ease: [0.21, 0.45, 0.27, 0.9] }}
                whileHover={{ y: -4 }}
                className="relative rounded-2xl bg-[#12061b] border border-white/10 hover:border-pink-500/40 p-6 flex flex-col justify-between group transition-all"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-black text-pink-500/40 group-hover:text-pink-400 font-display transition-colors">
                      {step.num}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-pink-500/10 text-pink-400 flex items-center justify-center border border-pink-500/20 group-hover:scale-110 transition-transform">
                      <IconComponent className="w-5 h-5" />
                    </div>
                  </div>

                  <h3 className="text-lg font-bold text-white font-display group-hover:text-pink-100 transition-colors">
                    {step.title}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm text-gray-300 leading-relaxed">
                    {step.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/5 flex flex-wrap gap-1.5">
                  {step.tags.map((tag, i) => (
                    <span key={i} className="text-[10px] text-gray-400 bg-white/5 px-2 py-0.5 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Production CTA Banner */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.55, delay: 0.2, ease: [0.21, 0.45, 0.27, 0.9] }}
          className="mt-14 p-8 rounded-2xl bg-gradient-to-r from-[#1b0726] via-[#240a33] to-[#15061e] border border-pink-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl"
        >
          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
              Ready to elevate your brand&apos;s visual narrative?
            </h3>
            <p className="text-xs sm:text-sm text-gray-300 mt-1">
              Book a 15-minute consultation to discuss shot list, moodboard, and budget.
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.96 }}
            onClick={onOpenBooking}
            className="btn-primary-gradient px-8 py-3.5 rounded-full text-xs sm:text-sm font-bold tracking-wider text-white uppercase shadow-lg shadow-pink-600/30 whitespace-nowrap cursor-pointer"
          >
            SCHEDULE CALL NOW
          </motion.button>
        </motion.div>

      </div>
    </section>
  );
};

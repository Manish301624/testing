import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Play, 
  Pause, 
  ArrowUpRight, 
  TrendingUp, 
  Award, 
  CheckCircle2, 
  Sliders, 
  Eye, 
  X, 
  Calendar 
} from 'lucide-react';
import { FEATURED_CLIENT_BRANDS } from '../data/mockData';
import { ClientBrand } from '../types';

interface InfiniteLogoCarouselProps {
  /** Title or eyebrow headline */
  title?: string;
  subtitle?: string;
  /** Section style variant */
  variant?: 'hero' | 'stats' | 'testimonial' | 'compact';
  /** Direction of auto-scrolling */
  direction?: 'left' | 'right';
  /** Base speed duration in seconds */
  speedSeconds?: number;
  /** Callback when a brand is clicked or selected */
  onSelectBrand?: (brand: ClientBrand) => void;
  /** Callback to trigger consultation/booking */
  onOpenBooking?: () => void;
  /** Optional custom class name */
  className?: string;
  /** Whether to show the top social proof pill */
  showPill?: boolean;
}

export const InfiniteLogoCarousel: React.FC<InfiniteLogoCarouselProps> = ({
  title = 'TRUSTED BY LEADING FOUNDERS & GLOBAL LUXURY BRANDS',
  subtitle = 'From bespoke architecture to viral fashion drops, we direct high-converting visuals for category leaders.',
  variant = 'stats',
  direction = 'left',
  speedSeconds = 36,
  onSelectBrand,
  onOpenBooking,
  className = '',
  showPill = true
}) => {
  const [isPaused, setIsPaused] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [selectedBrandModal, setSelectedBrandModal] = useState<ClientBrand | null>(null);
  const [hoveredBrandId, setHoveredBrandId] = useState<string | null>(null);

  // Duplicated brands array to guarantee a seamless 50% translation loop
  const duplicatedBrands = [...FEATURED_CLIENT_BRANDS, ...FEATURED_CLIENT_BRANDS];

  const effectiveDuration = speedSeconds / speedMultiplier;

  const handleBrandClick = (brand: ClientBrand) => {
    setSelectedBrandModal(brand);
    if (onSelectBrand) {
      onSelectBrand(brand);
    }
  };

  return (
    <div 
      className={`relative w-full overflow-hidden ${className}`}
      id="infinite-logo-carousel"
    >
      {/* Header & Social Proof Eyebrow */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6 sm:mb-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            {showPill && (
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-pink-500/30 bg-pink-500/10 text-[10px] sm:text-[11px] font-bold tracking-widest text-pink-300 uppercase mb-2.5">
                <Sparkles className="w-3 h-3 text-[#FF007A]" />
                <span>VERIFIED BRAND CLIENTS</span>
                <span className="w-1 h-1 rounded-full bg-pink-400" />
                <span className="text-gray-300">50+ PRODUCTION RUNS</span>
              </div>
            )}
            
            <h3 className="text-lg sm:text-xl md:text-2xl font-black text-white font-display tracking-tight flex items-center gap-2">
              <span>{title}</span>
            </h3>

            {subtitle && (
              <p className="text-xs sm:text-sm text-gray-400 max-w-2xl mt-1 font-normal">
                {subtitle}
              </p>
            )}
          </div>

          {/* Interactive Carousel Controls (Play/Pause & Speed Multiplier) */}
          <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
            {/* Play/Pause Button */}
            <button
              id="carousel-pause-toggle-btn"
              onClick={() => setIsPaused(!isPaused)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all cursor-pointer ${
                isPaused 
                  ? 'border-pink-500/60 bg-pink-500/20 text-pink-300 shadow-[0_0_12px_rgba(255,0,122,0.3)]'
                  : 'border-white/10 bg-white/5 text-gray-400 hover:text-white hover:border-white/20'
              }`}
              title={isPaused ? 'Resume Auto-Scroll' : 'Pause Auto-Scroll'}
            >
              {isPaused ? (
                <>
                  <Play className="w-3 h-3 fill-current text-[#FF007A]" />
                  <span>Resume</span>
                </>
              ) : (
                <>
                  <Pause className="w-3 h-3 fill-current" />
                  <span>Pause</span>
                </>
              )}
            </button>

            {/* Speed Toggle Pills */}
            <div className="inline-flex items-center p-0.5 rounded-full bg-black/40 border border-white/10 text-[10px] font-mono">
              {[1, 1.5, 2].map((spd) => (
                <button
                  key={spd}
                  onClick={() => {
                    setSpeedMultiplier(spd);
                    if (isPaused) setIsPaused(false);
                  }}
                  className={`px-2 py-0.5 rounded-full transition-all cursor-pointer font-bold ${
                    speedMultiplier === spd && !isPaused
                      ? 'bg-gradient-to-r from-[#FF007A] to-[#FF5E62] text-white shadow-sm'
                      : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Infinite Scrolling Track Wrapper with Left & Right Gradient Shadows */}
      <div 
        className="relative w-full overflow-hidden group py-2"
        onMouseEnter={() => !isPaused && setHoveredBrandId('track')}
        onMouseLeave={() => setHoveredBrandId(null)}
      >
        {/* Left Gradient Edge Fade */}
        <div 
          className="pointer-events-none absolute inset-y-0 left-0 w-16 sm:w-32 md:w-48 bg-gradient-to-r from-[#09030e] via-[#09030e]/80 to-transparent z-20" 
          aria-hidden="true"
        />

        {/* Right Gradient Edge Fade */}
        <div 
          className="pointer-events-none absolute inset-y-0 right-0 w-16 sm:w-32 md:w-48 bg-gradient-to-l from-[#09030e] via-[#09030e]/80 to-transparent z-20" 
          aria-hidden="true"
        />

        {/* Continuous Marquee Ribbon */}
        <div
          className={`flex items-center gap-4 sm:gap-6 w-max will-change-transform ${
            direction === 'left' ? 'animate-infinite-marquee' : 'animate-infinite-marquee-reverse'
          } ${isPaused ? 'pause-marquee' : ''} hover-pause-marquee`}
          style={{
            animationDuration: `${effectiveDuration}s`
          }}
        >
          {duplicatedBrands.map((brand, index) => {
            const isItemHovered = hoveredBrandId === `${brand.id}-${index}`;

            return (
              <div
                key={`${brand.id}-${index}`}
                id={`brand-logo-card-${brand.id}-${index}`}
                onClick={() => handleBrandClick(brand)}
                onMouseEnter={() => setHoveredBrandId(`${brand.id}-${index}`)}
                onMouseLeave={() => setHoveredBrandId(null)}
                className="relative shrink-0 group/card cursor-pointer"
              >
                {/* Brand Card Surface */}
                <div 
                  className={`relative h-24 sm:h-28 w-56 sm:w-64 rounded-2xl bg-[#110519]/80 border p-3.5 sm:p-4 flex flex-col justify-between transition-all duration-300 backdrop-blur-md shadow-lg shadow-black/40 overflow-hidden ${
                    isItemHovered
                      ? 'border-pink-500/70 -translate-y-1 shadow-[0_8px_25px_rgba(255,0,122,0.25)]'
                      : 'border-white/10 hover:border-pink-500/40'
                  }`}
                >
                  {/* Ambient accent back-glow on hover */}
                  <div 
                    className="absolute -right-6 -bottom-6 w-24 h-24 rounded-full blur-2xl opacity-0 group-hover/card:opacity-30 transition-opacity duration-300 pointer-events-none"
                    style={{ backgroundColor: brand.accentColor || '#FF007A' }}
                  />

                  {/* Top Row: Industry Category & Badge */}
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-gray-400 font-mono tracking-wider uppercase truncate max-w-[120px]">
                      {brand.industry}
                    </span>
                    {brand.metric && (
                      <span 
                        className="font-mono font-bold text-[9px] px-2 py-0.5 rounded-full border tracking-tight"
                        style={{
                          backgroundColor: `${brand.accentColor || '#FF007A'}15`,
                          borderColor: `${brand.accentColor || '#FF007A'}40`,
                          color: brand.accentColor || '#FF007A'
                        }}
                      >
                        {brand.metric}
                      </span>
                    )}
                  </div>

                  {/* Center Brand Identity / Custom Monogram & Typographic Logo */}
                  <div className="my-auto py-1 flex items-center gap-2.5">
                    {/* Brand Icon or Monogram */}
                    <div 
                      className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center text-sm sm:text-base shrink-0 border border-white/10 group-hover/card:scale-105 transition-transform"
                      style={{
                        backgroundColor: `${brand.accentColor || '#FF007A'}15`
                      }}
                    >
                      {brand.icon || '✦'}
                    </div>

                    {/* Brand Name Typography */}
                    <div className="flex flex-col min-w-0">
                      <span className="text-sm sm:text-base font-extrabold text-white tracking-tight truncate group-hover/card:text-pink-200 transition-colors font-display">
                        {brand.name}
                      </span>
                      <span className="text-[10px] text-gray-400 truncate tracking-wide">
                        {brand.subtitle}
                      </span>
                    </div>
                  </div>

                  {/* Bottom Interactive Prompt / Campaign Deliverable */}
                  <div className="flex items-center justify-between pt-1.5 border-t border-white/5 text-[9px] text-gray-400">
                    <span className="truncate max-w-[170px] text-gray-400 group-hover/card:text-gray-300 transition-colors">
                      {brand.badge || 'Verified Client'}
                    </span>
                    <span className="flex items-center gap-0.5 text-pink-400 font-bold opacity-0 group-hover/card:opacity-100 transition-opacity">
                      <span>Story</span>
                      <ArrowUpRight className="w-2.5 h-2.5" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Brand Detail Modal (Opens when user clicks any brand card) */}
      <AnimatePresence>
        {selectedBrandModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ duration: 0.25, ease: [0.21, 0.45, 0.27, 0.9] }}
              className="relative w-full max-w-lg rounded-3xl bg-[#13051c] border border-pink-500/40 p-6 sm:p-8 shadow-2xl shadow-black overflow-hidden"
            >
              {/* Radial Glow */}
              <div 
                className="absolute -top-16 -right-16 w-48 h-48 rounded-full blur-3xl opacity-30 pointer-events-none"
                style={{ backgroundColor: selectedBrandModal.accentColor || '#FF007A' }}
              />

              {/* Close Button */}
              <button
                onClick={() => setSelectedBrandModal(null)}
                className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
                title="Close Modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Brand Header */}
              <div className="flex items-center gap-3.5 mb-5">
                <div 
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl border shadow-inner"
                  style={{
                    backgroundColor: `${selectedBrandModal.accentColor || '#FF007A'}20`,
                    borderColor: `${selectedBrandModal.accentColor || '#FF007A'}50`
                  }}
                >
                  {selectedBrandModal.icon || '✦'}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xl sm:text-2xl font-black text-white font-display">
                      {selectedBrandModal.name}
                    </h4>
                    <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      Verified
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 font-medium mt-0.5">
                    {selectedBrandModal.industry} • {selectedBrandModal.subtitle}
                  </p>
                </div>
              </div>

              {/* Campaign Highlights & Deliverables */}
              <div className="space-y-4 my-6">
                <div className="p-4 rounded-2xl bg-black/40 border border-white/10">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-gray-400 font-mono uppercase tracking-wider text-[10px]">
                      Delivered Campaign
                    </span>
                    <span 
                      className="font-bold font-mono text-[10px] px-2 py-0.5 rounded-full border"
                      style={{
                        backgroundColor: `${selectedBrandModal.accentColor || '#FF007A'}15`,
                        borderColor: `${selectedBrandModal.accentColor || '#FF007A'}40`,
                        color: selectedBrandModal.accentColor || '#FF007A'
                      }}
                    >
                      {selectedBrandModal.badge || 'Commercial Release'}
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-white">
                    {selectedBrandModal.featuredCampaign || 'Cinematic High-Impact Social & Commercial Series'}
                  </p>
                </div>

                {/* Performance Metric Stat */}
                {selectedBrandModal.metric && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-xl bg-white/5 border border-white/5">
                      <div className="flex items-center gap-1.5 text-xs text-gray-400 mb-1">
                        <TrendingUp className="w-3.5 h-3.5 text-pink-400" />
                        <span>Recorded Outcome</span>
                      </div>
                      <div className="text-lg font-black text-white font-display">
                        {selectedBrandModal.metric}
                      </div>
                    </div>
                    <div className="p-3.5 rounded-xl bg-white/5 border border-white/5">
                      <div className="flex items-center gap-1.5 text-xs text-gray-400 mb-1">
                        <Award className="w-3.5 h-3.5 text-pink-400" />
                        <span>Direction Style</span>
                      </div>
                      <div className="text-xs font-bold text-white font-mono mt-1">
                        4K Macro & Anamorphic
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  onClick={() => {
                    setSelectedBrandModal(null);
                    if (onOpenBooking) onOpenBooking();
                  }}
                  className="w-full sm:flex-1 py-3 px-5 rounded-full btn-primary-gradient text-white text-xs sm:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-pink-500/20 cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Book Similar Production</span>
                </button>
                <button
                  onClick={() => setSelectedBrandModal(null)}
                  className="w-full sm:w-auto py-3 px-5 rounded-full bg-white/10 hover:bg-white/15 text-gray-300 text-xs sm:text-sm font-bold tracking-wider uppercase transition-colors cursor-pointer"
                >
                  Back
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

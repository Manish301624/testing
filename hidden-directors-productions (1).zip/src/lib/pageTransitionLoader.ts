// PageTransitionLoader utility utilizing requestIdleCallback for optimized resource pre-fetching

const routeAssets: Record<string, string[]> = {
  '/': [
    'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1920&q=80',
    'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=80'
  ],
  '/about': [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=1200&q=80'
  ],
  '/photography': [
    'https://images.unsplash.com/photo-1542038784456-1ea8e935640e?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=1200&q=80'
  ],
  '/films': [
    'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80'
  ],
  '/blog': [
    'https://images.unsplash.com/photo-1512758017271-d7b84c2113f1?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80'
  ]
};

export function prefetchRouteAssets(pathname: string) {
  if (typeof window === 'undefined') return;

  // Determine base route if dynamic (e.g. /blog/1 -> /blog)
  let baseKey = pathname;
  if (pathname.startsWith('/blog/')) baseKey = '/blog';
  if (pathname.startsWith('/project/')) baseKey = '/films';

  const assets = routeAssets[baseKey] || routeAssets['/'];

  const executePrefetch = () => {
    // Prefetch critical images
    assets.forEach((url) => {
      const img = new Image();
      img.src = url;
    });

    // Also warm up font stylesheet preloading if not already cached
    const fontPreload = document.querySelector('link[href*="general-sans"]');
    if (!fontPreload) {
      const fontLink = document.createElement('link');
      fontLink.rel = 'stylesheet';
      fontLink.href = 'https://api.fontshare.com/v2/css?f[]=general-sans@500,600,700&display=swap';
      document.head.appendChild(fontLink);
    }
  };

  if ('requestIdleCallback' in window) {
    (window as any).requestIdleCallback(executePrefetch, { timeout: 1200 });
  } else {
    setTimeout(executePrefetch, 80);
  }
}

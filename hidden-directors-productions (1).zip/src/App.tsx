import React, { useState, useEffect, useCallback } from 'react';
import { motion, useScroll, useSpring, AnimatePresence } from 'motion/react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { AboutPage } from './components/AboutPage';
import { PhotographyGalleryPage } from './components/PhotographyGalleryPage';
import { FilmsShowcasePage } from './components/FilmsShowcasePage';
import { BlogPostPage } from './components/BlogPostPage';
import { BlogPage } from './components/BlogPage';
import { ProjectPage } from './components/ProjectPage';
import { PersonalBrandingPage } from './components/PersonalBrandingPage';
import { CinematicPageTransition } from './components/CinematicPageTransition';
import { Footer } from './components/Footer';
import { BookCallModal } from './components/BookCallModal';
import { InstantCallbackModal } from './components/InstantCallbackModal';
import { ReelModal } from './components/ReelModal';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { ChatWidget } from './components/ChatWidget';
import { WhatsAppButton } from './components/WhatsAppButton';
import { ScrollToTopButton } from './components/ScrollToTopButton';
import { AdminDrawer } from './components/AdminDrawer';
import { LoadingSpinner } from './components/LoadingSpinner';
import { CustomCursor } from './components/CustomCursor';
import { PageTransitionLoader } from './components/PageTransitionLoader';
import { INITIAL_REELS, PORTFOLIO_PROJECTS, CLIENT_REVIEWS, BLOG_POSTS, filterItemsByCategories } from './data/mockData';
import { ReelItem, ProjectItem, ReviewItem, BookingSubmission, BlogPost } from './types';
import { useTheme } from './context/ThemeContext';

export default function App() {
  const location = useLocation();
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { theme, toggleTheme } = useTheme();
  const [reels, setReels] = useState<ReelItem[]>(INITIAL_REELS);
  const [projects, setProjects] = useState<ProjectItem[]>(PORTFOLIO_PROJECTS);
  const [reviews, setReviews] = useState<ReviewItem[]>(CLIENT_REVIEWS);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(BLOG_POSTS);
  const [bookingCount, setBookingCount] = useState<number>(2);

  // Modal States
  const [isBookingOpen, setIsBookingOpen] = useState<boolean>(false);
  const [isCallbackOpen, setIsCallbackOpen] = useState<boolean>(false);
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [selectedReel, setSelectedReel] = useState<ReelItem | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  // Check URL params to open project case study from shared link
  useEffect(() => {
    if (typeof window !== 'undefined' && projects.length > 0) {
      try {
        const url = new URL(window.location.href);
        const projectId = url.searchParams.get('project');
        if (projectId) {
          const found = projects.find(p => p.id === projectId);
          if (found) {
            setSelectedProject(found);
            const el = document.getElementById('portfolio');
            if (el) {
              setTimeout(() => {
                el.scrollIntoView({ behavior: 'smooth' });
              }, 350);
            }
          }
        }
      } catch {
        // safe ignore
      }
    }
  }, [projects]);

  // Dynamic vertical scroll progress tracker
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  // Dynamic API fetching logic with category parameter injection
  const fetchBackendData = useCallback(async (customCategoryParams?: {
    category?: string | string[];
    reelCategory?: string | string[];
    projectCategory?: string | string[];
  }) => {
    try {
      const searchParams = new URLSearchParams(location.search);

      // Extract dynamic category parameters from URL query string or injected overrides
      const queryCategory = searchParams.get('category') || searchParams.get('categories') || undefined;
      const queryReelCategory = searchParams.get('reelCategory') || undefined;
      const queryProjectCategory = searchParams.get('projectCategory') || undefined;

      const activeGlobalCategory = customCategoryParams?.category ?? queryCategory;
      const activeReelCategory = customCategoryParams?.reelCategory ?? (queryReelCategory || activeGlobalCategory);
      const activeProjectCategory = customCategoryParams?.projectCategory ?? (queryProjectCategory || activeGlobalCategory);

      // Construct dynamic API query endpoints with parameter injection
      const buildCategoryQuery = (cat?: string | string[]) => {
        if (!cat || cat === 'all' || cat === 'All') return '';
        const serialized = Array.isArray(cat) ? cat.join(',') : cat;
        return `?category=${encodeURIComponent(serialized)}`;
      };

      const reelsUrl = `/api/reels${buildCategoryQuery(activeReelCategory)}`;
      const projectsUrl = `/api/projects${buildCategoryQuery(activeProjectCategory)}`;

      const [reelsRes, projectsRes, reviewsRes, bookingsRes, blogRes] = await Promise.all([
        fetch(reelsUrl),
        fetch(projectsUrl),
        fetch('/api/reviews'),
        fetch('/api/bookings'),
        fetch('/api/blog')
      ]);

      if (reelsRes.ok) {
        const reelsData = await reelsRes.json();
        if (Array.isArray(reelsData)) setReels(reelsData);
      }

      if (projectsRes.ok) {
        const projectsData = await projectsRes.json();
        if (Array.isArray(projectsData)) setProjects(projectsData);
      }

      if (reviewsRes.ok) {
        const reviewsData = await reviewsRes.json();
        if (reviewsData?.length) setReviews(reviewsData);
      }

      if (bookingsRes.ok) {
        const bookingsData = await bookingsRes.json();
        if (bookingsData?.length) setBookingCount(bookingsData.length);
      }

      if (blogRes.ok) {
        const blogData = await blogRes.json();
        if (blogData?.length) setBlogPosts(blogData);
      }
    } catch (err) {
      console.warn('API fetch defaulted to normalized seed fallback:', err);
      const searchParams = new URLSearchParams(location.search);
      const cat = customCategoryParams?.category || searchParams.get('category');
      if (cat) {
        setReels(filterItemsByCategories(INITIAL_REELS, cat));
        setProjects(filterItemsByCategories(PORTFOLIO_PROJECTS, cat));
      }
    } finally {
      setTimeout(() => {
        setIsLoading(false);
      }, 500);
    }
  }, [location.search]);

  // Initial and parameter-reactive fetch
  useEffect(() => {
    fetchBackendData();
  }, [fetchBackendData]);

  // Support dynamic category injection from global events
  useEffect(() => {
    const handleCategoryFilterEvent = (e: Event) => {
      const customEv = e as CustomEvent<{
        category?: string | string[];
        reelCategory?: string | string[];
        projectCategory?: string | string[];
      }>;
      if (customEv.detail) {
        fetchBackendData(customEv.detail);
      }
    };

    window.addEventListener('hd:category-filter', handleCategoryFilterEvent);
    return () => {
      window.removeEventListener('hd:category-filter', handleCategoryFilterEvent);
    };
  }, [fetchBackendData]);

  const handleBookingSuccess = (newBooking: BookingSubmission) => {
    setBookingCount(prev => prev + 1);
  };

  const handleAddReview = async (review: { name: string; role: string; company: string; rating: number; comment: string; videoUrl?: string }) => {
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(review)
      });
      const data = await res.json();
      if (data.review) {
        setReviews(prev => [data.review, ...prev]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const scrollToPortfolio = () => {
    const el = document.getElementById('portfolio');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToReviews = () => {
    const el = document.getElementById('reviews');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#09030e] text-[#F3F4F6] font-sans antialiased overflow-x-hidden selection:bg-[#FF007A] selection:text-white">
      {/* Slim, full-width top scroll progress bar */}
      <motion.div
        id="top-scroll-progress-bar"
        className="fixed top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#FF007A] via-[#FF2E93] to-[#FF5E62] z-[100] origin-left shadow-[0_0_10px_rgba(255,0,122,0.8)] pointer-events-none"
        style={{ scaleX }}
        aria-hidden="true"
      />

      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div
            key="global-loading-view"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <LoadingSpinner fullScreen message="INITIALIZING CINEMATIC EXPERIENCE" />
          </motion.div>
        ) : (
          <motion.div
            key="content-view"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
          >
            {/* Global / Baseline SEO Defaults */}
            <Helmet defaultTitle="Hidden Directors Productions | Cinematic Video Production Agency" titleTemplate="%s">
              <title>Hidden Directors Productions | Cinematic Video Production Agency</title>
              <meta name="description" content="High-end visual production agency creating brand films, commercials, interiors, fashion, and personal branding visuals that define your story." />
              <meta name="robots" content="index, follow" />
              <meta property="og:site_name" content="Hidden Directors Productions" />
              <meta property="og:locale" content="en_US" />
              <meta name="twitter:site" content="@hiddendirectors" />
              <meta name="twitter:creator" content="@hiddendirectors" />
              <meta name="theme-color" content="#FF007A" />
            </Helmet>

            {/* Top Fixed Navbar */}
            <Navbar
              onOpenBooking={() => setIsBookingOpen(true)}
              onOpenAdmin={() => setIsAdminOpen(true)}
              onOpenCallback={() => setIsCallbackOpen(true)}
              bookingCount={bookingCount}
              theme={theme}
              onToggleTheme={toggleTheme}
            />

            {/* Cinematic Animated View Routing */}
            <CinematicPageTransition>
              <PageTransitionLoader />
              <Routes location={location}>
                <Route
                  path="/"
                  element={
                    <HomePage
                      reels={reels}
                      projects={projects}
                      reviews={reviews}
                      blogPosts={blogPosts}
                      isLoading={isLoading}
                      onSelectReel={(reel) => setSelectedReel(reel)}
                      onSelectProject={(proj) => setSelectedProject(proj)}
                      onOpenBooking={() => setIsBookingOpen(true)}
                      onOpenCallback={() => setIsCallbackOpen(true)}
                      onAddReview={handleAddReview}
                      scrollToPortfolio={scrollToPortfolio}
                      scrollToReviews={scrollToReviews}
                    />
                  }
                />
                <Route
                  path="/blog"
                  element={
                    <BlogPage
                      posts={blogPosts}
                      onOpenBooking={() => setIsBookingOpen(true)}
                    />
                  }
                />
                <Route
                  path="/blog/:slug"
                  element={
                    <BlogPostPage
                      onOpenBooking={() => setIsBookingOpen(true)}
                    />
                  }
                />
                <Route
                  path="/project/:id"
                  element={
                    <ProjectPage
                      projects={projects}
                      onOpenBooking={() => setIsBookingOpen(true)}
                      onOpenCallback={() => setIsCallbackOpen(true)}
                    />
                  }
                />
                <Route
                  path="/projects/:id"
                  element={
                    <ProjectPage
                      projects={projects}
                      onOpenBooking={() => setIsBookingOpen(true)}
                      onOpenCallback={() => setIsCallbackOpen(true)}
                    />
                  }
                />
                <Route
                  path="/about"
                  element={
                    <AboutPage
                      onOpenBooking={() => setIsBookingOpen(true)}
                      onOpenCallback={() => setIsCallbackOpen(true)}
                      onSelectReel={(reel) => setSelectedReel(reel)}
                    />
                  }
                />
                <Route
                  path="/work/:category/photography"
                  element={
                    <PhotographyGalleryPage
                      onOpenBooking={() => setIsBookingOpen(true)}
                      onOpenCallback={() => setIsCallbackOpen(true)}
                    />
                  }
                />
                <Route
                  path="/work/:category/films"
                  element={
                    <FilmsShowcasePage
                      onOpenBooking={() => setIsBookingOpen(true)}
                      onOpenCallback={() => setIsCallbackOpen(true)}
                    />
                  }
                />
                <Route
                  path="/personal-branding"
                  element={
                    <PersonalBrandingPage
                      onOpenBooking={() => setIsBookingOpen(true)}
                    />
                  }
                />
                {/* Fallback to Home */}
                <Route
                  path="*"
                  element={
                    <HomePage
                      reels={reels}
                      projects={projects}
                      reviews={reviews}
                      blogPosts={blogPosts}
                      isLoading={isLoading}
                      onSelectReel={(reel) => setSelectedReel(reel)}
                      onSelectProject={(proj) => setSelectedProject(proj)}
                      onOpenBooking={() => setIsBookingOpen(true)}
                      onOpenCallback={() => setIsCallbackOpen(true)}
                      onAddReview={handleAddReview}
                      scrollToPortfolio={scrollToPortfolio}
                      scrollToReviews={scrollToReviews}
                    />
                  }
                />
              </Routes>
            </CinematicPageTransition>

            {/* Footer */}
            <Footer
              onOpenBooking={() => setIsBookingOpen(true)}
            />

            {/* Floating Context-Aware WhatsApp Button with soft pulse */}
            <WhatsAppButton />

            {/* Scroll-To-Top Floating Button */}
            <ScrollToTopButton />

            {/* Floating Chat Widget ("Chat with us 👋" & Assistant) */}
            <ChatWidget
              onOpenBooking={() => setIsBookingOpen(true)}
              onExploreWork={scrollToPortfolio}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Interactive Consultation Booking Modal */}
      <BookCallModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        onBookingSuccess={handleBookingSuccess}
      />

      {/* Instant 15-Minute Callback Request Modal */}
      <InstantCallbackModal
        isOpen={isCallbackOpen}
        onClose={() => setIsCallbackOpen(false)}
      />

      {/* Fullscreen Video Reel Player Lightbox */}
      <ReelModal
        reel={selectedReel}
        poster={selectedReel?.posterUrl}
        onClose={() => setSelectedReel(null)}
        onBookShoot={() => setIsBookingOpen(true)}
      />

      {/* Project Case Study Modal */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onBookShoot={() => setIsBookingOpen(true)}
      />

      {/* Studio Leads & Inquiries Dashboard */}
      <AdminDrawer
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
      />

      {/* Global Page Cursor */}
      <CustomCursor />

    </div>
  );
}

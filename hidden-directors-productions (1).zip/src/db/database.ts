import fs from 'fs';
import path from 'path';
import { BookingSubmission, ContactMessage, ReviewItem, CallbackRequest, WhatsAppInquiry } from '../types';
import { CLIENT_REVIEWS } from '../data/mockData';

export interface DatabaseSchema {
  bookings: BookingSubmission[];
  reviews: ReviewItem[];
  contactMessages: ContactMessage[];
  callbackRequests: CallbackRequest[];
  whatsappInquiries: WhatsAppInquiry[];
  metadata: {
    version: number;
    lastUpdated: string;
    createdAt: string;
  };
}

// Initial seed data
const INITIAL_BOOKINGS_SEED: BookingSubmission[] = [
  {
    id: 'BK-1001',
    fullName: 'Ananya Sharma',
    email: 'ananya@luxestudio.in',
    phone: '+91 98765 43210',
    companyName: 'Luxe Studio Delhi',
    serviceCategory: 'Personal Branding & Social Media',
    budgetRange: '$2,000 - $5,000',
    targetDate: '2026-09-15',
    projectDetails: 'Looking for a 15-reel batching package with studio lighting and teleprompter setup.',
    instagramHandle: '@ananyasharma_official',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    status: 'confirmed'
  },
  {
    id: 'BK-1002',
    fullName: 'Vikramaditya Roy',
    email: 'vikram@roystudios.com',
    phone: '+91 98111 22334',
    companyName: 'Roy Architecture & Interiors',
    serviceCategory: 'Interiors & Architectural Films',
    budgetRange: '$5,000 - $10,000',
    targetDate: '2026-09-22',
    projectDetails: '4-BHK penthouse walkthrough in Gurgaon. Need 4K master film + 8 social cutdowns.',
    instagramHandle: '@roy_architects',
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    status: 'pending'
  }
];

const INITIAL_CONTACT_SEED: ContactMessage[] = [
  {
    id: 'MSG-501',
    name: 'Kavita Chawla',
    email: 'kavita@cafeblend.in',
    phone: '+91 99999 88888',
    subject: 'New Café Launch Shoot in Connaught Place',
    message: 'We are launching our 2nd outlet next month and want to shoot food reels and ambience promos.',
    createdAt: new Date(Date.now() - 43200000).toISOString()
  }
];

const INITIAL_CALLBACKS_SEED: CallbackRequest[] = [
  {
    id: 'HD-CB-101',
    name: 'Kabir Malhotra',
    phone: '+91 98123 45678',
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    status: 'pending'
  }
];

const INITIAL_WHATSAPP_SEED: WhatsAppInquiry[] = [
  {
    id: 'HD-WA-1082',
    context: 'portfolio',
    sourceSection: 'Portfolio - Vilasita Designs',
    projectName: 'Vilasita Designs Interior Walkthrough',
    message: "Hi Hidden Directors! I was exploring your portfolio on the website and love the \"Vilasita Designs Interior Walkthrough\" case study. I'd like to discuss creating a similar cinematic visual project.",
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X)'
  },
  {
    id: 'HD-WA-1083',
    context: 'services',
    sourceSection: 'Services - Commercial Productions',
    serviceName: 'Commercial & Brand Films',
    message: "Hi Hidden Directors! I'm interested in your Commercial & Brand Films service and would like to know more about timelines, packages, and deliverables.",
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'
  }
];

export class JsonDatabase {
  private dbFilePath: string;
  private memoryData: DatabaseSchema;
  private isInitialized: boolean = false;

  constructor(filePath?: string) {
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      try {
        fs.mkdirSync(dataDir, { recursive: true });
      } catch (err) {
        console.error('Failed to create database directory:', err);
      }
    }
    this.dbFilePath = filePath || path.join(dataDir, 'production_studio.json');
    this.memoryData = this.loadOrInitialize();
    this.isInitialized = true;
  }

  /**
   * Load existing database file or initialize and seed on first run
   */
  private loadOrInitialize(): DatabaseSchema {
    try {
      if (fs.existsSync(this.dbFilePath)) {
        const fileContent = fs.readFileSync(this.dbFilePath, 'utf-8');
        if (fileContent.trim()) {
          const parsed = JSON.parse(fileContent) as DatabaseSchema;
          // Merge initial seed reviews with any existing/newly added reviews so updated properties (like videoUrl) are preserved
          const existingReviews = Array.isArray(parsed.reviews) ? parsed.reviews : [];
          const mergedReviews = CLIENT_REVIEWS.map(seedRev => {
            const existing = existingReviews.find(r => r.id === seedRev.id);
            return existing ? { ...seedRev, ...existing, videoUrl: existing.videoUrl || seedRev.videoUrl, videoPosterUrl: existing.videoPosterUrl || seedRev.videoPosterUrl, videoDuration: existing.videoDuration || seedRev.videoDuration } : seedRev;
          });
          // Also append any non-seed user-submitted reviews
          const customUserReviews = existingReviews.filter(r => !CLIENT_REVIEWS.some(sr => sr.id === r.id));

          return {
            bookings: Array.isArray(parsed.bookings) ? parsed.bookings : [...INITIAL_BOOKINGS_SEED],
            reviews: [...mergedReviews, ...customUserReviews],
            contactMessages: Array.isArray(parsed.contactMessages) ? parsed.contactMessages : [...INITIAL_CONTACT_SEED],
            callbackRequests: Array.isArray(parsed.callbackRequests) ? parsed.callbackRequests : [...INITIAL_CALLBACKS_SEED],
            whatsappInquiries: Array.isArray(parsed.whatsappInquiries) ? parsed.whatsappInquiries : [...INITIAL_WHATSAPP_SEED],
            metadata: parsed.metadata || {
              version: 1,
              lastUpdated: new Date().toISOString(),
              createdAt: new Date().toISOString()
            }
          };
        }
      }
    } catch (err) {
      console.warn('Error reading database file, creating fresh seeded instance:', err);
    }

    // Default Seed Data Schema
    const freshDb: DatabaseSchema = {
      bookings: [...INITIAL_BOOKINGS_SEED],
      reviews: [...CLIENT_REVIEWS],
      contactMessages: [...INITIAL_CONTACT_SEED],
      callbackRequests: [...INITIAL_CALLBACKS_SEED],
      whatsappInquiries: [...INITIAL_WHATSAPP_SEED],
      metadata: {
        version: 1,
        lastUpdated: new Date().toISOString(),
        createdAt: new Date().toISOString()
      }
    };

    this.persistToDisk(freshDb);
    console.log(`[Database] Initialized and seeded persistent storage at: ${this.dbFilePath}`);
    return freshDb;
  }

  /**
   * Atomic file persistence using temporary file rename to guard against corruption
   */
  private persistToDisk(data: DatabaseSchema): void {
    try {
      data.metadata.lastUpdated = new Date().toISOString();
      const serialized = JSON.stringify(data, null, 2);
      const tempPath = `${this.dbFilePath}.tmp`;
      fs.writeFileSync(tempPath, serialized, 'utf-8');
      fs.renameSync(tempPath, this.dbFilePath);
    } catch (err) {
      console.error('[Database] Failed to write database to disk:', err);
    }
  }

  // -------------------------------------------------------------
  // BOOKINGS TABLE METHODS
  // -------------------------------------------------------------
  public getBookings(): BookingSubmission[] {
    return [...this.memoryData.bookings];
  }

  public getBookingById(id: string): BookingSubmission | undefined {
    return this.memoryData.bookings.find(b => b.id === id);
  }

  public insertBooking(booking: BookingSubmission): BookingSubmission {
    this.memoryData.bookings.unshift(booking);
    this.persistToDisk(this.memoryData);
    return booking;
  }

  public updateBooking(id: string, updates: Partial<BookingSubmission>): BookingSubmission | null {
    const idx = this.memoryData.bookings.findIndex(b => b.id === id);
    if (idx === -1) return null;
    this.memoryData.bookings[idx] = { ...this.memoryData.bookings[idx], ...updates };
    this.persistToDisk(this.memoryData);
    return this.memoryData.bookings[idx];
  }

  public deleteBooking(id: string): boolean {
    const initialLen = this.memoryData.bookings.length;
    this.memoryData.bookings = this.memoryData.bookings.filter(b => b.id !== id);
    if (this.memoryData.bookings.length !== initialLen) {
      this.persistToDisk(this.memoryData);
      return true;
    }
    return false;
  }

  // -------------------------------------------------------------
  // REVIEWS TABLE METHODS
  // -------------------------------------------------------------
  public getReviews(): ReviewItem[] {
    return [...this.memoryData.reviews];
  }

  public insertReview(review: ReviewItem): ReviewItem {
    this.memoryData.reviews.unshift(review);
    this.persistToDisk(this.memoryData);
    return review;
  }

  // -------------------------------------------------------------
  // CONTACT MESSAGES TABLE METHODS
  // -------------------------------------------------------------
  public getContactMessages(): ContactMessage[] {
    return [...this.memoryData.contactMessages];
  }

  public insertContactMessage(message: ContactMessage): ContactMessage {
    this.memoryData.contactMessages.unshift(message);
    this.persistToDisk(this.memoryData);
    return message;
  }

  // -------------------------------------------------------------
  // CALLBACK REQUESTS TABLE METHODS
  // -------------------------------------------------------------
  public getCallbackRequests(): CallbackRequest[] {
    return [...this.memoryData.callbackRequests];
  }

  public insertCallbackRequest(request: CallbackRequest): CallbackRequest {
    this.memoryData.callbackRequests.unshift(request);
    this.persistToDisk(this.memoryData);
    return request;
  }

  public updateCallbackStatus(id: string, status: 'pending' | 'completed' | 'contacted'): CallbackRequest | null {
    const idx = this.memoryData.callbackRequests.findIndex(cb => cb.id === id);
    if (idx === -1) return null;
    this.memoryData.callbackRequests[idx].status = status;
    this.persistToDisk(this.memoryData);
    return this.memoryData.callbackRequests[idx];
  }

  // -------------------------------------------------------------
  // WHATSAPP INQUIRIES TABLE METHODS
  // -------------------------------------------------------------
  public getWhatsAppInquiries(): WhatsAppInquiry[] {
    return [...(this.memoryData.whatsappInquiries || [])];
  }

  public insertWhatsAppInquiry(inquiry: WhatsAppInquiry): WhatsAppInquiry {
    if (!this.memoryData.whatsappInquiries) {
      this.memoryData.whatsappInquiries = [];
    }
    this.memoryData.whatsappInquiries.unshift(inquiry);
    this.persistToDisk(this.memoryData);
    return inquiry;
  }

  // -------------------------------------------------------------
  // UTILITY & STATS
  // -------------------------------------------------------------
  public getStats() {
    return {
      totalBookings: this.memoryData.bookings.length,
      totalReviews: this.memoryData.reviews.length,
      totalMessages: this.memoryData.contactMessages.length,
      totalCallbacks: this.memoryData.callbackRequests.length,
      totalWhatsAppInquiries: (this.memoryData.whatsappInquiries || []).length,
      lastUpdated: this.memoryData.metadata.lastUpdated
    };
  }

  public isReady(): boolean {
    return this.isInitialized;
  }
}

// Global Singleton Database Instance
export const db = new JsonDatabase();

import path from 'path';
import fs from 'fs';
import { db, JsonDatabase } from './database';

export function initializeDatabase(forceReset: boolean = false): void {
  const dataDir = path.join(process.cwd(), 'data');
  const dbFile = path.join(dataDir, 'production_studio.json');

  if (forceReset && fs.existsSync(dbFile)) {
    try {
      fs.unlinkSync(dbFile);
      console.log('[DB Init] Removed existing database file for fresh reset.');
    } catch (err) {
      console.error('[DB Init] Error removing old database file:', err);
    }
  }

  // Creating instance triggers directory check, schema creation, and seeding
  const instance = new JsonDatabase();
  const stats = instance.getStats();
  console.log('[DB Init] Database initialized successfully:');
  console.log(` - Bookings: ${stats.totalBookings}`);
  console.log(` - Reviews: ${stats.totalReviews}`);
  console.log(` - Contact Messages: ${stats.totalMessages}`);
  console.log(` - Instant Callbacks: ${stats.totalCallbacks}`);
  console.log(` - File Location: ${dbFile}`);
}

// If executed directly
if (process.argv[1] && process.argv[1].includes('initDb')) {
  const force = process.argv.includes('--reset');
  initializeDatabase(force);
}

import nodemailer from 'nodemailer';
import { BookingSubmission, ContactMessage, CallbackRequest } from '../types';

/**
 * ============================================================================
 * HIDDEN DIRECTORS PRODUCTION HOUSE - EMAIL NOTIFICATION SERVICE
 * ============================================================================
 * Supports SMTP (Gmail, Resend, SendGrid, Amazon SES, Mailgun, Custom SMTP)
 * Automatically falls back to formatted console logging if SMTP is unconfigured.
 */

const STUDIO_EMAIL = (process.env.STUDIO_EMAIL || process.env.ADMIN_EMAIL || '0105amitky@gmail.com').trim();
const SMTP_HOST = process.env.SMTP_HOST || 'smtp.resend.com';
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '587', 10);
const SMTP_USER = process.env.SMTP_USER || 'resend';
const SMTP_PASS = process.env.SMTP_PASS || 're_Mrkkpasf_QKVfW9Bzr3qpKX2Nt3EQbBX4';
const SMTP_SECURE = process.env.SMTP_SECURE === 'true';
const SMTP_FROM = process.env.SMTP_FROM || 'Hidden Directors Productions <onboarding@resend.dev>';
const WHATSAPP_NUMBER = process.env.WHATSAPP_NUMBER || '+919876543210';

let transporter: nodemailer.Transporter | null = null;

// Initialize Transporter
function getTransporter(): nodemailer.Transporter | null {
  if (transporter) return transporter;

  if (SMTP_USER && SMTP_PASS) {
    try {
      transporter = nodemailer.createTransport({
        host: SMTP_HOST,
        port: SMTP_PORT,
        secure: SMTP_SECURE,
        auth: {
          user: SMTP_USER,
          pass: SMTP_PASS
        },
        tls: {
          rejectUnauthorized: false
        }
      });
      console.log(`[Email Service] Initialized SMTP Transporter via ${SMTP_HOST}:${SMTP_PORT} (${SMTP_USER})`);
    } catch (err) {
      console.error('[Email Service] Failed to initialize SMTP Transporter:', err);
    }
  } else {
    console.log('[Email Service] SMTP credentials not provided. Notifications will be logged in developer preview mode.');
  }

  return transporter;
}

/**
 * Common Dark / Neon Pink CSS Styles matching Hidden Directors Website
 */
const EMAIL_STYLES = `
  body { margin: 0; padding: 0; background-color: #09030e; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #ffffff; }
  .wrapper { width: 100%; max-width: 600px; margin: 0 auto; background-color: #110416; border-radius: 16px; overflow: hidden; border: 1px solid rgba(255, 0, 122, 0.25); }
  .header { background: linear-gradient(135deg, #1f0525 0%, #09030e 100%); padding: 32px 24px; text-align: center; border-bottom: 1px solid rgba(255, 255, 255, 0.08); }
  .logo-badge { display: inline-block; background: linear-gradient(135deg, #FF007A 0%, #FF5E62 100%); color: #ffffff; font-weight: 800; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; padding: 6px 14px; border-radius: 30px; margin-bottom: 12px; }
  .title { margin: 0 0 8px; font-size: 22px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px; }
  .subtitle { margin: 0; font-size: 13px; color: #a1a1aa; line-height: 1.5; }
  .content { padding: 28px 24px; }
  .card { background-color: #180720; border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 12px; padding: 20px; margin-bottom: 20px; }
  .card-title { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: #FF007A; margin: 0 0 14px; }
  .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.05); font-size: 13px; }
  .info-label { color: #888899; font-weight: 500; }
  .info-value { color: #ffffff; font-weight: 600; text-align: right; }
  .cta-btn { display: inline-block; background: linear-gradient(135deg, #FF007A 0%, #FF5E62 100%); color: #ffffff !important; text-decoration: none; font-weight: 700; font-size: 13px; padding: 14px 28px; border-radius: 10px; text-transform: uppercase; letter-spacing: 1px; text-align: center; }
  .wa-btn { display: inline-block; background-color: #25D366; color: #ffffff !important; text-decoration: none; font-weight: 700; font-size: 13px; padding: 12px 24px; border-radius: 10px; margin-top: 10px; }
  .footer { background-color: #0d0212; padding: 20px 24px; text-align: center; font-size: 11px; color: #666677; border-top: 1px solid rgba(255, 255, 255, 0.06); }
`;

/**
 * 1. SEND BOOKING CONFIRMATION TO CLIENT
 */
export async function sendBookingClientConfirmation(booking: BookingSubmission): Promise<boolean> {
  const cleanPhone = WHATSAPP_NUMBER.replace(/[^0-9]/g, '');
  const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(`Hi Hidden Directors, I booked a consultation for ${booking.serviceCategory} (Ref: ${booking.id}).`)}`;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Consultation Call Confirmed - Hidden Directors</title>
        <style>${EMAIL_STYLES}</style>
      </head>
      <body style="margin:0;padding:24px 10px;background-color:#09030e;">
        <div class="wrapper">
          <div class="header">
            <div class="logo-badge">HIDDEN DIRECTORS PRODUCTION</div>
            <h1 class="title">Consultation Call Confirmed 🎬</h1>
            <p class="subtitle">Thank you, ${booking.fullName}. Our creative director is reviewing your brief.</p>
          </div>

          <div class="content">
            <div class="card">
              <div class="card-title">Booking Details • ${booking.id}</div>
              <table width="100%" cellpadding="6" cellspacing="0" style="font-size: 13px; color: #ffffff;">
                <tr>
                  <td style="color: #999; width: 40%;">Client Name:</td>
                  <td style="font-weight: 700; text-align: right;">${booking.fullName}</td>
                </tr>
                <tr>
                  <td style="color: #999;">Company / Brand:</td>
                  <td style="font-weight: 700; text-align: right;">${booking.companyName || 'Confidential'}</td>
                </tr>
                <tr>
                  <td style="color: #999;">Service Category:</td>
                  <td style="font-weight: 700; text-align: right; color: #FF007A;">${booking.serviceCategory}</td>
                </tr>
                <tr>
                  <td style="color: #999;">Budget Range:</td>
                  <td style="font-weight: 700; text-align: right;">${booking.budgetRange || '$1,500 - $3,000'}</td>
                </tr>
                <tr>
                  <td style="color: #999;">Target Timeline:</td>
                  <td style="font-weight: 700; text-align: right;">${booking.targetDate || 'Upcoming'}</td>
                </tr>
                ${booking.instagramHandle ? `
                <tr>
                  <td style="color: #999;">Instagram / Handle:</td>
                  <td style="font-weight: 700; text-align: right; color: #ec4899;">@${booking.instagramHandle.replace('@', '')}</td>
                </tr>
                ` : ''}
              </table>
            </div>

            <div class="card" style="background-color: #120517; border-left: 3px solid #FF007A;">
              <div class="card-title" style="color: #ffffff; font-size: 13px;">What Happens Next?</div>
              <ol style="margin: 0; padding-left: 20px; font-size: 13px; color: #d1d5db; line-height: 1.6;">
                <li><strong>Vision Review:</strong> Our senior visual director is reviewing your concept notes and moodboard.</li>
                <li><strong>Director Outreach:</strong> We will connect within <strong>4 business hours</strong> via Phone/WhatsApp (${booking.phone}) with meeting calendar invites.</li>
                <li><strong>Custom Treatment:</strong> We'll prepare a preliminary deck and cinematic budget breakdown for our call.</li>
              </ol>
            </div>

            <div style="text-align: center; margin: 28px 0 10px;">
              <p style="font-size: 13px; color: #a1a1aa; margin-bottom: 14px;">Need instant fast-track coordination?</p>
              <a href="${waUrl}" class="wa-btn" target="_blank">Chat with Director on WhatsApp 💬</a>
            </div>
          </div>

          <div class="footer">
            <p style="margin: 0 0 6px;">Hidden Directors Visual Productions • Premium Ads, Music Videos & Brand Films</p>
            <p style="margin: 0;">Ref Code: ${booking.id} • Submitted at ${new Date(booking.createdAt || '').toLocaleString()}</p>
          </div>
        </div>
      </body>
    </html>
  `;

  return await sendEmailSafely({
    to: booking.email,
    subject: `🎬 Consultation Confirmed [${booking.id}] — Hidden Directors Production Studio`,
    html
  });
}

/**
 * 2. SEND NEW BOOKING NOTIFICATION TO STUDIO TEAM
 */
export async function sendBookingStudioNotification(booking: BookingSubmission): Promise<boolean> {
  const cleanPhone = (booking.phone || '').replace(/[^0-9]/g, '');
  const waDirectUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(`Hi ${booking.fullName}, this is the Director from Hidden Directors following up on your consultation request for ${booking.serviceCategory}.`)}`;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>${EMAIL_STYLES}</style>
      </head>
      <body style="margin:0;padding:24px 10px;background-color:#09030e;">
        <div class="wrapper" style="border-color: #FF007A;">
          <div class="header" style="background: linear-gradient(135deg, #38022a 0%, #110416 100%);">
            <div class="logo-badge" style="background: #FF007A;">NEW CLIENT LEAD 🔥</div>
            <h1 class="title">New Consultation Booked!</h1>
            <p class="subtitle">${booking.fullName} • ${booking.serviceCategory} • ${booking.budgetRange || '$1,500+'}</p>
          </div>

          <div class="content">
            <div class="card">
              <div class="card-title">Lead Contact & Scope (${booking.id})</div>
              <table width="100%" cellpadding="6" cellspacing="0" style="font-size: 13px; color: #ffffff;">
                <tr>
                  <td style="color: #888899; width: 35%;">Client Name:</td>
                  <td style="font-weight: 700; text-align: right;">${booking.fullName}</td>
                </tr>
                <tr>
                  <td style="color: #888899;">Email:</td>
                  <td style="font-weight: 700; text-align: right;"><a href="mailto:${booking.email}" style="color: #FF007A;">${booking.email}</a></td>
                </tr>
                <tr>
                  <td style="color: #888899;">Phone:</td>
                  <td style="font-weight: 700; text-align: right;"><a href="tel:${booking.phone}" style="color: #22d3ee;">${booking.phone}</a></td>
                </tr>
                <tr>
                  <td style="color: #888899;">Company / Brand:</td>
                  <td style="font-weight: 700; text-align: right;">${booking.companyName || 'Not specified'}</td>
                </tr>
                <tr>
                  <td style="color: #888899;">Category:</td>
                  <td style="font-weight: 700; text-align: right; color: #FF5E62;">${booking.serviceCategory}</td>
                </tr>
                <tr>
                  <td style="color: #888899;">Budget:</td>
                  <td style="font-weight: 700; text-align: right; color: #4ade80;">${booking.budgetRange || 'Default'}</td>
                </tr>
                <tr>
                  <td style="color: #888899;">Target Date:</td>
                  <td style="font-weight: 700; text-align: right;">${booking.targetDate || 'Not specified'}</td>
                </tr>
                ${booking.instagramHandle ? `
                <tr>
                  <td style="color: #888899;">Instagram:</td>
                  <td style="font-weight: 700; text-align: right; color: #f472b6;">@${booking.instagramHandle.replace('@', '')}</td>
                </tr>
                ` : ''}
              </table>
            </div>

            <div class="card">
              <div class="card-title">Project Details & Vision Brief</div>
              <p style="margin: 0; font-size: 13px; color: #e4e4e7; line-height: 1.6; white-space: pre-wrap;">${booking.projectDetails || 'No additional details provided.'}</p>
            </div>

            <div style="text-align: center; margin: 24px 0 10px;">
              <a href="${waDirectUrl}" class="wa-btn" target="_blank">Open WhatsApp Chat with ${booking.fullName} 💬</a>
            </div>
          </div>

          <div class="footer">
            <p style="margin: 0;">Hidden Directors Internal Leads Desk • Priority Follow-up Target: &lt; 4 Hours</p>
          </div>
        </div>
      </body>
    </html>
  `;

  return await sendEmailSafely({
    to: STUDIO_EMAIL,
    replyTo: booking.email,
    subject: `🔥 [NEW LEAD] ${booking.fullName} — ${booking.serviceCategory} (${booking.budgetRange || '$1,500+'})`,
    html
  });
}

/**
 * 3. SEND CONTACT MESSAGE NOTIFICATION & CLIENT RECEIPT
 */
export async function sendContactEmails(contact: ContactMessage): Promise<boolean> {
  // Studio Notification
  const studioHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>${EMAIL_STYLES}</style>
      </head>
      <body style="margin:0;padding:24px 10px;background-color:#09030e;">
        <div class="wrapper" style="border-color: #FF5E62;">
          <div class="header">
            <div class="logo-badge">NEW CONTACT MESSAGE 📩</div>
            <h1 class="title">${contact.subject || 'Website Inquiry'}</h1>
            <p class="subtitle">From: ${contact.name} (${contact.email})</p>
          </div>

          <div class="content">
            <div class="card">
              <div class="card-title">Sender Details</div>
              <p style="margin: 0 0 6px; font-size: 13px; color: #fff;"><strong>Name:</strong> ${contact.name}</p>
              <p style="margin: 0 0 6px; font-size: 13px; color: #fff;"><strong>Email:</strong> <a href="mailto:${contact.email}" style="color: #FF007A;">${contact.email}</a></p>
              ${contact.phone ? `<p style="margin: 0 0 6px; font-size: 13px; color: #fff;"><strong>Phone:</strong> <a href="tel:${contact.phone}" style="color: #22d3ee;">${contact.phone}</a></p>` : ''}
              <p style="margin: 0; font-size: 13px; color: #fff;"><strong>Subject:</strong> ${contact.subject || 'General Inquiry'}</p>
            </div>

            <div class="card">
              <div class="card-title">Message Body</div>
              <p style="margin: 0; font-size: 13px; color: #f4f4f5; line-height: 1.6; white-space: pre-wrap;">${contact.message}</p>
            </div>

            <div style="text-align: center; margin: 20px 0 10px;">
              <a href="mailto:${contact.email}?subject=Re: ${encodeURIComponent(contact.subject || 'Inquiry - Hidden Directors')}" class="cta-btn">Reply Directly via Email ✉️</a>
            </div>
          </div>

          <div class="footer">
            <p style="margin: 0;">Ref: ${contact.id} • Received ${new Date(contact.createdAt || '').toLocaleString()}</p>
          </div>
        </div>
      </body>
    </html>
  `;

  // Client Acknowledgment
  const clientHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>${EMAIL_STYLES}</style>
      </head>
      <body style="margin:0;padding:24px 10px;background-color:#09030e;">
        <div class="wrapper">
          <div class="header">
            <div class="logo-badge">HIDDEN DIRECTORS</div>
            <h1 class="title">Message Received 🎥</h1>
            <p class="subtitle">Hi ${contact.name}, thank you for reaching out to Hidden Directors.</p>
          </div>

          <div class="content">
            <p style="font-size: 13px; color: #d4d4d8; line-height: 1.6;">
              We have received your message regarding <strong>"${contact.subject || 'Your Production Inquiry'}"</strong>. Our production team will review your inquiry and get back to you shortly.
            </p>

            <div class="card" style="margin-top: 20px;">
              <div class="card-title">Copy of Your Message</div>
              <p style="margin: 0; font-size: 13px; color: #a1a1aa; line-height: 1.6; font-style: italic;">&ldquo;${contact.message}&rdquo;</p>
            </div>
          </div>

          <div class="footer">
            <p style="margin: 0 0 4px;">Hidden Directors Visual Productions</p>
            <p style="margin: 0;">Message ID: ${contact.id}</p>
          </div>
        </div>
      </body>
    </html>
  `;

  // Send both notifications
  const [studioResult, clientResult] = await Promise.all([
    sendEmailSafely({
      to: STUDIO_EMAIL,
      replyTo: contact.email,
      subject: `📩 [NEW INQUIRY] from ${contact.name}: "${contact.subject || 'General Inquiry'}"`,
      html: studioHtml
    }),
    sendEmailSafely({
      to: contact.email,
      subject: `🎥 Message Received — Hidden Directors Production Studio`,
      html: clientHtml
    })
  ]);

  return studioResult || clientResult;
}

/**
 * 4. SEND INSTANT CALLBACK REQUEST NOTIFICATION TO STUDIO
 */
export async function sendCallbackStudioNotification(callback: CallbackRequest): Promise<boolean> {
  const cleanPhone = callback.phone.replace(/[^0-9]/g, '');
  const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(`Hi ${callback.name}, this is the Director from Hidden Directors calling you back.`)}`;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>${EMAIL_STYLES}</style>
      </head>
      <body style="margin:0;padding:24px 10px;background-color:#09030e;">
        <div class="wrapper" style="border-color: #22d3ee;">
          <div class="header" style="background: linear-gradient(135deg, #022c36 0%, #110416 100%);">
            <div class="logo-badge" style="background: #06b6d4;">URGENT 15-MIN CALLBACK ⚡</div>
            <h1 class="title">Callback Requested!</h1>
            <p class="subtitle">${callback.name} requested an immediate phone call.</p>
          </div>

          <div class="content">
            <div class="card">
              <div class="card-title">Caller Details (${callback.id})</div>
              <table width="100%" cellpadding="6" cellspacing="0" style="font-size: 13px; color: #ffffff;">
                <tr>
                  <td style="color: #888899; width: 35%;">Client Name:</td>
                  <td style="font-weight: 700; text-align: right; font-size: 15px;">${callback.name}</td>
                </tr>
                <tr>
                  <td style="color: #888899;">Phone Number:</td>
                  <td style="font-weight: 700; text-align: right; font-size: 15px;"><a href="tel:${callback.phone}" style="color: #22d3ee;">${callback.phone}</a></td>
                </tr>
                <tr>
                  <td style="color: #888899;">Requested At:</td>
                  <td style="font-weight: 600; text-align: right; color: #e4e4e7;">${new Date(callback.createdAt).toLocaleTimeString()} (${new Date(callback.createdAt).toLocaleDateString()})</td>
                </tr>
                <tr>
                  <td style="color: #888899;">Status:</td>
                  <td style="font-weight: 700; text-align: right; color: #fbbf24;">Pending Call (&lt; 15 mins)</td>
                </tr>
              </table>
            </div>

            <div style="text-align: center; margin: 24px 0 10px;">
              <a href="tel:${callback.phone}" class="cta-btn" style="background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%);">📞 Call ${callback.name} Now</a>
              <br/>
              <a href="${waUrl}" class="wa-btn" target="_blank" style="margin-top: 12px;">Chat on WhatsApp 💬</a>
            </div>
          </div>

          <div class="footer">
            <p style="margin: 0;">Hidden Directors Instant Callback Dispatcher</p>
          </div>
        </div>
      </body>
    </html>
  `;

  return await sendEmailSafely({
    to: STUDIO_EMAIL,
    subject: `⚡ [URGENT CALLBACK - 15 MIN] ${callback.name} (${callback.phone})`,
    html
  });
}

/**
 * Robust Email Sender with Graceful Fallback & Error Handling
 */
async function sendEmailSafely(options: {
  to: string;
  subject: string;
  html: string;
  replyTo?: string;
}): Promise<boolean> {
  const mailer = getTransporter();

  // If SMTP is not configured, log to server console cleanly so workflow never breaks
  if (!mailer) {
    console.log(`\n================= [EMAIL NOTIFICATION PREVIEW] =================`);
    console.log(`TO: ${options.to}`);
    console.log(`SUBJECT: ${options.subject}`);
    if (options.replyTo) console.log(`REPLY-TO: ${options.replyTo}`);
    console.log(`STATUS: Logged safely (Configure SMTP_USER & SMTP_PASS in .env to send real emails).`);
    console.log(`=================================================================\n`);
    return true;
  }

  try {
    const info = await mailer.sendMail({
      from: SMTP_FROM,
      to: options.to,
      replyTo: options.replyTo || STUDIO_EMAIL,
      subject: options.subject,
      html: options.html
    });

    console.log(`[Email Service] Email sent successfully to ${options.to} (Message ID: ${info.messageId})`);
    return true;
  } catch (err) {
    console.error(`[Email Service] Error sending email to ${options.to}:`, err);
    // Return true/false but do not throw - ensure caller never breaks
    return false;
  }
}

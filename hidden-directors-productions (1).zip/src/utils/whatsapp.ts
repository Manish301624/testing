/**
 * WhatsApp integration utility for Hidden Directors Productions
 * Supports configurable WhatsApp number via environment variable WHATSAPP_NUMBER / VITE_WHATSAPP_NUMBER
 * and dynamic backend config endpoint /api/whatsapp-config.
 */

export const DEFAULT_WHATSAPP_NUMBER = '+919876543210';
export const DEFAULT_WHATSAPP_MESSAGE = "Hi, I'm interested in booking a shoot with Hidden Directors Productions";

export type WhatsAppContextType = 
  | 'general' 
  | 'hero' 
  | 'portfolio' 
  | 'services' 
  | 'process' 
  | 'reviews' 
  | 'faq' 
  | 'booking' 
  | 'callback'
  | 'reel';

export interface WhatsAppContextMetadata {
  projectName?: string;
  reelTitle?: string;
  serviceName?: string;
  bookingRef?: string;
  sourceSection?: string;
}

/**
 * Returns a context-aware pre-filled WhatsApp message based on where the user interacted.
 */
export function getContextualWhatsAppMessage(
  context: WhatsAppContextType = 'general',
  metadata?: WhatsAppContextMetadata
): string {
  switch (context) {
    case 'portfolio':
      if (metadata?.projectName) {
        return `Hi Hidden Directors! I was exploring your portfolio on the website and love the "${metadata.projectName}" case study. I'd like to discuss creating a similar cinematic visual project.`;
      }
      return "Hi Hidden Directors! I'm browsing your Selected Work portfolio and would love to inquire about producing a video project for our brand.";

    case 'services':
      if (metadata?.serviceName) {
        return `Hi Hidden Directors! I'm interested in your ${metadata.serviceName} service and would like to know more about timelines, packages, and deliverables.`;
      }
      return "Hi Hidden Directors! I was reviewing your creative and production services on the website and would love to discuss a potential shoot.";

    case 'process':
      return "Hi Hidden Directors! I checked out your 5-stage production roadmap (Script to Final Master) and want to consult on an upcoming shoot concept.";

    case 'reviews':
      return "Hi Hidden Directors! I saw the client testimonials and brand case studies on your site. We're looking for a production partner for an upcoming shoot.";

    case 'faq':
      return "Hi Hidden Directors! I had a quick question regarding shoot logistics, gear, locations, or turnaround timelines.";

    case 'booking':
      if (metadata?.bookingRef) {
        return `Hi Hidden Directors! I recently scheduled a consultation on your website (Ref: ${metadata.bookingRef}). I'd like to fast-track details and share our moodboard on WhatsApp.`;
      }
      return "Hi Hidden Directors! I'd like to inquire about booking a commercial / music video / brand shoot.";

    case 'callback':
      return "Hi Hidden Directors! I requested an instant 15-minute callback on your website and am following up here directly on WhatsApp.";

    case 'reel':
      if (metadata?.reelTitle) {
        return `Hi Hidden Directors! I just watched your reel "${metadata.reelTitle}" on the website and loved the visual direction. Can we discuss a project?`;
      }
      return "Hi Hidden Directors! I just checked out your featured vertical reels and want to inquire about creating viral video content for our brand.";

    case 'hero':
      return "Hi Hidden Directors! I'm visiting your website and want to quickly inquire about hiring your production crew for a shoot.";

    case 'general':
    default:
      if (metadata?.sourceSection) {
        return `Hi Hidden Directors! I'm inquiring from the ${metadata.sourceSection} section of your website regarding a video production.`;
      }
      return "Hi, I'm interested in booking a shoot with Hidden Directors Productions.";
  }
}

let cachedWhatsAppNumber: string | null = null;

/**
 * Strips all non-digit characters to conform to wa.me/<number> international specification
 */
export function cleanWhatsAppNumber(phone: string): string {
  if (!phone) return '';
  return phone.replace(/[^0-9]/g, '');
}

/**
 * Generates an official WhatsApp web/app direct chat URL with pre-filled message
 */
export function buildWhatsAppUrl(phoneNumber: string, prefilledMessage?: string): string {
  const cleanNumber = cleanWhatsAppNumber(phoneNumber || DEFAULT_WHATSAPP_NUMBER);
  const encodedText = prefilledMessage ? encodeURIComponent(prefilledMessage) : '';
  
  if (cleanNumber) {
    return `https://wa.me/${cleanNumber}${encodedText ? `?text=${encodedText}` : ''}`;
  }
  return `https://wa.me/?text=${encodedText}`;
}

/**
 * Automatically logs a WhatsApp inquiry / click to the backend endpoint /api/whatsapp-inquiry
 * for tracking lead activity in the internal dashboard.
 */
export async function logWhatsAppInquiry(
  context: WhatsAppContextType = 'general',
  metadata?: WhatsAppContextMetadata,
  prefilledMessage?: string,
  clientDetails?: { clientPhone?: string; clientName?: string }
): Promise<void> {
  try {
    const payload = {
      context,
      sourceSection: metadata?.sourceSection || `Section: ${context}`,
      projectName: metadata?.projectName,
      reelTitle: metadata?.reelTitle,
      serviceName: metadata?.serviceName,
      bookingRef: metadata?.bookingRef,
      message: prefilledMessage || getContextualWhatsAppMessage(context, metadata),
      clientPhone: clientDetails?.clientPhone,
      clientName: clientDetails?.clientName,
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : undefined
    };

    if (typeof fetch !== 'undefined') {
      fetch('/api/whatsapp-inquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        keepalive: true
      }).catch((err) => {
        console.debug('WhatsApp inquiry tracking note:', err);
      });
    }
  } catch (err) {
    // safe non-blocking log
  }
}

/**
 * Convenience helper to open WhatsApp chat with contextual message and automatic backend logging
 */
export function openWhatsAppWithContext(
  context: WhatsAppContextType = 'general',
  metadata?: WhatsAppContextMetadata,
  clientDetails?: { clientPhone?: string; clientName?: string }
): void {
  const number = getInitialWhatsAppNumber();
  const message = getContextualWhatsAppMessage(context, metadata);
  const url = buildWhatsAppUrl(number, message);

  // Automatically log click into backend analytics & leads desk
  logWhatsAppInquiry(context, metadata, message, clientDetails);

  if (typeof window !== 'undefined') {
    window.open(url, '_blank', 'noopener,noreferrer');
  }
}

/**
 * Fetches the active WhatsApp number from the backend config (/api/whatsapp-config)
 * with graceful fallback to client-side env variable or default production number.
 */
export async function fetchConfiguredWhatsAppNumber(): Promise<string> {
  if (cachedWhatsAppNumber) return cachedWhatsAppNumber;

  try {
    const res = await fetch('/api/whatsapp-config');
    if (res.ok) {
      const data = await res.json();
      if (data.whatsappNumber) {
        cachedWhatsAppNumber = data.whatsappNumber;
        return data.whatsappNumber;
      }
    }
  } catch (err) {
    // safe fallback to client env or default
  }

  const clientEnv = (import.meta as any).env?.VITE_WHATSAPP_NUMBER;
  cachedWhatsAppNumber = clientEnv || DEFAULT_WHATSAPP_NUMBER;
  return cachedWhatsAppNumber;
}

/**
 * Synchronous getter that returns current cached number or client environment fallback
 */
export function getInitialWhatsAppNumber(): string {
  if (cachedWhatsAppNumber) return cachedWhatsAppNumber;
  const clientEnv = (import.meta as any).env?.VITE_WHATSAPP_NUMBER;
  return clientEnv || DEFAULT_WHATSAPP_NUMBER;
}

import type { Variants, TargetAndTransition } from 'motion/react';

/**
 * Standardized Framer Motion animation variants for UI consistency 
 * across gallery and showcase pages in Hidden Directors Productions.
 */

// Container variant that orchestrates staggered entry of child elements
export const containerStagger: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.04
    }
  }
};

// Item variant for sequential staggered fade-in + micro slide-up
export const staggerFadeIn: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.16, 1, 0.3, 1]
    }
  }
};

// Smooth slide up for headers, cards, and modal elements
export const slideUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: [0.22, 1, 0.36, 1]
    }
  }
};

// Slide down variant for notification bars, banners, or top-down entries
export const slideDown: Variants = {
  hidden: { opacity: 0, y: -20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.22, 1, 0.36, 1]
    }
  }
};

// Pure opacity fade for overlays, subtle backgrounds, and backdrop scrims
export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      duration: 0.45,
      ease: [0.16, 1, 0.3, 1]
    }
  },
  exit: {
    opacity: 0,
    transition: {
      duration: 0.3,
      ease: [0.16, 1, 0.3, 1]
    }
  }
};

// Clean scale-in for modal dialogs, lightbox popups, and preview thumbnails
export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.45,
      ease: [0.16, 1, 0.3, 1]
    }
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: {
      duration: 0.3,
      ease: [0.16, 1, 0.3, 1]
    }
  }
};

// Interactive card hover target for video previews and photo cards
export const cardHover: TargetAndTransition = {
  y: -6,
  transition: { duration: 0.3, ease: [0.22, 1, 0.36, 1] }
};

// Cinematic backdrop blur-in variant for lightboxes and video modals
export const backdropBlurIn: Variants = {
  hidden: {
    opacity: 0,
    backdropFilter: 'blur(0px)'
  },
  visible: {
    opacity: 1,
    backdropFilter: 'blur(20px)',
    transition: {
      duration: 0.38,
      ease: [0.22, 1, 0.36, 1]
    }
  },
  exit: {
    opacity: 0,
    backdropFilter: 'blur(0px)',
    transition: {
      duration: 0.28,
      ease: [0.22, 1, 0.36, 1]
    }
  }
};

// Modal content entrance (spring-damped scale + subtle lift) accompanying backdrop blur
export const modalContentEntrance: Variants = {
  hidden: {
    opacity: 0,
    scale: 0.95,
    y: 18
  },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: {
      duration: 0.36,
      ease: [0.22, 1, 0.36, 1]
    }
  },
  exit: {
    opacity: 0,
    scale: 0.96,
    y: 12,
    transition: {
      duration: 0.24,
      ease: [0.22, 1, 0.36, 1]
    }
  }
};

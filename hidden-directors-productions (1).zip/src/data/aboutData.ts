export interface MilestoneItem {
  year: string;
  title: string;
  description: string;
  metric?: string;
}

export interface CapabilityCardItem {
  id: string;
  category: string;
  title: string;
  description: string;
  videoUrl: string;
  posterUrl: string;
  deliverables: string[];
  tag: string;
}

export interface BtsGalleryItem {
  id: string;
  title: string;
  caption: string;
  tag: string;
  mediaUrl: string;
  posterUrl: string;
  isVideo: boolean;
  aspect?: string;
}

export interface FounderInfo {
  name: string;
  title: string;
  role: string;
  photoUrl: string;
  quote: string;
  bio: string[];
  experienceYears: string;
  projectsDirected: string;
  socialLinks: {
    instagram: string;
    linkedin: string;
    email: string;
  };
}

export const ABOUT_SHOWREEL = {
  id: 'about-master-showreel',
  title: 'This Is How We Create',
  subtitle: 'Master Studio Showreel & Creative Range',
  description: 'A 35-second high-energy montage showcasing our cinematic visual range across architectural films, executive branding, macro product commercials, and luxury hospitality.',
  videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-minimalist-furniture-41484-large.mp4',
  posterUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1600&q=85',
  duration: '0:35',
  client: 'Hidden Directors Productions',
  category: 'Showreel',
  resolution: '4K DCI Cinema Master',
  likes: 4820,
  tags: ['#Showreel2026', '#CinemaProduction', '#VisualCraft']
};

export const STUDIO_STORY = {
  headline: 'We Don’t Just Record Frames. We Engineer Cultural Gravity.',
  paragraphs: [
    'Founded in 2018, Hidden Directors Productions was born out of a simple yet uncompromising realization: standard social video is forgettable. Brands and high-profile founders were settling for formulaic templates, sterile lighting, and robotic pacing that dissolved into the algorithmic noise.',
    'We built a boutique production house operating at the intersection of cinema-grade lens craft, meticulous lighting choreography, and modern short-form psychology. Every frame is calibrated for emotional resonance, tactile texture, and instant visual authority.',
    'From our dedicated studio spaces in Delhi and Mumbai to on-location sets across the globe, our team of directors, DPs, sound engineers, and DaVinci colorists treat every 15-second reel with the same surgical precision as a feature commercial.'
  ]
};

export const STUDIO_MILESTONES: MilestoneItem[] = [
  {
    year: '2018',
    title: 'Founded & First Daylight Studio',
    description: 'Launched our boutique production studio with a focus on luxury interior films and architectural storytelling.',
    metric: 'Studio Inception'
  },
  {
    year: '2020',
    title: '100+ Projects & Executive Branding',
    description: 'Pioneered batch-filming systems for venture-backed founders, creators, and luxury aesthetic clinics.',
    metric: '100+ Delivered'
  },
  {
    year: '2023',
    title: 'Opened Mumbai Cinema Hub',
    description: 'Expanded nationwide footprint with high-speed macro motion rigs and RED Digital Cinema camera packages.',
    metric: 'West Coast Studio'
  },
  {
    year: '2026',
    title: '500+ Projects & 50M+ Views',
    description: 'Recognized as the premier director-led visual studio with over 500 completed campaigns and 98% client retention.',
    metric: '500+ Delivered'
  }
];

export const CAPABILITIES_SHOWCASE: CapabilityCardItem[] = [
  {
    id: 'cap-interior',
    category: 'Interior & Architecture',
    title: 'Interior & Architecture Films',
    description: 'Atmospheric walkthroughs, bespoke lighting choreography, and texture-focused cinema motion for luxury spaces.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-minimalist-furniture-41484-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=800&q=80',
    deliverables: ['4K Master Walkthroughs', 'Vertical Cutdowns', 'Lighting Plots'],
    tag: 'Architectural'
  },
  {
    id: 'cap-branding',
    category: 'Personal Branding',
    title: 'Personal Branding Reels',
    description: 'Authority-building video batches for CEOs, founders, doctors, and thought leaders with pro teleprompter and sound design.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-set-of-plateaus-seen-from-the-sky-in-a-sunset-26070-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
    deliverables: ['15-Reel Monthly Batches', 'Hook Optimization', 'Dynamic Subtitles'],
    tag: 'Founder Authority'
  },
  {
    id: 'cap-product',
    category: 'Product & E-Commerce',
    title: 'Product & E-Commerce Films',
    description: 'High-speed macro capture, liquid splashes, rotational turntables, and luminous cosmetic bottle grading.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-40892-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80',
    deliverables: ['Macro 120fps Shots', 'Studio Turntable Loops', 'Color Matched Cuts'],
    tag: 'Macro Commercial'
  },
  {
    id: 'cap-hospitality',
    category: 'Hospitality & Food',
    title: 'Hospitality & Food Experiences',
    description: 'Mouthwatering culinary sizzles, sensory cocktail preparation, and immersive venue ambiance that drives bookings.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-bartender-stirring-a-cocktail-43301-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    deliverables: ['Sensory Food Reels', 'Chef & Mixology Profiles', 'Ambience Master'],
    tag: 'Culinary'
  },
  {
    id: 'cap-fashion',
    category: 'Fashion & Lifestyle',
    title: 'Fashion & Apparel Films',
    description: 'Stylized editorial pacing, rhythm-cut transitions, high-contrast strobe lighting, and haute couture lookbooks.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-fashion-model-posing-in-a-studio-with-red-lighting-41844-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80',
    deliverables: ['Editorial Lookbooks', 'High-Energy Music Cuts', 'Color-Graded Stills'],
    tag: 'Haute Couture'
  },
  {
    id: 'cap-commercial',
    category: 'Commercial Ads',
    title: 'Commercial Brand Ads',
    description: 'Full-scale narrative campaigns built for high ROAS on Meta, YouTube, and national broadcast networks.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-interior-of-a-luxurious-hotel-room-with-warm-lighting-42358-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=800&q=80',
    deliverables: ['Concept to Script', 'Full Production Crew', 'Multi-Format Deliverables'],
    tag: 'High-Impact Ads'
  }
];

export const BTS_GALLERY: BtsGalleryItem[] = [
  {
    id: 'bts-1',
    title: 'On Set: Karma Interiors Penthouse',
    caption: 'Rigging motorized slider tracks for 4K architectural reveal shots in Gurgaon.',
    tag: 'Cinematography',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-minimalist-furniture-41484-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=800&q=80',
    isVideo: true
  },
  {
    id: 'bts-2',
    title: 'Studio Lighting Setup: Founder Batch',
    caption: 'Aputure 600d with parabolic softboxes and rim hair-light for crisp executive presence.',
    tag: 'Lighting Design',
    mediaUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80',
    posterUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80',
    isVideo: false
  },
  {
    id: 'bts-3',
    title: 'Director Briefing Talent',
    caption: 'Fine-tuning vocal cadence, pacing, and eye-line before capturing key hook lines.',
    tag: 'Direction',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-bartender-stirring-a-cocktail-43301-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=800&q=80',
    isVideo: true
  },
  {
    id: 'bts-4',
    title: 'Color Suite & Master Grading',
    caption: 'Custom 3D LUT generation and node-based highlight balancing in DaVinci Resolve Studio.',
    tag: 'Post-Production',
    mediaUrl: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=800&q=80',
    posterUrl: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=800&q=80',
    isVideo: false
  },
  {
    id: 'bts-5',
    title: 'Macro Lens Rigging for Skincare',
    caption: 'Laowa 24mm probe lens calibrated for liquid droplet viscosity testing under high-speed strobe.',
    tag: 'Macro Rig',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-40892-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1533750349088-cd871a92f312?auto=format&fit=crop&w=800&q=80',
    isVideo: true
  }
];

export const FOUNDER_PROFILE: FounderInfo = {
  name: 'Aryan Varma',
  title: 'Founder & Creative Director',
  role: 'Director of Photography & Creative Lead',
  photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=85',
  quote: '“Great video is not about expensive cameras; it is about intentional rhythm, authentic human presence, and lighting that demands attention.”',
  bio: [
    'With over 8 years behind cinema viewfinders directing architectural showcases and high-conversion brand films, Aryan founded Hidden Directors with a single vision: bringing high-end cinematic craftsmanship to the fast-moving short-form landscape.',
    'Having directed 500+ commercial projects and executive branding campaigns across India, Dubai, and Singapore, Aryan personally oversees creative strategy, lighting choreography, and master color grading for every key production.'
  ],
  experienceYears: '8+ Years',
  projectsDirected: '500+',
  socialLinks: {
    instagram: 'https://instagram.com',
    linkedin: 'https://linkedin.com',
    email: 'mailto:contact@hiddendirectors.com'
  }
};

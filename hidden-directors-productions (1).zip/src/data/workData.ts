import { WorkPhotoItem, WorkFilmItem, WorkCategoryMeta } from '../types';

export const WORK_CATEGORIES_CONFIG: Record<string, WorkCategoryMeta> = {
  'interior-architecture': {
    slug: 'interior-architecture',
    name: 'Interior & Architecture',
    nameEs: 'Interiorismo y Arquitectura',
    shortDescEn: 'Architectural photography and cinematic spatial films capturing the texture, light geometry, and tactile luxury of modern spaces.',
    shortDescEs: 'Fotografía arquitectónica y películas espaciales cinematográficas que capturan la geometría de la luz, textura y lujo de espacios modernos.',
    photoHeroTitleEn: 'Interior & Architecture — Photography',
    photoHeroTitleEs: 'Interiorismo y Arquitectura — Fotografía',
    filmsHeroTitleEn: "Interior & Architecture — Film's",
    filmsHeroTitleEs: 'Interiorismo y Arquitectura — Películas',
  },
  'hospitality-food': {
    slug: 'hospitality-food',
    name: 'Hospitality & Food',
    nameEs: 'Hospitalidad y Gastronomía',
    shortDescEn: 'Sensory restaurant films, master chef spotlights, and editorial cocktail and culinary photography for premier dining destinations.',
    shortDescEs: 'Películas sensoriales de restaurantes, perfiles de chefs y fotografía editorial culinaria para destinos gastronómicos de primer nivel.',
    photoHeroTitleEn: 'Hospitality & Food — Photography',
    photoHeroTitleEs: 'Hospitalidad y Gastronomía — Fotografía',
    filmsHeroTitleEn: "Hospitality & Food — Film's",
    filmsHeroTitleEs: 'Hospitalidad y Gastronomía — Películas',
  },
  'ecommerce-product': {
    slug: 'ecommerce-product',
    name: 'E-commerce & Product',
    nameEs: 'E-commerce y Producto',
    shortDescEn: 'High-speed macro cinematography and minimalist studio lookbooks engineered to drive high-converting digital campaigns.',
    shortDescEs: 'Cinematografía macro de alta velocidad y lookbooks de estudio minimalistas diseñados para campañas de alta conversión.',
    photoHeroTitleEn: 'E-commerce & Product — Photography',
    photoHeroTitleEs: 'E-commerce y Producto — Fotografía',
    filmsHeroTitleEn: "E-commerce & Product — Film's",
    filmsHeroTitleEs: 'E-commerce y Producto — Películas',
  },
  'personal-branding': {
    slug: 'personal-branding',
    name: 'Personal Branding',
    nameEs: 'Marca Personal',
    shortDescEn: 'Documentary-style visionary profiles, keynote visuals, and executive portraits designed for founders, creators, and leaders.',
    shortDescEs: 'Perfiles documentales de visión, visuales de ponencias y retratos ejecutivos diseñados para fundadores, creadores y líderes.',
    photoHeroTitleEn: 'Personal Branding — Photography',
    photoHeroTitleEs: 'Marca Personal — Fotografía',
    filmsHeroTitleEn: "Personal Branding — Film's",
    filmsHeroTitleEs: 'Marca Personal — Películas',
  }
};

export const PHOTOGRAPHY_BY_CATEGORY: Record<string, WorkPhotoItem[]> = {
  'interior-architecture': [
    {
      id: 'photo-ia-01',
      title: 'Monolithic Brutalist Living Sanctuary',
      client: 'Vilasita Designs',
      type: 'residential',
      imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=85',
      aspectRatio: 'tall',
      location: 'Pedregal, Mexico City',
      description: 'Hand-troweled microcement walls harmonized with raw basalt stone and floor-to-ceiling daylight glazing.',
      camera: 'Sony A7R V • 24mm F1.4 GM',
      year: '2025'
    },
    {
      id: 'photo-ia-02',
      title: 'Minimalist White Oak Acoustic Suite',
      client: 'Karma Interiors',
      type: 'residential',
      imageUrl: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'wide',
      location: 'Polanco Residence',
      description: 'Curved acoustic timber battens with concealed 2700K warm LED linear accents and bespoke joinery.',
      camera: 'Hasselblad H6D-100c • 28mm',
      year: '2025'
    },
    {
      id: 'photo-ia-03',
      title: 'Atelier Pavilion Glasshouse & Pool',
      client: 'Studio Archetype',
      type: 'residential',
      imageUrl: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=85',
      aspectRatio: 'tall',
      location: 'Valle de Bravo',
      description: 'Seamless indoor-outdoor cantilevers reflected over a dark volcanic stone infinity swimming pool.',
      camera: 'Sony A7R V • TS-E 17mm F4',
      year: '2025'
    },
    {
      id: 'photo-ia-04',
      title: 'Linear Concrete Executive Headquarters',
      client: 'Aura Capital HQ',
      type: 'commercial',
      imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'square',
      location: 'Reforma Financial District',
      description: 'Board-formed exposed architectural concrete with brushed brass dividers and acoustic ceilings.',
      camera: 'Leica SL2-S • 21mm Super-Elmar',
      year: '2024'
    },
    {
      id: 'photo-ia-05',
      title: 'Calacatta Viola Marble Chef Kitchen',
      client: 'Maison K Modern',
      type: 'residential',
      imageUrl: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'wide',
      location: 'Lomas de Chapultepec',
      description: 'Bookmatched Calacatta Viola monolithic kitchen island flanked by brushed smoked glass cabinetry.',
      camera: 'Sony A7R V • 35mm F1.4 GM',
      year: '2025'
    },
    {
      id: 'photo-ia-06',
      title: 'Sanctuary Amber Spa Reception & Lounge',
      client: 'DIVA Luxury Lounge',
      type: 'hospitality',
      imageUrl: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'Santa Fe Luxury District',
      description: 'Atmospheric cove illumination creating diffuse ambient shadows across curved plaster partitions.',
      camera: 'Hasselblad 907X • 45mm',
      year: '2025'
    },
    {
      id: 'photo-ia-07',
      title: 'Boutique Heritage Hotel Courtyard & Terrace',
      client: 'Casa Celeste Boutique',
      type: 'hospitality',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'San Miguel de Allende',
      description: 'Warm quarry stone arches framed by native olive trees, custom bronze lanterns, and terracotta tiles.',
      camera: 'Sony A7R V • 24-70mm GM II',
      year: '2024'
    },
    {
      id: 'photo-ia-08',
      title: 'Geometric Cantilever Penthouse Master Suite',
      client: 'Skyline Residencies',
      type: 'commercial',
      imageUrl: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85',
      aspectRatio: 'wide',
      location: 'Bosques de las Lomas',
      description: 'Double-height panoramic glass corner overlooking the city canopy, furnished with curated Brazilian modernist seating.',
      camera: 'Leica SL2-S • 24-90mm Vario',
      year: '2025'
    },
    {
      id: 'photo-ia-09',
      title: 'Sculptural Spiral Staircase & Skylight',
      client: 'Studio Archetype',
      type: 'residential',
      imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'Coyoacán Modernist Villa',
      description: 'Continuous spiral cast-concrete stairwell illuminated by zenithal sunlight from an oculus roof lantern.',
      camera: 'Sony A7R V • 16-35mm GM II',
      year: '2025'
    },
    {
      id: 'photo-ia-10',
      title: 'Obsidian & Travertine Bath Pavilion',
      client: 'Karma Interiors',
      type: 'residential',
      imageUrl: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'square',
      location: 'Jardines del Pedregal',
      description: 'Free-standing matte volcanic stone soaking tub surrounded by fluted Roman travertine cladding.',
      camera: 'Hasselblad H6D-100c • 35mm',
      year: '2024'
    },
    {
      id: 'photo-ia-11',
      title: 'Contemporary Art Gallery & Exhibition Hall',
      client: 'Galería Lumina',
      type: 'commercial',
      imageUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'Colonia Roma Norte',
      description: 'Museum-grade magnetic spotlighting tracks accentuating large-scale minimalist canvases on 5-meter gallery walls.',
      camera: 'Sony A7R V • 50mm F1.2 GM',
      year: '2025'
    },
    {
      id: 'photo-ia-12',
      title: 'Terrace Sunset Pergola & Fire Feature',
      client: 'Vilasita Designs',
      type: 'hospitality',
      imageUrl: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=85',
      aspectRatio: 'wide',
      location: 'Punta Mita Oceanfront',
      description: 'Dark steel slatted pergola casting linear shadow rhythms across a custom gas fire pit and low teak loungers.',
      camera: 'Sony A7R V • 24mm F1.4 GM',
      year: '2025'
    }
  ],
  'hospitality-food': [
    {
      id: 'photo-hf-01',
      title: 'Wood-Fired Ember Plating & Macro Smoke',
      client: 'Fuego Bistro',
      type: 'hospitality',
      imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'Roma Norte, CDMX',
      description: 'High-contrast directional lighting on charred wagyu ribeye resting on rustic volcanic slate.',
      camera: 'Sony A7R V • 90mm Macro F2.8',
      year: '2025'
    },
    {
      id: 'photo-hf-02',
      title: 'Speakeasy Smoked Mezcal Cocktail',
      client: 'Nocturna Lounge',
      type: 'hospitality',
      imageUrl: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'wide',
      location: 'Juárez Nightlife Quarter',
      description: 'Atmospheric amber backlighting catching aromatic citrus mist and hand-cut crystalline ice blocks.',
      camera: 'Leica SL2-S • 50mm Summilux',
      year: '2025'
    },
    {
      id: 'photo-hf-03',
      title: 'Artisan Sourdough & Morning Daylight',
      client: 'Masa Madre Bakery',
      type: 'commercial',
      imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'square',
      location: 'Condesa Bakery',
      description: 'Morning side-light catching the golden crust blister and dusted flour textures of fresh rustic loaves.',
      camera: 'Sony A7R V • 50mm F1.2 GM',
      year: '2024'
    },
    {
      id: 'photo-hf-04',
      title: 'Omakase Nigiri Precision Counter',
      client: 'Komorebi Sushi',
      type: 'hospitality',
      imageUrl: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'Polanco Dining Corridor',
      description: 'Glazed bluefin toro over warm seasoned rice, brushed with aged nikiri soy sauce on dark ceramic.',
      camera: 'Sony A7R V • 90mm Macro F2.8',
      year: '2025'
    }
  ],
  'ecommerce-product': [
    {
      id: 'photo-ep-01',
      title: 'Botanical Face Serum Frosted Glass Drop',
      client: 'Aura Botanicals',
      type: 'commercial',
      imageUrl: 'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'Hidden Directors Studio A',
      description: 'Precision studio macro with dual rim lighting capturing liquid viscosity on amber glass dropper.',
      camera: 'Hasselblad H6D-100c • 120mm Macro',
      year: '2025'
    },
    {
      id: 'photo-ep-02',
      title: 'Minimalist Chronograph Brushed Titanium',
      client: 'NORD Timepieces',
      type: 'commercial',
      imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'wide',
      location: 'Studio B Tabletop',
      description: 'Polarized studio lighting revealing matte micro-bead blasted case and sapphire glass chamfer.',
      camera: 'Sony A7R V • 90mm Macro',
      year: '2025'
    },
    {
      id: 'photo-ep-03',
      title: 'Handcrafted Ceramic Vessel Collection',
      client: 'Barro Puro Ceramics',
      type: 'residential',
      imageUrl: 'https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?auto=format&fit=crop&w=1400&q=85',
      aspectRatio: 'tall',
      location: 'Studio A Natural Light Bay',
      description: 'Earthy matte clay textures styled against raw textured linen and soft diffused window glow.',
      camera: 'Leica SL2-S • 50mm Summicron',
      year: '2024'
    }
  ]
};

export const FILMS_BY_CATEGORY: Record<string, WorkFilmItem[]> = {
  'interior-architecture': [
    {
      id: 'film-ia-01',
      title: 'Minimalist Architecture & Joinery',
      client: 'Vilasita Designs',
      duration: '0:34',
      type: 'residential',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-minimalist-furniture-41484-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1200&q=80',
      briefText: 'Highlighting precision white oak joinery and concealed push-to-open mechanics in a high-end Polanco apartment using motorized slider motion control.',
      servicesProvided: [
        'RED Komodo-X 6K Cinema Camera',
        'Motorized Edelkrone Slider Pacing',
        'DaVinci Resolve HDR Color Mastering',
        'Bespoke Ambient Spatial Sound Design'
      ],
      aspectRatio: '16:9',
      resolution: '4K DCI Cinema (2160p)',
      director: 'Santiago Valdés',
      gearUsed: ['RED Komodo-X', 'Atlas Orion Anamorphic 40mm', 'Aputure 600d Pro'],
      year: '2025'
    },
    {
      id: 'film-ia-02',
      title: 'Karma Interiors Luxury Living Space',
      client: 'Karma Interiors',
      duration: '0:28',
      type: 'residential',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-living-room-with-furniture-and-decor-41482-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
      briefText: 'Capturing tactile contrasts between high-gloss black marble, soft textured boucle seating, and natural daylight transitioning to dusk ambient lighting.',
      servicesProvided: [
        'Sony FX6 Full-Frame Cinema Package',
        'DJI Ronin 4D Continuous Gimbal',
        'Aputure Wireless App Lighting Control',
        'Original Soundtrack Composition'
      ],
      aspectRatio: '16:9',
      resolution: '4K ProRes 422 HQ',
      director: 'Elena Rostova',
      gearUsed: ['Sony FX6', 'Sony GM Primes (24mm, 50mm)', 'Nanlite Pavotube II'],
      year: '2025'
    },
    {
      id: 'film-ia-03',
      title: 'Sanctuary Amber Spa Experience',
      client: 'DIVA Luxury Lounge',
      duration: '0:32',
      type: 'hospitality',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-interior-of-a-luxurious-hotel-room-with-warm-lighting-42358-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80',
      briefText: 'A sensory journey through the spa sanctuary, designed to evoke tranquility through low-key warm amber lighting and slow cinematic tracking.',
      servicesProvided: [
        'RED V-Raptor 8K VV Cinema Rig',
        'Dedo Light Optical Focusing System',
        'Dolby 5.1 Atmospheric Soundscape',
        'Social Media Multi-Aspect Deliverables'
      ],
      aspectRatio: '16:9',
      resolution: '8K Master / 4K Deliverable',
      director: 'Santiago Valdés',
      gearUsed: ['RED V-Raptor', 'Leica R Vintage Cinema Primes', 'Amaran 300c'],
      year: '2025'
    },
    {
      id: 'film-ia-04',
      title: 'Modern Master Suite & Architectural Closet',
      client: 'FND Furniture Next Door',
      duration: '0:26',
      type: 'residential',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-interior-of-a-modern-and-elegant-bedroom-42426-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1558997519-83ea9252def8?auto=format&fit=crop&w=1200&q=80',
      briefText: 'Showcasing the intersection of bespoke Italian wardrobe architecture, fluted glass reflection, and velvet-lined jewelry drawers.',
      servicesProvided: [
        'Sony FX3 Cinema Rig with Gimbal Balance',
        'Macro Detail Lens Tracking',
        'Motion Graphics Overlay & Titles',
        'Social Cutdowns for Paid Ads'
      ],
      aspectRatio: '16:9',
      resolution: '4K UHD 60fps',
      director: 'Mateo Cárdenas',
      gearUsed: ['Sony FX3', 'Laowa 24mm Probe Lens', 'DJI RS3 Pro'],
      year: '2024'
    },
    {
      id: 'film-ia-05',
      title: 'Pacific Villa Infinity Pool & Cantilever',
      client: 'Studio Archetype',
      duration: '0:45',
      type: 'commercial',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-luxury-home-interior-with-pool-view-42418-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
      briefText: 'Drone master shots paired with low-angle slider movements illustrating the dramatic oceanfront cliffside architecture of a modern vacation estate.',
      servicesProvided: [
        'DJI Inspire 3 Cinema Drone 8K',
        'FAA Certified Drone Flight Crew',
        'Color Match to Studio Cameras',
        'Executive Investor Presentation Cut'
      ],
      aspectRatio: '16:9',
      resolution: '8K CinemaDNG to 4K Master',
      director: 'Santiago Valdés',
      gearUsed: ['DJI Inspire 3', 'Zenmuse X9-8K Air', 'Sony FX6 Ground Rig'],
      year: '2025'
    },
    {
      id: 'film-ia-06',
      title: 'Architectural Blueprint to Physical Form',
      client: 'Aura Capital HQ',
      duration: '0:38',
      type: 'commercial',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-architect-working-on-building-project-plans-40898-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
      briefText: 'Documentary brand film tracking the transformation from initial drafting blueprints to the physical pouring of architectural concrete.',
      servicesProvided: [
        'Documentary Cinematography',
        'Architect Interviews with Lav Mic Audio',
        'Fast-Paced Rhythmic Industrial Editing',
        'Film Grain & Film Emulation Grade'
      ],
      aspectRatio: '16:9',
      resolution: '4K DCI Cinema',
      director: 'Elena Rostova',
      gearUsed: ['RED Komodo-X', 'Canon K35 Vintage Primes', 'Sound Devices 833'],
      year: '2025'
    }
  ],
  'hospitality-food': [
    {
      id: 'film-hf-01',
      title: 'Sensory Culinary Alchemy & Coffee',
      client: 'Cafe Hawkers',
      duration: '0:22',
      type: 'hospitality',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-coffee-cup-on-a-table-in-a-cafe-41486-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=80',
      briefText: 'Fast-paced rhythmic morning cafe ambience with espresso extraction micro-shots and warm morning daylight.',
      servicesProvided: [
        'High-Speed 120fps Macro Cinematography',
        'Sensory Sound Design (Steam, Pour, Grind)',
        'Instagram 9:16 & Reels Adaptation',
        'DaVinci Resolve Golden Hour Color'
      ],
      aspectRatio: '16:9',
      resolution: '4K 120fps',
      director: 'Mateo Cárdenas',
      gearUsed: ['Sony FX6', 'Sony 90mm Macro', 'Aputure 300d II'],
      year: '2025'
    }
  ],
  'ecommerce-product': [
    {
      id: 'film-ep-01',
      title: 'Hydra-Boost Dropper Commercial',
      client: 'Ate Skincare',
      duration: '0:18',
      type: 'commercial',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-40892-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=1200&q=80',
      briefText: 'High-speed macro commercial revealing hydration formula droplet surface tension and luxurious skin absorption.',
      servicesProvided: [
        'Phantom Flex4K Slow-Motion Capture',
        'Liquid Splash Rig Engineering',
        'Commercial Beauty Grade in ACEScc',
        'D2C Social Ad Variances (1:1, 9:16, 16:9)'
      ],
      aspectRatio: '16:9',
      resolution: '4K Ultra High-Speed',
      director: 'Santiago Valdés',
      gearUsed: ['Phantom Flex4K', 'Master Macro 100mm', 'Broncolor Strobe Lighting'],
      year: '2025'
    }
  ]
};

export function getPhotographyByCategory(categorySlug: string): WorkPhotoItem[] {
  const normalized = categorySlug.toLowerCase().trim();
  return PHOTOGRAPHY_BY_CATEGORY[normalized] || [];
}

export function getFilmsByCategory(categorySlug: string): WorkFilmItem[] {
  const normalized = categorySlug.toLowerCase().trim();
  return FILMS_BY_CATEGORY[normalized] || [];
}

export function getCategoryMeta(categorySlug: string): WorkCategoryMeta {
  const normalized = categorySlug.toLowerCase().trim();
  if (WORK_CATEGORIES_CONFIG[normalized]) {
    return WORK_CATEGORIES_CONFIG[normalized];
  }

  // Fallback if custom slug is entered
  const formattedName = normalized
    .split('-')
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

  return {
    slug: normalized,
    name: formattedName,
    nameEs: formattedName,
    shortDescEn: `Exclusive cinematic works and luxury visuals in ${formattedName}.`,
    shortDescEs: `Trabajos cinematográficos exclusivos y visuales de lujo en ${formattedName}.`,
    photoHeroTitleEn: `${formattedName} — Photography`,
    photoHeroTitleEs: `${formattedName} — Fotografía`,
    filmsHeroTitleEn: `${formattedName} — Film's`,
    filmsHeroTitleEs: `${formattedName} — Películas`,
  };
}

import { ReelItem, ProjectItem, ReviewItem, ServiceOffer, BlogPost, ClientBrand, CategoryTaxonomy, NormalizedData } from '../types';

// Normalized Category Taxonomy for Reels
export const REEL_TAXONOMY: CategoryTaxonomy[] = [
  { id: 'cat-interior', name: 'Interior & Architecture', slug: 'interior', color: '#10B981', description: 'Architectural joinery, lighting & living spaces' },
  { id: 'cat-salon', name: 'Salon & Spa Sanctuary', slug: 'salon', color: '#F59E0B', description: 'Wellness retreats, aesthetics & amber lounges' },
  { id: 'cat-product', name: 'Product Commercials', slug: 'product', color: '#38BDF8', description: 'High-speed macro cinematography & consumer goods' },
  { id: 'cat-fashion', name: 'Fashion & Lookbooks', slug: 'fashion', color: '#EC4899', description: 'High-contrast editorial & apparel motion' },
  { id: 'cat-branding', name: 'Brand Storytelling', slug: 'branding', color: '#8B5CF6', description: 'Narrative films & corporate prestige' },
  { id: 'cat-commercial', name: 'Commercial & Advertising', slug: 'commercial', color: '#FF007A', description: 'High-impact promotional media & broadcast ads' }
];

// High quality video loops and posters with normalized multi-category classification
export const INITIAL_REELS: ReelItem[] = [
  {
    id: 'reel-1',
    title: 'Minimalist Architecture & Joinery',
    category: 'interior',
    categories: ['interior', 'commercial', 'branding'],
    client: 'Vilasita Designs',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-minimalist-furniture-41484-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=800&q=80',
    description: 'Precision motion control showcase of custom-crafted white oak joinery and smooth push-to-open drawer mechanisms.',
    duration: '0:18',
    resolution: '4K UHD (2160p)',
    clientType: 'Luxury Architecture',
    likes: 1240,
    tags: ['#InteriorDesign', '#LuxuryJoinery', '#ArchitecturalVideo'],
    captions: 'Smooth gliding push-to-open drawers crafted with perfection.'
  },
  {
    id: 'reel-2',
    title: 'Sanctuary Amber Spa Experience',
    category: 'salon',
    categories: ['salon', 'branding', 'commercial'],
    client: 'DIVA Luxury Lounge',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-interior-of-a-luxurious-hotel-room-with-warm-lighting-42358-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80',
    description: 'Moody architectural lighting and calming atmosphere created for upscale wellness sanctuary and aesthetic lounge.',
    duration: '0:24',
    resolution: '4K DCI Cinema',
    clientType: 'Wellness & Spa Lounge',
    likes: 2890,
    tags: ['#SpaAesthetics', '#AtmosphericLighting', '#BrandVisuals'],
    captions: 'Step into serenity. Crafted ambient cinematography.'
  },
  {
    id: 'reel-3',
    title: 'Karma Interiors Luxury Living',
    category: 'interior',
    categories: ['interior', 'branding'],
    client: 'Karma Interiors',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-living-room-with-furniture-and-decor-41482-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80',
    description: 'Reflective black marble coffee tables, curated sculptural ceramics, and bespoke modern living aesthetics.',
    duration: '0:22',
    resolution: '4K ProRes HDR',
    clientType: 'High-End Residential',
    likes: 1950,
    tags: ['#KarmaInteriors', '#MarbleDesign', '#HomeCinema'],
    captions: 'Reflective details & tactile materials captured in 4K.'
  },
  {
    id: 'reel-4',
    title: 'Hydra-Boost Dropper Commercial',
    category: 'product',
    categories: ['product', 'commercial', 'branding'],
    client: 'Ate Skincare',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-40892-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=800&q=80',
    description: 'High-speed macro cinematography highlighting active serum droplet viscosity and radiant skin application.',
    duration: '0:15',
    resolution: '4K 120fps Macro',
    clientType: 'Cosmetics & Skincare',
    likes: 4120,
    tags: ['#ProductCinematography', '#SkincareCommercial', '#MacroShoot'],
    captions: 'AND EFFECTIVE TAKE FEW DROPS OF radiant glow.'
  },
  {
    id: 'reel-5',
    title: 'Oversized Streetwear Lookbook',
    category: 'fashion',
    categories: ['fashion', 'commercial', 'branding'],
    client: 'NewMe Apparel',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-woman-posing-for-a-fashion-photoshoot-42416-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
    description: 'Studio editorial with high-contrast strobe lighting, wide-leg denim silhouette, and confident personal presence.',
    duration: '0:20',
    resolution: '4K 60fps Studio',
    clientType: 'Streetwear & Apparel',
    likes: 3670,
    tags: ['#FashionEditorial', '#StreetStyle', '#StudioShoot'],
    captions: 'Bold silhouettes, tailored light, unapologetic attitude.'
  },
  {
    id: 'reel-6',
    title: 'Bespoke Wardrobe Architecture',
    category: 'interior',
    categories: ['interior', 'product', 'commercial'],
    client: 'FND Furniture Next Door',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-interior-of-a-modern-and-elegant-bedroom-42426-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1558997519-83ea9252def8?auto=format&fit=crop&w=800&q=80',
    description: 'Sage green arched acoustic panels and fluted glass luxury wardrobe installation with integrated lighting.',
    duration: '0:28',
    resolution: '4K Ultra HD',
    clientType: 'Bespoke Joinery & Living',
    likes: 5400,
    tags: ['#FNDFurniture', '#LuxuryCloset', '#ArchitectureReel'],
    captions: 'Why Work with mediocre visuals? Upgrade your brand presence.'
  }
];

export const CLIENT_LOGOS = [
  { name: 'Cafe Hawkers', subtitle: 'Hospitality & Dining', iconText: '☕ Cafe Hawkers' },
  { name: 'Vilasita Designs', subtitle: 'Luxury Architecture', iconText: 'Vilasita DESIGNS' },
  { name: 'DIVA', subtitle: 'Aesthetics & Wellness', iconText: 'DIVA' },
  { name: 'FND Furniture Next Door', subtitle: 'Modern Furniture', iconText: '🪑 FND FURNITURE NEXT DOOR' },
  { name: 'ate', subtitle: 'Beauty & Skincare', iconText: 'ate' },
  { name: 'NEW ME', subtitle: 'Fashion & Streetwear', iconText: '🦎 NEW ME' }
];

export const FEATURED_CLIENT_BRANDS: ClientBrand[] = [
  {
    id: 'brand-cafe-hawkers',
    name: 'Cafe Hawkers',
    subtitle: 'Urban Gastronomy & Specialty Brews',
    industry: 'Hospitality & Dining',
    badge: 'Viral Dining Series',
    metric: '1.2M+ Views',
    accentColor: '#10B981',
    icon: '☕',
    featuredCampaign: 'Cinematic Food & Beverage Short-Form Series'
  },
  {
    id: 'brand-vilasita',
    name: 'Vilasita Designs',
    subtitle: 'Bespoke Spatial Architecture',
    industry: 'Luxury Architecture',
    badge: 'Architectural Films',
    metric: '+340% Inquiries',
    accentColor: '#F472B6',
    icon: '🏛️',
    featuredCampaign: 'High-End Minimalist Villa Motion Series'
  },
  {
    id: 'brand-diva',
    name: 'DIVA Salon & Spa',
    subtitle: 'High-End Aesthetic Sanctuary',
    industry: 'Aesthetics & Wellness',
    badge: 'Luxury Wellness',
    metric: '2.4M Campaign Reach',
    accentColor: '#FF007A',
    icon: '✨',
    featuredCampaign: 'Sensory Spa Ambience & Treatment Commercials'
  },
  {
    id: 'brand-fnd',
    name: 'FND Furniture',
    subtitle: 'Bespoke Architectural Living',
    industry: 'Contemporary Living',
    badge: 'Craftsmanship Series',
    metric: '5.4K Engagement',
    accentColor: '#F59E0B',
    icon: '🪑',
    featuredCampaign: 'Precision Joinery & Custom Walk-In Closets'
  },
  {
    id: 'brand-ate',
    name: 'ate Beauty',
    subtitle: 'Dermatological Clean Formulations',
    industry: 'Clean Skincare',
    badge: 'Macro Commercial',
    metric: '3.4x ROAS on Ads',
    accentColor: '#C084FC',
    icon: '💧',
    featuredCampaign: 'Macro Droplet & Texture High-Speed Lighting'
  },
  {
    id: 'brand-newme',
    name: 'NEW ME',
    subtitle: 'Urban Gen-Z Apparel Drops',
    industry: 'Fashion & Streetwear',
    badge: 'Viral Lookbook',
    metric: '2.1M Impressions',
    accentColor: '#34D399',
    icon: '🦎',
    featuredCampaign: 'Fast-Paced Kinetic Streetwear Campaign'
  },
  {
    id: 'brand-aura',
    name: 'Aura Botanics',
    subtitle: 'Cold-Pressed Sensory Elixirs',
    industry: 'Botanical Wellness',
    badge: 'Brand Identity Film',
    metric: '+410% Recall',
    accentColor: '#A78BFA',
    icon: '🌿',
    featuredCampaign: 'Organic Botanical Origin Cinematic Vignettes'
  },
  {
    id: 'brand-solis',
    name: 'Solis Architecture',
    subtitle: 'Modernist Coastal Private Estates',
    industry: 'Ultra-Luxury Estates',
    badge: 'Spatial Film',
    metric: '$14M Estate Sold',
    accentColor: '#FBBF24',
    icon: '📐',
    featuredCampaign: 'Anamorphic Sunset Aerials & Spatial Flow'
  },
  {
    id: 'brand-kroma',
    name: 'Kroma Optics',
    subtitle: 'Anamorphic Glass Systems',
    industry: 'Cinema Hardware',
    badge: 'Hardware Tech Reel',
    metric: 'Global Launch Feature',
    accentColor: '#38BDF8',
    icon: '🎥',
    featuredCampaign: 'Lens Flare & Precision Glass Showcase'
  },
  {
    id: 'brand-maisonv',
    name: 'Maison V',
    subtitle: 'Geneva Haute Horlogerie Atelier',
    industry: 'Heritage Luxury',
    badge: 'Atelier Mini-Doc',
    metric: '850K VIP Impressions',
    accentColor: '#E2E8F0',
    icon: '💎',
    featuredCampaign: 'Master Craftsman Macro Movement Film'
  },
  {
    id: 'brand-velvet-stone',
    name: 'Velvet & Stone',
    subtitle: 'Single-Origin Coffee Bar & Roastery',
    industry: 'Artisanal Roasters',
    badge: 'Sensory Roastery Doc',
    metric: '380K Views',
    accentColor: '#FB923C',
    icon: '☕',
    featuredCampaign: 'Beans-to-Cup Artisanal Slow-Mo Story'
  },
  {
    id: 'brand-lumina',
    name: 'Lumina Spatial',
    subtitle: 'Smart Interactive Ambient Living',
    industry: 'Spatial Tech',
    badge: 'Innovation Reel',
    metric: '4.9★ Client Rating',
    accentColor: '#E879F9',
    icon: '💡',
    featuredCampaign: 'Smart Home Spatial Ambience & Light Rhythms'
  }
];


export const SERVICE_OFFERS: ServiceOffer[] = [
  {
    id: 'personal-branding',
    badge: 'WHAT WE OFFER',
    title: 'Personal Branding & Social Media Presence',
    headline: 'Visuals that convert passive followers into loyal brand advocates.',
    paragraphs: [
      'You know you need to show up online but the real struggle is knowing how.',
      'What to post, how to present yourself, what direction to follow and how to stay consistent without feeling lost.',
      'That’s where we step in.',
      'We help you bring clarity to your personal presence.',
      'From understanding what you want to communicate, defining the right direction, shaping your ideas, scripting content, shooting with the right setup, editing thoughtfully and making sure everything shows up the way it should on social media.',
      'So instead of guessing or forcing content, your presence feels clear, confident and truly aligned with you.'
    ],
    features: [
      'High-end studio & on-location multi-cam shoots',
      'Scripting, tone-of-voice alignment & creative direction',
      'Reels, Shorts & TikTok optimized pacing (9:16 format)',
      'Professional color grading & dynamic captions',
      'Monthly content batching (15-30 ready-to-publish assets)'
    ],
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-photographer-taking-photos-of-a-model-in-a-studio-42417-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    stats: [
      { label: 'Avg. Reach Boost', value: '+340%' },
      { label: 'Shoots Delivered', value: '180+' },
      { label: 'Turnaround Time', value: '48-72 hrs' }
    ]
  },
  {
    id: 'commercial-product',
    badge: 'COMMERCIAL CINEMATOGRAPHY',
    title: 'Product & Commercial Advertising Films',
    headline: 'Transform your product features into irresistible visual desires.',
    paragraphs: [
      'In a world of infinite scrolling, your product has less than 2 seconds to make an impression.',
      'We craft cinematic commercials that highlight texture, lighting, engineering, and emotional resonance.',
      'From luxury cosmetics to consumer tech and FMCG brands, we handle full lighting choreography, macro cinematography, and bespoke sound design.',
      'Every frame is engineered to elevate perceived value and accelerate buying decisions.'
    ],
    features: [
      'Motion-controlled turntable & macro camera rigs',
      'Studio lighting choreography (Godox, Aputure & Profoto)',
      'Dynamic stop-motion, fluid dynamics & droplet styling',
      'E-commerce PDP videos & high-converting Meta/TikTok ads'
    ],
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-40892-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1200&q=80',
    stats: [
      { label: 'ROAS Lift', value: '3.8x' },
      { label: 'Products Shot', value: '1,200+' },
      { label: 'Color Accuracy', value: '100%' }
    ]
  },
  {
    id: 'interior-hospitality',
    badge: 'SPACES & ARCHITECTURE',
    title: 'Interiors, Cafés & Architectural Films',
    headline: 'Immersive spatial storytelling for architects, cafés & luxury venues.',
    paragraphs: [
      'Architecture and interior design aren’t static—they are meant to be experienced through motion, sunlight shifts, and texture.',
      'We bring spaces to life with smooth stabilized gimbal movements, HDR ambient lighting, and rhythmically paced walkthroughs.',
      'Whether launching a flagship café in the heart of the city or documenting an award-winning residential villa, our films capture the true soul of your design.'
    ],
    features: [
      'Architectural perspective correction & ultra-wide cinema lenses',
      'Day-to-night lighting transitions & golden hour captures',
      'Social walkthrough reels + 4K full horizontal showcase films',
      'Ambient acoustic field recordings & bespoke sound scoring'
    ],
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-living-room-with-furniture-and-decor-41482-large.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80',
    stats: [
      { label: 'Venues Filmed', value: '250+' },
      { label: 'Footfall Impact', value: '+45%' },
      { label: 'Resolution', value: '6K RAW' }
    ]
  }
];

// Normalized Category Taxonomy for Projects
export const PROJECT_TAXONOMY: CategoryTaxonomy[] = [
  { id: 'pcat-interiors', name: 'Interiors', slug: 'interiors', color: '#10B981', description: 'Luxury architectural residences & bespoke joinery' },
  { id: 'pcat-hospitality', name: 'Cafés & Restaurants', slug: 'cafes-restaurants', color: '#F59E0B', description: 'Gastronomy, artisanal brews & twilight dining' },
  { id: 'pcat-fashion', name: 'Fashion & Lifestyle', slug: 'fashion-lifestyle', color: '#EC4899', description: 'Editorial fashion collections & lookbooks' },
  { id: 'pcat-commercial', name: 'Commercial / Ads', slug: 'commercial-ads', color: '#FF007A', description: 'Sensory macro commercials & performance ads' },
  { id: 'pcat-branding', name: 'Personal Branding', slug: 'personal-branding', color: '#8B5CF6', description: 'Executive thought-leadership & founder stories' }
];

export const PORTFOLIO_PROJECTS: ProjectItem[] = [
  {
    id: 'proj-1',
    title: 'Vilasita Modern Villa Tour',
    client: 'Vilasita Designs',
    category: 'Interiors',
    categories: ['Interiors', 'Commercial / Ads'],
    thumbnailUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-minimalist-furniture-41484-large.mp4',
    description: 'A 6,000 sq.ft contemporary sanctuary filmed with cinematic dolly tracks, spatial natural daylight shifts, and warm oak textures.',
    deliverables: ['1x 4K Master Film', '6x Social Reels', '25x Architectural Stills', 'HDR Color Grade'],
    year: '2025',
    views: '124K',
    briefText: 'Vilasita Designs needed a master architectural film for a flagship 6,000 sq.ft contemporary villa in South Delhi. The core challenge was capturing the subtle interplay between shifting natural sunlight, custom white oak joinery, and monolithic limestone without making the video feel static or like a typical walkthrough.',
    processSteps: [
      'Architectural Sun Mapping: Tracked natural solar arcs across all living areas to shoot key rooms during peak golden hour.',
      'Precision Motion Control: Employed motorized camera sliders and stabilized cinema dollies for graceful, parallax-rich perspective reveals.',
      'Atmospheric Sound Recording: Captured ambient room acoustics, natural breeze through terrace foliage, and tactile footsteps on terrazzo surfaces.',
      'Film Print Emulation: Mastered in DaVinci Resolve utilizing custom Kodak 2383 print curve with 1000-nit HDR highlights.'
    ],
    resultMetrics: [
      { label: 'Client Inquiries', value: '+240%', numValue: 240, prefix: '+', suffix: '%', subtext: 'High-net-worth villa design leads' },
      { label: 'Organic 4K Views', value: '1.2M', numValue: 1.2, prefix: '', suffix: 'M', subtext: 'Across Instagram Reels and YouTube' },
      { label: 'Viewer Retention', value: '88%', numValue: 88, prefix: '', suffix: '%', subtext: 'Top 2% benchmark in architectural media' },
      { label: 'Design Awards', value: '2 Wins', numValue: 2, prefix: '', suffix: ' Wins', subtext: 'Featured by ArchDaily and Dezeen' }
    ],
    clientQuote: {
      quote: 'Hidden Directors understood the poetry of our architecture from minute one. They didn’t just record rooms; they gave our villa an emotional soul. Two multi-crore villa projects signed with us directly after seeing this showcase.',
      author: 'Shreya Singhania',
      role: 'Principal Architect & Founder',
      company: 'Vilasita Designs',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80',
      rating: 5
    }
  },
  {
    id: 'proj-2',
    title: 'Artisan Brews & Twilight Moods',
    client: 'Cafe Hawkers',
    category: 'Cafés & Restaurants',
    categories: ['Cafés & Restaurants', 'Commercial / Ads', 'Fashion & Lifestyle'],
    thumbnailUrl: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1000&q=80',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-coffee-being-poured-into-a-cup-41134-large.mp4',
    description: 'High-energy dining visual experience capturing espresso extraction, sizzling sourdough pizzas, and cozy café vibes.',
    deliverables: ['4x Viral Reels', '1x Brand Commercial', 'TikTok Ad Bundle', 'ASMR Audio Suite'],
    year: '2025',
    views: '450K',
    briefText: 'Cafe Hawkers was expanding into evening cocktails and gourmet wood-fired sourdough pizzas. They required a high-velocity visual repositioning campaign to transition from a daytime café into Connaught Place’s top twilight dining hotspot.',
    processSteps: [
      'Sensory Food Cinematography: Shot 120fps ultra-macro sequences of cheese pulls, caramelizing sourdough, and espresso crema.',
      'Twilight Lighting Choreography: Balanced warm 2700K ambient tungsten with subtle magenta and cobalt edge lights.',
      'Rhythmic 3-Second Hooks: Structured rapid-fire visual edits synchronized to trending percussion soundtracks.',
      'Localized Distribution Cuts: Packaged 4 dedicated vertical formats tailored for Meta and Instagram localized ad campaigns.'
    ],
    resultMetrics: [
      { label: 'Weekend Footfall', value: '+65%', numValue: 65, prefix: '+', suffix: '%', subtext: 'Tables booked out 3 weeks in advance' },
      { label: 'Viral Impressions', value: '2.3M', numValue: 2.3, prefix: '', suffix: 'M', subtext: 'Total social reach in the launch month' },
      { label: 'Performance ROAS', value: '4.6x', numValue: 4.6, prefix: '', suffix: 'x', subtext: 'Meta ad spend return on dinner bookings' },
      { label: 'User Saves & Shares', value: '38K', numValue: 38, prefix: '', suffix: 'K', subtext: 'Direct audience bookmarking actions' }
    ],
    clientQuote: {
      quote: 'The food styling and kinetic camera motion completely set our social presence on fire. Our weekend waitlist doubled overnight, and customers constantly show our reels to order at the counter!',
      author: 'Aarav Mehta',
      role: 'Co-Founder & Creative Director',
      company: 'Cafe Hawkers',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      rating: 5
    }
  },
  {
    id: 'proj-3',
    title: 'Monochrome Luxe Fall Collection',
    client: 'NEW ME Apparel',
    category: 'Fashion & Lifestyle',
    categories: ['Fashion & Lifestyle', 'Commercial / Ads'],
    thumbnailUrl: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1000&q=80',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-woman-posing-for-a-fashion-photoshoot-42416-large.mp4',
    description: 'Studio campaign combining harsh key lighting and soft fill reflectors for high-end minimalist street fashion.',
    deliverables: ['Brand Hero Video', '10x Lookbook Reels', 'E-commerce Assets', 'Meta 9:16 Ad Cuts'],
    year: '2025',
    views: '890K',
    briefText: 'NEW ME required an ultra-slick, editorial studio campaign for their flagship fall collection. The objective was elevating brand perception into international streetwear status and driving immediate add-to-cart conversions on the mobile storefront.',
    processSteps: [
      'Dual Strobe Lighting Matrix: Built a specialized high-contrast key and rim lighting array to bring out heavy cotton weave and tailored stitching.',
      'Movement Direction: Choreographed fluid model motion and dramatic turns to emphasize drape and garment movement.',
      'Kinetic Editorial Editing: Designed match-cuts, whip zooms, and sound-punched transitions for high scroll-stopping power.',
      'Conversion-Optimized Output: Delivered 10 vertical lookbooks, 4 paid ad cutdowns, and animated homepage banner loops.'
    ],
    resultMetrics: [
      { label: 'Collection Sellout', value: '72h', numValue: 72, prefix: '', suffix: 'h', subtext: 'Full outerwear and denim drop sold out' },
      { label: 'Engagement Rate', value: '+180%', numValue: 180, prefix: '+', suffix: '%', subtext: 'Lift over previous quarter baseline' },
      { label: 'Campaign ROAS', value: '3.8x', numValue: 3.8, prefix: '', suffix: 'x', subtext: 'Blended return on paid Meta and TikTok ads' },
      { label: 'Unique Reach', value: '3.5M', numValue: 3.5, prefix: '', suffix: 'M', subtext: 'Young fashion shoppers reached' }
    ],
    clientQuote: {
      quote: 'Hidden Directors is by far the most creative and reliable production team we have partnered with. Their studio lighting and editing speed are unmatched, driving record-breaking collection sales.',
      author: 'Rohan Kapoor',
      role: 'Brand Lead',
      company: 'NEW ME',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      rating: 5
    }
  },
  {
    id: 'proj-4',
    title: 'Pure Hydration Droplet Film',
    client: 'ate Botanicals',
    category: 'Commercial / Ads',
    categories: ['Commercial / Ads', 'Fashion & Lifestyle'],
    thumbnailUrl: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=1000&q=80',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-40892-large.mp4',
    description: 'Macro liquid simulations and tactile product application with bespoke ASMR sound mixing.',
    deliverables: ['3x 15s Performance Ads', 'Hero Product Reel', 'Banner Cutdowns'],
    year: '2025',
    views: '310K',
    briefText: 'Highlight active serum droplet viscosity and deep hydration benefits through sensory, macro product cinematography for a premium D2C beauty brand.',
    processSteps: [
      'High-Speed Macro Rig: 120fps macro lens with robotic turntable for liquid droplet surface impacts.',
      'Color Fidelity Calibration: Exact PANTONE skincare formula color matching under CRI 98+ studio lights.',
      'Spatial ASMR Foley: Layered droplet splashes, glass pipettes, and velvety balm applications.'
    ],
    resultMetrics: [
      { label: 'Product Conversion', value: '+42%', numValue: 42, prefix: '+', suffix: '%', subtext: 'PDP video conversion increase' },
      { label: 'Video CTR', value: '4.8%', numValue: 4.8, prefix: '', suffix: '%', subtext: 'Meta performance ad click-through rate' },
      { label: 'Customer ROAS', value: '3.4x', numValue: 3.4, prefix: '', suffix: 'x', subtext: 'First 60 days ad campaign performance' }
    ]
  },
  {
    id: 'proj-5',
    title: 'Founder Series: Scaling with Clarity',
    client: 'Executive Personal Branding',
    category: 'Personal Branding',
    categories: ['Personal Branding', 'Commercial / Ads'],
    thumbnailUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1000&q=80',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-photographer-taking-photos-of-a-model-in-a-studio-42417-large.mp4',
    description: 'Executive speaking series and conversational micro-podcasts tailored for LinkedIn and Instagram thought leaders.',
    deliverables: ['12x Thought-Leadership Reels', 'YouTube Long-form Master', 'Audiogram Clips'],
    year: '2025',
    views: '620K',
    briefText: 'Position high-growth tech and design founders as authoritative industry voices with polished multi-camera episodic video series.',
    processSteps: [
      'Strategic Script Doctoring: Distilled complex founder insights into punchy 45-second value-packed storylines.',
      'Acoustic Multi-Cam Setup: Dual Sony FX3 cinema cameras with Sennheiser lavalier audio processing.',
      'Dynamic Typography: Custom kinetic captions with color-coded emphasis keywords.'
    ],
    resultMetrics: [
      { label: 'LinkedIn Reach', value: '+340%', numValue: 340, prefix: '+', suffix: '%', subtext: 'Profile views and newsletter subscribers' },
      { label: 'Speaking Inquiries', value: '18+', numValue: 18, prefix: '', suffix: '+', subtext: 'Keynote & podcast invitations generated' }
    ]
  },
  {
    id: 'proj-6',
    title: 'Modular Wardrobes & Living Concepts',
    client: 'FND Furniture Next Door',
    category: 'Interiors',
    categories: ['Interiors', 'Commercial / Ads'],
    thumbnailUrl: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1000&q=80',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-interior-of-a-modern-and-elegant-bedroom-42426-large.mp4',
    description: 'Showcasing luxury interior finishes, silent hardware hinges, and customized storage architectures.',
    deliverables: ['8x Architecture Reels', 'Website Header Film', 'Catalog Assets'],
    year: '2025',
    views: '280K'
  }
];

/**
 * Generic Normalization Factory Function
 * Indexes any collection into byId, allIds, and byCategory normalized structure
 */
export function normalizeCollection<T extends { id: string; category: string; categories?: string[] }>(
  items: T[]
): NormalizedData<T> {
  const byId: Record<string, T> = {};
  const allIds: string[] = [];
  const byCategory: Record<string, string[]> = {};

  for (const item of items) {
    byId[item.id] = item;
    allIds.push(item.id);

    const categoriesList = item.categories && item.categories.length > 0
      ? item.categories
      : [item.category];

    for (const cat of categoriesList) {
      const normalizedKey = cat.toLowerCase().trim();
      if (!byCategory[normalizedKey]) {
        byCategory[normalizedKey] = [];
      }
      if (!byCategory[normalizedKey].includes(item.id)) {
        byCategory[normalizedKey].push(item.id);
      }
    }
  }

  return { byId, allIds, byCategory };
}

/**
 * Filter items by single or multiple categories across primary and secondary categories
 */
export function filterItemsByCategories<T extends { category: string; categories?: string[] }>(
  items: T[],
  filters?: string | string[]
): T[] {
  if (!filters || filters === 'all' || (Array.isArray(filters) && filters.length === 0)) {
    return items;
  }

  const rawFilters = Array.isArray(filters) ? filters : filters.split(',');
  const normalizedFilters = rawFilters
    .map(f => f.trim().toLowerCase())
    .filter(f => f && f !== 'all');

  if (normalizedFilters.length === 0) return items;

  return items.filter(item => {
    const itemCategories = [
      item.category.toLowerCase().trim(),
      ...(item.categories || []).map(c => c.toLowerCase().trim())
    ];

    return normalizedFilters.some(filter =>
      itemCategories.some(cat => 
        cat === filter || cat.includes(filter) || filter.includes(cat)
      )
    );
  });
}

// Normalized Data Repositories for O(1) Lookups and Multi-Category Traversal
export const NORMALIZED_REELS: NormalizedData<ReelItem> = normalizeCollection<ReelItem>(INITIAL_REELS);
export const NORMALIZED_PROJECTS: NormalizedData<ProjectItem> = normalizeCollection<ProjectItem>(PORTFOLIO_PROJECTS);


export const CLIENT_REVIEWS: ReviewItem[] = [
  {
    id: 'rev-1',
    name: 'Aarav Mehta',
    role: 'Co-Founder & Creative Director',
    company: 'Cafe Hawkers',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'Hidden Directors transformed our brand perception overnight. The food and ambience reels reached over 450,000 local foodies, driving weekend queues out our front door!',
    date: '2 weeks ago',
    verified: true,
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-coffee-being-poured-into-a-cup-41134-large.mp4',
    videoPosterUrl: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=600&q=80',
    videoDuration: '0:28'
  },
  {
    id: 'rev-2',
    name: 'Shreya Singhania',
    role: 'Principal Architect',
    company: 'Vilasita Designs',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'Their understanding of light, symmetry, and architectural pacing is unmatched. They don’t just shoot video; they capture the true emotional soul of our interior projects.',
    date: '1 month ago',
    verified: true,
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-minimalist-furniture-41484-large.mp4',
    videoPosterUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
    videoDuration: '0:34'
  },
  {
    id: 'rev-3',
    name: 'Rohan Kapoor',
    role: 'Brand Lead',
    company: 'NEW ME',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'The fastest turnaround and best studio lighting we have experienced in the country. Our return on ad spend jumped from 1.9x to 3.8x within the first campaign.',
    date: '3 weeks ago',
    verified: true,
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-woman-posing-for-a-fashion-photoshoot-42416-large.mp4',
    videoPosterUrl: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=600&q=80',
    videoDuration: '0:22'
  },
  {
    id: 'rev-4',
    name: 'Tanya Verma',
    role: 'Founder & CEO',
    company: 'DIVA Aesthetics',
    avatarUrl: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'Personal branding was terrifying for me until Hidden Directors stepped in. They scripted, directed, and made me look confident on camera. A true game-changer.',
    date: 'Just now',
    verified: true
  },
  {
    id: 'rev-5',
    name: 'Kabir Malhotra',
    role: 'Managing Partner',
    company: 'Oberoi Modern Living',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'From script breakdown to 4K color delivery in 72 hours, the speed and cinematic standard were beyond our expectations. Our luxury catalog engagement surged by 210%.',
    date: '4 days ago',
    verified: true
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-1',
    slug: 'why-short-form-reels-outperform-traditional-commercials',
    title: 'Why 15-Second Cinematic Reels Outperform Traditional TV Commercials in 2026',
    excerpt: 'How micro-cinematography, 3-second visual hooks, and 9:16 mobile framing deliver 4x higher brand recall and direct conversion than legacy advertising.',
    coverImage: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1200&q=80',
    publishedDate: '2026-02-18',
    category: 'Production Strategy',
    readTime: '5 min read',
    tags: ['Reels', 'Commercials', 'Direct Response', 'Mobile Video'],
    author: {
      name: 'Aryan Saxena',
      role: 'Creative Director',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    },
    seo: {
      metaTitle: 'Why 15-Second Cinematic Reels Outperform TV Commercials | Hidden Directors',
      metaDescription: 'Discover why high-contrast, vertical 9:16 reels capture 4x more attention and revenue than traditional 30-second landscape commercials in 2026.',
      keywords: ['cinematic reels', 'short form video production', 'commercial video agency', 'brand films 2026']
    },
    content: `
# The Death of the 30-Second Commercial

For over six decades, the holy grail of advertising was the glossy 30-second horizontal television commercial. Brands would spend hundreds of thousands of dollars crafting a narrative that spent 20 seconds building tension, 5 seconds introducing the brand, and 5 seconds displaying a logo.

In 2026, that formula is fundamentally obsolete.

Consumer psychology has shifted. Attention is no longer granted by default; it must be won within the first **800 milliseconds** of playback. Today's consumer consumes visual content vertically, on OLED handheld screens with refresh rates up to 120Hz, demanding tactile speed and cinematic intensity.

---

## The Anatomy of a High-Converting Reel

When Hidden Directors produces a short-form commercial, we engineer every micro-second according to our **3-Phase Kinetic Framework**:

### 1. The 0-2 Second Kinetic Hook
We reject slow title cards and fade-ins. Instead, we open on extreme high-contrast movement:
- High-speed macro fluid splashes captured at 240fps.
- Immediate spatial camera whip pans that stop dead on the subject.
- Bold, unignorable physical sound design (tactile whooshes, sub-bass impacts).

> *"If you haven't delivered a visual revelation within the first 1.5 seconds, the viewer's thumb has already scrolled."*

### 2. Sensory Immersion (Seconds 3 to 10)
Rather than telling the viewer why a product or space is luxurious, we let the cinematography trigger sensory empathy:
- **For Hospitality & Cafés:** Steaming espresso extraction, knife gliding through crisp brioche, warm 2700K amber lighting.
- **For Architecture & Interiors:** Gliding motion-controlled slider shots highlighting marble veins, fluted wood, and architectural acoustics.
- **For E-commerce & Fashion:** 4K slow-motion fabric dynamics, bold backlight silhouettes, and rapid beat-matched jump cuts.

### 3. The Irresistible Call-to-Action (Seconds 11 to 15)
The conclusion is swift, confident, and direct. No corporate disclaimers. Just an unmissable brand badge and a singular, friction-free action.

---

## Why High-End Production Matters in Short Form

Many creators assume short-form content should look intentionally lo-fi or amateurish. While raw user-generated content has its place in casual reviews, **luxury brands, visionary founders, and premium spaces cannot afford to compromise on visual fidelity**.

When your brand presents razor-sharp anamorphic glass, professional three-point cinematic lighting, and custom spatial audio, you immediately establish category dominance over competitors shooting on smartphones.

### Key Takeaways
1. **Vertical-First Composition:** Frame for 9:16 from the viewfinder, not as an afterthought crop.
2. **Dynamic Soundscapes:** 50% of the emotional conversion happens in the audio mix.
3. **Pacing Over Duration:** A fast 12-second reel will generate 10x the repeat loop views of a drawn-out 45-second clip.
`
  },
  {
    id: 'post-2',
    slug: 'the-art-of-macro-lighting-for-skincare-and-luxury-products',
    title: 'The Science of Macro Cinematography: Lighting Luxury Droplets & Skincare Viscosity',
    excerpt: 'A breakdown of Phantom high-speed capture, polarized rim-lighting, and fluid density control that makes luxury products irresistible.',
    coverImage: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1200&q=80',
    publishedDate: '2026-02-10',
    category: 'Cinematography',
    readTime: '6 min read',
    tags: ['Macro', 'Lighting', 'Product Commercials', 'High-Speed'],
    author: {
      name: 'Devika Roy',
      role: 'Director of Photography',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80'
    },
    seo: {
      metaTitle: 'The Science of Macro Cinematography for Luxury Products | Hidden Directors',
      metaDescription: 'Explore how Hidden Directors captures high-speed serum droplets, cross-polarized glass lighting, and liquid textures in 4K resolution.',
      keywords: ['macro cinematography', 'product commercial shoot', 'skincare video production', 'high speed phantom camera']
    },
    content: `
# Capturing the Unseen Texture of Luxury

When dealing with premium beauty serums, botanical oils, or high-end cosmetic formulations, the primary hurdle is communicating tactile richness through a flat glass screen.

How do you make an audience *feel* the hydrating density of a hyaluronic acid droplet? The answer lies in precision optical engineering and macro lighting science.

---

## The Optical Arsenal: Probes and High-Speed Sensors

Standard prime lenses are incapable of focusing at the ultra-close tolerances required for microscopic product shots. At Hidden Directors, our macro commercial toolkit includes:
- **Laowa 24mm Periprobe Lenses:** Allowing 2:1 macro magnification with an ultra-slim waterproof barrel that can travel submerged through liquids.
- **High-Speed Global Shutter Sensors:** Shooting at 120fps to 480fps in uncompressed RAW to reveal the gentle surface tension of a droplet falling from a glass pipette.
- **Precision Motorized Sliders:** Repeatable sub-millimeter motion control tracks that sweep past bottles with buttery smoothness.

---

## The Three Lighting Secrets for Translucent Bottles

Lighting clear liquid in frosted or amber glass bottles is notoriously difficult because reflections can easily turn into harsh, blown-out hot spots.

### 1. The Cross-Polarized Rim Light
By placing linear polarizing film over our key LED panels and pairing it with an adjustable circular polarizer on the cinema lens, we can cancel out blinding specular surface glare while keeping the vibrant inner liquid illuminated.

### 2. Edge-Lit Internal Refraction
Rather than blasting light directly onto the front of the packaging, we position narrow fiber-optic snoots directly behind and below the glass base. The light refracts upwards through the serum, causing the liquid itself to glow from within like fine gemstone.

### 3. Viscosity Tuning
Real cosmetic products often sink too quickly under hot studio lighting. We calibrate ambient room temperatures and gently adjust fluid viscosity using lab-grade glycerine dilutions to ensure droplets form with picturesque symmetry and suspended buoyancy.

> *"In luxury macro filmmaking, a single bubble can ruin a 6-hour setup. Patience and surgical cleanliness are non-negotiable."*

---

## Summary
When product visuals celebrate microscopic details—the crisp bevel of an embossed pump, the viscous bead of a peptide formulation—buyers perceive immediate quality and scientific superiority.
`
  },
  {
    id: 'post-3',
    slug: 'architectural-storytelling-luxury-interiors-and-spatial-films',
    title: 'Architectural Storytelling: Turning Physical Spaces into Cinematic Walkthroughs',
    excerpt: 'Why wide-angle stills fail modern architecture. Discover how motion-controlled axes, ambient natural light tracking, and tactile textures bring spaces alive.',
    coverImage: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    publishedDate: '2026-01-28',
    category: 'Interiors & Architecture',
    readTime: '7 min read',
    tags: ['Interior Film', 'Architecture', 'Real Estate', 'Spatial Video'],
    author: {
      name: 'Samir Kapoor',
      role: 'Architectural Cinematographer',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    },
    seo: {
      metaTitle: 'Architectural Storytelling: Cinematic Interior Films | Hidden Directors',
      metaDescription: 'Learn how motion-controlled gimbal paths, ambient natural lighting, and tactile material close-ups turn luxury villas and interior projects into immersive films.',
      keywords: ['architectural cinematography', 'interior design video', 'luxury real estate video', 'spatial walkthrough films']
    },
    content: `
# Architecture is Spatial Movement

A photograph is a static two-dimensional slice of a building. But architecture is inherently four-dimensional: it exists in length, width, height, and **time**.

You cannot understand a brutalist concrete staircase or an Italian marble kitchen island until you observe how afternoon sunlight drifts across its fluted ridges or hear the ambient acoustics of the double-height ceiling.

---

## Beyond the Fisheye Lens Trap

For decades, commercial interior videography was dominated by ultra-wide fisheye lenses mounted onto rushed operators running through rooms. The result was distorted wall curvature, unnatural perspectives, and cheap presentation.

At Hidden Directors, we approach architectural films like museum cinema:

### 1. Human-Eye Focal Lengths (35mm to 50mm)
We use natural perspective focal lengths with zero optical distortion. Vertical lines remain perpendicular. Proportion and architectural volume are honored faithfully.

### 2. Slow-Paced Axial Moves
Instead of erratic handheld movements, our cameras glide on motorized three-axis tracks and counterweighted jibs. The motion feels meditative, allowing the viewer's eyes to linger on custom cabinetry, hand-troweled lime plaster, and hidden LED pocket lights.

### 3. Chasing the Golden Hour Gradient
We schedule multi-day shoots around solar angles. A south-facing penthouse requires dawn shooting for cool, crisp morning rays through sheer drapery, followed by a dusk session to capture warm tungsten sconces glowing against twilight skies.

---

## The Power of Material Micro-Stories

A great interior film doesn't merely showcase entire rooms. It tells micro-stories about the materials:
- Push-to-open drawer mechanisms sliding shut with pneumatic silence.
- Hand brushing against raw bouclé upholstery.
- The warm reflection of an architectural pendant lamp bouncing off brushed bronze fixtures.

When luxury prospective clients see these intimate tactile moments, emotional ownership is sparked instantly.
`
  },
  {
    id: 'post-4',
    slug: 'founder-brand-authority-how-leaders-build-organic-reach',
    title: 'The Founder Video Playbook: Building Authority, Trust, and Cult Followings',
    excerpt: 'A step-by-step framework for founders and executives to transition from camera-shy to industry thought leaders using high-contrast visual identity.',
    coverImage: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=80',
    publishedDate: '2026-01-14',
    category: 'Personal Branding',
    readTime: '5 min read',
    tags: ['Personal Branding', 'Executive Presence', 'LinkedIn Video', 'Founder Media'],
    author: {
      name: 'Aryan Saxena',
      role: 'Creative Director',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    },
    seo: {
      metaTitle: 'The Founder Video Playbook: Personal Brand Authority | Hidden Directors',
      metaDescription: 'Discover our executive video production system that transforms founders, partners, and creators into magnetic visual thought leaders.',
      keywords: ['founder personal branding', 'executive video production', 'ceo thought leadership video', 'brand storytelling']
    },
    content: `
# People Don't Buy from Logos; They Buy from Visionaries

In the age of automated algorithms and cookie-cutter corporate websites, trust has become the rarest currency in business.

The founders and CEOs who command premium valuations and attract top-tier talent are those who have stepped out from behind faceless corporate decks to build an unshakeable personal visual brand.

---

## The 3 Pillars of Executive Visual Magnetism

When a founder books our **Executive Visual Retainer**, we systematically dismantle the friction of being on camera.

### Pillar 1: Conversational Directing (No Cold Scripts)
Most founders freeze on camera because they try to memorize written scripts like theatrical actors. 

We never give our clients scripts to memorize. Instead, our senior creative director conducts an informal, high-level interview in a relaxed studio lounge. We ask provocative, industry-specific questions. You speak naturally with genuine conviction; our editing suite extracts the 30-second gems of distilled wisdom.

### Pillar 2: High-Contrast Moody Lighting
Forget sterile corporate fluorescent boardrooms. We place executives in moody, cinematic environments:
- Rich dark backgrounds with warm hair-light separation.
- Soft key illumination that flatters skin tones while maintaining authoritative contrast.
- Shallow depth-of-field that isolates the speaker from ambient distractions.

### Pillar 3: Multi-Platform Asset Extraction
From a single 90-minute studio recording session, we produce:
- **4 Keynote Reel Cutdowns:** Formatted for Instagram & TikTok with kinetic subtitles.
- **2 Deep-Dive Documentaries:** Optimized for LinkedIn video algorithms and YouTube.
- **10 High-Resolution Editorial Portraits:** Suitable for Forbes, TechCrunch, or podcast cover artwork.

---

## The Compound ROI of Founder Visibility
When prospective clients, angel investors, or enterprise partners already recognize your face and respect your perspective before the first Zoom call, the sales cycle collapses from months into days.
`
  },
  {
    id: 'post-5',
    slug: 'the-invisible-50-percent-sound-design-in-commercial-films',
    title: 'The Invisible 50%: Why Sound Design Makes or Breaks Commercial Films',
    excerpt: 'How sub-bass frequency sweeps, tactile foley, and micro-risers trigger visceral emotional reactions before the viewer even notices the edit.',
    coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80',
    publishedDate: '2025-12-22',
    category: 'Audio & Post-Production',
    readTime: '4 min read',
    tags: ['Sound Design', 'Foley', 'Audio Mastering', 'Commercial Ads'],
    author: {
      name: 'Rohan Verma',
      role: 'Audio Director & Sound Designer',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
    },
    seo: {
      metaTitle: 'The Invisible 50%: Sound Design in Commercial Films | Hidden Directors',
      metaDescription: 'Explore how psychoacoustic foley, frequency layering, and sub-bass impacts elevate commercial cinematography into visceral brand experiences.',
      keywords: ['commercial sound design', 'foley audio production', 'cinematic audio mixing', 'brand film audio engineering']
    },
    content: `
# Audio Injects Soul into the Picture

George Lucas famously stated that sound is 50% of the cinematic experience. In modern commercial filmmaking, we would argue it accounts for **65% of emotional conversion**.

You can shoot on an 8K ARRI Alexa LF with vintage anamorphic lenses, but if your audio is hollow, muddy, or relies on generic stock acoustic guitar loops, the viewer instinctively registers the video as cheap.

---

## How We Engineer High-Impact Audio Stems

Every reel produced at Hidden Directors receives a bespoke multi-track spatial audio mix:

### 1. Organic Tactile Foley
When a bottle cap twists open, we don't use synthesized clicks. We record custom foley: the delicate metal friction, the release of atmospheric pressure, the gentle clink of glass on marble. These hyper-real sounds create ASMR-like tingles that glue viewers to the screen.

### 2. Frequency Separation for Mobile Speakers
Over 85% of short-form video is consumed through smartphone micro-speakers. Standard sub-bass frequencies (below 60Hz) are completely inaudible on mobile devices.
- We use harmonic saturation to push bass presence into the 100Hz–250Hz range, ensuring viewers feel the punch even through tiny iPhone speakers.
- We master dialogue within the 1kHz–3.5kHz clarity pocket so voices cut through ambient room noise effortlessly.

### 3. Pacing with Micro-Risers and Sudden Silence
The most powerful tool in sound design isn't volume—it is **silence**. By building tension with rising atmospheric textures and suddenly cutting all audio half a second before a major visual reveal, the subsequent impact hits with tenfold force.

---

## Takeaway for Brand Leaders
Never treat audio as an afterthought in post-production. Sound is the invisible thread that converts a passive spectator into an captivated customer.
`
  }
];


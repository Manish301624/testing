import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'en' | 'es';

interface Translations {
  nav: {
    featuredWork: string;
    verticalReels: string;
    productionPipeline: string;
    clientFeedback: string;
    faq: string;
    bookShoot: string;
    bookShort: string;
    studioPortal: string;
    studioCmsLogin: string;
    language: string;
  };
  hero: {
    badge: string;
    headline1: string;
    headline2: string;
    description: string;
    bookCallBtn: string;
    exploreWorkBtn: string;
    liveMarquee: string;
    gridMode: string;
  };
  stats: {
    totalViews: string;
    projectsDelivered: string;
    retentionRate: string;
    clientSatisfaction: string;
    trustedBy: string;
  };
  offer: {
    badge: string;
    title: string;
    subtitle: string;
    desc: string;
  };
  process: {
    badge: string;
    titleLine1: string;
    titleLine2: string;
    desc: string;
    reserveSlot: string;
    slotsOpen: string;
  };
  reviews: {
    badge: string;
    title: string;
    subtitle: string;
    writeReview: string;
  };
  faq: {
    badge: string;
    title: string;
    subtitle: string;
    ctaTitle: string;
    ctaDesc: string;
    ctaBtn: string;
  };
  footer: {
    connectTitle: string;
    connectDesc: string;
    tagline: string;
    newsletterTitle: string;
    newsletterDesc: string;
    subscribe: string;
    allRights: string;
  };
  modals: {
    close: string;
    bookShoot: string;
    directorCut: string;
    share: string;
  };
}

const TRANSLATIONS: Record<Language, Translations> = {
  en: {
    nav: {
      featuredWork: 'Featured Work',
      verticalReels: 'Vertical Reels',
      productionPipeline: 'Production Pipeline',
      clientFeedback: 'Client Feedback',
      faq: 'FAQ',
      bookShoot: 'BOOK A SHOOT',
      bookShort: 'BOOK',
      studioPortal: 'Studio Portal & CMS',
      studioCmsLogin: 'Studio CMS Login',
      language: 'Language',
    },
    hero: {
      badge: 'CINEMATIC VIDEO PRODUCTION FOR D2C & TECH LEADERS',
      headline1: 'HIGH-RETENTION REELS',
      headline2: 'THAT CONVERT.',
      description: 'We produce cinema-grade short-form commercials, viral vertical reels, and brand films engineered for organic attention and high-ROAS paid media.',
      bookCallBtn: 'BOOK STRATEGY CALL',
      exploreWorkBtn: 'EXPLORE REELS',
      liveMarquee: 'LIVE REEL FEED',
      gridMode: 'GRID VIEW',
    },
    stats: {
      totalViews: 'Organic Views Generated',
      projectsDelivered: 'Commercials Delivered',
      retentionRate: 'Average Watch Time',
      clientSatisfaction: 'Client Satisfaction',
      trustedBy: 'TRUSTED BY INNOVATIVE BRANDS & FOUNDERS WORLDWIDE',
    },
    offer: {
      badge: 'CAPABILITIES & SPECIALIZATIONS',
      title: 'Engineered for Digital Commercial Dominance',
      subtitle: 'From dynamic 9:16 vertical storytelling to cinematic anamorphic commercial spots.',
      desc: 'Every visual is treated with meticulous cinematic lighting, sound design, and viral narrative hooks.',
    },
    process: {
      badge: 'THE PRODUCTION PIPELINE',
      titleLine1: 'From Raw Concept To',
      titleLine2: 'High-Impact Brand Film',
      desc: 'A streamlined 4-step workflow engineered to deliver viral short-form commercials and premium brand films in under 10 business days.',
      reserveSlot: 'Reserve Production Slot',
      slotsOpen: '2 Slots Open for September',
    },
    reviews: {
      badge: 'CLIENT TESTIMONIALS',
      title: 'Trusted by High-Growth Brands Worldwide',
      subtitle: 'Read genuine reviews from founders, marketing directors, and creators we have partnered with.',
      writeReview: 'Share Feedback',
    },
    faq: {
      badge: 'CLEAR PRODUCTION ANSWERS',
      title: 'Frequently Asked Questions',
      subtitle: 'Everything you need to know about our cinematic workflows, turnarounds, camera packages, and commercial usage rights.',
      ctaTitle: 'Have a custom inquiry or special technical requirement?',
      ctaDesc: 'Our executive producers are ready to coordinate tailored multi-city shoots, custom camera packages, or bespoke retainer agreements.',
      ctaBtn: 'Book Direct Producer Call',
    },
    footer: {
      connectTitle: 'Follow Our Creative Production Journey',
      connectDesc: 'Explore daily director breakdowns, cinema-grade color grading tests, and high-impact reel case studies across our official channels.',
      tagline: 'We craft cinematic brand films, high-converting social reels, architectural walkthroughs, and executive personal branding visuals.',
      newsletterTitle: 'DIRECTOR INSIGHTS & VIRAL CASE STUDIES',
      newsletterDesc: 'Get our monthly breakdowns of high-performing reels, cinema color grading LUTs, and conversion secrets.',
      subscribe: 'Subscribe',
      allRights: 'All rights reserved. Cinema-grade production house.',
    },
    modals: {
      close: 'Close',
      bookShoot: 'Book A Similar Shoot',
      directorCut: "Director's Cut",
      share: 'Share',
    },
  },
  es: {
    nav: {
      featuredWork: 'Trabajos Destacados',
      verticalReels: 'Reels Verticales',
      productionPipeline: 'Flujo de Producción',
      clientFeedback: 'Opiniones',
      faq: 'Preguntas',
      bookShoot: 'RESERVAR RODAJE',
      bookShort: 'RESERVAR',
      studioPortal: 'Portal de Estudio y CMS',
      studioCmsLogin: 'Acceso CMS de Estudio',
      language: 'Idioma',
    },
    hero: {
      badge: 'PRODUCCIÓN AUDIOVISUAL CINEMATOGRÁFICA PARA D2C Y TECH',
      headline1: 'REELS DE ALTA RETENCIÓN',
      headline2: 'QUE CONVIERTEN.',
      description: 'Producimos comerciales cinematográficos de formato corto, reels verticales virales y películas de marca diseñadas para captar atención orgánica y maximizar ROAS.',
      bookCallBtn: 'RESERVAR LLAMADA',
      exploreWorkBtn: 'EXPLORAR REELS',
      liveMarquee: 'FEED EN VIVO',
      gridMode: 'VISTA CUADRÍCULA',
    },
    stats: {
      totalViews: 'Vistas Orgánicas Generadas',
      projectsDelivered: 'Comerciales Entregados',
      retentionRate: 'Retención Promedio',
      clientSatisfaction: 'Satisfacción del Cliente',
      trustedBy: 'CONFIADO POR MARCAS INNOVADORAS Y FUNDADORES GLOBALES',
    },
    offer: {
      badge: 'CAPACIDADES Y ESPECIALIZACIONES',
      title: 'Diseñado para el Dominio Comercial Digital',
      subtitle: 'Desde narrativa vertical dinámica 9:16 hasta comerciales anamórficos cinematográficos.',
      desc: 'Cada pieza visual cuenta con iluminación cinematográfica meticulosa, diseño de sonido envolvente y ganchos narrativos virales.',
    },
    process: {
      badge: 'EL PROCESO DE PRODUCCIÓN',
      titleLine1: 'Del Concepto Inicial a',
      titleLine2: 'Film de Marca de Alto Impacto',
      desc: 'Un flujo optimizado de 4 pasos para entregar comerciales virales y películas de marca premium en menos de 10 días hábiles.',
      reserveSlot: 'Reservar Cupo de Producción',
      slotsOpen: '2 Cupos Abiertos para Septiembre',
    },
    reviews: {
      badge: 'TESTIMONIOS DE CLIENTES',
      title: 'Respaldado por Marcas de Alto Crecimiento',
      subtitle: 'Opiniones reales de fundadores, directores de marketing y creadores con quienes colaboramos.',
      writeReview: 'Compartir Opinión',
    },
    faq: {
      badge: 'RESPUESTAS CLARAS DE PRODUCCIÓN',
      title: 'Preguntas Frecuentes',
      subtitle: 'Todo lo que necesitas saber sobre flujos cinematográficos, plazos, paquetes de cámaras y derechos comerciales.',
      ctaTitle: '¿Tienes una consulta personalizada o requerimiento técnico especial?',
      ctaDesc: 'Nuestros productores ejecutivos están listos para coordinar rodajes en múltiples ciudades, paquetes de cámara y acuerdos a medida.',
      ctaBtn: 'Agendar Llamada con Productor',
    },
    footer: {
      connectTitle: 'Sigue Nuestro Proceso de Producción Creativa',
      connectDesc: 'Explora análisis diarios de directores, pruebas de etalonaje cinematográfico y casos de estudio en nuestros canales oficiales.',
      tagline: 'Creamos películas de marca cinematográficas, reels sociales de alta conversión y producciones visuales ejecutivas.',
      newsletterTitle: 'ANÁLISIS DE DIRECTORES Y CASOS VIRALES',
      newsletterDesc: 'Recibe nuestros desgloses mensuales de reels virales, LUTs de color cinematográficos y estrategias de conversión.',
      subscribe: 'Suscribirse',
      allRights: 'Todos los derechos reservados. Productora cinematográfica.',
    },
    modals: {
      close: 'Cerrar',
      bookShoot: 'Reservar Rodaje Similar',
      directorCut: 'Corte del Director',
      share: 'Compartir',
    },
  },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('hd_lang');
        if (saved === 'es' || saved === 'en') return saved;
      } catch {
        // ignore
      }
    }
    return 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('hd_lang', lang);
    } catch {
      // ignore
    }
  };

  const toggleLanguage = () => {
    const nextLang = language === 'en' ? 'es' : 'en';
    setLanguage(nextLang);
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const value: LanguageContextType = {
    language,
    setLanguage,
    toggleLanguage,
    t: TRANSLATIONS[language],
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export interface PersonalBrandingItem {
  id: string;
  clientName: string;
  title: string;
  category: 'Creators' | 'Founders & Entrepreneurs' | 'Fashion & Lifestyle' | 'Coaches & Experts';
  videoUrl: string;
  posterUrl: string;
  description: string;
  impactStat?: string;
  duration: string;
  isFeatured?: boolean;
  views?: string;
  likes?: number;
}

export interface ReelItem {
  id: string;
  title: string;
  category: 'interior' | 'salon' | 'product' | 'fashion' | 'branding' | 'commercial';
  categories?: ('interior' | 'salon' | 'product' | 'fashion' | 'branding' | 'commercial' | string)[];
  client: string;
  videoUrl: string;
  posterUrl: string;
  description: string;
  duration?: string;
  resolution?: string;
  clientType?: string;
  views?: string;
  likes: number;
  tags: string[];
  captions?: string;
}

export interface BlogAuthor {
  name: string;
  role: string;
  avatarUrl?: string;
}

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string; // Markdown format
  coverImage: string;
  publishedDate: string;
  author: BlogAuthor;
  category?: string;
  readTime?: string;
  tags?: string[];
  seo?: {
    metaTitle?: string;
    metaDescription?: string;
    keywords?: string[];
  };
}

export interface ProjectMetric {
  label: string;
  value: string;
  numValue?: number;
  prefix?: string;
  suffix?: string;
  subtext?: string;
}

export interface ProjectClientQuote {
  quote: string;
  author: string;
  role: string;
  company?: string;
  avatarUrl?: string;
  rating?: number;
}

export interface CategoryTaxonomy {
  id: string;
  name: string;
  slug: string;
  description?: string;
  color?: string;
}

export interface NormalizedData<T> {
  byId: Record<string, T>;
  allIds: string[];
  byCategory: Record<string, string[]>;
}

export interface ProjectItem {
  id: string;
  title: string;
  client: string;
  category: 'Interiors' | 'Cafés & Restaurants' | 'Fashion & Lifestyle' | 'Commercial / Ads' | 'Personal Branding';
  categories?: ('Interiors' | 'Cafés & Restaurants' | 'Fashion & Lifestyle' | 'Commercial / Ads' | 'Personal Branding' | string)[];
  thumbnailUrl: string;
  videoUrl?: string;
  description: string;
  deliverables: string[];
  year: string;
  views?: string;
  duration?: string;
  resolution?: string;
  clientType?: string;
  briefText?: string;
  processSteps?: string[];
  resultMetrics?: ProjectMetric[];
  clientQuote?: ProjectClientQuote;
}

export interface BookingSubmission {
  id?: string;
  fullName: string;
  email: string;
  phone: string;
  companyName?: string;
  serviceCategory: string;
  budgetRange: string;
  targetDate: string;
  projectDetails: string;
  instagramHandle?: string;
  createdAt?: string;
  status?: 'pending' | 'confirmed' | 'completed';
}

export interface ContactMessage {
  id?: string;
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
  createdAt?: string;
}

export interface ClientBrand {
  id: string;
  name: string;
  subtitle: string;
  industry: string;
  badge?: string;
  metric?: string;
  accentColor?: string;
  icon?: string;
  featuredCampaign?: string;
  websiteUrl?: string;
}

export interface ReviewItem {
  id: string;
  name: string;
  role: string;
  company: string;
  avatarUrl: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
  videoUrl?: string;
  videoPosterUrl?: string;
  videoDuration?: string;
}

export interface ServiceOffer {
  id: string;
  badge: string;
  title: string;
  headline: string;
  paragraphs: string[];
  features: string[];
  videoUrl: string;
  posterUrl: string;
  stats: { label: string; value: string }[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: { label: string; action: string }[];
}

export interface CallbackRequest {
  id?: string;
  name: string;
  phone: string;
  createdAt?: string;
  status?: 'pending' | 'contacted' | 'completed';
}

export interface WhatsAppInquiry {
  id?: string;
  context?: string;
  sourceSection?: string;
  projectName?: string;
  reelTitle?: string;
  serviceName?: string;
  bookingRef?: string;
  message?: string;
  clientPhone?: string;
  clientName?: string;
  createdAt?: string;
  userAgent?: string;
}

export interface AdminUserSession {
  email: string;
  role: string;
  token: string;
  expiresAt: number; // timestamp in ms
}

export interface AdminLoginResponse {
  success: boolean;
  token?: string;
  user?: {
    email: string;
    role: string;
  };
  expiresIn?: number; // seconds
  expiresAt?: number; // timestamp in ms
  error?: string;
  message?: string;
}

export interface WorkPhotoItem {
  id: string;
  imageUrl: string;
  title: string;
  client: string;
  type: 'residential' | 'commercial' | 'hospitality' | string;
  aspectRatio?: 'tall' | 'wide' | 'square' | string;
  heightClass?: string;
  location?: string;
  description?: string;
  camera?: string;
  year?: string;
}

export interface WorkFilmItem {
  id: string;
  videoUrl: string;
  posterUrl: string;
  title: string;
  client: string;
  duration: string;
  type: 'residential' | 'commercial' | 'hospitality' | string;
  briefText: string;
  servicesProvided: string[];
  aspectRatio?: '16:9' | '9:16' | string;
  resolution?: string;
  director?: string;
  gearUsed?: string[];
  year?: string;
}

export interface WorkCategoryMeta {
  slug: string;
  name: string;
  nameEs: string;
  shortDescEn: string;
  shortDescEs: string;
  photoHeroTitleEn: string;
  photoHeroTitleEs: string;
  filmsHeroTitleEn: string;
  filmsHeroTitleEs: string;
}

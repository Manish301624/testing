import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { 
  INITIAL_REELS, 
  PORTFOLIO_PROJECTS, 
  SERVICE_OFFERS,
  BLOG_POSTS,
  filterItemsByCategories
} from './src/data/mockData';
import { PERSONAL_BRANDING_ITEMS } from './src/data/personalBrandingData';
import { 
  getPhotographyByCategory, 
  getFilmsByCategory, 
  getCategoryMeta 
} from './src/data/workData';
import { BookingSubmission, ContactMessage, ReviewItem, CallbackRequest, WhatsAppInquiry } from './src/types';
import { db } from './src/db/database';
import { 
  sendBookingClientConfirmation, 
  sendBookingStudioNotification, 
  sendContactEmails, 
  sendCallbackStudioNotification 
} from './src/server/emailService';

const app = express();
const PORT = 3000;

app.use(express.json());

// ================= ADMIN AUTHENTICATION & SECURITY CONFIGURATION ================= //
/**
 * Configuration for Admin Authentication
 * - ADMIN_EMAIL: Authorized administrator email (default: director@hiddendirectors.com)
 * - ADMIN_PASSWORD_HASH: Bcrypt hash of the administrator password (default: hash of 'director123')
 * - JWT_SECRET: Secret key used to sign and verify JSON Web Tokens
 * - JWT_EXPIRY: 15-minute token lifespan enforcing strict session security
 */
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'director@hiddendirectors.com').trim().toLowerCase();
const JWT_SECRET = process.env.JWT_SECRET || 'hidden_directors_jwt_production_secret_2026_prod';
const JWT_EXPIRY = '15m';
const JWT_EXPIRY_SECONDS = 15 * 60; // 900 seconds (15 minutes)

// Compute or read bcrypt password hash
const getAdminPasswordHash = (): string => {
  if (process.env.ADMIN_PASSWORD_HASH && process.env.ADMIN_PASSWORD_HASH.startsWith('$2')) {
    return process.env.ADMIN_PASSWORD_HASH;
  }
  // Default fallback password 'director123' if env variable is not set
  const rawPass = process.env.ADMIN_PASSWORD || 'director123';
  return bcrypt.hashSync(rawPass, 10);
};

const cachedAdminPasswordHash = getAdminPasswordHash();

/**
 * Middleware: authenticateAdmin
 * 1. Checks for Authorization header with Bearer token format
 * 2. Verifies token validity and expiration using jsonwebtoken
 * 3. Injects authenticated admin user info into req.adminUser
 * 4. Rejects invalid or expired requests with 401 Unauthorized status
 */
export const authenticateAdmin = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ')
    ? authHeader.slice(7)
    : (req.headers['x-admin-token'] as string);

  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'Authentication required. No admin session token provided.',
      code: 'UNAUTHORIZED'
    });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { email: string; role: string; iat: number; exp: number };
    (req as any).adminUser = decoded;
    next();
  } catch (err: any) {
    const isExpired = err?.name === 'TokenExpiredError';
    return res.status(401).json({
      success: false,
      error: isExpired ? 'Admin session has expired (15-minute timeout). Please log in again.' : 'Invalid admin session token.',
      code: isExpired ? 'SESSION_EXPIRED' : 'INVALID_TOKEN'
    });
  }
};

// ================= ADMIN AUTHENTICATION ENDPOINTS ================= //

/**
 * POST /api/admin/login
 * Validates credentials with bcrypt and returns a signed 15-minute JWT
 */
app.post('/api/admin/login', async (req: Request, res: Response) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      error: 'Please enter both admin email and password.'
    });
  }

  const normalizedInputEmail = String(email).trim().toLowerCase();
  const configuredEmail = (process.env.ADMIN_EMAIL || ADMIN_EMAIL).trim().toLowerCase();

  // Validate Admin Email
  if (normalizedInputEmail !== configuredEmail) {
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials. Access restricted to authorized production directors.'
    });
  }

  // Validate Admin Password using bcrypt comparison
  const targetHash = process.env.ADMIN_PASSWORD_HASH || cachedAdminPasswordHash;
  const isMatch = await bcrypt.compare(String(password), targetHash);

  if (!isMatch) {
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials. Access restricted to authorized production directors.'
    });
  }

  // Issue JWT Token with 15-minute lifespan
  const token = jwt.sign(
    { email: configuredEmail, role: 'admin' },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRY }
  );

  const expiresAt = Date.now() + JWT_EXPIRY_SECONDS * 1000;

  return res.json({
    success: true,
    message: 'Admin authentication successful. Welcome back to Leads Desk.',
    token,
    user: {
      email: configuredEmail,
      role: 'admin'
    },
    expiresIn: JWT_EXPIRY_SECONDS,
    expiresAt
  });
});

/**
 * GET /api/admin/verify
 * Protected endpoint to verify current session token validity
 */
app.get('/api/admin/verify', authenticateAdmin, (req: Request, res: Response) => {
  const user = (req as any).adminUser;
  res.json({
    success: true,
    valid: true,
    user,
    expiresAt: user.exp ? user.exp * 1000 : Date.now() + JWT_EXPIRY_SECONDS * 1000
  });
});

/**
 * POST /api/admin/refresh
 * Protected endpoint to extend/refresh active session for another 15 minutes
 */
app.post('/api/admin/refresh', authenticateAdmin, (req: Request, res: Response) => {
  const user = (req as any).adminUser;
  const configuredEmail = user.email || ADMIN_EMAIL;

  const token = jwt.sign(
    { email: configuredEmail, role: 'admin' },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRY }
  );

  const expiresAt = Date.now() + JWT_EXPIRY_SECONDS * 1000;

  res.json({
    success: true,
    message: 'Session successfully extended for another 15 minutes.',
    token,
    user: { email: configuredEmail, role: 'admin' },
    expiresIn: JWT_EXPIRY_SECONDS,
    expiresAt
  });
});

// ================= API ROUTES ================= //

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Hidden Directors Productions API',
    database: {
      status: db.isReady() ? 'connected' : 'initializing',
      ...db.getStats()
    }
  });
});

// Get agency live metrics
app.get('/api/stats', (req: Request, res: Response) => {
  res.json({
    completedProjects: '500+',
    totalRatings: '4.5K',
    activeUsers: '1.5K',
    clientRating: 4.9,
    retentionRate: '98%',
    totalViewsGenerated: '50M+'
  });
});

// Get video reels (supports dynamic single & multi-category filtering)
app.get('/api/reels', (req: Request, res: Response) => {
  const category = (req.query.category || req.query.categories) as string | string[] | undefined;
  if (category && category !== 'all') {
    const filtered = filterItemsByCategories(INITIAL_REELS, category);
    return res.json(filtered);
  }
  res.json(INITIAL_REELS);
});

// Get personal branding showcase items
app.get('/api/personal-branding', (req: Request, res: Response) => {
  const category = req.query.category as string | undefined;
  if (category && category !== 'All' && category !== 'all') {
    const filtered = PERSONAL_BRANDING_ITEMS.filter(item => item.category.toLowerCase() === category.toLowerCase());
    return res.json(filtered);
  }
  res.json(PERSONAL_BRANDING_ITEMS);
});

// Get portfolio projects (supports dynamic single & multi-category filtering)
app.get('/api/projects', (req: Request, res: Response) => {
  const category = (req.query.category || req.query.categories) as string | string[] | undefined;
  if (category && category !== 'all') {
    const filtered = filterItemsByCategories(PORTFOLIO_PROJECTS, category);
    return res.json(filtered);
  }
  res.json(PORTFOLIO_PROJECTS);
});

// Get specific project
app.get('/api/projects/:id', (req: Request, res: Response) => {
  const project = PORTFOLIO_PROJECTS.find(p => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }
  res.json(project);
});

// Get services
app.get('/api/services', (req: Request, res: Response) => {
  res.json(SERVICE_OFFERS);
});

// ================= DEDICATED WORK DISCIPLINES (PHOTOGRAPHY & FILMS) ================= //
/**
 * GET /api/work/:category/photography
 * Returns high-resolution editorial photography portfolio for the requested category
 */
app.get('/api/work/:category/photography', (req: Request, res: Response) => {
  const { category } = req.params;
  const filterType = req.query.type as string | undefined;
  
  const photos = getPhotographyByCategory(category);
  const meta = getCategoryMeta(category);

  if (filterType && filterType.toLowerCase() !== 'all') {
    const filtered = photos.filter(p => p.type.toLowerCase() === filterType.toLowerCase());
    return res.json({
      category: meta,
      items: filtered,
      totalCount: photos.length,
      filteredCount: filtered.length
    });
  }

  res.json({
    category: meta,
    items: photos,
    totalCount: photos.length,
    filteredCount: photos.length
  });
});

/**
 * GET /api/work/:category/films
 * Returns cinematic video project showcase for the requested category
 */
app.get('/api/work/:category/films', (req: Request, res: Response) => {
  const { category } = req.params;
  const filterType = req.query.type as string | undefined;

  const films = getFilmsByCategory(category);
  const meta = getCategoryMeta(category);

  if (filterType && filterType.toLowerCase() !== 'all') {
    const filtered = films.filter(f => f.type.toLowerCase() === filterType.toLowerCase());
    return res.json({
      category: meta,
      items: filtered,
      totalCount: films.length,
      filteredCount: filtered.length
    });
  }

  res.json({
    category: meta,
    items: films,
    totalCount: films.length,
    filteredCount: films.length
  });
});

/**
 * GET /api/work/:category/meta
 * Returns category SEO and heading metadata
 */
app.get('/api/work/:category/meta', (req: Request, res: Response) => {
  const { category } = req.params;
  const meta = getCategoryMeta(category);
  res.json(meta);
});

// ================= BLOG & INSIGHTS (SEO) ENDPOINTS ================= //
/**
 * GET /api/blog
 * Returns full list of blog articles for SEO indexing and grid display
 * Optional query parameter: ?category=<category_name>
 */
app.get('/api/blog', (req: Request, res: Response) => {
  const category = req.query.category as string | undefined;
  if (category && category.toLowerCase() !== 'all') {
    const filtered = BLOG_POSTS.filter(
      p => p.category?.toLowerCase() === category.toLowerCase()
    );
    return res.json(filtered);
  }
  res.json(BLOG_POSTS);
});

/**
 * GET /api/blog/:slug
 * Returns specific article by unique SEO-optimized URL slug
 */
app.get('/api/blog/:slug', (req: Request, res: Response) => {
  const { slug } = req.params;
  const post = BLOG_POSTS.find(p => p.slug === slug);
  if (!post) {
    return res.status(404).json({
      error: 'Blog article not found',
      requestedSlug: slug,
      code: 'POST_NOT_FOUND'
    });
  }
  res.json(post);
});

/**
 * =========================================================================
 * SITEMAP.XML GENERATION NOTE & SCRIPT (SEO ARCHITECTURE):
 * =========================================================================
 * In a Vite + React Single-Page Application (SPA) without native server-side
 * rendering (SSR), search crawlers (Googlebot, Bingbot, DuckDuckBot) rely
 * heavily on XML sitemaps to discover dynamic deep URLs like /blog/:slug.
 *
 * HOW TO GENERATE AS A BUILD SCRIPT:
 * 1. You can run a node/tsx build script before deploy (e.g., `npm run build:sitemap`)
 *    which reads all slugs from `mockData.ts` or database and writes `dist/sitemap.xml`.
 * 2. Alternatively, this live endpoint serves an up-to-date XML document on demand
 *    with proper <urlset>, <loc>, <lastmod>, <changefreq>, and <priority> tags.
 * =========================================================================
 */
app.get('/sitemap.xml', (req: Request, res: Response) => {
  const baseUrl = `${req.protocol}://${req.get('host') || 'hiddendirectors.com'}`;
  
  interface SitemapEntry {
    url: string;
    changefreq: string;
    priority: string;
    lastmod?: string;
  }

  const staticRoutes: SitemapEntry[] = [
    { url: '/', changefreq: 'weekly', priority: '1.0' },
    { url: '/about', changefreq: 'monthly', priority: '0.8' },
    { url: '/work/interior-architecture/photography', changefreq: 'weekly', priority: '0.9' },
    { url: '/work/interior-architecture/films', changefreq: 'weekly', priority: '0.9' },
    { url: '/work/hospitality-food/photography', changefreq: 'weekly', priority: '0.9' },
    { url: '/work/hospitality-food/films', changefreq: 'weekly', priority: '0.9' },
    { url: '/work/ecommerce-product/photography', changefreq: 'weekly', priority: '0.9' },
    { url: '/work/ecommerce-product/films', changefreq: 'weekly', priority: '0.9' },
  ];

  const blogRoutes: SitemapEntry[] = BLOG_POSTS.map(post => ({
    url: `/blog/${post.slug}`,
    changefreq: 'weekly',
    priority: '0.8',
    lastmod: post.publishedDate
  }));

  const allUrls: SitemapEntry[] = [...staticRoutes, ...blogRoutes];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allUrls.map(item => `  <url>
    <loc>${baseUrl}${item.url}</loc>
    ${item.lastmod ? `<lastmod>${item.lastmod}</lastmod>` : ''}
    <changefreq>${item.changefreq}</changefreq>
    <priority>${item.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

  res.header('Content-Type', 'application/xml; charset=utf-8');
  res.send(xml);
});

// ================= PERSISTENT REVIEWS ENDPOINTS ================= //
app.get('/api/reviews', (req: Request, res: Response) => {
  const reviews = db.getReviews();
  res.json(reviews);
});

app.post('/api/reviews', (req: Request, res: Response) => {
  const { name, role, company, rating, comment, videoUrl, videoPosterUrl, videoDuration } = req.body;
  if (!name || !comment || !rating) {
    return res.status(400).json({ error: 'Name, rating and comment are required fields.' });
  }

  const newReview: ReviewItem = {
    id: `rev-${Date.now()}`,
    name,
    role: role || 'Client',
    company: company || 'Independent Brand',
    avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80`,
    rating: Number(rating) || 5,
    comment,
    date: 'Just now',
    verified: true,
    ...(videoUrl ? { videoUrl, videoPosterUrl: videoPosterUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80', videoDuration: videoDuration || '0:30' } : {})
  };

  const saved = db.insertReview(newReview);
  res.status(201).json({ success: true, review: saved });
});

// ================= PERSISTENT BOOKINGS ENDPOINTS ================= //
// Note: GET & PATCH require authenticateAdmin JWT token to protect customer details & private consultation leads
app.get('/api/bookings', authenticateAdmin, (req: Request, res: Response) => {
  const bookings = db.getBookings();
  res.json(bookings);
});

app.get('/api/bookings/:id', authenticateAdmin, (req: Request, res: Response) => {
  const booking = db.getBookingById(req.params.id);
  if (!booking) {
    return res.status(404).json({ error: 'Booking not found' });
  }
  res.json(booking);
});

app.post('/api/bookings', (req: Request, res: Response) => {
  const { 
    fullName, 
    email, 
    phone, 
    companyName, 
    serviceCategory, 
    budgetRange, 
    targetDate, 
    projectDetails, 
    instagramHandle 
  } = req.body;

  // Validation
  if (!fullName || !email || !phone || !serviceCategory) {
    return res.status(400).json({ 
      error: 'Missing required booking information (Full Name, Email, Phone, and Service Category are mandatory).' 
    });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please provide a valid email address.' });
  }

  const newBooking: BookingSubmission = {
    id: `HD-BK-${Math.floor(1000 + Math.random() * 9000)}`,
    fullName,
    email,
    phone,
    companyName: companyName || 'Confidential',
    serviceCategory,
    budgetRange: budgetRange || '$1,500 - $3,000',
    targetDate: targetDate || 'Within next 2 weeks',
    projectDetails: projectDetails || 'Initial shoot inquiry discussion.',
    instagramHandle: instagramHandle || '',
    createdAt: new Date().toISOString(),
    status: 'pending'
  };

  const saved = db.insertBooking(newBooking);

  // Trigger Asynchronous Email Notifications (Client Confirmation & Studio Alert)
  // Non-blocking to guarantee instant user response while emails deliver
  Promise.all([
    sendBookingClientConfirmation(saved),
    sendBookingStudioNotification(saved)
  ]).catch(err => {
    console.error('[Notifications] Failed to deliver booking emails:', err);
  });

  res.status(201).json({
    success: true,
    message: 'Your production consultation call has been booked successfully! Our director will review your vision and reach out within 4 business hours.',
    booking: saved
  });
});

app.patch('/api/bookings/:id', authenticateAdmin, (req: Request, res: Response) => {
  const { status } = req.body;
  const updated = db.updateBooking(req.params.id, { status });
  if (!updated) {
    return res.status(404).json({ error: 'Booking not found' });
  }
  res.json({ success: true, booking: updated });
});

// ================= PERSISTENT CONTACT MESSAGES ENDPOINTS ================= //
// Note: GET requires authenticateAdmin JWT token to protect confidential user messages
app.get('/api/contact', authenticateAdmin, (req: Request, res: Response) => {
  const messages = db.getContactMessages();
  res.json(messages);
});

app.post('/api/contact', (req: Request, res: Response) => {
  const { name, email, phone, subject, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required.' });
  }

  const newMessage: ContactMessage = {
    id: `MSG-${Math.floor(100 + Math.random() * 900)}`,
    name,
    email,
    phone: phone || '',
    subject: subject || 'General Inquiry',
    message,
    createdAt: new Date().toISOString()
  };

  const saved = db.insertContactMessage(newMessage);

  // Trigger Asynchronous Email Notifications (Studio Lead Alert & Client Receipt)
  sendContactEmails(saved).catch(err => {
    console.error('[Notifications] Failed to deliver contact message emails:', err);
  });

  res.status(201).json({
    success: true,
    message: 'Thank you! Your message was received by our production team.',
    data: saved
  });
});

// Config endpoint for WhatsApp number (configurable via WHATSAPP_NUMBER env variable)
app.get('/api/whatsapp-config', (req: Request, res: Response) => {
  const rawNumber = process.env.WHATSAPP_NUMBER || '+919876543210';
  const cleanNumber = rawNumber.replace(/[^0-9]/g, '');
  res.json({
    whatsappNumber: rawNumber,
    cleanNumber
  });
});

// ================= PERSISTENT WHATSAPP INQUIRIES LOGGING ================= //
// Note: GET requires authenticateAdmin JWT token to protect client numbers & referral telemetry
app.get('/api/whatsapp-inquiry', authenticateAdmin, (req: Request, res: Response) => {
  const inquiries = db.getWhatsAppInquiries();
  res.json(inquiries);
});

app.post('/api/whatsapp-inquiry', (req: Request, res: Response) => {
  const { 
    context, 
    sourceSection, 
    projectName, 
    reelTitle, 
    serviceName, 
    bookingRef, 
    message, 
    clientPhone, 
    clientName,
    metadata 
  } = req.body || {};

  const userAgent = (req.headers['user-agent'] as string) || req.body?.userAgent || 'Unknown Device/Browser';

  const newInquiry: WhatsAppInquiry = {
    id: `HD-WA-${Math.floor(1000 + Math.random() * 9000)}`,
    context: context || metadata?.context || 'general',
    sourceSection: sourceSection || metadata?.sourceSection || 'Website Direct',
    projectName: projectName || metadata?.projectName || undefined,
    reelTitle: reelTitle || metadata?.reelTitle || undefined,
    serviceName: serviceName || metadata?.serviceName || undefined,
    bookingRef: bookingRef || metadata?.bookingRef || undefined,
    message: message || undefined,
    clientPhone: clientPhone || undefined,
    clientName: clientName || undefined,
    createdAt: new Date().toISOString(),
    userAgent
  };

  const saved = db.insertWhatsAppInquiry(newInquiry);

  res.status(201).json({
    success: true,
    message: 'WhatsApp inquiry click logged successfully.',
    inquiry: saved
  });
});

// ================= PERSISTENT INSTANT CALLBACK ENDPOINTS ================= //
// Note: GET & PATCH require authenticateAdmin JWT token to protect callback phone numbers
app.get('/api/callback-request', authenticateAdmin, (req: Request, res: Response) => {
  const callbacks = db.getCallbackRequests();
  res.json(callbacks);
});

app.post('/api/callback-request', (req: Request, res: Response) => {
  const { name, phone } = req.body;

  // Validation
  if (!name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'Please enter your name.' });
  }

  if (!phone || typeof phone !== 'string' || !phone.trim()) {
    return res.status(400).json({ error: 'Please provide a valid phone number for the instant callback.' });
  }

  const trimmedName = name.trim();
  const trimmedPhone = phone.trim();

  // Validate phone has sufficient digits
  const digitsOnly = trimmedPhone.replace(/[^0-9]/g, '');
  if (digitsOnly.length < 7) {
    return res.status(400).json({ error: 'Please enter a valid phone number (at least 7 digits).' });
  }

  const newCallback: CallbackRequest = {
    id: `HD-CB-${Math.floor(1000 + Math.random() * 9000)}`,
    name: trimmedName,
    phone: trimmedPhone,
    createdAt: new Date().toISOString(),
    status: 'pending'
  };

  const saved = db.insertCallbackRequest(newCallback);

  // Trigger Asynchronous Email Notification to Studio Team (Urgent 15-min callback alert)
  sendCallbackStudioNotification(saved).catch(err => {
    console.error('[Notifications] Failed to deliver urgent callback email:', err);
  });

  res.status(201).json({
    success: true,
    message: 'Instant callback requested! A creative director from Hidden Directors will reach out within 15 minutes.',
    callback: saved
  });
});

app.patch('/api/callback-request/:id', authenticateAdmin, (req: Request, res: Response) => {
  const { status } = req.body;
  if (!status || !['pending', 'completed', 'contacted'].includes(status)) {
    return res.status(400).json({ error: 'Valid status is required (pending, completed, or contacted).' });
  }
  const updated = db.updateCallbackStatus(req.params.id, status);
  if (!updated) {
    return res.status(404).json({ error: 'Callback request not found' });
  }
  res.json({ success: true, callback: updated });
});

// Interactive AI / Production Assistant Chat endpoint
app.post('/api/chat', (req: Request, res: Response) => {
  const { message } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'Message content is required.' });
  }

  const lower = message.toLowerCase();
  let reply = '';
  let suggestedActions: { label: string; action: string }[] = [];

  if (lower.includes('price') || lower.includes('cost') || lower.includes('package') || lower.includes('quote') || lower.includes('budget')) {
    reply = "Our production packages start at $1,200 for a curated 5-Reel Personal Branding Batch, and scale to full commercial campaigns ($3,500 - $12,000+) featuring cinema rigs (RED/Sony FX3), lighting choreography, and sound design. Would you like to book a quick 15-minute concept call with our creative director?";
    suggestedActions = [
      { label: 'Book a Consultation Call', action: 'open_booking' },
      { label: 'View Portfolio Work', action: 'view_work' },
      { label: 'Personal Branding Details', action: 'view_branding' }
    ];
  } else if (lower.includes('location') || lower.includes('where') || lower.includes('city') || lower.includes('delhi') || lower.includes('studio')) {
    reply = "We operate our primary daylight & dark-room studios in Delhi NCR and Mumbai, and frequently travel nationwide for on-location architectural, restaurant, and brand campaigns. Where is your project located?";
    suggestedActions = [
      { label: 'Schedule Studio Tour', action: 'open_booking' },
      { label: 'Contact Production Team', action: 'open_contact' }
    ];
  } else if (lower.includes('turnaround') || lower.includes('timeline') || lower.includes('how long') || lower.includes('days')) {
    reply = "Our standard turnaround time is 48 to 72 hours for social reels and 5-7 business days for high-end master commercials with full color grading (DaVinci Resolve) and custom audio mix.";
    suggestedActions = [
      { label: 'Check Availability', action: 'open_booking' }
    ];
  } else if (lower.includes('gear') || lower.includes('camera') || lower.includes('equipment') || lower.includes('lens')) {
    reply = "We shoot on cinema-grade setups including Sony FX6/FX3, RED Digital Cinema, anamorphic lenses, Godox & Aputure studio softboxes, motorized motion sliders, and wireless Sennheiser / Rode audio.";
    suggestedActions = [
      { label: 'See Sample Reels', action: 'view_reels' },
      { label: 'Book A Call', action: 'open_booking' }
    ];
  } else {
    reply = "Welcome to Hidden Directors Productions! We specialize in visuals that define your brand, story, and product — from viral personal branding reels to high-end interior and commercial films. How can we help bring your visual vision to life?";
    suggestedActions = [
      { label: 'Book A Call', action: 'open_booking' },
      { label: 'Explore Our Work', action: 'view_work' },
      { label: 'View Pricing & Packages', action: 'view_pricing' }
    ];
  }

  res.json({
    id: `msg-${Date.now()}`,
    sender: 'assistant',
    text: reply,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    suggestedActions
  });
});

// ================= VITE MIDDLEWARE & STATIC SERVING ================= //

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hidden Directors Production server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
